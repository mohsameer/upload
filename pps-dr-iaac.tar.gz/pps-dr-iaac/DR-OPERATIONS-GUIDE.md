# PPS DR Site — Operations Guide

Build, check, hand over and tear down the PPS (iCrypto SSO) DR site. Everything
runs on the **DR bastion**, as copy-paste commands. Details and history:
`DR-RUNBOOK.md`.

DR site: GKE `dr-icrypto-gke-cluster`, project `pps-qa-29102018`, `europe-west4`.
Build ≈ 30–35 min. Destroy ≈ 11 min. Bastion clock is **UTC**.

## 0. Every session — start here

```bash
cd /home/kusha/pps-dr-iaac
set -a; . ~/pps-dr-secrets/tfvars.env; set +a      # secrets for this shell only
kubectl config current-context                      # MUST be the DR cluster, never QA/PROD
```

Rules: never commit or paste `pps-dr.tfvars` / `~/pps-dr-secrets/`. One run at a
time (`ps -eo pid,args | grep -E "dr_build|dr_rebuild|dr_destroy|tofu"` must be empty).
Do not change the bastion's active gcloud account.

## 1. Build

Pre-check (read-only; fix every BLOCKER):

```bash
./prevalidate.sh --tfvars pps-dr.tfvars
```

Build (state empty):

```bash
setsid nohup scripts/dr_build.sh > /home/kusha/dr-build/build.out 2>&1 &
```

Destroy + build in one run (rehearsal; **destroys first, no prompt**):

```bash
setsid nohup scripts/dr_rebuild.sh > /home/kusha/dr-build/rebuild.out 2>&1 &
```

Watch (safe to Ctrl-C and re-run; read-only):

```bash
scripts/dr_watch.sh
```

Done = **FINISHED OK**, or:

```bash
tail -3 $(ls -t /home/kusha/dr-build/build-*.log | head -1)     # want: FINISHED rc=0
```

Stages: 0 Preflight · 1 GKE cluster · 1b Registry creds · 2 Platform · 3 Data restore ·
4 Argo CD · 5 Secrets · 5b App config · 6 App sync · 7 Ingress/DNS request ·
**8 Healthcheck validation** · 9 Sign-off (off until DNS, section 3).

Reading the screen: the **%** counts resources, not minutes — it can sit still
for minutes on the cluster, the database restore or the load balancer; the
*In progress* list shows what it waits on. `unchanged` = nothing to do this run.
**⚠ LIKELY FAILED** = a step silent for 150 s; the real error prints later. A
failed step is retried automatically on the next round (`dr_rebuild.sh` runs up
to 4).

## 2. Verify

```bash
kubectl -n argocd get applications.argoproj.io \
  -o custom-columns='NAME:.metadata.name,SYNC:.status.sync.status,HEALTH:.status.health.status'
kubectl get pods -A | grep -vE 'Running|Completed'      # want: nothing
scripts/dr_healthcheck.sh                                # every deployed service must pass
```

Want: all applications **Synced + Healthy** (17), no stray pods (~80 total).
`skipped` in the healthcheck = not deployed on DR (not a failure). Report:
`.dr-run/healthcheck-report.json`.

## 3. Hand over to PPS

PPS creates DNS by hand. The records to create (the address **changes on every
rebuild** — always send a fresh list):

```bash
jq -r '.records[] | "\(.hostname)\t\(.address)"' modules/70-ingress-dns/.dr-run/dns-change-request.json
```

After PPS applies DNS, confirm every name resolves, then run sign-off (stage 9):

```bash
HOSTS=$(jq -r '.records[].hostname' modules/70-ingress-dns/.dr-run/dns-change-request.json | tr '\n' ' ')
./modules/70-ingress-dns/dns_resolution_check.sh "$HOSTS"          # must exit 0
tofu apply -target=module.validation -var-file=pps-dr.tfvars       # writes sign-off-report.json
```

Keep `sign-off-report.json` as the exercise evidence.

## 4. Destroy (irreversible)

Deletes the cluster and everything restored in it. Before that it **empties every
database on the DR Cloud SQL instance** (except `postgres` and system DBs) so the
next build restores clean.

```bash
DRY_RUN=1 scripts/dr_empty_postgres.sh                 # optional: list what would be emptied
CONFIRM_DESTROY_DR=yes scripts/dr_destroy.sh           # shows the same progress screen
```

Verify:

```bash
tail -3 $(ls -t /home/kusha/dr-build/destroy-*.log | head -1)     # want: FINISHED rc=0
tofu state list | wc -l                                           # want: 0
gcloud container clusters list                                    # DR cluster gone
```

Failed part-way? Run the same command again.

## 5. Refresh the restore set (on the PRODUCTION bastion)

DR is only as current as its restore set: `gs://pps-k8s-prod-backups/pps-dr-iac-restore/`
(each run overwrites the last; bucket versioning keeps history). Copy
`scripts/collect_dr_restore_set.sh` to the production bastion, then:

```bash
PG_MODE=pod PG_UPLOAD_MODE=tar PG_EXCLUDE_TABLE_DATA=m_audit PG_POD_DISK=50Gi \
  bash collect_dr_restore_set.sh
```

PostgreSQL only (≈ 7 min): add `STAGES=postgresql` in front. Object names are
fixed — the DR config never needs editing; the next build picks up the new backup.
Do this on a schedule, and **before every rehearsal**.

## 5a. What the build corrects after the restore

The production restore is wrong for DR in a few places, and the build fixes them on
every run, so there is nothing to do by hand:

- **IdM resources:** the IdM Directory Capella account (production's → the DR account),
  the `trueLDAP` and `PRO-FiT-DB` host (`trueldap.pps.co.za`) and the MFA address
  (in-cluster `mfa-facade-service`, also for `cred-mgmt-service`'s password/username reset flows). Settings: `vault_kv_overrides`,
  `vault_kv_couchbase_overrides`.
- **LDAP:** the application service accounts under `ou=services` join `adminWrite`
  (`ldap_group_additions`), which is **wider than production** (read-only there); the LDAP
  certificate is production's; the LDAP load balancer listens on 1389 / 1636.
- **LDAP access rules** are enforced after the restore (`ldap_access_rules`, production's
  rules), so an old restore set no longer causes LDAP error 32 for service accounts. The
  LDAP certificate is collected once with `STAGES=ldaptls`.

## 6. Troubleshooting

Start with *Recorded failures* on the watch screen and the end of the log.

| Symptom | Cause | Action |
|---|---|---|
| Stops at stage 0, `BLOCKER` | Prerequisite/config problem | Read the `BLOCKERS` block, fix, rebuild |
| `chart-version:eso … does not resolve` | `eso_chart_version` is not a tag in the PPS registry | Set it to an existing tag (e.g. `1.0.5-pps`) |
| Cluster `ERROR`, `GCE_STOCKOUT` | Google has no capacity in the zone | Wait and retry; ask platform team about more zones. Delete the broken cluster first |
| Node creation refused, "labels" | Project policy needs labels on VMs | Check `dr_gke_node_resource_labels` (`environment`, `agile_team`, `tiering`) |
| Destroy: `Attempt to index null value` | Cluster stuck in `ERROR`, nothing inside | `gcloud container clusters delete`, then clear leftover state with the platform team |
| `Error acquiring the state lock` | Killed run left a lock | Scripts clear it; if you ran `tofu` by hand delete `gs://dr-icrypto-gke-iac/terraform/state-v2/default.tflock` |
| Stage 3 `LIKELY FAILED` on `postgres_psql_restore` | Database restore failed | `kubectl -n persistent get pods`; reason in `/tmp/dr-phase-failures.log`; retried automatically next round |
| midPoint: `no partition of relation "m_audit_event"` | Audit partitions missing | Build creates them after restore (`postgres_future_partitions`); on an old site ask platform team to re-run it |
| App `Degraded` | Index building / dependency starting | Wait a few min, `scripts/dr_healthcheck.sh`; else `kubectl -n <ns> describe pod <pod>` |
| Healthcheck fails for one service | Deployed but not answering | Run `scripts/dr_healthcheck.sh` for URL + response; check pod logs; do not skip without agreement |
| `probe could not run curl` | Probe image has no curl | Set `healthchecks_probe_image` to an image with curl |
| `curl` to a DR hostname from the bastion returns nothing | Bastion has no public egress to the load balancer | Expected; use `scripts/dr_healthcheck.sh`, or test from a PPS network after DNS |
| IdM resource Test connection fails on `trueldap-az1`, `mfa.pps.co.za` or Capella | The restored Vault value still names production | Applied automatically at build (section 5a); on a live site set `vault_overrides_restart_workloads` and apply |
| nginx-api-gw logs `unexpected A record in DNS response` | In-cluster DNS redirect (`dr-dns-redirect`) answered AAAA with an A record | Fixed in the build: address targets answer A only, AAAA gets an empty reply. On an old site re-run Phase 2 (`dns_redirect.sh`) |
| Names do not resolve after DNS change | Not applied, or an old address list | Re-send the current list (section 3); allow for DNS caching |

Cannot resolve it? **Stop.** Send the platform team the log file name, the failing
stage and the *Recorded failures* block. Never start a second run over a failing one.

## 7. Settings you may touch (`pps-dr.tfvars`; re-run the pre-check after)

| Setting | Default | Meaning |
|---|---|---|
| `healthchecks_enabled` | `true` | Run stage 8 in the build |
| `healthchecks_skip_workloads` | `[]` | Leave services out, as `namespace/name` |
| `healthchecks_fail_on_error` | `true` | `false` = report failures without failing the build |
| `healthchecks_timeout_seconds` | `180` | Retry time per check |
| `postgres_cleanup_before_restore` | `true` | Empty each DB just before its restore |
| `postgres_future_partitions` | `10` | Audit partitions created after restore (`0` = off) |
| `validation_enabled` | `false` | Stage 9; only after the DNS change |

Script options (prefix the command): `MAX_WAVES=4` (`dr_rebuild.sh` rounds) ·
`HEALTH_WAIT=900` · `EMPTY_POSTGRES=no` (skip emptying Cloud SQL on destroy) ·
`SKIP_WORKLOADS="name"` / `TIMEOUT_SECONDS=60` (`dr_healthcheck.sh`) ·
`STALE=150` (`dr_watch.sh`).

## 8. Good to know

- **Not managed here (survive a destroy):** Cloud SQL `dr-idm-user-data` (emptied on
  destroy, refilled on build), Capella DR cluster, the backup bucket, the `pps-dr`
  VPC, production. DNS is changed by PPS only.
- **Audit history is not restored** (midPoint `m_audit_*` come back empty by design —
  97% of that database); DR audits normally from first start.
- **Fixed addresses (PPS DNS stays valid across rebuilds):** idmv2/admin/truetrace
  `10.200.16.101`, truepolicy `10.200.16.102`, trueldap `10.200.16.44` (reserved by the
  build as `ldap-dr-int`), oidc/sidas `136.69.85.179`. The external one stays only while
  `external_ingress_vip_manage = false`; with the default (`true`) a destroy deletes it and
  the next build gets a new address, so send PPS a fresh list (section 3).
- Stage 8 checks only services running on DR, using the health endpoints in
  `modules/75-healthchecks/healthchecks.json` (regenerate with
  `scripts/collect_healthchecks.sh` when services change).

## 9. Handover checklist

- [ ] DR bastion access; `kubectl config current-context` = DR cluster
- [ ] `./prevalidate.sh --tfvars pps-dr.tfvars` has no blockers
- [ ] Watched a full build with `scripts/dr_watch.sh`; `scripts/dr_healthcheck.sh` all pass
- [ ] Produced the DNS list; know it must be re-sent after every rebuild
- [ ] Ran and verified a destroy (section 4)
- [ ] Know who refreshes the restore set (section 5) and how often
- [ ] Shared credentials rotated by their owners (notably the Couchbase Capella DR and production accounts)

| Role | Name | Contact |
|---|---|---|
| DR automation owner | | |
| PPS DNS change | | |
| Production backup owner | | |
| GCP project owner `pps-qa-29102018` | | |
