# DR runbook — destroy and rebuild the DR site by hand

Operator runbook, written 2026-10-13 after the first fully unattended success:
run `rebuild-20261013-090417.log` finished `rc=0 after 2 wave(s)` in **48m37s**
(destroy 11m28s, wave 1 34m50s, wave 2 1m43s), verified 17/17 Argo CD
applications Synced+Healthy, 81 pods, 0 not ready.

Planning context lives in `DR-REBUILD-PLAN.md` and `DR-EXECUTION-PLAN.md`; this
file is only the sequence of commands to run.

Secrets (SA key JSON, DB/Vault/Capella passwords) never go into git, tfvars or
this file.

## 0. Get on the bastion

```bash
ssh -i /Users/kushalmehta/work/icrypto/pps-ssh-keys/id_rsa kusha@34.91.152.93
```

The OpenSSH post-quantum warning is noise. The bastion clock is UTC — run
`date -u` before judging whether a log is live or dead.

```bash
cd /home/kusha/pps-dr-iaac
kubectl config current-context      # must be the DR cluster, not QA or PROD
```

The repo on the bastion is the one that runs. It is kept in step with a laptop
checkout by `rsync`; it is not a git remote.

## 1. Record what the destroy will take away

A fresh external VIP is minted on every destroy, so capture the current one
before it goes:

```bash
gcloud compute addresses list --global --format='table(name,address,status)'
kubectl -n argocd get applications.argoproj.io \
  -o custom-columns='NAME:.metadata.name,SYNC:.status.sync.status,HEALTH:.status.health.status'
```

## 2. Destroy

**Irreversible.** This deletes the GKE cluster and every workload on it,
including the LDAP and Consul PVCs, whose restored data exists nowhere else,
and the reserved ingress addresses. Not managed by this repo and therefore
untouched: Cloud SQL `dr-idm-user-data`, the Capella buckets, the GCS backups,
the VPC and the prod KMS key.

```bash
cd /home/kusha/pps-dr-iaac
CONFIRM_DESTROY_DR=yes scripts/dr_destroy.sh
```

Foreground, about 11 minutes, with a live progress screen (overall percentage,
resources done / in progress / pending, one row per phase). The log is
`/home/kusha/dr-build/destroy-<stamp>.log`. Ctrl-C stops only the screen: the
destroy carries on, and `scripts/dr_watch.sh` picks it up again. Without
the environment variable the script refuses and exits 2 — that is the guard,
which lives in the script because `lifecycle.prevent_destroy` cannot be driven
by a variable and left a single-pass destroy impossible.

Before the cluster is deleted, the destroy also empties every user database on
the DR Cloud SQL instance (`scripts/dr_empty_postgres.sh`): each one is dropped
and created again, empty, so the next build restores into nothing. `postgres`,
the templates and `cloudsqladmin` are never touched. It runs from a pod in the
cluster, because the instance is reachable only on its private address. It is
best effort - if the cluster is already gone it warns and the destroy carries on,
and the restore's own cleanup step is the backstop. `EMPTY_POSTGRES=no` skips it;
`DRY_RUN=1 scripts/dr_empty_postgres.sh` lists what it would empty.

Verify the site is gone:

```bash
tail -3 $(ls -t /home/kusha/dr-build/destroy-*.log | head -1)   # want "FINISHED rc=0"
tofu state list | wc -l                   # want 0
gcloud container clusters list
gcloud compute addresses list --global
```

Leftovers in state are safe to clear by running the same command again.

## 3. Build

### 3a. Destroy and build in one unattended run

This is what produced the 48m37s result.

```bash
cd /home/kusha/pps-dr-iaac
setsid nohup scripts/dr_rebuild.sh > /home/kusha/dr-build/rebuild.out 2>&1 &
```

It destroys first — no confirmation, the teardown is part of the flow — then
applies up to `MAX_WAVES` (default 4) times, stopping when an apply returns 0
**and** the site reports healthy within `HEALTH_WAIT` (default 900s).

Several waves are normal and are not a failure: a failed provisioner leaves its
resource tainted but everything it created persists, so the next wave resumes
rather than restarting. Success is judged from the site, not from tofu's exit
code.

### 3b. Build only, when state is already empty

```bash
cd /home/kusha/pps-dr-iaac
setsid nohup scripts/dr_build.sh > /home/kusha/dr-build/build.out 2>&1 &
```

One apply, no wave loop. If it ends `rc=1` with the site incomplete, run it
again.

Expect roughly 35 minutes for the first wave and 2 minutes for a mop-up wave.
Phase 8 validation stays off (`validation_enabled = false`): its checks resolve
the public hostnames, which point here only after PPS makes the DNS change.

## 4. Watch it

```bash
scripts/dr_watch.sh                 # newest build / rebuild / destroy log
```

It draws a progress screen: an overall bar with the percentage and the number
of resources done, in progress and pending; one row per phase (done, running,
pending); what is running right now and for how long. The percentage counts
resources, not minutes, so it sits still while the midpoint restore runs - the
"In progress" list underneath shows what it is waiting on. Piped to a file it
prints one summary line every 30 seconds instead.

Use this rather than tailing. OpenTofu prints a provisioner's error only after
every in-flight resource has drained, and the longest resource is the restore,
so a Phase 2 failure can stay invisible for an hour while the log shows nothing
but "Still creating..." — and the apply is already doomed. The watcher infers
the failure from the log instead.

Raw log, if wanted:

```bash
tail -f $(ls -t /home/kusha/dr-build/rebuild-*.log | head -1)
```

### Postgres cleanup

Before each database in `postgres_databases` is restored, Phase 3 empties it:
`DROP DATABASE ... WITH (FORCE)` then `CREATE DATABASE`, from a short pod in the
DR cluster (`modules/30-data-restore/postgres_cleanup.sh`). Controlled by
`postgres_cleanup_before_restore` (default `true`). Only the listed databases are
touched; `postgres`, the templates and `cloudsqladmin` are refused. It is skipped
when the restore Job for the current backup generation is already running or
succeeded, so a retried wave cannot wipe data that nothing would reload.

### Audit partitions after the restore

The restore leaves midPoint's partitioned audit tables with production's
partitions (ids ~98,000,000-149,000,000) but, with the audit rows excluded, an id
sequence that restarts at 1. Without a partition for those ids the first audit
INSERT fails - `no partition of relation "m_audit_event" found for row` - and
midPoint's startup import dies. After each restore of a database listed in
`postgres_future_partition_databases` (default `midpoint`),
`modules/30-data-restore/postgres_future_partitions.sh` calls the database's own
`create_future_partitions_for_m_audit_event` and `_delta` functions
(`postgres_future_partitions`, default 10; 0 disables). They start at the
partition holding `MAX(id)`, so on an empty audit table they create partitions
from 0 upward. It then checks that the current sequence value is covered, and
fails the phase if it is not.

### Healthchecks (stage 8)

Shown as stage 8 in the progress screen and timings; the sign-off validation that
the original plan numbers 8 (modules/80-validation, off until DNS) is shown as 9.

`modules/75-healthchecks` runs QA's own readiness probes against DR, in the same
apply, after Phase 7 (it needs no DNS). The catalog,
`modules/75-healthchecks/healthchecks.json`, is generated from QA by
`scripts/collect_healthchecks.sh` (services, default and authn namespaces; 19
endpoints at the time of writing) and committed. Re-collect it when QA changes:

```bash
KUBECTL='ssh -i <key> kushal@10.200.110.99 kubectl --context gke-qa-az1' \
  scripts/collect_healthchecks.sh
```

Only workloads deployed on DR are checked. Not deployed, or scaled to 0, is
`skipped` and never a failure; deployed with replicas above 0 and unhealthy is
a failure, retried for `healthchecks_timeout_seconds` (default 180) first. HTTP
checks go through the workload's Service when DR has one, else straight to a
running pod, from a short-lived curl pod (`healthchecks_probe_image`, default `curlimages/curl`); the one exec probe (oidcv2-auth-server)
runs inside the workload. The report is `.dr-run/healthcheck-report.json`.

Run it again at any time without OpenTofu:

```bash
scripts/dr_healthcheck.sh
```

`healthchecks_skip_workloads = ["oidc-mgmt-portal"]` leaves a workload out;
`healthchecks_fail_on_error = false` reports failures without failing the apply.

### Corrections applied after the production restore

Restoring production brings production's Vault values and LDAP membership, which are
wrong for DR in a few places. The build corrects them on every run, only when
different (nothing to do by hand; settings in `pps-dr.tfvars.example`):

| What | Where it runs | Production's value | DR's value |
|---|---|---|---|
| IdM Directory Capella account | Phase 5, `modules/50-secrets/vault_overrides.sh` | `prod-icrypto-sa-ha` and its password | the DR Capella account (`couchbase_username`, `TF_VAR_couchbase_password`) |
| Capella account and password in every other Vault key that held production's (SSO login bucket `ext-authn-service/capella-auth-pass`, oidc-v3, the oidcv2 password-expiry script, session-mgmt, sage) | same | production's | the DR account |
| Capella account, password and host written into the "PPS Password expiration scope" script in the `oidcv2` bucket | Phase 3, `capella_rewrite_endpoints.sh` | production's, hard-coded as Java constants | the DR account and host |
| IdM trueLDAP and PRO-FiT host | same | `trueldap-az1.pps.co.za` (does not resolve on DR) | `trueldap.pps.co.za` |
| IdM MFA address (`mfa-domain`) | same | `https://mfa.pps.co.za` (does not resolve on DR) | `http://mfa-facade-service.services.svc.cluster.local:8099` |
| Application service accounts in `adminWrite` | Phase 3, `modules/30-data-restore/ldap_group_members.sh` | read-only (`adminRead`) | read and write |
| LDAP access rules on `dc=ppspar,dc=PPSDMN` | Phase 3, `ldap_access_rules.sh` | whatever the restore set carried | production's rules (adminWrite write, adminRead read), enforced |
| `kmokgadi1` in `remote-acl-users` | Phase 3, `ldap_group_members.sh` | not a member | member (read on `secAuthority=Default`) |
| LDAP certificate | Phase 3, `ldap_tls_restore.sh` | production's | the same, copied from the restore set |
| LDAP Service ports | Phase 2 chart values | 1389 / 1636 | 1389 / 1636 (the chart's file says 389 / 636) |

The LDAP access rules are enforced after the restore (`ldap_access_rules`), so DR no
longer depends on how current the restore set is: on 2026-10-20 the set predated
production's `adminRead`/`adminWrite` rules, so `Springboot_PROD` could bind but read
nothing (LDAP error 32). Refreshing the set before a rebuild is still right, for the data.

Still open: `secret/idm/pro-fit-userCreateServiceAddress` and `secret/idm/iaa-serviceAddress`
name production IPs (10.200.17.x) that were not verified as reachable from DR, and
`secret/idm/idmDirectory-cbPassword` is production's unused in-cluster Couchbase password.

The LDAP certificate files are collected once from production with
`STAGES=ldaptls bash collect_dr_restore_set.sh` (not in the default stages: it copies
a private key into the bucket).

## 5. Verify the site

```bash
kubectl -n argocd get applications.argoproj.io \
  -o custom-columns='NAME:.metadata.name,SYNC:.status.sync.status,HEALTH:.status.health.status'
kubectl get pods -A | grep -vE 'Running|Completed'
```

Target: 17/17 Synced and Healthy, about 81 pods, nothing not ready.

Database spot-check runs from a pod inside the cluster, never from the bastion —
the bastion's PostgreSQL client is 9.2.24, too old to read a 1.15 dump header
and unable to do SCRAM authentication:

```bash
kubectl -n default run pgchk --rm -it --image=postgres:16 --restart=Never -- \
  psql -h 10.221.111.2 -U postgres -d midpoint -c '\dt'
```

The password lives in Vault. All six `m_audit*` tables are expected to be
present with 0 rows; every other table carries its data.

## 6. Timings

```bash
cat $(ls -t /home/kusha/dr-build/timings-*.txt | head -1)
```

On a multi-wave run that report covers only the **last** wave, by design — it
reads the log after the final `=== APPLY` marker so the destroy's time is not
charged to Phase 0. For wave 1's real breakdown, slice it out first:

```bash
L=$(ls -t /home/kusha/dr-build/rebuild-*.log | head -1)
S=$(grep -n "=== APPLY wave 1/4" "$L" | cut -d: -f1)
E=$(grep -n "wave 1 apply rc=" "$L" | cut -d: -f1)
sed -n "${S},${E}p" "$L" > /tmp/wave1.log
bash scripts/dr_phase_timings.sh /tmp/wave1.log
```

Reference breakdown from the 34m50s wave 1 (phases 3, 4 and 6 overlap):

| phase | | elapsed |
|---|---|---|
| 0 | Preflight | 0:59 |
| 1 | GKE cluster + node pool | 9:59 |
| 1b | Registry credentials | 0:57 |
| 2 | Platform | 2:45 |
| 3 | Data restore | 5:39 |
| 4 | Argo CD | 5:54 |
| 5 | Secrets | 0:59 |
| 5b | App config | 0:06 |
| 6 | App sync + convergence | 15:52 |

Slowest resources: `self_hostname_redirect` 9m52s (GCLB provisioning), the GKE
cluster 8m59s, `postgres_psql_restore["midpoint"]` 5m12s. The critical path is
cluster creation and load balancer provisioning, not data.

## 7. Hand off to PPS

```bash
gcloud compute addresses list --global --format='table(name,address,status)'
```

Send PPS the new `icrypto-nginx-external-01` address as a DNS change. It
changes on every destroy, which costs a fresh change each rebuild; making it
survive a teardown (created out of band, read through a data source) is still
open.

Phase 8 validation stays off until the DNS cutover is done and someone gives an
explicit go.

## Gotchas

- **State lock.** All three scripts delete
  `gs://dr-icrypto-gke-iac/terraform/state-v2/default.tflock` before applying,
  because a killed run leaves it behind. Running `tofu` by hand means deleting
  it by hand.
- **Failed Jobs** must be deleted before a retry wave, not re-attached.
- **No public egress from the bastion.** `curl` to the GCLB returns `http=000`
  in a millisecond; only the pinned `private.googleapis.com` addresses in
  `/etc/hosts` work. The site cannot be validated from there.
- **Prod bucket reads** use `backup_credentials_file` under a scratch
  `CLOUDSDK_CONFIG`. Never switch the bastion's active account.
- **Phase 7 before convergence, not after.** `oidc-mgmt-portal` fetches
  `https://oidc.pps.co.za` at startup, Phase 2 already points that name at this
  site's reserved address, and a reserved address answers nothing until an
  ingress attaches a load balancer. Gating the ingress on convergence
  deadlocked the build; `wave1_gate` is therefore threaded from
  `wave1_released`. The DNS change request still sits behind the full gate.
- **Audit data is not restorable piecemeal.** `m_audit_delta`, `m_audit_item`,
  `m_audit_prop_value`, `m_audit_ref_value` and `m_audit_resource` are all FK
  children of `m_audit_event`, one constraint to the parent plus 102 per
  partition each. Excluding only event and delta would load orphan rows and the
  restore would then fail validating `ADD CONSTRAINT` a hundred times. All six
  or none — which is why `postgres_exclude_table_data` names all six and
  `PG_EXCLUDE_TABLE_DATA=m_audit` is used when collecting the dump.
