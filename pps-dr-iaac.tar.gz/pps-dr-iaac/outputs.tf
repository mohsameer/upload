output "preflight_report" {
  description = "Result of each prerequisite check run before Phase 1."
  value       = module.preflight.preflight_report
}

output "dr_cluster_name" {
  description = "Name of the DR GKE cluster, whether created or adopted."
  value       = module.dr_cluster.cluster_name
}

output "dr_cluster_endpoint" {
  description = "Control plane endpoint of the DR GKE cluster."
  value       = module.dr_cluster.cluster_endpoint
  sensitive   = true
}

output "registry_credentials" {
  description = "Registry credential refresh: schedule, managed namespaces, and how to check staleness."
  value = {
    schedule                = module.registry_credentials.refresh_schedule
    pull_secret             = module.registry_credentials.pull_secret_name
    argocd_repo_secret      = module.registry_credentials.argocd_repo_secret_name
    managed_namespaces      = module.registry_credentials.managed_namespaces
    staleness_check_command = module.registry_credentials.staleness_check_command
  }
}

output "cloudsql_connection_name" {
  description = "Connection name of the pre-existing Cloud SQL instance the data was restored into."
  value       = module.data_restore.cloudsql_connection_name
}

output "restore_report" {
  description = "Per-component result of the Phase 3 restores."
  value       = module.data_restore.restore_report
}

# Phase 7 hands this to the operator, who raises the DNS change request with
# PPS. This repo never creates public DNS records.
output "dns_change_request" {
  description = "Hostname -> ingress IP mapping PPS must create DNS records for."
  value       = try(module.ingress_dns[0].dns_change_request, "phase 7 not run (ingress_dns_enabled = false)")
}

output "dns_resolution_check_command" {
  description = "Command to verify every DR hostname resolves before Phase 8 is run."
  value       = try(module.ingress_dns[0].dns_resolution_check_command, "phase 7 not run (ingress_dns_enabled = false)")
}

output "phase8_command" {
  description = "Targeted apply that runs Phase 8 once DNS resolves."
  value       = "tofu apply -target=module.validation -var-file=pps-dr.tfvars"
}

output "signoff_report_path" {
  description = "Path of the Phase 8 sign-off report on the bastion."
  value       = try(module.validation[0].signoff_report_path, "phase 8 not run (validation_enabled = false)")
}
