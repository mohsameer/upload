# PPS DR Site - Infrastructure as Code

Builds the PPS (iCrypto SSO) Disaster Recovery site as code, following the
8-phase runbook in *"iCrypto - Disaster Recovery Plan for PPS"*.

Run from the **DR bastion VM** (opentofu/terraform, `gcloud`, `kubectl`,
`helm` installed there).

## What changed from the previous version of this repo

This is a rebuild (see [`openspec/changes/pps-dr-iaac-v2`](openspec/changes/pps-dr-iaac-v2/proposal.md)
for the full proposal/specs/design/tasks):

- PostgreSQL moved to **Cloud SQL** (managed) - no longer installed in-cluster.
- Couchbase moved to **Couchbase Capella** (managed) - no longer installed
  in-cluster, no Couchbase Operator.
- Application delivery moved to **Argo CD** - no more per-service
  `*_deploy.sh` scripts.
- Secrets moved to **Vault + External Secrets Operator**.
- Every environment-specific value now ships as an obvious `REPLACE_ME_*`
  placeholder until PPS supplies the real values (see below).

## Prerequisites (owned outside this repo)

This repo **consumes** these; it never creates or destroys them. Phase 0
(preflight) checks all six before anything else runs:

1. IDM PostgreSQL sized via partitioning (upstream, in `idm-audit-db-partition`).
2. Couchbase Capella cluster exists and is reachable in the DR region.
3. Cloud SQL PostgreSQL instance provisioned in the DR region.
4. All DB backup files present and verified in the GCS bucket.
5. GCS bucket credentials valid and accessible from the DR environment.
6. iCrypto team holds kubeconfig / GKE credentials for the DR cluster.

The DR project also carries a custom org policy, `custom.requireComputeLabels`,
which **denies creating any Compute instance** without `environment`,
`agile_team` (underscore) and `tiering` (value of the form `tierN`) labels. The
node pool's VMs need all three, so `dr_gke_node_resource_labels` must be set -
a node pool whose instances are refused leaves the cluster in ERROR with no
nodes. The cluster's own `dr_gke_resource_labels` do not satisfy the policy:
the constraint is evaluated against each instance. The working set is:

```hcl
dr_gke_node_resource_labels = { environment = "dr", agile_team = "sso", tiering = "tier1" }
```

## Placeholder values

PPS has not yet supplied real environment values. **Every** environment-
specific input in [`pps-dr.tfvars.example`](pps-dr.tfvars.example) is a
placeholder (`REPLACE_ME_*`, a dummy CIDR, or a dummy identifier). A
`validation` block on each such variable rejects an apply that still carries
a placeholder, so this fails loudly and early rather than half-building a
site.

```bash
cp pps-dr.tfvars.example pps-dr.tfvars   # git-ignored, real values go here
```

**Before a real run**, work through [`DR-EXECUTION-PLAN.md`](DR-EXECUTION-PLAN.md):
the values PPS has to supply, which placeholders fail loudly and which ones
pass validation silently, the gated step-by-step runbook, and per-failure
recovery notes. Then run [`./prevalidate.sh`](#prevalidation-gate) - see
below - as the actual first command, before `tofu init`.

Sensitive inputs are **not** in the tfvars file at all - they come from
`TF_VAR_*` environment variables:

```bash
export TF_VAR_ecr_access_key="..."
export TF_VAR_ecr_secret_key="..."
export TF_VAR_cloudsql_import_password="..."
export TF_VAR_capella_api_token="..."
export TF_VAR_couchbase_password="..."
export TF_VAR_vault_root_token="..."
export TF_VAR_ldap_admin_password="..."
export TF_VAR_argocd_admin_password_bcrypt="..."
export TF_VAR_git_pat="..."
export TF_VAR_oidc_validation_client_secret="..."
```

## Layout

```
prevalidate.sh              # gate: run this FIRST, before tofu init (see below)
prevalidate/                # shared check suite behind prevalidate.sh and Phase 0
main.tf                     # phase orchestration
scripts/collect_dr_restore_set.sh # collect the whole restore set from the prod bastion
scripts/dr_build.sh         # unattended one-pass build + per-phase timing report
scripts/dr_destroy.sh       # one-pass teardown behind a confirmation guard
modules/common/helm_apply.sh      # every Helm release goes through here (no helm provider)
modules/00-preflight/       # Phase 0: prerequisite verification (read-only, delegates to prevalidate/)
modules/10-gke-cluster/     # Phase 1: cluster create-or-adopt, namespaces
modules/15-registry-credentials/  # ECR pull secrets + Argo CD Helm OCI secret, refreshed on a schedule
modules/20-platform/        # Phase 2: consul, vault, ldap, zeebe
modules/30-data-restore/    # Phase 3: cloudsql import, capella restore, consul/vault/ldap restore
modules/40-argocd/          # Phase 4: argocd install + backup restore
modules/50-secrets/         # Phase 5: vault configuration (vault_config.sh) + ESO + sync gate
modules/55-app-config/      # Phase 5b: application config and secrets no backup carries
modules/60-app-services/    # Phase 6: app-of-apps, service versions, health gate
modules/70-ingress-dns/     # Phase 7: ingress reuse-or-create, TLS, DNS change request
modules/80-validation/      # Phase 8: graceful restart, validation, sign-off report
```

## Prevalidation gate

Run this **first**, before `tofu init`. It needs no Terraform state, no
backend, and never mutates anything - safe to run at any time, as often as
you want:

```bash
./prevalidate.sh --tfvars pps-dr.tfvars
```

It catches, in seconds rather than the tens of minutes it would otherwise
cost mid-run, everything that reliably breaks a DR attempt:

- the six documented prerequisites (same as Phase 0, see below)
- **silent placeholder values** that pass Terraform's own variable
  validation but still build a broken site - dummy CIDRs, all-zero Capella
  UUIDs, `0.0.0-dummy` service versions, an empty `backend_services` map
  (which would otherwise render ingress backends literally named
  `REPLACE-ME-<key>-service` with no validation rule catching it)
- every bastion binary each phase script actually calls (`psql`, `cbc`,
  `cbbackupmgr` when selected, `openssl`, `getent`, not just the five the old
  check covered)
- configuration facts beyond mere presence: Cloud SQL has a PRIVATE IP, its
  service account can read the backup dump, the TLS cert/key are a matching
  pair, the bastion's egress IP is inside `dr_gke_master_authorized_networks`,
  pinned Helm chart versions actually resolve, configured Capella buckets
  exist, the Argo CD backup archive parses

Every check is read-only and reports together rather than stopping at the
first failure - one fix-and-rerun cycle per problem is expensive during an
incident. Results are tagged with severity (`blocker` fails the gate,
`warning` does not, `skipped` records a disabled feature explicitly) and the
phase each would have broken:

```bash
./prevalidate.sh --tfvars pps-dr.tfvars --offline   # skip network calls
./prevalidate.sh --tfvars pps-dr.tfvars --report ./my-report.json
```

`modules/00-preflight` runs this exact same check suite during `tofu apply`
(against the same `pps-dr.tfvars`, via `path.root` - no separate wiring
needed) as the Phase 0 gate, so the two entry points cannot drift apart.

## Registry credentials

The iCrypto images and Helm charts live in a private AWS ECR registry, and an
ECR authorization token is valid for **12 hours**. `modules/15-registry-credentials`
therefore runs the token exchange *inside* the cluster on a CronJob (every 6h
by default) rather than once from the bastion, and keeps two things current:

- the `dockerconfigjson` image pull secret in every configured namespace, and
- the Argo CD repository secret (`type: helm`, `enableOCI: true`) that lets
  Argo CD pull the iCrypto Helm charts over OCI.

A bootstrap Job runs immediately on apply, so later phases are never waiting
on the first scheduled tick. To check credentials are current:

```bash
kubectl -n platform get secret icrypto-registry \
  -o jsonpath='{.metadata.annotations.pps-dr/last-refresh}'
```

Note that `registry_runner_image` must be pullable **without** registry
credentials - it is the workload that creates them.

## Backup set layout

One backup set = one folder in `backup_bucket`. Point a run at it with a single
value, `backup_prefix`; every `*_backup_object(s)`, `postgres_databases` entry and
`couchbase_index_definitions_object` is a path **relative to that folder**.

Keep the same sub-folders and **stable file names** in every set, and put the date
in the folder name only. A new set is then a one-line tfvars change:

```
gs://<backup_bucket>/<backup_prefix>/      e.g. pps-k8s-prod-backups/pps-dr-iac-restore/
  postgresql/<db>.sql | <db>.sql.gz        postgres_databases       (plain pg_dump, streamed;
                                                                     postgres_dump_format = "plain")
  postgresql/<db>.dump | <db>.dump.tar     postgres_databases       (pg_dump -Fc, or -Fd tarred;
                                                                     postgres_dump_format = "custom",
                                                                     restored with postgres_restore_jobs workers)
  couchbase/<archive>.tar.gz               couchbase_backup_objects (cbbackupmgr archive, all buckets)
  consul/<export>.json | <snapshot>.snap   consul_backup_object     (kv export or snapshot)
  ldap/ldap-config-backup.ldif             ldap_backup_objects      (names must contain
  ldap/ldap-secauth-backup.ldif                                      config / secauth; anything
  ldap/ldap-data-backup.ldif                                         else loads as data)
  argocd/<bundle>.tar.gz                   argocd_backup_object     (one YAML per resource kind)
```

Rules the restore scripts rely on:

- Extension decides handling: `.gz` is decompressed in the stream, `.tar`/`.tar.gz`/`.tgz`
  is extracted, `.snap` selects Consul snapshot restore (anything else: `consul kv import`).
- A cbbackupmgr tarball may hold a full archive (with `.backup`) or one bare repository.
- LDAP file names must contain `config` / `secauth`; they are loaded config first.
- `./prevalidate.sh` checks every configured object exists and is non-empty under the
  prefix, read with `backup_credentials_file`, before anything is built.
- There is **no globals dump**: `postgres_globals_object` stays `""` and is
  unused. `pg_dumpall --globals-only` cannot read `pg_authid` as the Cloud SQL
  `postgres` user, and nothing needs it - every database is dumped with
  `--no-owner --no-acl`, so a restore does not depend on the source roles.

### Collecting a set from production

`scripts/collect_dr_restore_set.sh` runs **on the prod bastion** and produces a
complete set in one prefix (`gs://pps-k8s-prod-backups/pps-dr-iac-restore/`)
with fixed object names, so the DR tfvars reference them once and never change
after a backup run - Terraform notices a new set from the object's GCS
generation, not its name:

```
consul/consul-kv-export.json                      argocd/argocd-backup.tar.gz
ldap/ldap-{config,secauth,data}-backup.ldif       couchbase/capella.tar.gz
postgresql/{midpoint,idpv3,oidc-mgmt-portal}.dump.tar
```

Consul, LDAP and Argo CD come from triggering PPS's own backup CronJobs, so the
dumps are made exactly the way the scheduled backups make them.

The run is **resumable by stage**, which matters because midpoint alone is a
225GB dump:

```bash
STAGES="argocd postgresql couchbase" bash scripts/collect_dr_restore_set.sh
```

`PG_MODE=pod` (the default) dumps with `pg_dump -Fd -j` from a Job inside the
prod cluster instead of from the bastion: measured **2113 MB/min against
420 MB/min**, which takes midpoint from ~4.5h to ~50min. `PG_MODE=bastion`
still works (`pg_dump -Fc` piped straight to the bucket, no cluster objects and
no disk) and writes `<db>.dump` rather than `<db>.dump.tar`.

## Running it

State lives in GCS (`gs://dr-icrypto-gke-iac/terraform/state-v2`).

```bash
tofu init
tofu validate
tofu plan -var-file=pps-dr.tfvars
```

### Build - one pass

```bash
tofu apply -var-file=pps-dr.tfvars
```

The same command on a cold build and on every later run. There is deliberately
**no `kubernetes`, `helm` or `vault` provider** in this repo: a provider is
configured before any resource in the apply runs, so one that needs the DR
cluster - or the Vault inside it - cannot be configured by the apply that
creates them, which is what forced the old two-pass procedure
(`-target=module.dr_cluster`, then the rest). Instead every Helm release goes
through `modules/common/helm_apply.sh`, the Vault KMS Secret through `kubectl`,
and all Vault configuration (KV mount, Kubernetes auth, policies, the ESO role
and the database static roles) through `modules/50-secrets/vault_config.sh`.
The unused `couchbase-capella` provider is gone as well.

This runs Phases 0-7 and stops. It will not create the cluster again, will
not re-import already-restored data (restore flags gate on the backup
object's GCS generation, not `timestamp()`), and will not recreate an
existing ingress.

For an unattended run, `scripts/dr_build.sh` does that same apply detached from
the terminal, timestamps every log line and writes a per-phase timing report
through `scripts/dr_phase_timings.sh`.

Teardown is one pass too:

```bash
tofu destroy -var-file=pps-dr.tfvars
```

`scripts/dr_destroy.sh` is the same destroy behind a `CONFIRM_DESTROY_DR=yes`
guard. Cloud SQL, Capella, the GCS backups and the VPC are not managed here and
survive it.

### DNS (PPS action) and Phase 8

Phase 8 is gated by `validation_enabled`, **default `false`** - that is what
lets the build above be a single apply. Every Phase 8 check resolves the public
hostnames, and those point at the DR site only once PPS has made the DNS
change.

Phase 7 emits the hostname -> ingress IP mapping as the `dns_change_request`
output - raise that with PPS. Check with:

```bash
./modules/70-ingress-dns/dns_resolution_check.sh "$(tofu output -json dns_change_request | jq -r '.records[].hostname' | tr '\n' ' ')"
```

Once it passes:

```bash
tofu apply -target=module.validation -var-file=pps-dr.tfvars
```

Phase 8 writes a sign-off report (`signoff_report_path`, default
`./sign-off-report.json`) on both success and failure - that's the DR
exercise's evidence.

## Working on this repo

Changes are proposed and specified with [OpenSpec](https://github.com/Fission-AI/OpenSpec)
before implementation. See `openspec/changes/` for active proposals and
`openspec/specs/` for the accepted capability specs once archived.

```bash
openspec list                        # active changes
openspec show pps-dr-iaac-v2          # this rebuild's proposal/specs/design/tasks
openspec validate pps-dr-iaac-v2 --strict
```
