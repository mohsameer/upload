#!/usr/bin/env bash
# DR prevalidation - the single check suite behind both entry points:
#   - standalone: ./prevalidate.sh, run before `tofu init`
#   - in-band:    modules/00-preflight/preflight.sh, run during `tofu apply`
#
# Every check here is READ-ONLY. No create/apply/patch/delete, anywhere.
# Grep for those verbs in this file as a standing invariant check.
#
# Checks run to completion and are reported together - stopping at the first
# failure would mean one fix-and-rerun cycle per problem, and each cycle
# costs minutes during an incident.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=./lib.sh
source "${SCRIPT_DIR}/lib.sh"

OFFLINE="${OFFLINE:-false}"
GCP_ACTIVATED="false"

# ---------------------------------------------------------------------------
# Section 1: bastion tooling, per phase
# ---------------------------------------------------------------------------

check_tooling() {
  echo "== bastion tooling =="
  require_bin gcloud  "all"     "blocker"
  require_bin kubectl "all"     "blocker"
  require_bin helm    "all"     "blocker"
  require_bin curl    "all"     "blocker"
  require_bin jq      "all"     "blocker"
  require_bin tar     "3,4"     "blocker" "archive extraction (Couchbase/Argo CD backups)"
  require_bin base64  "3,4,7"   "blocker" "credential/manifest encoding"
  require_bin psql    "3,8"     "blocker" "Cloud SQL verify job and read/write sign-off check"
  require_bin cbc     "8"       "warning" "Couchbase session read/write sign-off check (Phase 8 only)"
  require_bin openssl "7"       "blocker" "TLS cert/key validation"
  require_bin getent  "7,8"     "blocker" "DNS resolution checks"

  if tfv_map_values couchbase_restore_methods | grep -qx cbbackupmgr; then
    require_bin cbbackupmgr "3" "blocker" "a bucket in couchbase_restore_methods uses cbbackupmgr (runs on this bastion)"
  else
    skip "tooling:cbbackupmgr" "3" "no bucket in couchbase_restore_methods uses cbbackupmgr"
  fi

  if [[ "${OFFLINE}" == "true" ]]; then
    skip "tooling:aws" "15" "offline mode; registry credential check skipped"
  elif command -v aws >/dev/null 2>&1; then
    pass "tooling:aws" "15" "present (used to validate ECR credentials below)"
  else
    warn "tooling:aws" "15" "aws CLI absent on this bastion; registry credential check below will be skipped. The in-cluster refresher (module 15) brings its own, so this only affects this gate's own coverage."
  fi
}

# ---------------------------------------------------------------------------
# Section 2: silent placeholder detection
#
# REPLACE_ME_* is already caught by Terraform's own variable validation.
# Everything here is the class of value that PASSES validation and still
# builds a broken site.
# ---------------------------------------------------------------------------

check_placeholders() {
  echo
  echo "== silent placeholder values =="

  local hits
  hits=$(_tfv_clean | grep -oE 'REPLACE_ME_[A-Za-z0-9_]+' | sort -u | tr '\n' ' ')
  if [[ -n "${hits}" ]]; then
    fail "placeholder:replace-me" "all" "unfilled REPLACE_ME_* values (Terraform will also reject these): ${hits}"
  else
    pass "placeholder:replace-me" "all" "no REPLACE_ME_* values remain"
  fi

  local cidr_hits=()
  for c in $(tfv_get dr_gke_cluster_ipv4_cidr_block) $(tfv_get dr_gke_services_ipv4_cidr_block) $(tfv_get dr_gke_master_ipv4_cidr_block); do
    case "${c}" in
      10.200.0.0/16|10.201.0.0/20|172.31.255.0/28) cidr_hits+=("${c}") ;;
    esac
  done
  if [[ ${#cidr_hits[@]} -gt 0 ]]; then
    fail "placeholder:dummy-cidrs" "1" "example CIDR(s) from pps-dr.tfvars.example still in use: ${cidr_hits[*]}"
  else
    pass "placeholder:dummy-cidrs" "1" "cluster/services/master CIDRs are not the shipped example values"
  fi

  local test_net
  test_net=$(tfv_authorized_cidrs | grep -E '^192\.0\.2\.' || true)
  if [[ -n "${test_net}" ]]; then
    fail "placeholder:test-net-bastion" "1" "dr_gke_master_authorized_networks still contains TEST-NET-1 example range(s): $(echo "${test_net}" | tr '\n' ' ')"
  else
    pass "placeholder:test-net-bastion" "1" "no TEST-NET-1 (192.0.2.0/24) example ranges in master authorized networks"
  fi

  local proj cluster
  proj=$(tfv_get capella_project_id)
  cluster=$(tfv_get capella_cluster_id)
  if [[ "${proj}" == "00000000-0000-0000-0000-000000000000" || "${cluster}" == "00000000-0000-0000-0000-000000000001" ]]; then
    fail "placeholder:capella-uuids" "3" "capella_project_id/capella_cluster_id are still the all-zero example UUIDs"
  else
    pass "placeholder:capella-uuids" "3" "capella_project_id/capella_cluster_id are not the shipped example UUIDs"
  fi

  local connstr
  connstr=$(tfv_get capella_connection_string)
  if [[ "${connstr}" == *"cb.dummy."* ]]; then
    fail "placeholder:capella-connstr" "3,6" "capella_connection_string is still the example dummy value: ${connstr}"
  else
    pass "placeholder:capella-connstr" "3,6" "capella_connection_string is not the shipped dummy value"
  fi

  local dummy_buckets=()
  while IFS= read -r b; do
    [[ "${b}" == dummy-* ]] && dummy_buckets+=("${b}")
  done < <(tfv_list capella_buckets)
  if [[ ${#dummy_buckets[@]} -gt 0 ]]; then
    fail "placeholder:capella-buckets" "3" "capella_buckets still lists example dummy bucket(s): ${dummy_buckets[*]}"
  else
    pass "placeholder:capella-buckets" "3" "capella_buckets does not contain the shipped dummy names"
  fi

  local dummy_versions=()
  while IFS='=' read -r svc ver; do
    [[ "${ver}" == *"dummy"* || "${ver}" == "0.0.0-dummy" ]] && dummy_versions+=("${svc}")
  done < <(tfv_map_pairs service_versions)
  if [[ ${#dummy_versions[@]} -gt 0 ]]; then
    fail "placeholder:service-versions" "6" "service_versions still has dummy version(s) for: ${dummy_versions[*]}"
  else
    pass "placeholder:service-versions" "6" "every entry in service_versions is a real-looking version"
  fi

  local dummy_backups=()
  while IFS= read -r obj; do
    [[ "${obj}" == backups/dummy/* ]] && dummy_backups+=("${obj}")
  done < <(
    printf '%s\n' "$(tfv_get postgres_backup_object)" "$(tfv_get consul_backup_object)" \
                   "$(tfv_get vault_backup_object)" "$(tfv_get argocd_backup_object)" \
                   "$(tfv_get couchbase_index_definitions_object)"
    tfv_map_values couchbase_backup_objects
  )
  if [[ ${#dummy_backups[@]} -gt 0 ]]; then
    fail "placeholder:backup-paths" "3,4" "example backup object path(s) still in use: ${dummy_backups[*]}"
  else
    pass "placeholder:backup-paths" "3,4" "backup object paths are not the shipped backups/dummy/ examples"
  fi

  local argocd_host
  argocd_host=$(tfv_get argocd_hostname)
  if [[ "${argocd_host}" == *".invalid" ]]; then
    fail "placeholder:argocd-hostname" "4" "argocd_hostname is still the example .invalid value: ${argocd_host}"
  else
    pass "placeholder:argocd-hostname" "4" "argocd_hostname is not the shipped example value"
  fi

  local dummy_restart
  dummy_restart=$(tfv_list post_restart_services | grep -c '^deployment/dummy-' || true)
  if [[ "${dummy_restart}" -gt 0 ]]; then
    fail "placeholder:post-restart-services" "8" "post_restart_services still lists example dummy-* workload(s)"
  else
    pass "placeholder:post-restart-services" "8" "post_restart_services does not contain the shipped dummy entries"
  fi

  # The worst one: no validation rule catches this because the rendered
  # values use hyphens (REPLACE-ME-*), not the underscore REPLACE_ME_ prefix
  # Terraform's variable validation greps for.
  local backend_svc_count
  backend_svc_count=$(tfv_map_pairs backend_services | grep -c . || true)
  if [[ -n "$(tfv_get ingress_manifest_file)" ]]; then
    local mf
    mf=$(tfv_get ingress_manifest_file)
    [[ "${mf}" != /* ]] && mf="${SCRIPT_DIR}/../${mf}"
    if [[ -s "${mf}" ]]; then
      pass "placeholder:backend-services-empty" "7" "ingress_manifest_file is set (${mf}); backend_services is not used"
    else
      fail "placeholder:backend-services-empty" "7" "ingress_manifest_file ${mf} is missing or empty"
    fi
  elif [[ "${backend_svc_count}" -eq 0 ]]; then
    fail "placeholder:backend-services-empty" "7" "backend_services is empty. Phase 7 will render ingress backends literally named 'REPLACE-ME-<key>-service' for every hostname in dr_hostnames - no Terraform validation catches this because the placeholder uses hyphens, not the underscore prefix the validation rules grep for. Set backend_services explicitly before applying."
  else
    pass "placeholder:backend-services-empty" "7" "backend_services has ${backend_svc_count} entries"
  fi
}

# ---------------------------------------------------------------------------
# Section 3: the six documented DR prerequisites (parity with the current
# modules/00-preflight/preflight.sh, unified into this shared suite)
# ---------------------------------------------------------------------------

_gcp_activate() {
  [[ "${GCP_ACTIVATED}" == "true" ]] && return 0
  [[ "${OFFLINE}" == "true" ]] && return 1
  local creds
  creds=$(tfv_get gcp_credentials_file)
  [[ -z "${creds}" || "${creds}" == REPLACE_ME* ]] && return 1
  local attempt
  for attempt in 1 2 3; do
    if with_timeout "${NET_TIMEOUT_SECONDS}" gcloud auth activate-service-account --key-file="${creds}" \
         --project="$(tfv_get project_id)" >/dev/null 2>&1; then
      GCP_ACTIVATED="true"
      return 0
    fi
    [[ ${attempt} -lt 3 ]] && sleep $((attempt * 3))
  done
  return 1
}

# gcloud as the identity that can read backup_bucket. The prod backup bucket
# is readable only by the prod SA (backup_credentials_file); without it the
# activated gcp_credentials_file identity is used.
#
# Applies its own timeout - `timeout` cannot run a shell function, so callers
# must NOT wrap this in with_timeout - and retries once: GCS calls from the DR
# bastion have been seen to hang intermittently.
gcloud_backup() {
  local creds attempt
  creds=$(tfv_get backup_credentials_file)
  creds="${creds/#\~/${HOME}}"
  for attempt in 1 2; do
    if [[ -n "${creds}" ]]; then
      CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE="${creds}" with_timeout "${NET_TIMEOUT_SECONDS}" gcloud "$@" && return 0
    else
      with_timeout "${NET_TIMEOUT_SECONDS}" gcloud "$@" && return 0
    fi
    [[ ${attempt} -eq 1 ]] && sleep 2
  done
  return 1
}

# Object paths in tfvars are relative to backup_prefix (same join as root
# main.tf); an empty path stays empty.
backup_obj() {
  local prefix obj="$1"
  prefix=$(tfv_get backup_prefix)
  prefix="${prefix#/}"; prefix="${prefix%/}"
  [[ -z "${obj}" ]] && return 0
  if [[ -n "${prefix}" ]]; then echo "${prefix}/${obj}"; else echo "${obj}"; fi
}

check_prerequisites() {
  echo
  echo "== 6 documented DR prerequisites =="

  if [[ "${OFFLINE}" == "true" ]]; then
    skip "prereq:all" "0" "offline mode; prerequisite reachability checks require network access"
    return
  fi

  if ! command -v gcloud >/dev/null 2>&1; then
    skip "prereq:gcp-auth" "0" "gcloud not present; cannot check GCP-backed prerequisites"
    return
  fi

  if _gcp_activate; then
    pass "prereq:gcp-auth" "0" "activated service account from gcp_credentials_file"
  else
    fail "prereq:gcp-auth" "0" "could not activate GCP service account (check gcp_credentials_file and project_id)"
    return
  fi

  local project instance pg_method
  project=$(tfv_get project_id)
  instance=$(tfv_get cloudsql_instance_name)
  pg_method=$(tfv_get postgres_restore_method)
  pg_method="${pg_method:-psql_pod}"

  # Prerequisite 3: Cloud SQL instance provisioned and serving.
  # gcloud_sql_import reads it through the Cloud SQL Admin API; psql_pod
  # never touches that API (it may be unreachable from this bastion), so it
  # only needs the private IP and a listening port.
  if [[ "${pg_method}" == "gcloud_sql_import" ]]; then
    if ! tfv_is_true allow_gcloud_sql_import; then
      fail "prereq3:postgres-method" "3" "postgres_restore_method=gcloud_sql_import without allow_gcloud_sql_import=true; it stays disabled until sqladmin.googleapis.com is reachable from the DR bastion"
    fi
    local state
    state=$(with_timeout "${NET_TIMEOUT_SECONDS}" gcloud sql instances describe "${instance}" --project="${project}" --format='value(state)' 2>/dev/null)
    if [[ "${state}" == "RUNNABLE" ]]; then
      pass "prereq3:cloudsql-serving" "3" "instance ${instance} is RUNNABLE"
    else
      fail "prereq3:cloudsql-serving" "3" "instance ${instance} state is '${state:-unreachable}', expected RUNNABLE (is sqladmin.googleapis.com reachable from this host?)"
    fi
  else
    local pg_ip
    pg_ip=$(tfv_get cloudsql_private_ip)
    if [[ -z "${pg_ip}" ]]; then
      fail "prereq3:cloudsql-private-ip" "3" "postgres_restore_method=psql_pod needs cloudsql_private_ip"
    elif with_timeout 5 bash -c "exec 3<>/dev/tcp/${pg_ip}/5432" 2>/dev/null; then
      pass "prereq3:cloudsql-reachable" "3" "${pg_ip}:5432 accepts TCP connections from this host"
    else
      warn "prereq3:cloudsql-reachable" "3" "${pg_ip}:5432 not reachable from this host; the psql_pod Job connects from inside the DR cluster, which may still route to it. Confirm from a pod if in doubt."
    fi
  fi

  # Prerequisite 1: recorded, not independently verifiable here.
  pass "prereq1:idm-partitioning" "3" "assumed applied upstream (idm-audit-db-partition repo); verified post-restore in Phase 3"

  # Prerequisite 5: GCS credentials usable.
  local bucket
  bucket=$(tfv_get backup_bucket)
  if gcloud_backup storage ls "gs://${bucket}" >/dev/null 2>&1; then
    pass "prereq5:gcs-credentials" "3" "bucket gs://${bucket} is listable"
  else
    fail "prereq5:gcs-credentials" "3" "cannot list gs://${bucket} with the supplied credentials"
  fi

  # Prerequisite 4: every configured backup object present and non-empty.
  local objs=()
  mapfile -t objs < <(
    printf '%s\n' "$(tfv_get postgres_backup_object)" "$(tfv_get consul_backup_object)" \
                   "$(tfv_get vault_backup_object)" "$(tfv_get argocd_backup_object)" \
                   "$(tfv_get postgres_globals_object)"
    tfv_list ldap_backup_objects
    if [[ "$(tfv_get couchbase_restore_enabled)" != "false" ]]; then
      tfv_map_values couchbase_backup_objects
      tfv_get couchbase_index_definitions_object
    fi
    true
  )
  for obj in "${objs[@]}"; do
    [[ -z "${obj}" ]] && continue
    obj=$(backup_obj "${obj}")
    if gcloud_backup storage objects describe "gs://${bucket}/${obj}" >/dev/null 2>&1; then
      local size
      size=$(gcloud_backup storage objects describe "gs://${bucket}/${obj}" --format='value(size)' 2>/dev/null)
      if [[ "${size:-0}" -gt 0 ]]; then
        pass "prereq4:backup-object:${obj}" "3,4" "present, ${size} bytes"
      else
        fail "prereq4:backup-object:${obj}" "3,4" "gs://${bucket}/${obj} exists but is zero bytes"
      fi
    else
      fail "prereq4:backup-object:${obj}" "3,4" "missing object gs://${bucket}/${obj}"
    fi
  done

  # Prerequisite 2: Capella cluster reachable and healthy.
  local capella_url token org proj_id cluster_id
  capella_url=$(tfv_get capella_api_url)
  token="${TF_VAR_capella_api_token:-}"
  org=$(tfv_get capella_organization_id)
  proj_id=$(tfv_get capella_project_id)
  cluster_id=$(tfv_get capella_cluster_id)

  if [[ -z "${token}" ]]; then
    skip "prereq2:capella" "3" "TF_VAR_capella_api_token not set in this shell; cannot reach the Management API"
  else
    local endpoint="${capella_url}/v4/organizations/${org}/projects/${proj_id}/clusters/${cluster_id}"
    local body code
    body=$(mktemp)
    code=$(curl -sS --max-time "${NET_TIMEOUT_SECONDS}" -o "${body}" -w '%{http_code}' -H "Authorization: Bearer ${token}" -H "Accept: application/json" "${endpoint}" 2>/dev/null)
    if [[ "${code}" == "200" ]]; then
      local cb_state
      cb_state=$(jq -r '.currentState // "unknown"' <"${body}" 2>/dev/null)
      if [[ "${cb_state}" == "healthy" ]]; then
        pass "prereq2:capella" "3" "cluster ${cluster_id} is healthy"
      else
        fail "prereq2:capella" "3" "cluster ${cluster_id} currentState is '${cb_state}', expected healthy"
      fi
    else
      fail "prereq2:capella" "3" "Capella API returned HTTP ${code} for cluster ${cluster_id}"
    fi
    rm -f "${body}"
  fi

  # Prerequisite 6: DR cluster credentials usable.
  local gke_name gke_loc create_cluster
  gke_name=$(tfv_get dr_gke_name)
  gke_loc=$(tfv_get dr_gke_location)
  create_cluster=$(tfv_get create_gke_cluster)
  # Only a definite NOT_FOUND counts as "absent": a timeout or permission
  # error must not be read as "safe to create".
  local gke_err gke_rc
  for attempt in 1 2 3; do
    gke_err=$(with_timeout "${NET_TIMEOUT_SECONDS}" gcloud container clusters describe "${gke_name}" --location="${gke_loc}" --project="${project}" --format='value(status)' 2>&1)
    gke_rc=$?
    # 0=exists, non-0+NOT_FOUND=absent -> break; anything else may be a flake.
    { [[ ${gke_rc} -eq 0 ]] || echo "${gke_err}" | grep -qiE 'NOT_FOUND|404|not found'; } && break
    [[ ${attempt} -lt 3 ]] && sleep $((attempt * 3))
  done
  if [[ ${gke_rc} -eq 0 ]]; then
    # Existing cluster is fine whether create_gke_cluster is true (idempotent
    # re-apply after creation) or false (adopt path).
    pass "prereq6:gke-credentials" "1" "cluster ${gke_name} is describable (status ${gke_err})"
  elif echo "${gke_err}" | grep -qiE 'NOT_FOUND|404|not found'; then
    if [[ "${create_cluster}" == "true" ]]; then
      pass "prereq6:gke-credentials" "1" "cluster ${gke_name} absent; create_gke_cluster=true so Phase 1 will create it"
    else
      fail "prereq6:gke-credentials" "1" "cluster ${gke_name} not found in ${gke_loc} and create_gke_cluster=false"
    fi
  else
    fail "prereq6:gke-credentials" "1" "could not determine whether ${gke_name} exists (rc ${gke_rc}): $(echo "${gke_err}" | tail -1 | cut -c1-160)"
  fi
}

# ---------------------------------------------------------------------------
# Section 4: configuration correctness beyond mere presence
# ---------------------------------------------------------------------------

check_config_correctness() {
  echo
  echo "== configuration correctness =="

  # --- Cloud SQL: PRIVATE IP present ---------------------------------------
  local pg_method
  pg_method=$(tfv_get postgres_restore_method)
  if [[ "${pg_method:-psql_pod}" != "gcloud_sql_import" ]]; then
    skip "config:cloudsql-private-ip" "3" "postgres_restore_method=psql_pod; cloudsql_private_ip is used directly (checked under prereq3)"
    skip "config:cloudsql-sa-grant" "3" "postgres_restore_method=psql_pod; the dump is read by the in-cluster Job with gcp_credentials_file, not the Cloud SQL service agent"
  elif [[ "${OFFLINE}" == "true" || "${GCP_ACTIVATED}" != "true" ]]; then
    skip "config:cloudsql-private-ip" "3" "offline or GCP auth unavailable"
    skip "config:cloudsql-sa-grant" "3" "offline or GCP auth unavailable"
  else
    local project instance
    project=$(tfv_get project_id)
    instance=$(tfv_get cloudsql_instance_name)
    local ips
    ips=$(with_timeout "${NET_TIMEOUT_SECONDS}" gcloud sql instances describe "${instance}" --project="${project}" \
      --format='value(ipAddresses[].type)' 2>/dev/null)
    if echo "${ips}" | grep -qi PRIVATE; then
      pass "config:cloudsql-private-ip" "3" "instance ${instance} exposes a PRIVATE IP"
    else
      fail "config:cloudsql-private-ip" "3" "instance ${instance} has no PRIVATE IP; the Phase 3 in-cluster verify Job connects from inside the DR cluster and will fail without one"
    fi

    # --- Cloud SQL: service account can read the dump object --------------
    local sa bucket dump_obj
    sa=$(with_timeout "${NET_TIMEOUT_SECONDS}" gcloud sql instances describe "${instance}" --project="${project}" \
      --format='value(serviceAccountEmailAddress)' 2>/dev/null)
    bucket=$(tfv_get backup_bucket)
    dump_obj=$(backup_obj "$(tfv_get postgres_backup_object)")
    if [[ -z "${sa}" ]]; then
      warn "config:cloudsql-sa-grant" "3" "could not determine the Cloud SQL instance's service account; skipping the read-grant check"
    else
      local iam_json
      iam_json=$(with_timeout "${NET_TIMEOUT_SECONDS}" gcloud storage objects describe "gs://${bucket}/${dump_obj}" --format=json 2>/dev/null || true)
      # Object-level ACL isn't always populated under uniform bucket-level
      # access; fall back to a bucket-level IAM policy check for the SA.
      local grant
      grant=$(with_timeout "${NET_TIMEOUT_SECONDS}" gcloud storage buckets get-iam-policy "gs://${bucket}" --format=json 2>/dev/null \
        | jq -r --arg sa "serviceAccount:${sa}" \
          '.bindings[]? | select(.role | test("objectViewer|objectAdmin|legacyBucketReader|legacyObjectReader")) | .members[]? | select(. == $sa)' 2>/dev/null || true)
      if [[ -n "${grant}" ]]; then
        pass "config:cloudsql-sa-grant" "3" "Cloud SQL service account ${sa} has a read-capable IAM binding on gs://${bucket}"
      else
        warn "config:cloudsql-sa-grant" "3" "could not confirm ${sa} has read access to gs://${bucket}/${dump_obj} via bucket IAM policy; grant objectViewer if the Phase 3 import fails with a permission error"
      fi
    fi
  fi

  # --- Registry credentials -------------------------------------------------
  if [[ "${OFFLINE}" == "true" ]]; then
    skip "config:registry-credentials" "1,15" "offline mode"
  elif ! command -v aws >/dev/null 2>&1; then
    skip "config:registry-credentials" "1,15" "aws CLI absent on this bastion; the in-cluster refresher (module 15) validates this at bootstrap instead"
  else
    local registry key secret
    registry=$(tfv_get registry_server)
    key="${TF_VAR_ecr_access_key:-}"
    secret="${TF_VAR_ecr_secret_key:-}"
    if [[ -z "${key}" || -z "${secret}" ]]; then
      skip "config:registry-credentials" "1,15" "TF_VAR_ecr_access_key / TF_VAR_ecr_secret_key not set in this shell"
    elif [[ "${registry}" == *".ecr."* ]]; then
      local region
      region=$(echo "${registry}" | awk -F. '{print $4}')
      if AWS_ACCESS_KEY_ID="${key}" AWS_SECRET_ACCESS_KEY="${secret}" \
          with_timeout "${NET_TIMEOUT_SECONDS}" aws ecr get-login-password --region "${region}" >/dev/null 2>&1; then
        pass "config:registry-credentials" "1,15" "ECR token exchange succeeded for ${registry}"
      else
        fail "config:registry-credentials" "1,15" "ECR token exchange failed for ${registry} with the supplied TF_VAR_ecr_access_key/secret_key"
      fi
    else
      pass "config:registry-credentials" "1,15" "registry_server is not an ECR host; token exchange not applicable"
    fi
  fi

  # --- application config seed -----------------------------------------------
  # Phase 5b needs the cn Secret, which cannot be generated: Jans encrypted the
  # restored Couchbase bucket with its keys. Checked here because a rebuild
  # otherwise reaches Phase 3, spends two hours restoring Postgres, and only
  # then finds authn has nothing to start from.
  local oidcv2_on secret_dir cn_file
  oidcv2_on=$(tfv_get oidcv2_enabled)
  secret_dir=$(tfv_get app_config_secret_dir)
  secret_dir="${secret_dir/#\~/${HOME}}"

  if [[ "${oidcv2_on}" != "true" ]]; then
    skip "config:app-config-seed" "5b" "oidcv2_enabled is not true; oidcv2 is not deployed"
  elif [[ -z "${secret_dir}" ]]; then
    fail "config:app-config-seed" "5b" "oidcv2_enabled is true but app_config_secret_dir is empty; secret/cn cannot be seeded"
  elif [[ ! -d "${secret_dir}" ]]; then
    fail "config:app-config-seed" "5b" "app_config_secret_dir does not exist: ${secret_dir}"
  else
    cn_file="${secret_dir}/cn.yaml"
    if [[ ! -r "${cn_file}" ]]; then
      fail "config:app-config-seed" "5b" "secret/cn manifest not readable at ${cn_file}; see modules/55-app-config/examples/cn.secret.example.yaml for the required keys"
    else
      local missing=()
      for k in encoded_salt auth_openid_jks_pass auth_jks_base64 ssl_cert ssl_key; do
        grep -q "^  ${k}:" "${cn_file}" || missing+=("${k}")
      done
      if [[ ${#missing[@]} -gt 0 ]]; then
        fail "config:app-config-seed" "5b" "secret/cn at ${cn_file} is missing required keys: ${missing[*]}"
      else
        pass "config:app-config-seed" "5b" "secret/cn present at ${cn_file} with the crypto keys oidcv2 needs"
      fi
    fi
  fi

  # --- TLS certificate/key pair --------------------------------------------
  if ! command -v openssl >/dev/null 2>&1; then
    skip "config:tls-pair" "7" "openssl not present on this host"
  else
    local cert key
    cert=$(tfv_get pps_cert_file)
    key=$(tfv_get pps_key_file)
    cert="${cert/#\~/${HOME}}"
    key="${key/#\~/${HOME}}"
    if [[ ! -r "${cert}" || ! -r "${key}" ]]; then
      fail "config:tls-pair" "7" "certificate or key not readable (cert: ${cert:-unset}, key: ${key:-unset})"
    else
      local cert_mod key_mod
      cert_mod=$(openssl x509 -noout -modulus -in "${cert}" 2>/dev/null | openssl md5 2>/dev/null)
      key_mod=$(openssl rsa -noout -modulus -in "${key}" 2>/dev/null | openssl md5 2>/dev/null)
      if [[ -n "${cert_mod}" && "${cert_mod}" == "${key_mod}" ]]; then
        pass "config:tls-pair" "7" "certificate and key are a matching pair"
      else
        fail "config:tls-pair" "7" "certificate and key do not match (or key is not RSA-decodable): ${cert} / ${key}"
      fi
    fi
  fi

  # --- Bastion IP in master authorized networks ----------------------------
  if [[ "${OFFLINE}" == "true" ]]; then
    skip "config:bastion-authorized" "1" "offline mode; cannot determine this bastion's egress IP"
  else
    local my_ip
    my_ip=$(curl -sS --max-time 5 https://checkip.amazonaws.com 2>/dev/null | tr -d '[:space:]')
    if [[ -z "${my_ip}" ]]; then
      warn "config:bastion-authorized" "1" "could not determine this host's egress IP (no network / checkip unreachable); verify dr_gke_master_authorized_networks manually"
    else
      local matched="false"
      while IFS= read -r cidr; do
        [[ -z "${cidr}" ]] && continue
        if ip_in_cidr "${my_ip}" "${cidr}"; then
          matched="true"
          break
        fi
      done < <(tfv_authorized_cidrs)

      if [[ "${matched}" == "true" ]]; then
        pass "config:bastion-authorized" "1" "this host's egress IP (${my_ip}) is covered by dr_gke_master_authorized_networks"
      else
        fail "config:bastion-authorized" "1" "this host's egress IP (${my_ip}) is NOT in any configured dr_gke_master_authorized_networks CIDR; the cluster would build and then be unreachable from this bastion"
      fi
    fi
  fi

  # --- Pinned Helm chart versions resolve ----------------------------------
  # A case statement rather than an associative array (bash 4+ only, and
  # this gate is deliberately the lowest-friction, run-it-first check - it
  # should not carry a bash-version requirement the rest of the suite
  # doesn't already need).
  if [[ "${OFFLINE}" == "true" ]] || ! command -v helm >/dev/null 2>&1; then
    skip "config:chart-versions" "2,4,15" "offline mode or helm not present"
  else
    while IFS='=' read -r component version; do
      [[ -z "${component}" ]] && continue
      local repo="" chart="${component}"
      case "${component}" in
        consul)   repo="https://helm.releases.hashicorp.com" ;;
        vault)    repo="https://helm.releases.hashicorp.com" ;;
        openldap) repo="https://jp-gouin.github.io/helm-openldap"; chart="openldap-stack-ha" ;;
        zeebe)    repo="https://helm.camunda.io"; chart="camunda-platform" ;;
      esac
      if [[ -z "${repo}" ]]; then
        warn "config:chart-version:${component}" "2" "no known repository for platform component '${component}'; verify manually"
        continue
      fi
      if with_retry 3 with_timeout "${NET_TIMEOUT_SECONDS}" env HELM_REPOSITORY_CONFIG=/dev/null helm show chart "${chart}" --repo "${repo}" --version "${version}" >/dev/null 2>&1; then
        pass "config:chart-version:${component}" "2" "${chart} ${version} resolves from ${repo}"
      else
        fail "config:chart-version:${component}" "2" "${chart} version ${version} does not resolve from ${repo}"
      fi
    done < <(tfv_map_pairs platform_chart_versions)

    local argocd_ver
    argocd_ver=$(tfv_get argocd_chart_version)
    if [[ -n "${argocd_ver}" ]]; then
      if with_retry 3 with_timeout "${NET_TIMEOUT_SECONDS}" env HELM_REPOSITORY_CONFIG=/dev/null helm show chart argo-cd --repo https://argoproj.github.io/argo-helm --version "${argocd_ver}" >/dev/null 2>&1; then
        pass "config:chart-version:argocd" "4" "argo-cd ${argocd_ver} resolves"
      else
        fail "config:chart-version:argocd" "4" "argo-cd version ${argocd_ver} does not resolve from https://argoproj.github.io/argo-helm"
      fi
    fi

    # ESO comes from the same ECR as every other PPS chart (the restored
    # Argo CD Application points at it), so the pin is checked there. The
    # upstream repository is only the fallback for a non-ECR registry: it is
    # served from ghs.googlehosted.com, which this bastion cannot always reach
    # (2026-10-15: connection timeouts), and the pin 0.9.10 never existed as
    # the chart PPS actually deploys (1.0.5-pps).
    local eso_ver eso_registry eso_key eso_secret
    eso_ver=$(tfv_get eso_chart_version)
    eso_registry=$(tfv_get registry_server)
    eso_key="${TF_VAR_ecr_access_key:-}"
    eso_secret="${TF_VAR_ecr_secret_key:-}"
    if [[ -n "${eso_ver}" ]]; then
      if [[ "${eso_registry}" == *".ecr."* ]]; then
        if [[ -z "${eso_key}" || -z "${eso_secret}" ]] || ! command -v aws >/dev/null 2>&1; then
          skip "config:chart-version:eso" "5" "ECR credentials or aws CLI absent; cannot check external-secrets ${eso_ver} in ${eso_registry}"
        elif with_retry 3 helm_show_ecr_chart "${eso_registry}" external-secrets "${eso_ver}" "${eso_key}" "${eso_secret}"; then
          pass "config:chart-version:eso" "5" "external-secrets ${eso_ver} resolves from oci://${eso_registry}"
        else
          fail "config:chart-version:eso" "5" "external-secrets ${eso_ver} does not resolve from oci://${eso_registry} (eso_chart_version must be a tag of that repository, e.g. 1.0.5-pps)"
        fi
      elif with_retry 3 with_timeout "${NET_TIMEOUT_SECONDS}" env HELM_REPOSITORY_CONFIG=/dev/null helm show chart external-secrets --repo https://charts.external-secrets.io --version "${eso_ver}" >/dev/null 2>&1; then
        pass "config:chart-version:eso" "5" "external-secrets ${eso_ver} resolves"
      else
        fail "config:chart-version:eso" "5" "external-secrets version ${eso_ver} does not resolve from https://charts.external-secrets.io"
      fi
    fi
  fi

  # --- Configured Capella buckets exist -------------------------------------
  if [[ "${OFFLINE}" == "true" || -z "${TF_VAR_capella_api_token:-}" ]]; then
    skip "config:capella-buckets" "3" "offline mode or TF_VAR_capella_api_token not set"
  else
    local capella_url token org proj_id cluster_id
    capella_url=$(tfv_get capella_api_url)
    token="${TF_VAR_capella_api_token:-}"
    org=$(tfv_get capella_organization_id)
    proj_id=$(tfv_get capella_project_id)
    cluster_id=$(tfv_get capella_cluster_id)
    local base="${capella_url}/v4/organizations/${org}/projects/${proj_id}/clusters/${cluster_id}"
    local buckets_json
    buckets_json=$(curl -sS --max-time 10 -H "Authorization: Bearer ${token}" -H "Accept: application/json" "${base}/buckets" 2>/dev/null)

    while IFS= read -r b; do
      [[ -z "${b}" ]] && continue
      local exists
      exists=$(echo "${buckets_json}" | jq -r --arg b "${b}" '.data[]? | select(.name == $b) | .name' 2>/dev/null)
      if [[ -z "${exists}" ]]; then
        fail "config:capella-bucket:${b}" "3" "bucket '${b}' not found on cluster ${cluster_id}"
      else
        pass "config:capella-bucket:${b}" "3" "bucket '${b}' exists"
      fi
    done < <(tfv_list capella_buckets)
  fi

  # --- Argo CD backup archive readable/parseable ----------------------------
  if [[ "${OFFLINE}" == "true" ]]; then
    skip "config:argocd-backup-parse" "4" "offline mode"
  else
    local bucket obj
    bucket=$(tfv_get backup_bucket)
    obj=$(backup_obj "$(tfv_get argocd_backup_object)")
    if [[ "${GCP_ACTIVATED}" != "true" ]]; then
      skip "config:argocd-backup-parse" "4" "GCP auth unavailable; cannot download the backup object to inspect it"
    else
      local tmp
      tmp=$(mktemp)
      if gcloud_backup storage cp "gs://${bucket}/${obj}" "${tmp}" >/dev/null 2>&1; then
        local check_file="${tmp}"
        case "${obj}" in
          *.tar.gz|*.tgz) tar -tzf "${tmp}" >/dev/null 2>&1 && check_file="ok" || check_file="" ;;
          *.gz) gunzip -t "${tmp}" >/dev/null 2>&1 && check_file="ok" || check_file="" ;;
          *) grep -qE '^(apiVersion|kind):' "${tmp}" 2>/dev/null && check_file="ok" || check_file="" ;;
        esac
        if [[ -n "${check_file}" ]]; then
          pass "config:argocd-backup-parse" "4" "gs://${bucket}/${obj} is readable and parses as its declared format"
        else
          fail "config:argocd-backup-parse" "4" "gs://${bucket}/${obj} downloaded but does not parse as its declared format"
        fi
      else
        fail "config:argocd-backup-parse" "4" "could not download gs://${bucket}/${obj} to verify it"
      fi
      rm -f "${tmp}"
    fi
  fi

  # --- GCS state backend accessible -----------------------------------------
  # Deliberately does NOT write a probe object to prove writability: this is
  # the real terraform/state-v2 prefix a live DR run uses, and this gate must
  # stay strictly read-only (requirement: "Every check is read-only"). A
  # write-then-delete probe against production state is exactly the kind of
  # self-inflicted risk that requirement exists to rule out - a failed
  # cleanup on a network blip would leave a stray object in real DR state.
  # Instead: confirm the bucket is reachable and infer write capability from
  # the calling identity's IAM roles, same approach as the Cloud SQL
  # service-account grant check above. Inconclusive is a warning, not a
  # blocker, because IAM policy inspection here cannot see project-level
  # bindings that also grant access.
  if [[ "${OFFLINE}" == "true" || "${GCP_ACTIVATED}" != "true" ]]; then
    skip "config:state-backend-accessible" "0" "offline mode or GCP auth unavailable"
  else
    local state_bucket="dr-icrypto-gke-iac"
    # Reachability is tested the way tofu uses the bucket: by listing the state
    # prefix, which needs only object access. `buckets describe` needs
    # storage.buckets.get, a bucket-level permission that objectAdmin does not
    # carry; it started failing on 2026-10-20 although the state was readable and
    # the build needs nothing but objects.
    if ! with_timeout "${NET_TIMEOUT_SECONDS}" gcloud storage ls "gs://${state_bucket}/terraform/" >/dev/null 2>&1 \
        && ! with_timeout "${NET_TIMEOUT_SECONDS}" gcloud storage buckets describe "gs://${state_bucket}" >/dev/null 2>&1; then
      fail "config:state-backend-accessible" "0" "gs://${state_bucket} cannot be listed or described with the supplied credentials; tofu init will fail on the backend before reaching any other check"
    else
      local caller
      caller=$(gcloud config get-value account 2>/dev/null)
      local write_role
      write_role=$(with_timeout "${NET_TIMEOUT_SECONDS}" gcloud storage buckets get-iam-policy "gs://${state_bucket}" --format=json 2>/dev/null \
        | jq -r --arg m "serviceAccount:${caller}" --arg m2 "user:${caller}" \
          '.bindings[]? | select(.role | test("objectAdmin|storage\\.admin|objectCreator")) | select(.members[]? == $m or .members[]? == $m2) | .role' 2>/dev/null | head -1)
      if [[ -n "${write_role}" ]]; then
        pass "config:state-backend-accessible" "0" "gs://${state_bucket} reachable; ${caller} holds ${write_role}"
      else
        warn "config:state-backend-accessible" "0" "gs://${state_bucket} is reachable but a write-capable IAM role for ${caller:-the active account} was not found on the bucket policy directly; it may still be granted at project level. Verify tofu init succeeds, or check IAM manually."
      fi
    fi
  fi
}

# ---------------------------------------------------------------------------
# Entry point used by both prevalidate.sh and modules/00-preflight
# ---------------------------------------------------------------------------

run_prevalidation() {
  local tfvars_file="$1" report_path="$2"
  tfv_load "${tfvars_file}"

  echo "DR prevalidation gate"
  echo "tfvars: ${tfvars_file}"
  echo "mode:   $([[ "${OFFLINE}" == "true" ]] && echo offline || echo online)"
  echo

  check_tooling
  check_placeholders
  check_prerequisites
  check_config_correctness

  write_report "${report_path}"
  summarise "${report_path}"
}
