#!/usr/bin/env bash
# Shared helpers for the DR prevalidation gate: result recording, severity
# handling, reporting, and a small tfvars parser.
#
# Sourced by prevalidate/checks.sh. Not executable on its own.

# --------------------------------------------------------------------------
# Results
#
# Three severities, because two are not enough:
#   blocker - will fail the DR run. Exits non-zero.
#   warning - suspicious but survivable (e.g. an empty Capella bucket on a
#             first-ever DR build).
#   skipped - the feature is disabled, so the check does not apply. Recorded
#             explicitly: a silently absent check is indistinguishable from a
#             passing one, and that is how operators learn to ignore a gate.
# --------------------------------------------------------------------------

ENTRIES=()
BLOCKERS=()
WARNINGS=()
SKIPPED=()
PASSED=0

# record <id> <phase> <severity> <status> <detail>
#   status: pass | fail | skip
record() {
  local id="$1" phase="$2" severity="$3" status="$4" detail="$5"
  local esc
  esc=$(printf '%s' "${detail}" | tr '\n' ' ' | sed 's/\\/\\\\/g; s/"/\\"/g')

  ENTRIES+=("$(printf '{"check":"%s","phase":"%s","severity":"%s","status":"%s","detail":"%s"}' \
    "${id}" "${phase}" "${severity}" "${status}" "${esc}")")

  case "${status}" in
    pass) PASSED=$((PASSED + 1)); printf '  \033[32mPASS\033[0m  %-42s %s\n' "${id}" "${detail}" ;;
    skip) SKIPPED+=("${id}: ${detail}"); printf '  \033[90mSKIP\033[0m  %-42s %s\n' "${id}" "${detail}" ;;
    fail)
      if [[ "${severity}" == "blocker" ]]; then
        BLOCKERS+=("${id}|${phase}|${detail}")
        printf '  \033[31mFAIL\033[0m  %-42s %s\n' "${id}" "${detail}"
      else
        WARNINGS+=("${id}|${phase}|${detail}")
        printf '  \033[33mWARN\033[0m  %-42s %s\n' "${id}" "${detail}"
      fi
      ;;
  esac
}

# Convenience wrappers.
pass()  { record "$1" "$2" "blocker" "pass" "$3"; }
fail()  { record "$1" "$2" "blocker" "fail" "$3"; }
warn()  { record "$1" "$2" "warning" "fail" "$3"; }
skip()  { record "$1" "$2" "skipped" "skip" "$3"; }

write_report() {
  local path="$1" result="pass"
  [[ ${#BLOCKERS[@]} -gt 0 ]] && result="fail"

  mkdir -p "$(dirname "${path}")"
  local joined
  joined=$(IFS=,; echo "${ENTRIES[*]:-}")
  cat >"${path}" <<EOF
{
  "gate": "dr-prevalidation",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "result": "${result}",
  "counts": {
    "passed": ${PASSED},
    "blockers": ${#BLOCKERS[@]},
    "warnings": ${#WARNINGS[@]},
    "skipped": ${#SKIPPED[@]}
  },
  "checks": [${joined}]
}
EOF
}

# Print the summary and set the exit code. Blockers first, each naming the
# phase it protects - that is what turns a check list into a triage tool.
summarise() {
  local report_path="$1"

  echo
  echo "=============================================================="
  printf 'passed: %d   blockers: %d   warnings: %d   skipped: %d\n' \
    "${PASSED}" "${#BLOCKERS[@]}" "${#WARNINGS[@]}" "${#SKIPPED[@]}"
  echo "=============================================================="

  if [[ ${#WARNINGS[@]} -gt 0 ]]; then
    echo
    echo "WARNINGS (do not block the run):"
    for w in "${WARNINGS[@]}"; do
      IFS='|' read -r id phase detail <<<"${w}"
      printf '  - [%s] %s\n      %s\n' "${phase}" "${id}" "${detail}"
    done
  fi

  if [[ ${#SKIPPED[@]} -gt 0 ]]; then
    echo
    echo "SKIPPED (feature disabled or not applicable):"
    for s in "${SKIPPED[@]}"; do echo "  - ${s}"; done
  fi

  if [[ ${#BLOCKERS[@]} -gt 0 ]]; then
    echo
    echo "BLOCKERS - the DR run WILL fail on these:" >&2
    for b in "${BLOCKERS[@]}"; do
      IFS='|' read -r id phase detail <<<"${b}"
      printf '  - [%s] %s\n      %s\n' "${phase}" "${id}" "${detail}" >&2
    done
    echo >&2
    echo "Report: ${report_path}" >&2
    return 1
  fi

  echo
  echo "Prevalidation PASSED. Report: ${report_path}"
  return 0
}

# --------------------------------------------------------------------------
# Tooling
# --------------------------------------------------------------------------

# require_bin <bin> <phase> <severity> [reason]
require_bin() {
  local bin="$1" phase="$2" severity="$3" reason="${4:-}"
  if command -v "${bin}" >/dev/null 2>&1; then
    record "tooling:${bin}" "${phase}" "${severity}" "pass" "present${reason:+ (${reason})}"
  else
    record "tooling:${bin}" "${phase}" "${severity}" "fail" \
      "${bin} not on the DR bastion PATH${reason:+; needed for ${reason}}"
  fi
}

# --------------------------------------------------------------------------
# tfvars parsing
#
# A deliberately narrow HCL subset covering exactly the shapes pps-dr.tfvars
# uses. Evaluating real HCL would mean `tofu console`, which needs init and a
# backend - the very thing this gate exists to run ahead of.
#
# Anything unparseable is a loud failure, never a silently skipped check.
# --------------------------------------------------------------------------

TFVARS_FILE=""

tfv_load() {
  TFVARS_FILE="$1"
  if [[ ! -r "${TFVARS_FILE}" ]]; then
    echo "ERROR: tfvars file not readable: ${TFVARS_FILE}" >&2
    exit 2
  fi
}

# Strip comments and trailing whitespace, keep structure.
_tfv_clean() {
  sed -e 's/[[:space:]]*#.*$//' -e 's/[[:space:]]*$//' "${TFVARS_FILE}"
}

# tfv_get <key> -> scalar value, quotes stripped. Empty when unset.
tfv_get() {
  _tfv_clean | awk -v k="$1" '
    $0 ~ "^[[:space:]]*"k"[[:space:]]*=" {
      sub("^[[:space:]]*"k"[[:space:]]*=[[:space:]]*", "")
      gsub(/^"|"$/, "")
      print
      exit
    }'
}

# tfv_list <key> -> one element per line, quotes stripped.
# Handles both single-line ["a","b"] and multi-line forms.
tfv_list() {
  _tfv_clean | awk -v k="$1" '
    BEGIN { inblock = 0 }
    inblock == 0 && $0 ~ "^[[:space:]]*"k"[[:space:]]*=[[:space:]]*\\[" {
      line = $0
      sub("^[[:space:]]*"k"[[:space:]]*=[[:space:]]*\\[", "", line)
      if (line ~ /\]/) { sub(/\].*$/, "", line); print line; exit }
      inblock = 1
      if (line != "") print line
      next
    }
    inblock == 1 {
      if ($0 ~ /^[[:space:]]*\]/) { exit }
      print
    }
  ' | tr ',' '\n' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
      -e 's/^"//' -e 's/"$//' | grep -v '^$'
}

# tfv_map_keys <key>  /  tfv_map_values <key>  /  tfv_map_pairs <key>
# For simple `key = { a = "1" ... }` maps.
_tfv_map_body() {
  _tfv_clean | awk -v k="$1" '
    BEGIN { inblock = 0 }
    inblock == 0 && $0 ~ "^[[:space:]]*"k"[[:space:]]*=[[:space:]]*\\{" {
      line = $0
      sub("^[[:space:]]*"k"[[:space:]]*=[[:space:]]*\\{", "", line)
      if (line ~ /\}/) { sub(/\}.*$/, "", line); print line; exit }
      inblock = 1
      next
    }
    inblock == 1 {
      if ($0 ~ /^[[:space:]]*\}/) { exit }
      print
    }'
}

tfv_map_pairs() {
  _tfv_map_body "$1" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//' \
    | grep -v '^$' \
    | sed -e 's/[[:space:]]*=[[:space:]]*/=/' -e 's/"//g'
}

tfv_map_keys()   { tfv_map_pairs "$1" | cut -d= -f1; }
tfv_map_values() { tfv_map_pairs "$1" | cut -d= -f2-; }

# CIDR blocks out of the dr_gke_master_authorized_networks object list.
tfv_authorized_cidrs() {
  _tfv_clean | awk '
    BEGIN { inblock = 0 }
    inblock == 0 && /^[[:space:]]*dr_gke_master_authorized_networks[[:space:]]*=[[:space:]]*\[/ { inblock = 1; next }
    inblock == 1 {
      if ($0 ~ /^[[:space:]]*\]/) { exit }
      print
    }' | grep -oE 'cidr_block[[:space:]]*=[[:space:]]*"[^"]+"' \
       | sed -e 's/.*"\(.*\)"/\1/'
}

# True when the value is a boolean true.
tfv_is_true() { [[ "$(tfv_get "$1")" == "true" ]]; }

# --------------------------------------------------------------------------
# Network-call timeout
#
# The entire point of this gate is to fail in seconds, not minutes. An
# unbounded gcloud/helm/curl call against a slow or unreachable endpoint
# would defeat that. GNU `timeout` (coreutils) is used when present - the
# real DR bastion is Linux; a portable background+kill fallback covers dev
# machines without it (e.g. stock macOS).
# --------------------------------------------------------------------------

NET_TIMEOUT_SECONDS="${NET_TIMEOUT_SECONDS:-15}"

# A single network failure should not block a 3-hour build. The bastion's
# outbound path is intermittent - on 2026-10-12 the external-secrets index
# (113KB) failed to download once at 10:21 and resolved on the next attempt
# 90 seconds later, which cost a whole apply - so every network check retries
# before it is called a blocker.
with_retry() {
  local attempts="$1"
  shift
  local i rc
  for (( i = 1; i <= attempts; i++ )); do
    "$@" && return 0
    rc=$?
    [[ "${i}" -lt "${attempts}" ]] && sleep 3
  done
  return "${rc}"
}

with_timeout() {
  local secs="$1"
  shift
  if command -v timeout >/dev/null 2>&1; then
    timeout "${secs}" "$@"
    return $?
  fi
  "$@" &
  local pid=$!
  ( sleep "${secs}"; kill -TERM "${pid}" 2>/dev/null ) &
  local watcher=$!
  local rc
  wait "${pid}" 2>/dev/null
  rc=$?
  kill "${watcher}" 2>/dev/null
  wait "${watcher}" 2>/dev/null
  return "${rc}"
}

# --------------------------------------------------------------------------
# IPv4 CIDR containment, pure bash - no python3/dnsutils dependency added
# just for this one check.
# --------------------------------------------------------------------------

_ipv4_to_int() {
  local IFS=.
  local -a o=($1)
  echo $(( (o[0] << 24) + (o[1] << 16) + (o[2] << 8) + o[3] ))
}

# ip_in_cidr <ip> <cidr> -> 0 if ip is inside cidr, 1 otherwise
ip_in_cidr() {
  local ip="$1" cidr="$2"
  local net="${cidr%/*}" bits="${cidr#*/}"
  [[ "${ip}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || return 1
  [[ "${net}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]] || return 1
  [[ "${bits}" =~ ^[0-9]+$ ]] || return 1
  local ip_int net_int mask
  ip_int=$(_ipv4_to_int "${ip}")
  net_int=$(_ipv4_to_int "${net}")
  if [[ "${bits}" -eq 0 ]]; then
    mask=0
  else
    mask=$(( 0xFFFFFFFF << (32 - bits) & 0xFFFFFFFF ))
  fi
  [[ $(( ip_int & mask )) -eq $(( net_int & mask )) ]]
}

# helm_show_ecr_chart <registry> <chart> <version> <access_key> <secret_key>
# Succeeds when oci://<registry>/<chart> has that version. Logs in with a
# private registry config so nothing is left behind in the operator's helm
# state. A function, so with_timeout cannot wrap it; each network call carries
# its own timeout instead.
helm_show_ecr_chart() {
  local registry="$1" chart="$2" version="$3" key="$4" secret="$5" region cfg token rc t=()
  command -v timeout >/dev/null 2>&1 && t=(timeout "${NET_TIMEOUT_SECONDS:-30}")
  region=$(echo "${registry}" | awk -F. '{print $4}')
  cfg=$(mktemp); echo "{}" > "${cfg}"   # helm rejects an empty registry config
  token=$(AWS_ACCESS_KEY_ID="${key}" AWS_SECRET_ACCESS_KEY="${secret}" "${t[@]}" aws ecr get-login-password --region "${region}" 2>/dev/null) || { rm -f "${cfg}"; return 1; }
  HELM_REGISTRY_CONFIG="${cfg}" "${t[@]}" helm registry login "${registry}" --username AWS --password-stdin <<<"${token}" >/dev/null 2>&1 \
    && HELM_REGISTRY_CONFIG="${cfg}" "${t[@]}" helm show chart "oci://${registry}/${chart}" --version "${version}" >/dev/null 2>&1
  rc=$?
  rm -f "${cfg}"
  return "${rc}"
}
