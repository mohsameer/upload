# DR Execution Plan

Working document for turning this repo from "placeholder-safe code" into a
real DR run, once PPS supplies the environment values.

**Current state:** code complete (OpenSpec change `pps-dr-iaac-v2`, 87/91
tasks). The 4 open tasks are §13 of
[`openspec/changes/pps-dr-iaac-v2/tasks.md`](openspec/changes/pps-dr-iaac-v2/tasks.md)
and are all blocked on PPS. Nothing further needs to be written — what
remains is value intake, one rehearsal, then the real run.

Everything below runs from the **DR bastion VM**. Tick the boxes as you go.

---

## Stage A — Intake from PPS

Two deliverables from PPS: **answers** to the open questions, and **values**
for the table below. Do not start Stage B until both are in hand.

### A1. Open questions (from `design.md`)

Each of these changes what gets built, so they are answered before values are
filled, not during the run.

- [ ] **OpenSearch** — does the DR site still need it? It existed in the v1
      repo but appears in none of the 8 phases. If yes, it becomes a fifth
      component in `modules/20-platform` and this is a code change, not a
      config change.
- [ ] **Zeebe backing store** — self-contained in DR, or does it need an
      external Elasticsearch/PostgreSQL? Current
      `modules/20-platform/values/zeebe.yaml.tftpl` disables Operate,
      Tasklist, Optimize, Identity, Connectors and Elasticsearch.
- [ ] **Couchbase restore path, per bucket** — Capella's own backup service
      (`capella_api`), a `cbbackupmgr` tarball (`cbbackupmgr`, runs on the
      bastion, which needs `cbbackupmgr`), or a `cbexport` JSON file
      (`cbimport`, runs in-cluster; needs a key rule in
      `couchbase_cbimport_key_modes`). Sets `couchbase_restore_methods`.
- [ ] **Argo CD backup format** — `argocd admin export` output, or a
      third-party backup tool? `modules/40-argocd/argocd_restore.sh` assumes
      a YAML manifest export (plain, `.gz`, or `.tar.gz`). Anything else
      needs a different restore step.
- [ ] **IDM audit partitioning** — does the DR Cloud SQL instance already
      carry the partitioned audit schema, or does the restore supply it?
      Affects prerequisite 1 and the Phase 3 post-restore assertions.
- [ ] **DR hostname set** — confirm `truepolicy`, `oidc`, `sidas`, `admin`,
      `idm` under `pps.co.za` is still complete and correct. Anything missing
      here surfaces as a missing DNS record at Phase 7, which costs a full
      DNS change cycle to fix.
- [ ] **DR region and project** — v1 hardcoded `europe-west4` /
      `pps-qa-29102018`. Both are variables now and need real values.
- [ ] **ECR registry and credentials** — which AWS account and IAM principal
      issues the DR ECR credentials, and is it the same key already used in
      QA? Is the DR registry the same `eu-west-1` registry, or one replicated
      into the DR region? A cross-region pull works but adds latency to every
      Phase 6 image pull. Should `registry_runner_image` be mirrored into a
      registry PPS controls rather than pulled from Docker Hub at bootstrap?

### A2. Values needed

24 values carry a `REPLACE_ME_*` placeholder and **will fail the apply** if
left unset. They are marked **[hard]** below. The rest are dummy values that
**pass validation silently** and will build a broken site — marked
**[silent]**. Treat [silent] rows with more care than [hard] rows, not less.

#### GCP / global

| Variable | Guard | What PPS must give |
|---|---|---|
| `project_id` | [hard] | GCP project that owns the DR site |
| `dr_region` | [hard] | DR region, e.g. `europe-west4` |
| `gcp_credentials_file` | [hard] | Path on the DR bastion to the SA key JSON |
| `kubeconfig_path` | — | Defaults to `~/.kube/config`; change only if the bastion differs |

#### Phase 1 — cluster

| Variable | Guard | What PPS must give |
|---|---|---|
| `dr_gke_name` | [hard] | DR cluster name |
| `dr_gke_location` | [hard] | Region or zone of the cluster |
| `dr_gke_node_locations` | [hard] | Node zone(s) |
| `dr_gke_node_sa_account` | [hard] | Node service account email |
| `dr_gke_network_link` | [hard] | VPC self-link or name |
| `dr_gke_subnetwork_link` | [hard] | Subnet self-link or name |
| `dr_gke_cluster_ipv4_cidr_block` | **[silent]** | Real pod secondary range (example ships `10.200.0.0/16`) |
| `dr_gke_services_ipv4_cidr_block` | **[silent]** | Real service secondary range (example ships `10.201.0.0/20`) |
| `dr_gke_master_ipv4_cidr_block` | **[silent]** | Real control-plane range (example ships `172.31.255.0/28`) |
| `dr_gke_master_authorized_networks` | **[silent]** | Real bastion/jumpbox CIDRs. Example ships `192.0.2.10/32` and `.11/32` (TEST-NET-1). Wrong values here lock you out of your own control plane. |
| `create_gke_cluster` | — | `true` to build, `false` to adopt an existing DR cluster |
| `dr_gke_machine_type` / `disk_size_gb` / `disk_type` / `node_count` | — | Confirm sizing; defaults are `e2-standard-8` / 200GB / `pd-balanced` / 3 nodes |
| `registry_server` | [hard] | Private ECR registry hosting the iCrypto images and Helm OCI charts |
| `registry_runner_image` | **[silent]** | Image running the credential refresh (needs `aws` + `kubectl`). Default `alpine/k8s:1.31.3` from Docker Hub. **Must be pullable without registry credentials** — it is the workload that creates them. Confirm whether PPS wants it mirrored somewhere they control. |
| `registry_refresh_schedule` | — | Default every 6h. Validation rejects anything slower than 6h, because ECR tokens die at 12h. |
| `argocd_repo_secret_name` | — | Default `icrypto-helm`, matching the other PPS environments |

#### Prerequisites — backups (GCS)

| Variable | Guard | What PPS must give |
|---|---|---|
| `backup_bucket` | [hard] | Bucket holding the verified production backups |
| `postgres_backup_object` | **[silent]** | Real object path (example: `backups/dummy/pg-backup-prod.sql`) |
| `consul_backup_object` | **[silent]** | Real object path |
| `vault_backup_object` | **[silent]** | Real object path |
| `ldap_backup_objects` | **[silent]** | Real LDIF paths, **in apply order** (config → secauth → data) |
| `couchbase_backup_objects` | **[silent]** | Bucket → object, for every `cbbackupmgr` / `cbimport` bucket |
| `couchbase_index_definitions_object` | — | Optional GSI definition file replayed after the restore |
| `argocd_backup_object` | **[silent]** | Real Argo CD backup path |

Every object must be readable by the identity in `gcp_credentials_file`
(Terraform reads them as data sources, and the in-cluster restore Jobs use the
same key). Objects held in another project's bucket are staged into a DR
bucket first.

On `postgres_restore_method = "gcloud_sql_import"` also confirm the **Cloud
SQL instance's service account** has read access to the Postgres dump object
— that import runs as that identity, not as the bastion.
`modules/30-data-restore` outputs `cloudsql_service_account` for exactly this.

#### Prerequisite — Cloud SQL

| Variable | Guard | What PPS must give |
|---|---|---|
| `postgres_restore_method` | — | `psql_pod` (default; in-cluster Job over the private IP, no Cloud SQL Admin API) or `gcloud_sql_import` (needs `allow_gcloud_sql_import = true` and sqladmin reachable from the bastion) |
| `cloudsql_private_ip` | [hard] | Private IP of the instance — required for `psql_pod` |
| `cloudsql_instance_name` | [hard] | Existing instance in the DR region — `gcloud_sql_import` only |
| `postgres_recreate_database` | — | `true` drops and recreates the target DB before a `psql_pod` load; otherwise a non-empty target fails |
| `cloudsql_database_name` | [hard] | Database the dump is imported into |
| `cloudsql_import_user` | [hard] | Role used for import + verification |
| — | — | Instance must have a **PRIVATE IP**; the Phase 3 verify job connects from inside the cluster and fails without one |

#### Prerequisite — Capella

| Variable | Guard | What PPS must give |
|---|---|---|
| `capella_organization_id` | [hard] | Org UUID |
| `capella_project_id` | **[silent]** | Real project UUID (example ships all-zeroes) |
| `capella_cluster_id` | **[silent]** | Real cluster UUID (example ships all-zeroes) |
| `capella_connection_string` | **[silent]** | Real `couchbases://...` (example ships `cb.dummy.cloud.couchbase.com`) |
| `capella_buckets` | **[silent]** | Real bucket list (example ships `dummy-sessions`, `dummy-cred`) |
| `couchbase_username` | [hard] | Capella DB user for restore verification |
| `couchbase_restore_methods` | — | Set from the A1 answer, per bucket |
| `couchbase_expected_doc_counts` | — | Minimum doc count per bucket for Phase 3 verification |

#### Phase 2 — platform

| Variable | Guard | What PPS must give |
|---|---|---|
| `platform_chart_versions` | **[silent]** | Confirm/pin consul, vault, openldap, zeebe chart versions. Example values are plausible but unverified against the DR bastion's Helm repos. |
| `platform_storage_sizes` / `platform_replicas` | — | Confirm sizing against production |
| `storage_class` | — | Confirm `standard-rwo` exists on the DR cluster |
| `ldap_base_dn` | [hard] | Real base DN |

#### Phase 4 — Argo CD

| Variable | Guard | What PPS must give |
|---|---|---|
| `argocd_chart_version` | — | Pinned; confirm it matches what the backup was taken from |
| `argocd_hostname` | **[silent]** | Real hostname (example ships `argocd.dummy.invalid`) |
| `git_repo_url` | [hard] | Deployment manifests repo |
| `git_user` | [hard] | Git user for that repo |

#### Phase 6 — app services

| Variable | Guard | What PPS must give |
|---|---|---|
| `service_versions` | **[silent]** | Argo CD Application name → version, pinned onto the Applications restored in Phase 4. Example ships `0.0.0-dummy` — this passes validation. Empty map keeps the restored revisions. |
| `app_of_apps_enabled` | — | `false` (default): PPS Applications are Helm OCI charts restored in Phase 4. `true` renders a git app-of-apps |
| `app_of_apps_path` / `app_of_apps_revision` | — | Only with `app_of_apps_enabled = true` |
| `app_namespaces` / `eso_target_namespaces` | — | Confirm; both default to `["default"]` |

#### Phase 7 — ingress and DNS

| Variable | Guard | What PPS must give |
|---|---|---|
| `dr_hostnames` | **[silent]** | Confirmed hostname set from A1 |
| `backend_services` | **[silent, worst]** | Hostname key → backing Service name. **Defaults to `{}`**, in which case the ingress renders backends literally named `REPLACE-ME-<key>-service`. Note the hyphens: no validation rule catches this, and the ingress comes up pointing at services that do not exist. Set this explicitly. |
| `pps_cert_file` | [hard] | Path on the bastion to the `*.pps.co.za` certificate |
| `pps_key_file` | [hard] | Path on the bastion to the matching private key |
| `ingress_class` / `ingress_namespace` | — | Confirm `nginx` / `default` |

#### Phase 8 — validation

| Variable | Guard | What PPS must give |
|---|---|---|
| `post_restart_services` | **[silent]** | Real workload list as `kind/name` (example ships `deployment/dummy-*`) |
| `health_check_endpoints` | **[silent]** | Real health URLs per service |
| `oidc_discovery_url` | **[silent]** | Real discovery URL |
| `oidc_validation_client_id` | [hard] | Client used for the token-issuance check |

### A3. Secrets (10, `TF_VAR_*` only — never in a tfvars file)

- [ ] `TF_VAR_ecr_access_key`
- [ ] `TF_VAR_ecr_secret_key`
- [ ] `TF_VAR_cloudsql_import_password`
- [ ] `TF_VAR_capella_api_token`
- [ ] `TF_VAR_couchbase_password`
- [ ] `TF_VAR_vault_root_token`
- [ ] `TF_VAR_ldap_admin_password`
- [ ] `TF_VAR_argocd_admin_password_bcrypt` (bcrypt **hash**, not plaintext)
- [ ] `TF_VAR_git_pat`
- [ ] `TF_VAR_oidc_validation_client_secret`

### A4. Bastion readiness

- [ ] `tofu` >= 1.9 installed
- [ ] `gcloud`, `kubectl`, `helm`, `jq`, `curl`, `openssl` on PATH
- [ ] `psql` (Phase 8 Postgres probe)
- [ ] `cbc` / libcouchbase (Phase 8 Couchbase probe)
- [ ] `cbbackupmgr` — only if a bucket in `couchbase_restore_methods` uses `cbbackupmgr`
- [ ] `aws` CLI — only if `registry_server` is an ECR host (bastion side; the in-cluster refresh brings its own)
- [ ] Bastion's egress IP is in `dr_gke_master_authorized_networks`
- [ ] Bastion can write to `gs://dr-icrypto-gke-iac/terraform/state-v2`

---

## Stage B — Fill and verify (no infrastructure touched)

### B1. Fill values

```bash
cp pps-dr.tfvars.example pps-dr.tfvars
```

Edit `pps-dr.tfvars`. It is git-ignored — never commit it.

### B2. Silent-dummy audit

`REPLACE_ME_*` is caught automatically. The dummies are not, so grep for them
by hand before every run:

```bash
grep -nE 'dummy|0\.0\.0|192\.0\.2\.|00000000-0000|REPLACE-ME|\.invalid' pps-dr.tfvars
```

- [ ] Zero matches, or every match consciously accepted
- [ ] `backend_services` is set and non-empty
- [ ] Every `service_versions` entry is a real version

### B3. Export secrets

```bash
export TF_VAR_ecr_access_key= TF_VAR_ecr_secret_key= TF_VAR_cloudsql_import_password= TF_VAR_capella_api_token= TF_VAR_couchbase_password= TF_VAR_vault_root_token= TF_VAR_ldap_admin_password= TF_VAR_argocd_admin_password_bcrypt= TF_VAR_git_pat= TF_VAR_oidc_validation_client_secret=
```

### B4. Init and plan

```bash
tofu init
```

```bash
tofu validate
```

```bash
tofu plan -var-file=pps-dr.tfvars -out=dr.tfplan
```

**Gate — the plan must show:**

- [ ] No create/update/destroy for `google_sql_database_instance` (prerequisite, read-only)
- [ ] No create/update/destroy for any Capella cluster/project resource
- [ ] No resource creating a public DNS record for a `pps.co.za` host
- [ ] `google_container_cluster` creating **or** being read as a data source — matching what `create_gke_cluster` says, not the other one

Stop and fix if any of these is wrong. Do not proceed on a plan you have not
read.

---

## Stage C — Rehearsal (strongly recommended before a real incident)

Run the whole thing once against a throwaway GCP project and a scratch
Capella cluster, with copies of real backups. A rehearsal finds the answers
you did not know you needed — a live incident is the wrong place to discover
that a chart version does not exist or the Argo CD backup is in an
unexpected format.

- [ ] Rehearsal `pps-dr.tfvars` pointed at throwaway project + scratch Capella
- [ ] Stage D executed end to end
- [ ] Sign-off report captured
- [ ] Per-phase wall-clock time recorded (feeds the RTO figure)
- [ ] Every surprise folded back into this repo via an OpenSpec change, not an ad-hoc `.tf` edit
- [ ] Rehearsal cluster torn down

---

## Stage D — Execution runbook

Each step has a gate. Do not carry a failed gate forward — the phase modules
are chained on `completed` outputs precisely so a half-built site cannot
advance, and bypassing that defeats the design.

### D1. Preflight alone (cheapest failure point)

```bash
tofu apply -target=module.preflight -var-file=pps-dr.tfvars
```

Verifies all 6 prerequisites read-only and writes
`modules/00-preflight/.dr-run/preflight-report.json`.

**Gate:** all checks `pass`. A failure names the exact prerequisite. Fix it
with PPS before anything is built.

### D2. Cluster — first-ever build only

```bash
tofu apply -target=module.dr_cluster -var-file=pps-dr.tfvars
```

Needed because the `kubernetes`/`helm` providers read a kubeconfig, which
cannot exist before the cluster does (design decision D4a). **Skip this step
entirely on any run where the DR cluster already exists.**

**Gate:** `kubectl get nodes` against the DR cluster returns the expected node
count.

### D3. Phases 0–7

```bash
tofu apply -var-file=pps-dr.tfvars
```

Runs preflight → cluster → platform → data restore → Argo CD → secrets → app
services → ingress. Stops at Phase 7; Phase 8 is deliberately not part of
this apply.

Expect this to be the long step — the Cloud SQL import of a full IDM dump
dominates it.

**Gates, in order:**

- [ ] Registry credentials: bootstrap Job succeeded, pull secret present in every namespace, and `icrypto-helm` present in the Argo CD namespace once Phase 4 has run
- [ ] Phase 2: Consul, Vault, OpenLDAP, Zeebe all Ready; Vault `initialized=true`, `sealed=false`
- [ ] Phase 3: `tofu output restore_report` shows every enabled restore completed; Postgres table-count and Capella per-bucket document-count assertions passed
- [ ] Phase 4: Argo CD Applications restored, destinations resolve to the DR cluster, auto-sync **held**
- [ ] Phase 5: every ExternalSecret in the target namespaces reports `SecretSynced`
- [ ] Phase 6: every Application `Synced` + `Healthy`, all workloads Ready
- [ ] Phase 7: `tofu output dns_change_request` shows every hostname mapped to a real ingress IP

### D4. DNS — PPS action

```bash
tofu output -json dns_change_request | jq .
```

Send that mapping to PPS as the DNS change request. This repo creates no DNS
records by design.

While waiting, do not re-run the apply for unrelated reasons: recreating the
ingress would allocate a new load balancer IP and invalidate the records PPS
is in the middle of creating.

### D5. DNS gate

```bash
./modules/70-ingress-dns/dns_resolution_check.sh "$(tofu output -json dns_change_request | jq -r '.records[].hostname' | tr '\n' ' ')"
```

Checks every hostname resolves **both** from the bastion and from inside the
cluster.

**Gate:** exits 0. Phase 8 does not run before this passes — services that
started while their hostnames were unresolvable will fail the validation for
the wrong reason.

### D6. Phase 8 — restart, validate, sign off

```bash
tofu apply -target=module.validation -var-file=pps-dr.tfvars
```

Graceful restart of `post_restart_services`, then: DNS, health endpoints,
OIDC discovery + token issuance, Couchbase session read/write, IDM Postgres
read/write, Argo CD health.

**Gate:** `sign-off-report.json` has `"result": "pass"`. The report is
written on failure too — that is the artefact to attach to the DR record
either way.

---

## Stage E — After the run

- [ ] Archive `sign-off-report.json`, `preflight-report.json` and the Phase 3
      `restore_report` with the DR exercise record
- [ ] Record measured wall-clock per phase; update the RTO figure in the DR
      plan document
- [ ] Set `postgres_restore_enabled` / `couchbase_restore_enabled` /
      `consul_restore_enabled` / `vault_restore_enabled` /
      `ldap_restore_enabled` to `false` if the site is to be kept running, so
      a routine re-apply cannot re-restore over live data
- [ ] Fold every deviation back into the repo through an OpenSpec change
      (`openspec-propose`), then `openspec-archive-change` for
      `pps-dr-iaac-v2`
- [ ] Push `feat/pps-dr-iaac-v2` and open the MR — CI runs validate plus a
      placeholder-plan and asserts the prerequisites stay read-only

---

## Recovery notes

| Failure | Recovery |
|---|---|
| Cloud SQL import fails partway | Import is not transactional. Drop and recreate `cloudsql_database_name`, then re-run Phase 3. The error message quotes the operation id. |
| Capella restore stuck | Job is polled for up to 2h, then fails. Check the Capella console for the restore job before re-running. |
| Vault sealed after restore | `modules/30-data-restore/vault_restore.sh` re-unseals from the `vault-unseal-keys` Secret in the platform namespace. If that Secret is lost, the DR Vault is unrecoverable — treat it as critical. |
| ExternalSecrets never sync | Phase 5 fails listing each unsynced one. Usually a wrong Vault KV path or the ESO Kubernetes-auth role not matching the ESO service account namespace. |
| Existing ingress hostname mismatch | Phase 7 refuses to adopt and reports the mismatch rather than serving the wrong hosts. Reconcile `dr_hostnames`, or delete the stale ingress — deleting changes the LB IP and needs a fresh DNS change request. |
| Applications point at production | Phase 4 fails listing them. Repoint destinations at the DR cluster before continuing; do not force past this. |
| `ImagePullBackOff` across the site | The ECR token has expired and the refresh CronJob is not running or is failing. Check `kubectl -n platform get cronjob registry-credential-refresh` and the last few Jobs; `kubectl -n platform get secret icrypto-registry -o jsonpath='{.metadata.annotations.pps-dr/last-refresh}'` shows how stale the credential is. Re-run `tofu apply -target=module.registry_credentials` to force a fresh bootstrap. |
| Argo CD cannot resolve OCI Helm charts | The `icrypto-helm` repository secret is stale or missing. Same CronJob owns it; same recovery. Argo CD's repo-server caches, so restart `deployment/argocd-repo-server` after the secret is refreshed. |
| Need to abandon and fall back to v1 | v1 code is on `main` with its own state prefix (`terraform/state`, untouched by v2's `terraform/state-v2`). Rollback is a branch checkout plus a backend prefix switch. |
