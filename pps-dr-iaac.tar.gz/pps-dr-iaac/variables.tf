# ---------------------------------------------------------------------------
# PPS DR IaC - root inputs
#
# Every environment-specific value ships as a "REPLACE_ME_*" placeholder in
# pps-dr.tfvars.example. The validation blocks below make an apply with a
# placeholder still in place fail loudly instead of half-building a DR site.
# Real values arrive from PPS; see openspec/changes/pps-dr-iaac-v2/design.md.
# ---------------------------------------------------------------------------

# --------------------------- GCP / global ----------------------------------

variable "project_id" {
  type        = string
  description = "GCP project that owns the DR site."
  validation {
    condition     = !startswith(var.project_id, "REPLACE_ME")
    error_message = "project_id is still a placeholder. Supply the real DR GCP project id."
  }
}

variable "dr_region" {
  type        = string
  description = "GCP region for the DR site."
  validation {
    condition     = !startswith(var.dr_region, "REPLACE_ME")
    error_message = "dr_region is still a placeholder."
  }
}

variable "gcp_credentials_file" {
  type        = string
  description = "Path to the GCP service account key JSON on the DR bastion."
  validation {
    condition     = !startswith(var.gcp_credentials_file, "REPLACE_ME")
    error_message = "gcp_credentials_file is still a placeholder."
  }
}

variable "backup_credentials_file" {
  type        = string
  description = "Service account key on the DR bastion that can READ backup_bucket. The prod backup bucket is readable only by the prod SA; the DR SA gets 403. Used for Terraform's backup-object reads, the bastion-side downloads and the in-cluster restore Jobs. Empty falls back to gcp_credentials_file."
  default     = ""
  validation {
    condition     = !startswith(var.backup_credentials_file, "REPLACE_ME")
    error_message = "backup_credentials_file is still a placeholder."
  }
}

variable "kubeconfig_path" {
  type        = string
  description = "Kubeconfig used by the kubernetes and helm providers. Phase 1 refreshes it via gcloud container clusters get-credentials."
  default     = "~/.kube/config"
}

variable "kubeconfig_context" {
  type        = string
  description = "Kubeconfig context for the DR cluster. Empty means current-context."
  default     = ""
}

# --------------------------- Phase 1: cluster ------------------------------

variable "cluster_deletion_protection" {
  type        = bool
  description = <<-EOT
    GKE deletion protection. The provider defaults it to true, which refuses
    the delete and breaks a single-pass tofu destroy. A DR site that exists to
    be rebuilt sets it false, so the teardown completes in one run; a cluster
    already created with it true must be applied once with it false before it
    can be destroyed.
  EOT
  default     = true
}

variable "create_gke_cluster" {
  type        = bool
  description = "true: create the DR GKE cluster. false: adopt the existing cluster as a data source."
  default     = true
}

variable "dr_gke_name" {
  type        = string
  description = "Name of the DR GKE cluster."
  validation {
    condition     = !startswith(var.dr_gke_name, "REPLACE_ME")
    error_message = "dr_gke_name is still a placeholder."
  }
}

variable "dr_gke_location" {
  type        = string
  description = "Location (region or zone) of the DR GKE cluster."
  validation {
    condition     = !startswith(var.dr_gke_location, "REPLACE_ME")
    error_message = "dr_gke_location is still a placeholder."
  }
}

variable "dr_gke_node_locations" {
  type        = list(string)
  description = "Zones the DR node pool runs in."
  default     = []
}

variable "dr_gke_machine_type" {
  type        = string
  description = "Machine type for DR nodes."
  default     = "e2-standard-8"
}

variable "dr_gke_disk_size_gb" {
  type        = number
  description = "Boot disk size per DR node, in GB."
  default     = 200
}

variable "dr_gke_disk_type" {
  type        = string
  description = "Boot disk type for DR nodes."
  default     = "pd-balanced"
}

variable "dr_gke_image_type" {
  type        = string
  description = "Node image type."
  default     = "COS_CONTAINERD"
}

variable "dr_gke_node_sa_account" {
  type        = string
  description = "Service account email attached to DR nodes."
  validation {
    condition     = !startswith(var.dr_gke_node_sa_account, "REPLACE_ME")
    error_message = "dr_gke_node_sa_account is still a placeholder."
  }
}

variable "dr_gke_network_link" {
  type        = string
  description = "Self link or name of the VPC network for the DR cluster."
  validation {
    condition     = !startswith(var.dr_gke_network_link, "REPLACE_ME")
    error_message = "dr_gke_network_link is still a placeholder."
  }
}

variable "dr_gke_subnetwork_link" {
  type        = string
  description = "Self link or name of the subnetwork for the DR cluster."
  validation {
    condition     = !startswith(var.dr_gke_subnetwork_link, "REPLACE_ME")
    error_message = "dr_gke_subnetwork_link is still a placeholder."
  }
}

variable "dr_gke_networking_mode" {
  type        = string
  description = "GKE networking mode."
  default     = "VPC_NATIVE"
  validation {
    condition     = contains(["VPC_NATIVE", "ROUTES"], var.dr_gke_networking_mode)
    error_message = "dr_gke_networking_mode must be VPC_NATIVE or ROUTES."
  }
}

variable "dr_gke_cluster_ipv4_cidr_block" {
  type        = string
  description = "Secondary range CIDR for pods."
}

variable "dr_gke_services_ipv4_cidr_block" {
  type        = string
  description = "Secondary range CIDR for services."
}

variable "dr_gke_master_ipv4_cidr_block" {
  type        = string
  description = "CIDR for the private control plane endpoint."
}

variable "dr_gke_master_authorized_networks" {
  type = list(object({
    cidr_block   = string
    display_name = string
  }))
  description = "Bastion/jumpbox CIDRs allowed to reach the control plane. Public access stays disabled."
  validation {
    condition     = length(var.dr_gke_master_authorized_networks) > 0
    error_message = "At least one master authorized network is required; the control plane is never opened to 0.0.0.0/0."
  }
  validation {
    condition     = alltrue([for n in var.dr_gke_master_authorized_networks : n.cidr_block != "0.0.0.0/0"])
    error_message = "0.0.0.0/0 is not an acceptable master authorized network."
  }
}

variable "dr_gke_node_pool_name" {
  type        = string
  description = "Name of the DR node pool."
  default     = "icrypto"
}

variable "dr_gke_node_count" {
  type        = number
  description = "Nodes in the DR node pool. The DR plan calls for 3."
  default     = 3
  validation {
    condition     = var.dr_gke_node_count >= 1
    error_message = "dr_gke_node_count must be at least 1."
  }
}

variable "dr_gke_release_channel" {
  type        = string
  description = "GKE release channel."
  default     = "REGULAR"
}

# Fidelity with the live DR cluster (openspec change dr-drill-fixes, E1/E2).
# Defaults reproduce the module's previous output; pps-dr.tfvars sets the
# values captured from dr-icrypto-gke-cluster on 2026-10-05.

variable "dr_gke_datapath_provider" {
  type        = string
  description = "LEGACY_DATAPATH or ADVANCED_DATAPATH. Empty keeps the provider default."
  default     = ""
  validation {
    condition     = contains(["", "LEGACY_DATAPATH", "ADVANCED_DATAPATH"], var.dr_gke_datapath_provider)
    error_message = "dr_gke_datapath_provider must be empty, LEGACY_DATAPATH or ADVANCED_DATAPATH."
  }
}

variable "dr_gke_resource_labels" {
  type        = map(string)
  description = "GCP resource labels on the cluster."
  default     = {}
}

variable "dr_gke_node_resource_labels" {
  type        = map(string)
  description = <<-EOT
    GCP labels on the node VMs, which are what the org policy
    custom.requireComputeLabels checks: it denies any Compute instance without
    environment, agile_team and tiering labels. agile_team takes an
    underscore, and tiering wants the tierN form - `tiering = "1"` is refused.
    A node pool whose instances are denied leaves the cluster in ERROR with no
    nodes, which is how this was found.

    The cluster's own dr_gke_resource_labels do not satisfy the policy: the
    constraint is evaluated against each instance.
  EOT
  default     = {}
}

variable "dr_gke_oauth_scopes" {
  type        = list(string)
  description = "OAuth scopes for node VMs."
  default     = ["https://www.googleapis.com/auth/cloud-platform"]
}

variable "dr_gke_enable_integrity_monitoring" {
  type        = bool
  description = "Shielded node integrity monitoring."
  default     = true
}

variable "dr_gke_enable_secure_boot" {
  type        = bool
  description = "Shielded node secure boot."
  default     = false
}

variable "dr_gke_workload_metadata_mode" {
  type        = string
  description = "GKE_METADATA (Workload Identity) or GCE_METADATA. Empty leaves it unset."
  default     = ""
  validation {
    condition     = contains(["", "GKE_METADATA", "GCE_METADATA"], var.dr_gke_workload_metadata_mode)
    error_message = "dr_gke_workload_metadata_mode must be empty, GKE_METADATA or GCE_METADATA."
  }
}

variable "dr_gke_logging_components" {
  type        = list(string)
  description = "Cluster logging components, e.g. [\"SYSTEM_COMPONENTS\", \"WORKLOADS\"]. Empty leaves logging_config unset."
  default     = []
}

variable "dr_gke_managed_prometheus" {
  type        = bool
  description = "Google managed Prometheus. Null leaves monitoring_config unset."
  default     = null
}

variable "dr_gke_max_pods_per_node" {
  type        = number
  description = "Default max pods per node."
  default     = 110
}

variable "dr_gke_private_endpoint_enforcement" {
  type        = bool
  description = "Enforce private endpoint access for the master authorized networks."
  default     = false
}

variable "dr_gke_cluster_secondary_range_name" {
  type        = string
  description = "Adopt an existing subnet secondary range for pods by name. When set, dr_gke_cluster_ipv4_cidr_block is ignored."
  default     = ""
}

variable "dr_gke_services_secondary_range_name" {
  type        = string
  description = "Adopt an existing subnet secondary range for services by name. When set, dr_gke_services_ipv4_cidr_block is ignored."
  default     = ""
}

variable "platform_namespace" {
  type        = string
  description = "Namespace for the stateful platform components."
  default     = "platform"
}

variable "argocd_namespace" {
  type        = string
  description = "Namespace for Argo CD."
  default     = "argocd"
}

variable "external_secrets_namespace" {
  type        = string
  description = "Namespace for External Secrets Operator."
  default     = "external-secrets"
}

variable "app_namespaces" {
  type        = list(string)
  description = "Namespaces the iCrypto SSO services are deployed into."
  default     = ["default"]
}

variable "image_pull_secret_name" {
  type        = string
  description = "Name of the image pull secret created in each namespace."
  default     = "icrypto-registry"
}

variable "registry_server" {
  type        = string
  description = "Container registry hosting the iCrypto images."
  validation {
    condition     = !startswith(var.registry_server, "REPLACE_ME")
    error_message = "registry_server is still a placeholder."
  }
}

variable "ecr_access_key" {
  type        = string
  description = "Registry access key. Supply via TF_VAR_ecr_access_key."
  sensitive   = true
}

variable "ecr_secret_key" {
  type        = string
  description = "Registry secret key. Supply via TF_VAR_ecr_secret_key."
  sensitive   = true
}

variable "argocd_repo_secret_name" {
  type        = string
  description = "Argo CD repository secret carrying the ECR Helm OCI credential. Matches the name used in the other PPS environments."
  default     = "icrypto-helm"
}

variable "registry_refresh_schedule" {
  type        = string
  description = "Cron schedule for the in-cluster registry credential refresh. ECR tokens expire after 12h; every 6h leaves a full missed run of margin."
  default     = "0 */6 * * *"
}

variable "registry_runner_image" {
  type        = string
  description = "Image running the registry credential refresh. Needs aws + kubectl, and must be pullable WITHOUT registry credentials since it is what creates them."
  default     = "alpine/k8s:1.31.3"
}

variable "attach_pull_secret_to_default_sa" {
  type        = bool
  description = "Attach the pull secret to each namespace's default ServiceAccount so workloads need not declare imagePullSecrets."
  default     = true
}

# --------------------------- Prerequisites: backups ------------------------

variable "backup_bucket" {
  type        = string
  description = "GCS bucket holding the verified production backups. Owned outside this repo."
  validation {
    condition     = !startswith(var.backup_bucket, "REPLACE_ME")
    error_message = "backup_bucket is still a placeholder."
  }
}

variable "backup_prefix" {
  type        = string
  description = <<-EOT
    Folder inside backup_bucket holding one backup set, e.g. "5thoctober2026".
    Every *_backup_object(s), postgres_globals_object and
    couchbase_index_definitions_object is relative to it, so a new backup set
    only changes this value. Empty = object paths are bucket-relative.
    Recommended layout of a set (see README "Backup set layout"):
      <prefix>/postgresql/<db>.sql[.gz]   <prefix>/postgresql/globals.sql
      <prefix>/couchbase/<archive>.tar.gz <prefix>/consul/<export>.json|.snap
      <prefix>/ldap/ldap-{config,secauth,data}-backup.ldif
      <prefix>/argocd/<bundle>.tar.gz
  EOT
  default     = ""
  validation {
    condition     = !startswith(var.backup_prefix, "REPLACE_ME") && !startswith(var.backup_prefix, "gs://")
    error_message = "backup_prefix is a folder inside backup_bucket (no gs:// and no placeholder)."
  }
}

variable "postgres_backup_object" {
  type = string
  validation {
    condition     = !startswith(var.postgres_backup_object, "gs://") && !startswith(var.postgres_backup_object, "/")
    error_message = "postgres_backup_object is a path relative to backup_prefix inside backup_bucket, not a gs:// URL."
  }
  description = "Path (relative to backup_prefix) in backup_bucket for the PostgreSQL dump imported into Cloud SQL."
}

variable "postgres_globals_object" {
  type        = string
  description = "Optional pg_dumpall --globals-only file in backup_bucket, loaded into the postgres DB before the dump (psql_pod only). Errors from roles that exist or need superuser are reported, not fatal."
  default     = ""
}

variable "consul_backup_object" {
  type = string
  validation {
    condition     = !startswith(var.consul_backup_object, "gs://") && !startswith(var.consul_backup_object, "/")
    error_message = "consul_backup_object is a path relative to backup_prefix inside backup_bucket, not a gs:// URL."
  }
  description = "Path (relative to backup_prefix) in backup_bucket for the Consul KV/snapshot backup."
}

variable "vault_backup_object" {
  type = string
  validation {
    condition     = !startswith(var.vault_backup_object, "gs://") && !startswith(var.vault_backup_object, "/")
    error_message = "vault_backup_object is a path relative to backup_prefix inside backup_bucket, not a gs:// URL."
  }
  description = "Path (relative to backup_prefix) in backup_bucket for the Vault backup."
}

variable "ldap_backup_objects" {
  type        = list(string)
  description = "Paths (relative to backup_prefix) in backup_bucket for the OpenLDAP LDIF backups, applied in order."
  default     = []
}

variable "ldap_group_additions" {
  type        = map(string)
  description = "LDAP group DN -> search base DN. Every inetOrgPerson one level under the base is added to the group after the LDAP restore (idempotent). Default: the application service accounts under ou=services join adminWrite, because on DR they all write; on production they are read-only (adminRead). Empty keeps production's membership."
  default = {
    "cn=adminWrite,ou=roles,ou=admin,dc=ppspar,dc=PPSDMN" = "ou=services,ou=admin,dc=ppspar,dc=PPSDMN"
  }
}

variable "ldap_group_member_dns" {
  type        = map(list(string))
  description = "LDAP group DN -> named member DNs added after the LDAP restore (idempotent). Default: kmokgadi1 joins remote-acl-users, which gives that account read on secAuthority=Default (the adminRead/adminWrite groups are in the other database, so the access rules cannot use them there)."
  default = {
    "cn=remote-acl-users,cn=SecurityGroups,secAuthority=Default" = ["uid=kmokgadi1,ou=users,ou=admin,dc=ppspar,dc=PPSDMN"]
  }
}

variable "ldap_access_rules" {
  type        = map(list(string))
  description = "LDAP suffix -> access rules {0}, {1}, ... enforced on that database after the LDAP restore, whatever the restore set carried. Default: production's rules for dc=ppspar,dc=PPSDMN, which give adminWrite write and adminRead read. The restore set from 2026-10-13 predated them and DR's service accounts could read nothing (LDAP error 32). Empty leaves what the restore brought."
  default = {
    "dc=ppspar,dc=PPSDMN" = [
      "to attrs=userPassword,shadowLastChange by self write by dn.exact=gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth manage by group.exact=\"cn=adminWrite,ou=roles,ou=admin,dc=ppspar,DC=PPSDMN\" write by group.exact=\"cn=adminRead,ou=roles,ou=admin,dc=ppspar,DC=PPSDMN\" read by dn=\"cn=root,secAuthority=Default\" write by dn=\"cn=admin,dc=ppspar,dc=PPSDMN\" write by dn=\"principalName=sec_master,cn=Users,secAuthority=DEFAULT\" write by dn=cn=root,secAuthority=Default write by group=cn=SecurityGroup,secAuthority=Default write by group=cn=remote-acl-users,cn=SecurityGroups,secAuthority=Default read by group=cn=ivacld-servers,cn=SecurityGroups,secAuthority=Default read by anonymous auth by * none",
      "to * by self write by dn.exact=gidNumber=0+uidNumber=0,cn=peercred,cn=external,cn=auth manage by dn=\"cn=root,secAuthority=Default\" write by group.exact=\"cn=adminWrite,ou=roles,ou=admin,dc=ppspar,DC=PPSDMN\" write by group.exact=\"cn=adminRead,ou=roles,ou=admin,dc=ppspar,DC=PPSDMN\" read by dn=\"cn=admin,dc=ppspar,dc=PPSDMN\" write by dn=\"principalName=sec_master,cn=Users,secAuthority=DEFAULT\" write by dn=cn=root,secAuthority=Default write by group=cn=SecurityGroup,secAuthority=Default write  by group=cn=remote-acl-users,cn=SecurityGroups,secAuthority=Default read by group=cn=ivacld-servers,cn=SecurityGroups,secAuthority=Default read by * none",
    ]
  }
}

variable "ldap_admin_dn" {
  type        = string
  description = "DN the LDAP group step binds as. Empty means cn=admin,<ldap_base_dn>."
  default     = ""
}

variable "vault_kv_overrides" {
  type        = map(string)
  description = "Restored Vault values that name the source site, as KV path -> value, written after the Vault restore only when different. The defaults point the IdM trueLDAP and PRO-FiT resources at trueldap.pps.co.za (production's per-AZ name trueldap-az1 does not resolve here) and the MFA resource at the in-cluster mfa-facade-service (mfa.pps.co.za does not resolve here)."
  default = {
    "secret/idm/trueLDAP-host"            = "trueldap.pps.co.za"
    "secret/idm/pro-fit-serviceHost"      = "trueldap.pps.co.za"
    "secret/idm/mfa-domain"               = "http://mfa-facade-service.services.svc.cluster.local:8099"
    "secret/cred-mgmt-service/mfa-domain" = "http://mfa-facade-service.services.svc.cluster.local:8099/api/" # the reset flows POST to <this>mfa/internal/token; mfa.pps.co.za does not resolve on DR
  }
}

variable "vault_kv_couchbase_overrides" {
  type        = map(string)
  description = "KV path -> \"username\" or \"password\", set to the DR Capella account (couchbase_username, TF_VAR_couchbase_password). The IdM Directory resource reads production's Capella account from these otherwise, and its Test connection fails."
  default = {
    "secret/idm/idmDirectory-capella-user"     = "username"
    "secret/idm/idmDirectory-capella-password" = "password"
    # Found by scanning every Vault mount on 2026-10-21: each still held production's
    # Capella account or password after the restore.
    "secret/ext-authn-service/capella-auth-pass"                = "password" # the SSO login's bucket; production's password made every login fail
    "secret/oidc-v3/couchbase.capella.user"                     = "username"
    "secret/oidc-v3/couchbase.capella.pass"                     = "password"
    "secret/oidcv2/passwordExpiredScopeScript-capella-username" = "username"
    "secret/oidcv2/passwordExpiredScopeScript-capella-password" = "password"
    "secret/sage-autotermination/couchbase-user"                = "username"
    "secret/sage-autotermination/couchbase-pass"                = "password"
    "secret/session-mgmt-service/couchbase-user"                = "username"
    "secret/session-mgmt-service/couchbase-pass"                = "password"
  }
}

variable "vault_overrides_restart_workloads" {
  type        = list(string)
  description = "Workloads restarted when an override changed a value, as namespace/kind/name. Leave empty on a cold build (the readers have not started). On a live site set [\"services/deployment/idm-server-v2\"]."
  default     = []
}

variable "ldap_tls_objects" {
  type        = list(string)
  description = "Paths (relative to backup_prefix) of the LDAP certificate production serves: certificate, key and CA, in that set. Installed on the DR LDAP before the LDAP restore, so DR serves the same certificate and every client that pins it keeps trusting it. Empty leaves the certificate the image generates."
  default = [
    "ldap/tls/openldap.crt",
    "ldap/tls/openldap.key",
    "ldap/tls/openldapCA.crt",
  ]
}

variable "ldap_service_ldap_port" {
  type        = number
  description = "Port the LDAP Service (the internal load balancer) listens on for plain LDAP. The pod listens on 1389; 1389 is what production's clients use."
  default     = 1389
}

variable "ldap_service_ssl_port" {
  type        = number
  description = "Port the LDAP Service listens on for LDAPS. The pod listens on 1636."
  default     = 1636
}

variable "ldap_lb_ip" {
  type        = string
  description = "Fixed address for the LDAP internal load balancer (trueldap.pps.co.za). Empty lets GKE pick one, which changes on a rebuild. Reserved by this repo (ldap_lb_reserve) so nothing else takes it."
  default     = ""
}

variable "ldap_lb_reserve" {
  type        = bool
  description = "Reserve ldap_lb_ip as a named internal address in this state. False when it was reserved outside this repo (gcloud compute addresses create ... --addresses <ip>)."
  default     = true
}

variable "ldap_lb_address_name" {
  type        = string
  description = "Name of the reserved internal address for the LDAP load balancer."
  default     = "ldap-dr-int"
}

variable "argocd_backup_object" {
  type = string
  validation {
    condition     = !startswith(var.argocd_backup_object, "gs://") && !startswith(var.argocd_backup_object, "/")
    error_message = "argocd_backup_object is a path relative to backup_prefix inside backup_bucket, not a gs:// URL."
  }
  description = "Path (relative to backup_prefix) in backup_bucket for the Argo CD backup archive."
}

# --------------------------- Prerequisite: Cloud SQL -----------------------

variable "cloudsql_instance_name" {
  type        = string
  description = "Existing Cloud SQL PostgreSQL instance in the DR region. Read as a data source; never created here. Only needed when postgres_restore_method = \"gcloud_sql_import\"."
  default     = ""
  validation {
    condition     = !startswith(var.cloudsql_instance_name, "REPLACE_ME")
    error_message = "cloudsql_instance_name is still a placeholder."
  }
}

variable "postgres_databases" {
  type        = map(string)
  description = <<-EOT
    Database name -> backup object, one entry per database to restore. The
    production instance holds midpoint, idpv3 and oidc-mgmt-portal, and
    restoring only midpoint leaves the other two empty.

    Each database gets its own restore Job, so a failure isolates to that
    database. Leave empty to restore the single database named by
    cloudsql_database_name from postgres_backup_object.
  EOT
  default     = {}
}

variable "postgres_dump_format" {
  type        = string
  description = <<-EOT
    plain or custom.

    plain is a SQL text dump: psql replays it through a single connection, so
    the load uses one core and is bound by per-commit WAL flushes. 251GiB took
    130 minutes this way.

    custom is pg_dump -Fc, which pg_restore can load with
    postgres_restore_jobs workers - the only way to use more than one core.
    Parallel restore needs to seek, so the dump is staged on disk rather than
    streamed, and postgres_stage_size has to fit it.
  EOT
  default     = "plain"

  validation {
    condition     = contains(["plain", "custom"], var.postgres_dump_format)
    error_message = "postgres_dump_format must be plain or custom."
  }
}

variable "postgres_restore_jobs" {
  type        = number
  description = "pg_restore workers for a custom dump. Ignored for a plain dump."
  default     = 8
}

variable "postgres_stage_size" {
  type        = string
  description = "emptyDir size for a staged custom dump. Must exceed the dump."
  default     = "400Gi"
}

variable "postgres_session_tuning" {
  type        = string
  description = <<-EOT
    Session settings prepended to a plain dump, newline-separated. Defaults to
    turning synchronous_commit off and raising maintenance_work_mem and
    max_wal_size, which is the one large win available without changing the
    dump format: on a REGIONAL instance every commit otherwise waits for the
    standby. Safe for a bulk load, where losing recent commits on a crash means
    redoing a restore that would be redone anyway. Empty disables it.
  EOT
  default     = "SET synchronous_commit = off;\nSET maintenance_work_mem = '2GB';\nSET max_wal_size = '16GB';"
}

variable "postgres_restore_method" {
  type        = string
  description = <<-EOT
    How Phase 3 loads the PostgreSQL dump:
      psql_pod          - in-cluster Job streams the dump from GCS into psql over
                          cloudsql_private_ip. No Cloud SQL Admin API needed. Default.
      gcloud_sql_import - `gcloud sql import sql` from the bastion. Needs
                          sqladmin.googleapis.com reachable, cloudsql_instance_name,
                          and allow_gcloud_sql_import = true.
  EOT
  default     = "psql_pod"
  validation {
    condition     = contains(["psql_pod", "gcloud_sql_import"], var.postgres_restore_method)
    error_message = "postgres_restore_method must be psql_pod or gcloud_sql_import."
  }
}

variable "allow_gcloud_sql_import" {
  type        = bool
  description = "Explicit opt-in for postgres_restore_method = gcloud_sql_import. Keep false until sqladmin.googleapis.com is reachable from the DR bastion."
  default     = false
}

variable "cloudsql_private_ip" {
  type        = string
  description = "Private IP of the Cloud SQL instance. Required for psql_pod; when set it also overrides the IP read from the instance data source."
  default     = ""
  validation {
    condition     = !startswith(var.cloudsql_private_ip, "REPLACE_ME")
    error_message = "cloudsql_private_ip is still a placeholder."
  }
}

variable "postgres_recreate_database" {
  type        = bool
  description = "psql_pod only: DROP DATABASE ... WITH (FORCE) and CREATE it before loading. Destructive. Without it a non-empty target database fails the restore."
  default     = false
}

variable "postgres_cleanup_before_restore" {
  type        = bool
  description = "psql_pod only: empty each database in postgres_databases (DROP DATABASE ... WITH (FORCE), then CREATE) in its own step before it is restored. Destructive to whatever the DR instance holds under those names; databases it does not list are untouched. Skipped for a database whose restore Job already ran for this backup generation."
  default     = true
}

variable "postgres_future_partitions" {
  type        = number
  description = "psql_pod only: after a database is restored, call its create_future_partitions_for_m_audit_event/_delta functions with this count, so the audit INSERTs midPoint makes from the first start have a partition (500000 ids each; count + 1 are created). The restored audit tables keep production's partitions (ids ~98M-149M) but, with audit rows excluded, the id sequence restarts at 1, and midPoint's startup import fails with 'no partition of relation m_audit_event found for row'. 0 disables."
  default     = 10
  validation {
    condition     = var.postgres_future_partitions >= 0 && var.postgres_future_partitions == floor(var.postgres_future_partitions)
    error_message = "postgres_future_partitions must be a whole number, 0 or more."
  }
}

variable "postgres_future_partition_databases" {
  type        = list(string)
  description = "Databases from postgres_databases that carry the partitioned midPoint audit tables."
  default     = ["midpoint"]
}

variable "postgres_on_error_stop" {
  type        = bool
  description = "psql_pod only: stop the load at the first failing statement (psql ON_ERROR_STOP)."
  default     = true
}

variable "postgres_restore_timeout_seconds" {
  type        = number
  description = "psql_pod only: Job activeDeadlineSeconds and how long Phase 3 waits for it. A ~270 GB dump takes hours."
  default     = 86400
}

variable "postgres_fetch_image" {
  type        = string
  description = "psql_pod only: image that streams the dump from GCS (needs gcloud)."
  default     = "gcr.io/google.com/cloudsdktool/google-cloud-cli:stable"
}

variable "postgres_client_image" {
  type        = string
  description = <<-EOT
    Image running psql/pg_restore inside the DR cluster.

    Match the server's major version. The Cloud SQL target is PostgreSQL 16,
    and pg_restore 17 emits `SET transaction_timeout = 0` - a parameter that
    only exists from 17 - which 16 rejects, so the restore ends with
    "unrecognized configuration parameter" and a non-zero exit.

    A client older than the server is the other failure: a plain dump taken
    with pg_dump 17 carries `\restrict`, which needs psql >= 17.6. The dumps
    this repo restores are directory-format from pg_dump 16, so 16 is right.
  EOT
  default     = "postgres:16"
}

variable "cloudsql_database_name" {
  type        = string
  description = "Database the PostgreSQL dump is imported into."
}

variable "cloudsql_import_user" {
  type        = string
  description = "PostgreSQL role used for the import and for verification queries."
}

variable "cloudsql_import_password" {
  type        = string
  description = "Password for cloudsql_import_user. Supply via TF_VAR_cloudsql_import_password."
  sensitive   = true
}

variable "postgres_restore_enabled" {
  type        = bool
  description = "Run the Cloud SQL import. Set false after a successful restore so re-applies are no-ops."
  default     = true
}

# --------------------------- Prerequisite: Capella -------------------------

variable "capella_organization_id" {
  type        = string
  description = "Couchbase Capella organization id."
  validation {
    condition     = !startswith(var.capella_organization_id, "REPLACE_ME")
    error_message = "capella_organization_id is still a placeholder."
  }
}

variable "capella_project_id" {
  type        = string
  description = "Couchbase Capella project id."
}

variable "capella_cluster_id" {
  type        = string
  description = "Existing Capella cluster id in the DR region. Read only; never created here."
}

variable "capella_api_token" {
  type        = string
  description = "Capella Management API v4 bearer token. Supply via TF_VAR_capella_api_token."
  sensitive   = true
}

variable "capella_api_url" {
  type        = string
  description = "Capella Management API base URL."
  default     = "https://cloudapi.cloud.couchbase.com"
}

variable "capella_connection_string" {
  type        = string
  description = "Capella connection string the SSO services use (couchbases://...)."
}

variable "capella_buckets" {
  type        = list(string)
  description = "Buckets restored and verified in Phase 3."
  default     = []
}

variable "couchbase_username" {
  type        = string
  description = "Capella database user for restore verification."
}

variable "couchbase_password" {
  type        = string
  description = "Password for couchbase_username. Supply via TF_VAR_couchbase_password."
  sensitive   = true
}

variable "couchbase_restore_enabled" {
  type        = bool
  description = "Run the Capella restore. Set false after a successful restore."
  default     = true
}

variable "couchbase_flush_before_restore" {
  type        = bool
  description = <<-EOT
    Flush each target bucket before restoring it, so documents that exist in DR
    but not in the backup do not survive. Requires flushEnabled on the bucket;
    Capella leaves that off by default and answers the flush call with HTTP 403.
    Set false to restore by upsert instead, which overwrites every document in
    the backup and replays its tombstones, but leaves any DR-only document in
    place.
  EOT
  default     = true
}

variable "couchbase_restore_methods" {
  type        = map(string)
  description = <<-EOT
    Bucket -> restore method (openspec change dr-drill-fixes, E5):
      capella_api - Capella Management API restore from Capella's own backups (needs TF_VAR_capella_api_token)
      cbbackupmgr - cbbackupmgr restore on the bastion from a tarball (archive or bare repository)
      cbimport    - in-cluster cbimport of a cbexport JSON list/lines file; see couchbase_cbimport_key_modes
  EOT
  default     = {}
  validation {
    condition     = alltrue([for m in values(var.couchbase_restore_methods) : contains(["capella_api", "cbbackupmgr", "cbimport"], m)])
    error_message = "couchbase_restore_methods values must be capella_api, cbbackupmgr or cbimport."
  }
}

variable "couchbase_backup_objects" {
  type        = map(string)
  description = "Bucket -> object path in backup_bucket. Required for cbbackupmgr and cbimport buckets."
  default     = {}
}

variable "couchbase_cbimport_key_modes" {
  type        = map(string)
  description = "Bucket -> document key rule for cbimport: jans_dn (Janssen key from dn), field:<name> (body field, kept) or id_field:<name> (export-only id field such as __doc_id__, removed)."
  default     = {}
  validation {
    condition     = alltrue([for m in values(var.couchbase_cbimport_key_modes) : m == "jans_dn" || startswith(m, "field:") || startswith(m, "id_field:")])
    error_message = "couchbase_cbimport_key_modes values must be jans_dn, field:<name> or id_field:<name>."
  }
}

variable "couchbase_index_definitions_object" {
  type        = string
  description = "Optional GSI index definition file in backup_bucket (e.g. prod-index-definitions.sql), replayed after the data restore."
  default     = ""
}

variable "couchbase_expected_doc_counts" {
  type        = map(number)
  description = "Bucket -> minimum document count Phase 3 verification requires. Unlisted buckets only need to be non-empty."
  default     = {}
}

variable "couchbase_server_image" {
  type        = string
  description = "Image providing cbimport for in-cluster imports (needs --ignore-fields)."
  default     = "couchbase/server:enterprise-7.6.4"
}

# --------------------------- Phase 2: platform -----------------------------

variable "storage_class" {
  type        = string
  description = "StorageClass backing the platform PVCs."
  default     = "standard-rwo"
}

variable "platform_chart_versions" {
  type        = map(string)
  description = "Pinned Helm chart versions, keyed by consul, vault, openldap, zeebe."
  validation {
    condition     = length(setsubtract(["consul", "vault", "openldap", "zeebe"], keys(var.platform_chart_versions))) == 0
    error_message = "platform_chart_versions must define consul, vault, openldap and zeebe."
  }
}

variable "platform_storage_sizes" {
  type        = map(string)
  description = "PVC size per platform component, keyed by consul, vault, openldap, zeebe."
  default = {
    consul   = "10Gi"
    vault    = "10Gi"
    openldap = "20Gi"
    zeebe    = "50Gi"
  }
}

variable "platform_replicas" {
  type        = map(number)
  description = "Replica count per platform component."
  default = {
    consul   = 3
    vault    = 3
    openldap = 2
    zeebe    = 3
  }
}

variable "readiness_timeout_seconds" {
  type        = number
  description = "How long a phase waits for a component to become Ready before failing."
  default     = 900
}

variable "authn_namespace" {
  type        = string
  description = "Namespace holding oidcv2 and its Jans configuration."
  default     = "authn"
}

variable "environment_name" {
  type        = string
  description = "ENVIRONMENT value in icrypto-global-config."
  default     = "prod"
}

variable "icrypto_env" {
  type        = string
  description = "ICRYPTO_ENV value in icrypto-global-config."
  default     = "prod_az1"
}

variable "oidcv2_enabled" {
  type        = bool
  description = <<-EOT
    Render the oidcv2 config (jans-couchbase and the cn ConfigMap). Needs
    app_config_secret_dir to hold the source site's cn Secret, without which
    oidcv2 cannot decrypt the restored Couchbase bucket.
  EOT
  default     = false
}

variable "oidc_hostname" {
  type        = string
  description = <<-EOT
    OIDC issuer hostname in the cn ConfigMap. This is the name the site serves
    after the DNS cutover, so it stays the production name rather than a
    DR-specific host.
  EOT
  default     = ""
}

variable "app_config_secret_dir" {
  type        = string
  description = <<-EOT
    Directory on the bastion holding the application secret material as
    Kubernetes manifests: the cn Secret plus the oidcv2 Couchbase password and
    certificate. Seeded from the source environment and never committed. The cn
    Secret's crypto keys must be the source site's, because Jans encrypted the
    restored bucket with them; its Couchbase credentials are retargeted to this
    site automatically.
  EOT
  default     = ""
}

variable "convergence_tolerate_missing_jobs" {
  type        = list(string)
  description = <<-EOT
    Argo CD Applications allowed to report OutOfSync/Missing when the only
    resources at fault are run-once Jobs. A completed Job is removed by its own
    ttlSecondsAfterFinished and Argo CD then reports the Application Missing
    for ever - oidcv2 does this with the Jans configurator Job. Naming the
    Application keeps the exemption auditable rather than ignoring every
    missing resource.
  EOT
  default     = []
}

variable "internal_ingress_vips" {
  type        = map(string)
  description = <<-EOT
    Reserved internal VIP name -> address for the ingresses that pin an address
    with kubernetes.io/ingress.regional-static-ip-name. Reserving them here
    keeps the addresses stable across a rebuild; a GKE-allocated address would
    change and every DNS record pointing at it would have to be reissued.
  EOT
  default     = {}
}

variable "dr_subnetwork" {
  type        = string
  description = "Subnetwork the internal ingress VIPs are reserved in."
  default     = ""
}

variable "eso_managed_by_argocd" {
  type        = bool
  description = <<-EOT
    Let the restored external-secrets Argo CD Application own ESO instead of
    installing it with a Helm release here. The source bundle carries that
    Application, and two owners of the same release fight. Phase 5 then syncs
    that one Application ahead of the Phase 6 release, because it needs the
    CRDs and controller before it can create a ClusterSecretStore.
  EOT
  default     = false
}

variable "eso_application_name" {
  type        = string
  description = "Argo CD Application that delivers ESO when eso_managed_by_argocd is true."
  default     = "external-secrets"
}

variable "argocd_retarget_destinations" {
  type        = bool
  description = <<-EOT
    Rewrite every restored Application's destination to
    https://kubernetes.default.svc before it is applied. Required when the
    backup comes from another site: its Applications name that site's API
    server, and applying them unchanged lets this Argo CD deploy there.
  EOT
  default     = false
}

variable "argocd_skip_cluster_secrets" {
  type        = bool
  description = <<-EOT
    Do not restore Argo CD cluster Secrets. A backup from another site carries
    a working bearer token for that site's API server, which must never be
    present here.
  EOT
  default     = false
}

variable "argocd_exclude_applications" {
  type        = list(string)
  description = "Applications in the backup that this site does not run."
  default     = []
}

variable "services_namespace" {
  type        = string
  description = <<-EOT
    Namespace holding the SSO services. notification-service-lb, the internal
    load balancer that service is reached on, is created here; it is applied out
    of band in the source environments so no backup carries it. Empty skips it.
  EOT
  default     = "services"
}

variable "pps_health_namespace" {
  type        = string
  description = "Namespace for the pps-health deployment nginx-api-gw points at."
  default     = "default"
}

variable "pps_health_image" {
  type        = string
  description = <<-EOT
    Image for the pps-health deployment that nginx-api-gw lists as an upstream.
    nginx resolves upstreams at config load, so without it the gateway fails to
    start. Empty disables it.
  EOT
  default     = ""
}

variable "argocd_ignore_differences" {
  type = map(list(object({
    group         = string
    kind          = string
    json_pointers = list(string)
  })))
  description = <<-EOT
    Argo CD Application name -> ignoreDifferences rules, for fields the API
    server normalises so that Argo CD would otherwise diff them forever. The
    Applications are re-applied by the Phase 4 restore, so these are patched on
    every run.
  EOT
  default     = {}
}

variable "vault_uses_consul_storage" {
  type        = bool
  description = <<-EOT
    Vault stores its data in Consul, so the Consul restore replaces Vault's
    storage and Vault must be restarted afterwards to read it. Keep this true
    wherever vault_restore_enabled is false because "Vault data = Consul data".
  EOT
  default     = true
}

variable "vault_approle_secrets" {
  type = map(object({
    namespace = string
    role      = string
    layout    = optional(string, "pair")
    mount     = optional(string, "approle")
  }))
  description = <<-EOT
    Kubernetes Secret basename -> {namespace, Vault AppRole role} for the
    credentials the application pods mount. Each entry produces <name>-role
    (key role_id) and <name>-secret (key secret_id).

    layout = "combined" instead produces one Secret named <name> holding both
    keys, which is what authn/oidc-v3 mounts. A pod whose Secret is missing or
    the wrong shape never starts its first init container; it sits on
    "MountVolume.SetUp failed ... secret not found", which is how oidc-v3,
    oidcv2-loader and oidc-mgmt-portal stayed in Init:0/2 on 2026-10-12 long
    after the auth server they were blamed on had recovered.

    The mapping is not derivable from the names: on PPS
    vault-cred-mgmt-service-ext uses the role "credmgmt",
    vault-idm2-server-ext uses "idm-server" and vault-mfa-facade-ext uses
    "mfa". Recover it by matching a working environment's role_id against the
    role_id of every AppRole role.
  EOT
  default     = {}
}

variable "app_credential_namespaces" {
  type        = list(string)
  description = "Namespaces that receive the shared consul-secret and aws-secret."
  default     = []
}

variable "app_consul_token" {
  type        = string
  description = <<-EOT
    Token written to consul-secret. The init container rejects an empty value,
    so a placeholder is still required where the Consul ACL system is disabled
    and the token is never checked.
  EOT
  sensitive   = true
  default     = ""
}

variable "vault_manage_kv_mount" {
  type        = bool
  description = <<-EOT
    Create the KV mount at vault_kv_mount. Set false when Phase 3 restored
    Vault: its mounts come back with it, and Vault refuses a mount whose path
    is a prefix of existing ones (prod is secret/<service>/, so secret/ fails
    with "path is already in use").
  EOT
  default     = true
}

variable "vault_kv_version" {
  type        = number
  description = <<-EOT
    KV engine version behind vault_kv_mount, which decides the shape of the
    generated policies: v2 grants <mount>/data/* and <mount>/metadata/*, v1
    grants <mount>/*. The restored prod tree is kv v1, where a v2-shaped
    policy grants nothing.
  EOT
  default     = 2

  validation {
    condition     = contains([1, 2], var.vault_kv_version)
    error_message = "vault_kv_version must be 1 or 2."
  }
}

variable "vault_address" {
  type        = string
  description = "Vault address reachable from the bastion (port-forward or internal LB)."
  default     = "http://127.0.0.1:8200"
}

variable "vault_root_token" {
  type        = string
  description = "Vault root token. Supply via TF_VAR_vault_root_token. Never committed, never output."
  sensitive   = true
}

variable "ldap_admin_password" {
  type        = string
  description = "OpenLDAP admin password. Supply via TF_VAR_ldap_admin_password."
  sensitive   = true
}

variable "ldap_base_dn" {
  type        = string
  description = "OpenLDAP base DN, used by the post-restore search check."
}

variable "vault_seal_type" {
  type        = string
  description = "shamir (new Shamir init with keys stored in the cluster) or gcpckms (auto-unseal). On a Consul restore of a gcpckms source, use gcpckms and point at the same KMS key: Vault will auto-unseal."
  default     = "shamir"
  validation {
    condition     = contains(["shamir", "gcpckms"], var.vault_seal_type)
    error_message = "vault_seal_type must be shamir or gcpckms."
  }
}

variable "vault_kms_sa_file" {
  type        = string
  description = "gcpckms: SA key JSON on the bastion with cloudkms.cryptoKeyEncrypterDecrypter on the key. Mounted into every Vault pod as a Secret."
  default     = ""
}

variable "vault_kms_project" {
  type        = string
  description = "gcpckms: GCP project holding the KMS key."
  default     = ""
}

variable "vault_kms_region" {
  type        = string
  description = "gcpckms: KMS location (e.g. global)."
  default     = "global"
}

variable "vault_kms_keyring" {
  type        = string
  description = "gcpckms: KMS keyring."
  default     = ""
}

variable "vault_kms_crypto_key" {
  type        = string
  description = "gcpckms: KMS crypto key."
  default     = ""
}

variable "openldap_deployment" {
  type        = string
  description = <<-EOT
    How Phase 2 deploys OpenLDAP:
      stack_ha  - public openldap-stack-ha chart (Bitnami) in platform_namespace;
                  Phase 3 must restore cn=config (ldap_restore_config = true).
      pps_chart - the chart + values PPS environments run (pps-ldap image,
                  release ldap_release_name in ldap_namespace), read from
                  ldap_chart_path / ldap_values_file on the bastion. The image
                  builds the secauthority DB; set ldap_restore_config = false
                  and ldap_pod_name = "<release>-openldap-0".
  EOT
  default     = "stack_ha"
  validation {
    condition     = contains(["stack_ha", "pps_chart"], var.openldap_deployment)
    error_message = "openldap_deployment must be stack_ha or pps_chart."
  }
}

variable "ldap_release_name" {
  type        = string
  description = "pps_chart: Helm release name (the old DR site uses \"ldap\", giving StatefulSet ldap-openldap)."
  default     = "ldap"
}

variable "ldap_namespace" {
  type        = string
  description = "pps_chart: namespace of the LDAP release; Phase 3 restores there."
  default     = "ldap-v2"
}

variable "ldap_chart_name" {
  type        = string
  description = "OCI chart name for the PPS LDAP chart in registry_server."
  default     = "pps-ldap"
}

variable "ldap_chart_version" {
  type        = string
  description = <<-EOT
    Version of the OCI LDAP chart to install, e.g. "1.0.97-pps". Set this and
    the chart is pulled from the registry, so nothing has to be staged on the
    bastion. Leave empty to use ldap_chart_path instead.
  EOT
  default     = ""
}

variable "ldap_chart_path" {
  type        = string
  description = "pps_chart: chart directory on the bastion (extracted from the existing release; may embed default passwords, so kept out of git)."
  default     = ""
}

variable "ldap_ready_selector" {
  type        = string
  default     = ""
  description = <<-EOT
    Label selector for the LDAP readiness gate. Empty waits on
    release=<ldap_release_name>, which matches whichever chart is in use: the
    PPS OCI chart labels pods app=pps-ldap and the local directory chart
    app=openldap, so a selector naming the app label only works for one of them.
  EOT
}

variable "ldap_values_file" {
  type        = string
  description = "pps_chart: values file on the bastion. Holds LDAP passwords - never committed."
  default     = ""
}

variable "ldap_pod_name" {
  type        = string
  description = "OpenLDAP pod the Phase 3 restore runs slapadd in (StatefulSet = name without the ordinal)."
  default     = "openldap-0"
}

variable "ldap_slapd_config_dir" {
  type        = string
  description = "slapd.d directory inside the OpenLDAP image. Bitnami layout by default, matching the openldap-stack-ha chart."
  default     = "/opt/bitnami/openldap/etc/slapd.d"
}

variable "ldap_wipe_before_restore" {
  type        = bool
  description = "Clear the OpenLDAP on-disk databases (and slapd.d when restoring config) before slapadd. Destructive; meant for a freshly built DR instance."
  default     = true
}

variable "ldap_restore_config" {
  type        = bool
  description = "Load the *config* LDIF into cn=config. Needed on a fresh instance because the secauthority DB only exists in the source config; ldap_admin_password must then be the source admin password."
  default     = true
}

# --------------------------- Phase 3: restore toggles ----------------------

variable "consul_restore_enabled" {
  type        = bool
  description = "Run the Consul KV restore."
  default     = true
}

variable "vault_restore_enabled" {
  type        = bool
  description = "Run the Vault data restore."
  default     = true
}

variable "ldap_restore_enabled" {
  type        = bool
  description = "Run the OpenLDAP LDIF restore."
  default     = true
}

# --------------------------- Phase 4: Argo CD ------------------------------

variable "argocd_chart_version" {
  type        = string
  description = "Pinned argo-cd Helm chart version."
  validation {
    condition     = !startswith(var.argocd_chart_version, "REPLACE_ME") && var.argocd_chart_version != "latest"
    error_message = "argocd_chart_version must be an explicit pinned version, not a placeholder or 'latest'."
  }
}

variable "argocd_hostname" {
  type        = string
  description = "Hostname Argo CD is served on in the DR site."
}

variable "argocd_admin_password_bcrypt" {
  type        = string
  description = "Bcrypt hash of the Argo CD admin password. Supply via TF_VAR_argocd_admin_password_bcrypt."
  sensitive   = true
}

variable "git_repo_url" {
  type        = string
  description = "Git repository holding the iCrypto deployment manifests. Empty when no git source is used (PPS Applications are Helm OCI charts from ECR); Phase 4 then registers no git credential."
  default     = ""
  validation {
    condition     = !startswith(var.git_repo_url, "REPLACE_ME")
    error_message = "git_repo_url is still a placeholder."
  }
}

variable "git_user" {
  type        = string
  description = "Git user for repository access."
  default     = ""
}

variable "argocd_internal_lb_enabled" {
  type        = bool
  description = "Create the argocd-server-int internal LoadBalancer Service as on the old DR site."
  default     = false
}

variable "git_pat" {
  type        = string
  description = "Git personal access token. Supply via TF_VAR_git_pat (only when git_repo_url is set)."
  sensitive   = true
  default     = ""
}

# --------------------------- Phase 5: secrets ------------------------------

variable "eso_chart_version" {
  type        = string
  description = "Pinned external-secrets Helm chart version."
  validation {
    condition     = !startswith(var.eso_chart_version, "REPLACE_ME") && var.eso_chart_version != "latest"
    error_message = "eso_chart_version must be an explicit pinned version."
  }
}

variable "eso_chart_repository" {
  type        = string
  description = "Helm repository for the external-secrets chart when Terraform installs it (eso_managed_by_argocd = false). Empty means oci://<registry_server>, the PPS ECR."
  default     = ""
}

variable "eso_vault_role" {
  type        = string
  description = "Vault Kubernetes-auth role ESO authenticates with."
  default     = "external-secrets"
}

variable "vault_kv_mount" {
  type        = string
  description = "Vault KV v2 mount holding the SSO service secrets."
  default     = "secret"
}

variable "vault_rotation_period_seconds" {
  type        = number
  description = "Rotation period applied to rotatable Vault credentials."
  default     = 2592000
}

variable "eso_target_namespaces" {
  type        = list(string)
  description = "Namespaces whose ExternalSecrets must reach SecretSynced before Phase 6 runs."
  default     = []
}

# --------------------------- Phase 6: app services -------------------------

variable "service_versions" {
  type        = map(string)
  description = "Argo CD Application name -> chart version (X.Y.Z, X.Y.Z-pps or img.X.Y.Z) pinned for this DR run. Empty keeps the revisions restored in Phase 4."
  default     = {}
  validation {
    condition     = alltrue([for v in values(var.service_versions) : !startswith(v, "REPLACE_ME") && v != ""])
    error_message = "Every entry in service_versions must be an explicit pinned version."
  }
}

variable "app_of_apps_enabled" {
  type        = bool
  description = "Render a git app-of-apps in Phase 6. Off by default: PPS delivers Helm OCI charts from ECR and Phase 4 restores those Applications."
  default     = false
}

variable "app_of_apps_path" {
  type        = string
  description = "Path inside git_repo_url holding the app-of-apps Application manifests. Only used when app_of_apps_enabled."
  default     = ""
}

variable "app_of_apps_revision" {
  type        = string
  description = "Git revision (tag or commit) the app-of-apps deploys from. Only used when app_of_apps_enabled."
  default     = ""
}

# --------------------------- Phase 7: ingress and DNS ----------------------

variable "ingress_namespace" {
  type        = string
  description = "Namespace holding the ingress objects and TLS secrets."
  default     = "default"
}

variable "ingress_class" {
  type        = string
  description = "Ingress class used by the DR ingress objects."
  default     = "nginx"
}

variable "dr_hostnames" {
  type        = map(string)
  description = "Hostnames requiring a DNS record, keyed by service (truepolicy, oidc, sidas, admin, idm, ...)."
  validation {
    condition     = length(var.dr_hostnames) > 0
    error_message = "At least one DR hostname is required for the DNS change request output."
  }
}

variable "pps_cert_file" {
  type        = string
  description = "Path on the bastion to the *.pps.co.za certificate. Never committed."
  validation {
    condition     = !startswith(var.pps_cert_file, "REPLACE_ME")
    error_message = "pps_cert_file is still a placeholder."
  }
}

variable "pps_key_file" {
  type        = string
  description = "Path on the bastion to the *.pps.co.za private key. Never committed."
  validation {
    condition     = !startswith(var.pps_key_file, "REPLACE_ME")
    error_message = "pps_key_file is still a placeholder."
  }
}

variable "ingress_manifest_file" {
  type        = string
  description = "Captured ingress manifest applied by Phase 7 instead of the template (path relative to the repo root, or absolute). Use it when the site's ingresses do not fit the template, e.g. env/pps-dr/ingresses.yaml. backend_services is then not used."
  default     = ""
}

variable "ingress_names" {
  type        = map(string)
  description = "Ingress objects Phase 7 manages and reads addresses from for the DNS change request; keys internal, external, opa."
  default = {
    internal = "icrypto-internal"
    external = "icrypto-external"
    opa      = "opa-internal"
  }
}

variable "backend_services" {
  type        = map(string)
  description = "dr_hostnames key -> backing Kubernetes Service name for the DR ingress. Must cover every key in dr_hostnames."
  default     = {}
}

variable "tls_secret_name" {
  type        = string
  description = "Name of the TLS secret created from pps_cert_file and pps_key_file."
  default     = "pps-tls"
}

variable "backend_timeout_seconds" {
  type        = number
  description = <<-EOT
    GCLB backend request timeout for the ingress backends, applied as a
    BackendConfig on the Services named in backend_timeout_services. One
    BackendConfig covers both ingress classes, because the external (global) and
    the internal (regional) backend service are both derived from the Service.

    The GKE default of 30s is too short for DR: a midPoint user ADD fans out to
    trueLDAP, IAA and Sparkle, which only production can reach, so the request
    sits in connector connect timeouts and the caller gets a GCLB 502 with
    request_time 30.001 - a timeout reported as a server error. 0 keeps the GKE
    default.
  EOT
  default     = 120

  validation {
    condition     = var.backend_timeout_seconds >= 0
    error_message = "backend_timeout_seconds must be 0 or more."
  }
}

variable "backend_timeout_services" {
  type        = list(string)
  description = "Services in ingress_namespace that carry the BackendConfig annotation. They are owned by Argo CD applications with selfHeal, so each also needs an argocd_ignore_differences rule for the annotation or Argo reverts it."
  default     = ["nginx-api-gw", "true-policy-opa"]
}

# --------------------------- Phase 8: validation ---------------------------

variable "post_restart_services" {
  type        = list(string)
  description = "Workloads gracefully restarted once DNS resolves."
  default     = []
}

variable "health_check_endpoints" {
  type        = map(string)
  description = "Health endpoints checked after the restart, keyed by service name."
  default     = {}
}

variable "oidc_discovery_url" {
  type        = string
  description = "OIDC discovery document URL on the DR site."
}

variable "oidc_validation_client_id" {
  type        = string
  description = "Client id used for the Phase 8 token issuance check. Empty skips the OIDC token issuance check."
  default     = ""
}

variable "oidc_validation_client_secret" {
  type        = string
  description = "Client secret for the Phase 8 token issuance check. Supply via TF_VAR_oidc_validation_client_secret. Empty skips the check."
  sensitive   = true
  default     = ""
}

variable "signoff_report_path" {
  type        = string
  description = "Where the Phase 8 sign-off report is written on the bastion."
  default     = "./sign-off-report.json"
}

variable "zeebe_enabled" {
  type        = bool
  description = "Install Zeebe in Phase 2. False on the PPS DR site: bpmn-engine is restored by Argo CD in Phase 4."
  default     = true
}

variable "cert_manager_enabled" {
  type        = bool
  description = "Install cert-manager in Phase 2."
  default     = false
}

variable "cert_manager_version" {
  type        = string
  description = "cert-manager Helm chart version."
  default     = "v1.5.4"
}

variable "validation_enabled" {
  type        = bool
  default     = false
  description = <<-EOT
    Phase 8: graceful restart, end-to-end checks and the sign-off report.

    Off by default so that one `tofu apply` can build the whole site: these
    checks resolve the public hostnames, which point at this site only after
    PPS has made the DNS change. Turn it on (or target the module) once DNS is
    live.
  EOT
}

variable "pin_googleapis" {
  type        = bool
  default     = true
  description = <<-EOT
    Pin the googleapis hostnames to private.googleapis.com (199.36.153.8) in
    the pods that download backups.

    The DR environment drops the rotating public googleapis addresses, which
    is why the bastion pins them in /etc/hosts. Inside the cluster the same
    gap made `gcloud auth activate-service-account` time out after 120s, and
    two of three Postgres restores failed having staged nothing while the
    third happened to get through.
  EOT
}

variable "postgres_stage_storage_class" {
  type        = string
  default     = "premium-rwo"
  description = <<-EOT
    StorageClass for the Postgres restore staging volume, which holds the
    downloaded dump and is deleted with the Job.

    Deliberately separate from storage_class: this volume wants speed for an
    hour, while Consul and Vault want cheap durable disk for the life of the
    site. Persistent Disk performance scales with size, so the class and
    postgres_stage_size together set the ceiling - measured on this site, a
    160Gi pd-balanced volume (standard-rwo) staged midpoint's 117GB at
    40 MB/s, 89% of that disk's 45 MB/s ceiling, so it was the bottleneck.

      standard-rwo  pd-balanced  0.28 MB/s and  6 IOPS per GB
      premium-rwo   pd-ssd       0.48 MB/s and 30 IOPS per GB
      dynamic-rwo   hyperdisk-balanced where the node family supports it,
                    otherwise pd-balanced - N2 nodes get no benefit

    premium-rwo at 300Gi gives ~144 MB/s and 9,000 IOPS, which also matters to
    pg_restore -j, reading the staged dump with several workers at once.
    Empty falls back to storage_class.
  EOT
}

variable "postgres_restore_work_mem" {
  type        = string
  default     = "256MB"
  description = <<-EOT
    work_mem applied to the target database while the restore runs, and reset
    afterwards.

    pg_restore's final items are the foreign keys, and validating one is an
    ordinary join - governed by work_mem, not the maintenance_work_mem the
    restore already raised. The Cloud SQL default here is 4MB, which turned
    the validation of midpoint's FK on m_audit_delta (~100 partitions against
    ~100 on the referenced side) into a disk-spilling join that ran over an
    hour as the only remaining item, with three of four restore workers idle.
  EOT
}

variable "postgres_restore_parallel_workers" {
  type        = number
  default     = 4
  description = <<-EOT
    max_parallel_workers_per_gather applied to the target database while the
    restore runs, and reset afterwards. A foreign-key validation is a query and
    can use parallel workers; the server default on this instance is 2.
  EOT
}

variable "ldap_slapadd_quick" {
  type        = bool
  default     = true
  description = <<-EOT
    Load the LDAP LDIFs with `slapadd -q`.

    Without it, each entry is its own transaction with an fsync and up to 15
    index updates. Measured on this site: 155,569 entries went in at about
    0.5 MB/min and the step was still running after 1h40m, because the LDAP
    volume is pd-standard - roughly 75 write IOPS at 50GB. -q defers index
    maintenance and skips the per-entry checks; it assumes a consistent LDIF,
    which a slapcat of a healthy directory is, and the script's own ldapsearch
    check at the end verifies the result either way.
  EOT
}

variable "deferred_applications" {
  type        = list(string)
  default     = ["idm-server-v2"]
  description = <<-EOT
    Applications held back until the database restore completes, so the rest
    of the site comes up alongside it.

    midpoint's restore is the longest step in the build - on a measured run,
    50 minutes of staging plus an hour of loading - and every later phase used
    to wait for it. Of the 28 Applications in the Argo CD backup, only
    idm-server-v2 references the Postgres host; sage-kafka-consumer and
    prometheus-msteams reference IDM but are already excluded on this site.
    So Argo CD, the secrets phase, the application config, 27 of 28 syncs and
    the ingress all proceed while it restores.

    Empty makes the build single-wave again.
  
    Three applications are deferred on the PPS DR site, for two different
    reasons:

      idm-server-v2      needs the midpoint database, which is the longest
                         step of the build.
      cred-mgmt-service  its connectivity-check waits for
                         idm-server-v2:8080 (SERVICE_NAMES=...,idm,...), so in
                         wave 1 it would block for the whole restore and time
                         out the gate.
      oidc-mgmt-portal   fetches https://oidc.pps.co.za at startup, which only
                         answers once Phase 7 has created the ingress - and
                         Phase 7 waits on wave 1 converging. Left in wave 1 it
                         deadlocks the build.

    The wave-2 release waits on the database gate, which takes far longer than
    Phase 7 does, so by the time these converge the ingress is serving. That
    ordering is by timing rather than by an explicit edge: making the deferred
    gate depend on Phase 7 would be a module-level cycle, since Phase 7 already
    depends on wave 1.
  EOT
}

variable "postgres_skip_fk_constraints" {
  type        = list(string)
  default     = ["fk_audit_delta"]
  description = <<-EOT
    Foreign keys left out of the restore, by constraint name.

    pg_restore's last items are the foreign keys, and validating one scans
    every row already loaded. fk_audit_delta is the extreme case: it checks
    ~102 partitions of m_audit_delta against m_audit_event, which ran for over
    two hours with the default 4MB work_mem and was still going at 46 minutes
    with 256MB. It is the single longest step in the build.

    Skipping it is safe for a restore specifically: the rows came from a
    production database where the constraint was validated and enforced, so
    pg_dump could not have produced rows that violate it. The scan re-proves
    what the source already guaranteed.

    ADD CONSTRAINT ... NOT VALID would normally be the better answer - the
    constraint enforces new writes while existing rows are trusted - but
    PostgreSQL 16 refuses it on a partitioned table, so these are simply left
    out. The restore prints the statements needed to add them, and a DR site
    that is not yet serving writes can take the lock whenever convenient.

    Empty restores every foreign key the archive carries.
  EOT
}

variable "postgres_exclude_table_data" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Tables whose rows are left out of the restore, by name prefix. The schema,
    indexes and constraints are still restored - only the TABLE DATA items are
    dropped from pg_restore's table of contents, so the tables arrive empty.

    This exists because midPoint's audit tables dwarf everything else. Measured
    on the prod midpoint database (173GB total):

      m_audit_delta   101 objects (parent + 100 partitions)   136GB
      m_audit_event   101 objects (parent + 100 partitions)    16GB
      m_audit_item      1 object                               16GB
      everything else ~12 objects                              ~5GB

    The audit history is 97% of the database and a DR site does not need the
    source site's audit trail to authenticate anyone - it needs the identity
    objects. Excluding the audit data turns a 173GB restore into a ~5GB one.

    A prefix matches the table itself and its partitions: "m_audit_delta"
    covers m_audit_delta and every m_audit_delta_<n>. midPoint names its
    partitions with the schema embedded in the relation name
    ("public.m_audit_delta_132500000"), so a leading "public." is stripped
    before the comparison.

    Exclude a family as a whole. Keeping m_audit_ref_value while dropping the
    m_audit_event rows it references would leave rows whose parent is gone, and
    the foreign key would then refuse to validate.
  EOT
}

variable "couchbase_build_deferred_indexes" {
  type        = bool
  default     = true
  description = <<-EOT
    Build every deferred GSI index after the Capella restore, and wait for the
    builds to come online before Phase 6 syncs the applications.

    cbbackupmgr restores index definitions with defer_build set, so a restored
    cluster has definitions and no usable indexes. That is not a performance
    footnote: io.jans.orm's CouchbaseConnectionProvider.isConnected() queries
    the bucket, and with no index to serve it the connection pool never
    initialises. On 2026-10-12, 18 of 47 indexes on bucket oidcv2 were left
    deferred and jans-auth retried every 5 seconds for 22 minutes before
    failing with "Failed to create Couchbase connection pool!" - its liveness
    probe killed it long before that, so it crash-looped and took oidcv2,
    oidcv2-loader, oidc-v3, oidc-mgmt-portal and cred-mgmt-service with it.
    BUILD INDEX fixed it in 45 seconds.
  EOT
}

variable "couchbase_index_build_timeout_seconds" {
  type        = number
  default     = 1800
  description = "How long Phase 3 waits for the GSI builds to come online before failing."
}

variable "couchbase_ca_cert_file" {
  type        = string
  default     = ""
  description = <<-EOT
    CA certificate for the DR Capella cluster, on the machine running the
    apply. The query-service calls in Phase 3 use it.

    Capella serves a certificate from its own CA, which is not in the bastion's
    trust store, so without this curl fails with "Peer's Certificate issuer is
    not recognized" and every index statement is reported as a failure. Empty
    falls back to an unverified connection.
  EOT
}

variable "ingress_dns_enabled" {
  type        = bool
  default     = true
  description = <<-EOT
    Phase 7: the ingress, its TLS certificate and the DNS change request.

    Off for a drill, where the site is reached through the cluster rather than
    its public hostnames, and where the DNS change request - a hand-off asking
    PPS to repoint production DNS - must not go out. Leaving it off also keeps
    the Ingress from creating the load balancer resources that have to be torn
    down again before the cluster can be deleted.
  EOT
}

variable "endpoint_redirects" {
  type        = map(string)
  default     = {}
  description = <<-EOT
    Source-site hostnames redirected to this site's equivalents inside the
    cluster, as domain -> host.

    The applications' init container probes a Capella host baked into its image
    per environment name, and the restored Applications carry
    ENVIRONMENT=prod_az1 - so every pod probes production's Capella, which does
    not allowlist this cluster. Measured from a pod: 18091 filtered on
    production's host, open on this site's private endpoint. Without a redirect,
    twelve of seventeen Applications never leave Init:0/2.

    A Cloud DNS private zone would be tidier, but the DR service account has no
    dns.* permission, so this is done with a small in-cluster resolver and a
    kube-dns stub domain. Empty leaves cluster DNS untouched.
  EOT
}

variable "capella_credential_services" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Services whose Vault capella-url, capella-username and capella-pass are
    repointed at this site's Capella after the restore.

    The Vault restore brings production's endpoint and credentials, so a service
    left alone starts up aimed at a cluster it cannot reach and could not
    authenticate against. Established by probing the restored Vault: six
    services carry these keys.
  EOT
}

variable "dns_change_request_enabled" {
  type        = bool
  default     = true
  description = <<-EOT
    Emit the DNS change request at the end of Phase 7.

    False builds everything up to and including the ingress - its address and
    its TLS certificate - and stops short of the hand-off that asks PPS to
    repoint production DNS. That is the right setting for a drill, and for a
    cutover where PPS makes the DNS change by hand.
  EOT
}

variable "restore_exclude_secrets" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Extra Secrets in the Argo CD backup that must not be applied, by name.

    argocd_repo_secret_name is always excluded: module 15 mints a fresh ECR
    token and writes it before Phase 4, and the backup carries the same secret
    with the token that was valid when the backup was taken. Measured on this
    site - a secret created at 05:19 held a token that had expired four days
    earlier, so every Helm OCI chart pull failed 403 Forbidden and Phase 5
    stalled waiting for an ESO that could never sync.
  EOT
}

variable "ldap_cert_vault_path" {
  type        = string
  default     = "secret/token-exchange-service/ldap-certPem"
  description = <<-EOT
    KV entry holding the LDAP certificate token-exchange-service trusts.

    On by default because the stored value is stale on every build in two
    directions at once: the Vault restore brings the source site's certificate,
    and the PPS LDAP image mints a fresh self-signed one on each container
    start (its certs directory is a memory-backed emptyDir that overrides the
    chart's volumeClaimTemplate). On 2026-10-15 Vault held the 2025-07-01
    certificate while the pod served one minted that morning.

    Empty skips the step, as does an empty ldap_pod_name.
  EOT
}

variable "ldap_cert_vault_overrides" {
  type        = map(string)
  default     = {}
  description = <<-EOT
    Sibling KV entries written alongside the certificate, as path -> value.

    Site-specific, so empty by default, but the restored
    secret/token-exchange-service/ldap-host and -ldap-port name the source
    site's LDAP: on this site ldap-host was trueldap.pps.co.za with port 1636,
    a name that resolves in-cluster to an address no Service here owns and
    that refuses both 1636 and 636. Repoint them at the in-cluster LDAP
    Service or the refreshed certificate is never exercised. See
    pps-dr.tfvars.example.
  EOT
}

variable "ldap_cert_restart_workloads" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Workloads restarted when the stored LDAP certificate changes, as
    namespace/kind/name, e.g. services/deployment/token-exchange-service.

    They read the KV entry once at startup, so a pod that came up before the
    write keeps the old certificate. Empty by default: on a cold build Phase 5
    writes the certificate before Phase 6 syncs the Applications, so there is
    nothing to restart. It earns its place on a site that is already running -
    an LDAP pod restart mints a new certificate and silently invalidates the
    trust of everything that had already read the old one.
  EOT
}

variable "ldap_service_aliases" {
  type        = map(string)
  default     = {}
  description = <<-EOT
    Extra Service names for LDAP, as name -> "port:targetPort".

    The restored applications resolve ldap-openldap.<namespace>.svc:1389, the
    Service name on the source site. The PPS OCI chart names its Service after
    the release - ldap-pps-ldap - and publishes 389/636/9330, so every service
    that checks LDAP on 1389 waited on a name that does not exist here:
    ext-authn-service retried it indefinitely in Init:0/2.

    An alias Service keeps the chart stock.
  EOT
}

variable "convergence_tolerate_applications" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Applications whose health the convergence gate reports but does not
    enforce, together with their workloads (matched by prefix, so a tolerated
    "oidcv2" also covers deployment/oidcv2-auth-server).

    Default empty, and it should stay empty. This existed because the Janssen
    stack could not start on this site, and keeping an app listed after it
    works converts the gate from a check into a rubber stamp: the build would
    pass while the app was broken. On 2026-10-12 all six formerly-tolerated
    applications - oidcv2, oidcv2-loader, oidc-v3, oidc-mgmt-portal,
    cred-mgmt-service and idm-server-v2 - reached Healthy once the real causes
    were fixed (the icrypto-oidc-filter version, the Capella endpoints in
    Vault/parameters/documents, the missing AppRole Secrets and the database
    credentials), so the list was emptied.

    Use it only to get a diagnostic run past a known-broken app, and empty it
    again in the same session.
  EOT
}

variable "capella_foreign_usernames" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Capella usernames belonging to the source site, replaced with
    couchbase_username wherever they appear in a restored Argo CD
    Application's Helm parameters.

    On the PPS DR site this is ["prod-icrypto-sa-ha"], which the oidcv2
    Application carries in config.configmap.cnCouchbaseUser and
    cnCouchbaseSuperUser. Explicit rather than inferred: a hostname identifies
    its cluster, a username does not, and rewriting the wrong parameter would
    break something unrelated.
  EOT
}

variable "capella_password_parameters" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Helm parameter names holding the Capella password, set to
    couchbase_password on any Application that names a Capella host.

    Matched by name, not by value: a password says nothing about which site it
    belongs to. On the PPS DR site these are
    config.configmap.cnCouchbasePassword and
    config.configmap.cnCouchbaseSuperUserPassword.
  EOT
}

variable "icrypto_oidc_filter_version" {
  type        = string
  default     = "1.0.0.126"
  description = <<-EOT
    Version of icrypto-oidc-filter that jans-auth downloads from the iCrypto
    CDN, written into the icrypto-patch ConfigMap.

    This has to match the data the site restores, not whatever the old DR
    cluster happened to run. The captured manifest froze 1.0.0.90, and the
    restored client `clients_filter-client-id` carries a `config` attribute
    containing `internalTokenExchange` - a field FilterConfig only gained in
    1.0.0.126. Jackson is not configured to ignore unknown properties, so
    1.0.0.90 failed to deserialise it and
    com.icrypto.configuration.FilterConfiguration.getConfig() reported
    "No config or client for filter" (CONFIG_FILER_ERROR). That aborted
    SessionMetadataFilter.init, which failed the whole oxAuth Server context,
    so every request answered 503 and the Applications waiting on the auth
    server never started. The message names the client, which is why this read
    for hours as missing data rather than a version skew.

    Measured on 2026-10-12: FilterConfig has 11 fields in 1.0.0.105, 12 in
    1.0.0.120 and 13 including internalTokenExchange from 1.0.0.126. With
    1.0.0.126 the auth server answered health-check 200.

    The right value is whatever production runs; 1.0.0.126 is the lowest that
    understands the restored configuration.
  EOT
}

variable "capella_credential_secrets" {
  type = map(object({
    username_key = string
    password_key = string
  }))
  default     = {}
  description = <<-EOT
    "namespace/secret-name" -> the keys holding this site's Capella username
    and password, for charts that read Capella credentials from a Secret of
    their own instead of from Vault.

    The restore does not bring these. oidcv2-loader takes CB_USER and CB_PASS
    from authn/oidcv2-loader-capella-secrets, and without it the pod fails with
    `Error: secret "oidcv2-loader-capella-secrets" not found` and sits in
    CreateContainerConfigError, which no amount of waiting resolves.
  EOT
}

variable "postgres_credential_overrides" {
  type        = map(string)
  default     = {}
  description = <<-EOT
    Vault path -> kind for the restored database credentials that have to name
    this site's instance. Kind is "password", "username" or "url"; a URL keeps
    its host, port and database and only its credentials are replaced.

    The restore brings the source site's values, and they do not work here.
    Found on 2026-10-12 once the auth server was healthy:

      secret/idm/db-passwd            the source site's password, mounted by
                                      midPoint at
                                      /etc/secrets/mp_database_password.txt;
                                      "FATAL: password authentication failed
                                      for user postgres"
      secret/oidc-v3/db.pass          the same password, same result
      secret/oidc-mgmt-portal/db.url  postgres://oidc_user:...@host/db, and
                                      oidc_user does not exist here

    That last one is not a dump to fix: no roles are restored on this site
    (postgres_globals_object is empty, because pg_dumpall needs read access to
    pg_authid the source does not grant), so postgres is the only login role
    that exists and everything connects as it.

    The host needs no rewriting - cloud-sql-ha.pps.co.za is redirected to this
    site's instance by the Phase 2 DNS redirect.
  EOT
}

variable "couchbase_rewrite_document_endpoints" {
  type        = bool
  default     = true
  description = <<-EOT
    Rewrite Capella hostnames carried inside restored Couchbase documents so
    they name this site's cluster.

    Some restored data is configuration, including code: the "PPS Password
    expiration scope" custom script has the source site's Capella host in its
    Java source (the jansScr field of
    scripts_b58818fa-597a-43f8-a5c9-055f1e7e4c28 in bucket oidcv2). jans-auth
    runs it at startup and it opens a Couchbase connection of its own, so one
    JVM ends up with two SDK cores on two clusters and hundreds of
    AuthenticationFailureException entries against the source site. Repointing
    Vault and the Argo CD parameters cannot reach that copy.
  EOT
}

variable "min_external_secrets" {
  type        = number
  default     = 0
  description = <<-EOT
    Fewest ExternalSecrets the Phase 5 gate must see before it passes.

    Zero, and it has to be: the ExternalSecret objects are created by the Argo
    CD Applications, which sync in Phase 6 - and Phase 6 waits for Phase 5. A
    non-zero minimum here deadlocks the build, which is what happened on the
    2026-10-12 rebuild: the gate sat at "All 0 ExternalSecret(s)" waiting for
    objects that could not exist until it had already passed.

    An adversarial review flagged the 0 default as "the gate's safety net is
    not wired up", and in isolation that reads correctly - a gate that always
    passes checks nothing. But the invariant available at this point is not
    "some secrets exist", it is "ESO is running and every ExternalSecret that
    does exist is synced", which is what the gate actually asserts. Requiring a
    count would only be meaningful in a check that runs after Phase 6.
  EOT
}

variable "external_ingress_vip_manage" {
  type        = bool
  description = <<-EOT
    true: this state creates external_ingress_vip_name and a destroy deletes it,
    so the next build gets a NEW address and PPS must repeat the DNS change.
    false: the address already exists (reserved once, outside this state) and is
    only read, so every rebuild keeps the same address. Before switching to
    false on a site that already created it, run
    `tofu state rm 'google_compute_global_address.external_ingress[0]'` - or the
    next apply would delete it. scripts/dr_destroy.sh does that on its own when
    this is false. To create it by hand:
    gcloud compute addresses create <name> --global
  EOT
  default     = true
}

variable "external_ingress_vip_name" {
  type        = string
  default     = ""
  description = <<-EOT
    Name of the reserved global address for the external ingress, pinned with
    kubernetes.io/ingress.global-static-ip-name.

    Empty leaves GKE to allocate one per rebuild, which has two costs. PPS has
    to issue a new DNS record every time; and because the address is then only
    knowable after Phase 7 creates the ingress, this site's own hostnames
    cannot be redirected until then - which deadlocks the build, since
    oidc-mgmt-portal fetches https://oidc.pps.co.za at startup and wave 1
    cannot converge without it while the ingress waits on wave 1.
  EOT
}

# --------------------------- Stage 8: healthchecks ------------------------

variable "healthchecks_enabled" {
  type        = bool
  description = "Run the in-cluster healthcheck validation after Phase 7. Checks only the workloads deployed on DR that have a healthcheck in modules/75-healthchecks/healthchecks.json (collected from QA)."
  default     = true
}

variable "healthchecks_probe_image" {
  type        = string
  description = "Image of the short-lived pod the HTTP healthchecks are curl'ed from. Must contain curl: the cloud-sdk image used for the restores has neither curl nor python3."
  default     = "docker.io/curlimages/curl:8.10.1"
}

variable "healthchecks_timeout_seconds" {
  type        = number
  description = "How long each healthcheck retries before it counts as failed."
  default     = 180
}

variable "healthchecks_skip_workloads" {
  type        = list(string)
  description = "Workloads left out of the healthchecks, as namespace/name or name."
  default     = []
}

variable "healthchecks_fail_on_error" {
  type        = bool
  description = "Fail the apply when a deployed workload's healthcheck fails. False reports the failure without failing."
  default     = true
}
