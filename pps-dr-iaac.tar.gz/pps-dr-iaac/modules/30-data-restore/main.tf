# Phase 3 - data restore.
#
# PostgreSQL is imported into the pre-existing Cloud SQL instance from GCS, and
# Couchbase is restored into the pre-existing Capella cluster. Neither service
# is created or destroyed here - both are prerequisites. Consul, Vault and LDAP
# are restored into the Phase 2 StatefulSets.
#
# Every restore is gated on its *_restore_enabled flag and triggered on the
# backup object's GCS generation, so a re-apply after a successful restore is a
# no-op instead of a second restore.

# Read only on the gcloud_sql_import path; psql_pod must not depend on the
# Cloud SQL Admin API (openspec change dr-drill-fixes, E3).
data "google_sql_database_instance" "dr" {
  count   = local.uses_sqladmin ? 1 : 0
  name    = var.cloudsql_instance_name
  project = var.project_id
}

locals {
  # One entry per database to restore. postgres_databases carries
  # name -> backup object; with it empty the single-database inputs are used,
  # so an existing configuration keeps working unchanged.
  postgres_restore_set = length(var.postgres_databases) > 0 ? var.postgres_databases : {
    (var.cloudsql_database_name) = var.postgres_backup_object
  }
}

data "external" "postgres_backup_per_db" {
  for_each = var.postgres_restore_enabled && !local.uses_sqladmin ? local.postgres_restore_set : {}

  program = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${each.value}"
    credentials_file = var.backup_credentials_file
  }
}

data "external" "postgres_backup" {
  program = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${var.postgres_backup_object}"
    credentials_file = var.backup_credentials_file
  }
}

data "external" "consul_backup" {
  count   = var.consul_restore_enabled ? 1 : 0
  program = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${var.consul_backup_object}"
    credentials_file = var.backup_credentials_file
  }
}

data "external" "vault_backup" {
  count   = var.vault_restore_enabled ? 1 : 0
  program = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${var.vault_backup_object}"
    credentials_file = var.backup_credentials_file
  }
}

data "external" "ldap_backups" {
  for_each = var.ldap_restore_enabled ? toset(var.ldap_backup_objects) : toset([])
  program  = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${each.value}"
    credentials_file = var.backup_credentials_file
  }
}

locals {
  uses_sqladmin = var.postgres_restore_method == "gcloud_sql_import"

  # cloudsql_private_ip wins when set; otherwise read it off the instance.
  cloudsql_private_ip = var.cloudsql_private_ip != "" ? var.cloudsql_private_ip : try(one([
    for ip in data.google_sql_database_instance.dr[0].ip_address : ip.ip_address
    if ip.type == "PRIVATE"
  ]), "")

  # The import runs as the instance's service account, which must be able to
  # read the dump object. Surfaced so the operator can grant it if missing.
  cloudsql_service_account = try(data.google_sql_database_instance.dr[0].service_account_email_address, "")
}

# gcloud_sql_import stays off until sqladmin.googleapis.com is reachable from
# the DR bastion. A precondition rather than a cross-variable validation, so
# the gate does not depend on the OpenTofu version's support for those.
resource "terraform_data" "postgres_method_gate" {
  input = var.postgres_restore_method

  lifecycle {
    precondition {
      condition     = var.postgres_restore_method != "gcloud_sql_import" || var.allow_gcloud_sql_import
      error_message = "postgres_restore_method = \"gcloud_sql_import\" is disabled until sqladmin.googleapis.com is reachable from the DR bastion. Use \"psql_pod\", or set allow_gcloud_sql_import = true once the network path is fixed."
    }
    precondition {
      condition     = var.postgres_restore_method != "gcloud_sql_import" || var.cloudsql_instance_name != ""
      error_message = "postgres_restore_method = \"gcloud_sql_import\" needs cloudsql_instance_name."
    }
    precondition {
      condition     = var.postgres_restore_method != "psql_pod" || var.cloudsql_private_ip != ""
      error_message = "postgres_restore_method = \"psql_pod\" needs cloudsql_private_ip (the Cloud SQL private IP reachable from the DR cluster)."
    }
  }
}

# --- PostgreSQL: import the GCS dump into Cloud SQL ------------------------

resource "null_resource" "postgres_restore" {
  count = var.postgres_restore_enabled && local.uses_sqladmin ? 1 : 0

  triggers = {
    instance          = var.cloudsql_instance_name
    database          = var.cloudsql_database_name
    backup_object     = var.postgres_backup_object
    backup_generation = data.external.postgres_backup.result.generation
    script            = filemd5("${path.module}/cloudsql_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./cloudsql_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      PROJECT_ID                     = var.project_id
      GOOGLE_APPLICATION_CREDENTIALS = var.gcp_credentials_file
      CLOUDSQL_INSTANCE              = var.cloudsql_instance_name
      DATABASE_NAME                  = var.cloudsql_database_name
      IMPORT_USER                    = var.cloudsql_import_user
      BACKUP_URI                     = "gs://${var.backup_bucket}/${var.postgres_backup_object}"
      CLOUDSQL_SERVICE_ACCOUNT       = local.cloudsql_service_account
    }
  }

  depends_on = [terraform_data.postgres_method_gate]
}

# --- PostgreSQL: stream the GCS dump into Cloud SQL from inside the cluster -

# One Job per database, so a failure isolates to that database and can be
# retried without touching the others. The instance holds midpoint, idpv3 and
# oidc-mgmt-portal, and restoring only midpoint left the other two empty.
resource "null_resource" "postgres_psql_restore" {
  for_each = var.postgres_restore_enabled && !local.uses_sqladmin ? local.postgres_restore_set : {}

  triggers = {
    host              = local.cloudsql_private_ip
    database          = each.key
    backup_object     = each.value
    backup_generation = data.external.postgres_backup_per_db[each.key].result.generation
    recreate          = tostring(var.postgres_recreate_database)
    cleanup           = tostring(var.postgres_cleanup_before_restore)
    partitions        = "${var.postgres_future_partitions}:${join(",", var.postgres_future_partition_dbs)}"
    partitions_script = filemd5("${path.module}/postgres_future_partitions.sh")
    globals_object    = var.postgres_globals_object
    script            = filemd5("${path.module}/psql_restore.sh")
    cleanup_script    = filemd5("${path.module}/postgres_cleanup.sh")
  }

  # Cleanup is the first half of the same provisioner rather than a resource of
  # its own: a restore that failed is retried by the next wave, and the retry
  # has to start from an empty database again. A separate resource would not
  # re-run when only this one is tainted.
  provisioner "local-exec" {
    command     = "${var.postgres_cleanup_before_restore ? "./postgres_cleanup.sh && " : ""}./psql_restore.sh && ./postgres_future_partitions.sh"
    interpreter = ["/bin/bash", "-c"]
    working_dir = path.module

    environment = {
      KUBECONFIG                     = pathexpand(var.kubeconfig_path)
      NAMESPACE                      = var.platform_namespace
      GOOGLE_APPLICATION_CREDENTIALS = var.backup_credentials_file
      BACKUP_URI                     = "gs://${var.backup_bucket}/${each.value}"
      BACKUP_GENERATION              = data.external.postgres_backup_per_db[each.key].result.generation
      PG_HOST                        = local.cloudsql_private_ip
      PG_DATABASE                    = each.key
      PG_USER                        = var.cloudsql_import_user
      PG_PASSWORD                    = var.cloudsql_import_password
      GLOBALS_URI                    = var.postgres_globals_object == "" ? "" : "gs://${var.backup_bucket}/${var.postgres_globals_object}"
      RECREATE_DATABASE              = tostring(var.postgres_recreate_database)
      FUTURE_PARTITIONS              = tostring(var.postgres_future_partitions)
      FUTURE_PARTITION_DATABASES     = join(" ", var.postgres_future_partition_dbs)
      ON_ERROR_STOP                  = tostring(var.postgres_on_error_stop)
      TIMEOUT_SECONDS                = tostring(var.postgres_restore_timeout_seconds)
      FETCH_IMAGE                    = var.postgres_fetch_image
      CLIENT_IMAGE                   = var.postgres_client_image
      DUMP_FORMAT                    = var.postgres_dump_format
      RESTORE_JOBS                   = tostring(var.postgres_restore_jobs)
      STAGE_SIZE                     = var.postgres_stage_size
      RESTORE_WORK_MEM               = var.postgres_restore_work_mem
      SKIP_FK_CONSTRAINTS            = join(" ", var.postgres_skip_fk_constraints)
      EXCLUDE_TABLE_DATA             = join(" ", var.postgres_exclude_table_data)
      RESTORE_PARALLEL_WORKERS       = tostring(var.postgres_restore_parallel_workers)
      # A PVC, not node ephemeral storage: the nodes have 98GiB and
      # midpoint's archive is 117GB.
      STAGE_STORAGE_CLASS = var.postgres_stage_storage_class != "" ? var.postgres_stage_storage_class : var.storage_class
      PIN_GOOGLEAPIS      = tostring(var.pin_googleapis)
      SESSION_TUNING      = var.postgres_session_tuning
    }
  }

  depends_on = [terraform_data.postgres_method_gate]
}

# Post-restore verification plus the in-cluster connectivity check. Runs even
# when the import is disabled, so a re-run still proves the data tier is usable.
resource "null_resource" "postgres_verify" {
  triggers = {
    instance   = var.cloudsql_instance_name
    database   = var.cloudsql_database_name
    restore_id = try(null_resource.postgres_restore[0].id, join(",", [for r in null_resource.postgres_psql_restore : r.id]), "skipped")
    script     = filemd5("${path.module}/cloudsql_verify.sh")
    min_tables = tostring(var.postgres_min_expected_tables)
  }

  provisioner "local-exec" {
    command     = "./cloudsql_verify.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG          = pathexpand(var.kubeconfig_path)
      NAMESPACE           = var.platform_namespace
      PG_HOST             = local.cloudsql_private_ip
      PG_DATABASE         = var.cloudsql_database_name
      PG_USER             = var.cloudsql_import_user
      PG_PASSWORD         = var.cloudsql_import_password
      PG_CLIENT_IMAGE     = var.postgres_client_image
      MIN_EXPECTED_TABLES = tostring(var.postgres_min_expected_tables)
    }
  }

  depends_on = [null_resource.postgres_restore, null_resource.postgres_psql_restore]
}

# --- Couchbase: restore into Capella, per bucket ---------------------------
#
# couchbase_restore_methods picks the path per bucket (openspec change
# dr-drill-fixes, E5): capella_api and cbbackupmgr run on the bastion,
# cbimport runs as an in-cluster Job. Each restore triggers on its backup
# object's generation, so a re-apply after success is a no-op.

locals {
  couchbase_enabled_methods = var.couchbase_restore_enabled ? var.couchbase_restore_methods : {}

  couchbase_bastion_buckets = {
    for b, m in local.couchbase_enabled_methods : b => m if m != "cbimport"
  }
  couchbase_cbimport_buckets = {
    for b, m in local.couchbase_enabled_methods : b => m if m == "cbimport"
  }
  couchbase_object_buckets = {
    for b, m in local.couchbase_enabled_methods : b => var.couchbase_backup_objects[b] if m != "capella_api"
  }

  # First host of the connection string, for the query/management REST APIs.
  # Empty means "use the CA committed in modules/common", so verification is
  # the default and nothing depends on an operator having fetched it.
  couchbase_ca_cert_file = var.couchbase_ca_cert_file != "" ? pathexpand(var.couchbase_ca_cert_file) : abspath("${path.root}/modules/common/capella-cloud-ca.pem")

  couchbase_host = split(",", split("?", split("/", replace(var.capella_connection_string, "/^[a-z]+:\\/\\//", ""))[0])[0])[0]
}

resource "terraform_data" "couchbase_inputs_gate" {
  input = local.couchbase_enabled_methods

  lifecycle {
    precondition {
      condition = alltrue([
        for b, m in local.couchbase_enabled_methods : m == "capella_api" || lookup(var.couchbase_backup_objects, b, "") != ""
      ])
      error_message = "Every bucket restored with cbbackupmgr or cbimport needs an entry in couchbase_backup_objects."
    }
    precondition {
      condition = alltrue([
        for b, m in local.couchbase_enabled_methods : m != "cbimport" || lookup(var.couchbase_cbimport_key_modes, b, "") != ""
      ])
      error_message = "Every bucket restored with cbimport needs a key mode in couchbase_cbimport_key_modes (jans_dn or field:<name>)."
    }
    precondition {
      condition     = !contains(values(local.couchbase_enabled_methods), "capella_api") || var.capella_api_token != ""
      error_message = "couchbase_restore_methods uses capella_api, which needs TF_VAR_capella_api_token."
    }
  }
}

data "external" "couchbase_backups" {
  for_each = local.couchbase_object_buckets
  program  = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${each.value}"
    credentials_file = var.backup_credentials_file
  }
}

resource "null_resource" "capella_restore" {
  for_each = local.couchbase_bastion_buckets

  triggers = {
    bucket            = each.key
    method            = each.value
    cluster           = var.capella_cluster_id
    backup_object     = lookup(var.couchbase_backup_objects, each.key, "")
    backup_generation = try(data.external.couchbase_backups[each.key].result.generation, "")
    script            = filemd5("${path.module}/capella_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./capella_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      BUCKET                                 = each.key
      METHOD                                 = each.value
      CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE = var.backup_credentials_file
      BACKUP_URI                             = lookup(var.couchbase_backup_objects, each.key, "") == "" ? "" : "gs://${var.backup_bucket}/${var.couchbase_backup_objects[each.key]}"
      CONNECTION_STRING                      = var.capella_connection_string
      COUCHBASE_USERNAME                     = var.couchbase_username
      COUCHBASE_PASSWORD                     = var.couchbase_password
      COUCHBASE_FLUSH_BEFORE_RESTORE         = tostring(var.couchbase_flush_before_restore)
      CAPELLA_API_URL                        = var.capella_api_url
      CAPELLA_API_TOKEN                      = var.capella_api_token
      CAPELLA_ORG_ID                         = var.capella_organization_id
      CAPELLA_PROJECT_ID                     = var.capella_project_id
      CAPELLA_CLUSTER_ID                     = var.capella_cluster_id
    }
  }

  depends_on = [terraform_data.couchbase_inputs_gate]
}

resource "null_resource" "couchbase_cbimport" {
  for_each = local.couchbase_cbimport_buckets

  triggers = {
    bucket            = each.key
    backup_object     = var.couchbase_backup_objects[each.key]
    backup_generation = data.external.couchbase_backups[each.key].result.generation
    key_mode          = var.couchbase_cbimport_key_modes[each.key]
    script            = filemd5("${path.module}/cbimport_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./cbimport_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG                     = pathexpand(var.kubeconfig_path)
      NAMESPACE                      = var.platform_namespace
      GOOGLE_APPLICATION_CREDENTIALS = var.backup_credentials_file
      BUCKET                         = each.key
      BACKUP_URI                     = "gs://${var.backup_bucket}/${var.couchbase_backup_objects[each.key]}"
      BACKUP_GENERATION              = data.external.couchbase_backups[each.key].result.generation
      KEY_MODE                       = var.couchbase_cbimport_key_modes[each.key]
      CONNECTION_STRING              = var.capella_connection_string
      COUCHBASE_USERNAME             = var.couchbase_username
      COUCHBASE_PASSWORD             = var.couchbase_password
      FLUSH_BEFORE_RESTORE           = tostring(var.couchbase_flush_before_restore)
      FETCH_IMAGE                    = var.postgres_fetch_image
      COUCHBASE_IMAGE                = var.couchbase_server_image
    }
  }

  depends_on = [terraform_data.couchbase_inputs_gate]
}

data "external" "couchbase_indexes" {
  count   = var.couchbase_restore_enabled && var.couchbase_index_definitions_object != "" ? 1 : 0
  program = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${var.couchbase_index_definitions_object}"
    credentials_file = var.backup_credentials_file
  }
}

resource "null_resource" "couchbase_indexes" {
  count = length(data.external.couchbase_indexes)

  triggers = {
    object     = var.couchbase_index_definitions_object
    generation = data.external.couchbase_indexes[0].result.generation
    script     = filemd5("${path.module}/capella_indexes.sh")
  }

  provisioner "local-exec" {
    command     = "./capella_indexes.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      INDEX_URI                              = "gs://${var.backup_bucket}/${var.couchbase_index_definitions_object}"
      CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE = var.backup_credentials_file
      QUERY_HOST                             = local.couchbase_host
      COUCHBASE_USERNAME                     = var.couchbase_username
      COUCHBASE_PASSWORD                     = var.couchbase_password
      COUCHBASE_CA_CERT_FILE                 = local.couchbase_ca_cert_file
    }
  }

  depends_on = [null_resource.capella_restore, null_resource.couchbase_cbimport]
}

# The restore brings the source site's data verbatim, and some of that data is
# configuration - including code. The "PPS Password expiration scope" custom
# script has the source site's Capella host written into its Java source, in
# the jansScr field of scripts_b58818fa-597a-43f8-a5c9-055f1e7e4c28 in bucket
# oidcv2. jans-auth runs that script at startup and it opens a Couchbase
# connection of its own, so the JVM ends up with two SDK cores on two clusters
# and hundreds of AuthenticationFailureException entries against the source
# site's host. Repointing Vault and the Argo CD parameters cannot reach this
# copy; nothing outside the database can.
resource "null_resource" "couchbase_rewrite_endpoints" {
  count = var.couchbase_rewrite_document_endpoints && length(var.capella_buckets) > 0 ? 1 : 0

  triggers = {
    buckets  = join(",", var.capella_buckets)
    host     = local.couchbase_host
    restores = jsonencode(concat([for r in null_resource.capella_restore : r.id], [for r in null_resource.couchbase_cbimport : r.id]))
    script   = filemd5("${path.module}/capella_rewrite_endpoints.sh")
  }

  provisioner "local-exec" {
    command     = "./capella_rewrite_endpoints.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      QUERY_HOST             = local.couchbase_host
      CAPELLA_HOST           = local.couchbase_host
      BUCKETS                = join(" ", var.capella_buckets)
      COUCHBASE_USERNAME     = var.couchbase_username
      COUCHBASE_PASSWORD     = var.couchbase_password
      COUCHBASE_CA_CERT_FILE = local.couchbase_ca_cert_file
    }
  }

  # After the index build, not before it. The search below filters on
  # objectClass, which needs a secondary index online - and every index a
  # restore brings is deferred until couchbase_build_indexes runs. Ordered the
  # other way the query cannot be served at all.
  depends_on = [
    null_resource.capella_restore,
    null_resource.couchbase_cbimport,
    null_resource.couchbase_build_indexes,
  ]
}

# cbbackupmgr restores index definitions deferred, and null_resource
# .couchbase_indexes above only exists when an index definition file is
# supplied (count = length(data.external.couchbase_indexes)). With
# couchbase_index_definitions_object empty - the normal case, since the DR
# cluster gets its definitions from the backup - nothing built them, and
# jans-auth cannot start against a bucket whose indexes are deferred. This
# step is unconditional on that file and waits for the builds to finish.
resource "null_resource" "couchbase_build_indexes" {
  count = var.couchbase_build_deferred_indexes && length(var.capella_buckets) > 0 ? 1 : 0

  triggers = {
    buckets  = join(",", var.capella_buckets)
    restores = jsonencode(concat([for r in null_resource.capella_restore : r.id], [for r in null_resource.couchbase_cbimport : r.id]))
    script   = filemd5("${path.module}/capella_build_indexes.sh")
  }

  provisioner "local-exec" {
    command     = "./capella_build_indexes.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      QUERY_HOST             = local.couchbase_host
      BUCKETS                = join(" ", var.capella_buckets)
      COUCHBASE_USERNAME     = var.couchbase_username
      COUCHBASE_PASSWORD     = var.couchbase_password
      COUCHBASE_CA_CERT_FILE = local.couchbase_ca_cert_file
      WAIT_SECONDS           = tostring(var.couchbase_index_build_timeout_seconds)
    }
  }

  depends_on = [
    null_resource.capella_restore,
    null_resource.couchbase_cbimport,
    null_resource.couchbase_indexes,
  ]
}

resource "null_resource" "capella_verify" {
  count = length(var.capella_buckets) > 0 ? 1 : 0

  triggers = {
    buckets  = join(",", var.capella_buckets)
    restores = jsonencode(concat([for r in null_resource.capella_restore : r.id], [for r in null_resource.couchbase_cbimport : r.id]))
    expected = jsonencode(var.couchbase_expected_doc_counts)
    script   = filemd5("${path.module}/capella_verify.sh")
  }

  provisioner "local-exec" {
    command     = "./capella_verify.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      CAPELLA_API_URL    = var.capella_api_url
      CAPELLA_API_TOKEN  = var.capella_api_token
      CAPELLA_ORG_ID     = var.capella_organization_id
      CAPELLA_PROJECT_ID = var.capella_project_id
      CAPELLA_CLUSTER_ID = var.capella_cluster_id
      CAPELLA_BUCKETS    = join(" ", var.capella_buckets)
      CONNECTION_STRING  = var.capella_connection_string
      COUCHBASE_USERNAME = var.couchbase_username
      COUCHBASE_PASSWORD = var.couchbase_password
      EXPECTED_COUNTS    = join(" ", [for b, n in var.couchbase_expected_doc_counts : "${b}=${n}"])
    }
  }

  depends_on = [null_resource.capella_restore, null_resource.couchbase_cbimport, null_resource.couchbase_indexes]
}

# --- Consul KV --------------------------------------------------------------

resource "null_resource" "consul_restore" {
  count = var.consul_restore_enabled ? 1 : 0

  triggers = {
    backup_object     = var.consul_backup_object
    backup_generation = data.external.consul_backup[0].result.generation
    script            = filemd5("${path.module}/consul_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./consul_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG              = pathexpand(var.kubeconfig_path)
      BACKUP_CREDENTIALS_FILE = var.backup_credentials_file
      NAMESPACE               = var.platform_namespace
      BACKUP_URI              = "gs://${var.backup_bucket}/${var.consul_backup_object}"
    }
  }

  depends_on = [terraform_data.platform_ready]
}

# The Consul restore replaces Vault's storage while Vault is running, so Vault
# keeps serving the cluster Phase 2 initialised and fails every request with
# "decryption failed". It also inherits the source cluster's HA lock. Clear the
# lock and restart Vault so it picks up the restored data and auto-unseals.
resource "null_resource" "vault_post_consul_restore" {
  count = var.consul_restore_enabled && var.vault_uses_consul_storage ? 1 : 0

  triggers = {
    consul_restore = null_resource.consul_restore[0].id
    script         = filemd5("${path.module}/vault_post_consul_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./vault_post_consul_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.platform_namespace
      CONSUL_POD      = "consul-server-0"
      VAULT_LABEL     = "app.kubernetes.io/name=vault"
      TIMEOUT_SECONDS = tostring(var.vault_recovery_timeout_seconds)
    }
  }
}

# --- Vault ------------------------------------------------------------------

resource "null_resource" "vault_restore" {
  count = var.vault_restore_enabled ? 1 : 0

  triggers = {
    backup_object     = var.vault_backup_object
    backup_generation = data.external.vault_backup[0].result.generation
    script            = filemd5("${path.module}/vault_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./vault_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG              = pathexpand(var.kubeconfig_path)
      BACKUP_CREDENTIALS_FILE = var.backup_credentials_file
      NAMESPACE               = var.platform_namespace
      BACKUP_URI              = "gs://${var.backup_bucket}/${var.vault_backup_object}"
      VAULT_ROOT_TOKEN        = var.vault_root_token
    }
  }

  # Vault stores its data in Consul, so Consul must be restored first.
  depends_on = [
    terraform_data.platform_ready,
    null_resource.consul_restore,
  ]
}

# --- OpenLDAP ---------------------------------------------------------------

# The LDAP certificate production serves, installed before the LDAP restore so
# the restore's pod restart is the one that loads it. See ldap_tls_restore.sh.
resource "null_resource" "ldap_tls" {
  count = length(var.ldap_tls_objects) > 0 ? 1 : 0

  triggers = {
    objects = join(",", var.ldap_tls_objects)
    pod     = var.ldap_pod_name
    script  = filemd5("${path.module}/ldap_tls_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./ldap_tls_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG              = pathexpand(var.kubeconfig_path)
      BACKUP_CREDENTIALS_FILE = var.backup_credentials_file
      NAMESPACE               = var.ldap_namespace
      BACKUP_BUCKET           = var.backup_bucket
      LDAP_POD                = var.ldap_pod_name
      TLS_OBJECTS             = join(" ", var.ldap_tls_objects)
    }
  }

  depends_on = [terraform_data.platform_ready]
}

resource "null_resource" "ldap_restore" {
  count = var.ldap_restore_enabled && length(var.ldap_backup_objects) > 0 ? 1 : 0

  triggers = {
    backup_objects = join(",", var.ldap_backup_objects)
    backup_generations = join(",", [
      for o in var.ldap_backup_objects : data.external.ldap_backups[o].result.generation
    ])
    script         = filemd5("${path.module}/ldap_restore.sh")
    restore_config = tostring(var.ldap_restore_config)
  }

  provisioner "local-exec" {
    command     = "./ldap_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG               = pathexpand(var.kubeconfig_path)
      BACKUP_CREDENTIALS_FILE  = var.backup_credentials_file
      NAMESPACE                = var.ldap_namespace
      BACKUP_BUCKET            = var.backup_bucket
      LDIF_OBJECTS             = join(" ", var.ldap_backup_objects)
      LDAP_ADMIN_PASSWORD      = var.ldap_admin_password
      LDAP_BASE_DN             = var.ldap_base_dn
      LDAP_POD                 = var.ldap_pod_name
      LDAP_SLAPD_CONFIG_DIR    = var.ldap_slapd_config_dir
      LDAP_WIPE_BEFORE_RESTORE = tostring(var.ldap_wipe_before_restore)
      LDAP_RESTORE_CONFIG      = tostring(var.ldap_restore_config)
      SLAPADD_QUICK            = tostring(var.ldap_slapadd_quick)
    }
  }

  depends_on = [terraform_data.platform_ready, null_resource.ldap_tls]
}

# DR-only group membership: the service accounts under ou=services also write on
# DR. Runs after the data is loaded. See ldap_group_members.sh.
resource "null_resource" "ldap_access_rules" {
  count = var.ldap_restore_enabled && length(var.ldap_access_rules) > 0 ? 1 : 0

  triggers = {
    rules   = jsonencode(var.ldap_access_rules)
    pod     = var.ldap_pod_name
    restore = join(",", [for r in null_resource.ldap_restore : r.id])
    script  = filemd5("${path.module}/ldap_access_rules.sh")
  }

  provisioner "local-exec" {
    command     = "./ldap_access_rules.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG   = pathexpand(var.kubeconfig_path)
      NAMESPACE    = var.ldap_namespace
      LDAP_POD     = var.ldap_pod_name
      ACCESS_RULES = join("\n", flatten([for suffix, rules in var.ldap_access_rules : [for i, r in rules : "${suffix}|${i}|${r}"]]))
    }
  }

  depends_on = [null_resource.ldap_restore]
}

resource "null_resource" "ldap_groups" {
  count = var.ldap_restore_enabled && (length(var.ldap_group_additions) > 0 || length(var.ldap_group_member_dns) > 0) ? 1 : 0

  triggers = {
    additions = jsonencode(var.ldap_group_additions)
    members   = jsonencode(var.ldap_group_member_dns)
    pod       = var.ldap_pod_name
    restore   = join(",", [for r in null_resource.ldap_restore : r.id])
    script    = filemd5("${path.module}/ldap_group_members.sh")
  }

  provisioner "local-exec" {
    command     = "./ldap_group_members.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG          = pathexpand(var.kubeconfig_path)
      NAMESPACE           = var.ldap_namespace
      LDAP_POD            = var.ldap_pod_name
      LDAP_ADMIN_DN       = var.ldap_admin_dn != "" ? var.ldap_admin_dn : "cn=admin,${var.ldap_base_dn}"
      LDAP_ADMIN_PASSWORD = var.ldap_admin_password
      GROUP_ADDITIONS     = join("\n", [for g, b in var.ldap_group_additions : "${g}|${b}"])
      GROUP_MEMBERS       = join("\n", flatten([for g, ms in var.ldap_group_member_dns : [for m in ms : "${g}|${m}"]]))
    }
  }

  depends_on = [null_resource.ldap_restore, null_resource.ldap_access_rules]
}

# --- Report -----------------------------------------------------------------

resource "local_file" "restore_report" {
  filename = "${path.module}/${var.report_path}"
  content = jsonencode({
    postgres = {
      enabled       = var.postgres_restore_enabled
      method        = var.postgres_restore_method
      instance      = var.cloudsql_instance_name
      host          = local.cloudsql_private_ip
      database      = var.cloudsql_database_name
      source        = "gs://${var.backup_bucket}/${var.postgres_backup_object}"
      generation    = data.external.postgres_backup.result.generation
      verified      = true
      resource_kind = "prerequisite (data source)"
    }
    couchbase = {
      enabled       = var.couchbase_restore_enabled
      cluster       = var.capella_cluster_id
      buckets       = var.capella_buckets
      methods       = var.couchbase_restore_methods
      objects       = var.couchbase_backup_objects
      resource_kind = "prerequisite (data source)"
    }
    consul = {
      enabled = var.consul_restore_enabled
      source  = var.consul_restore_enabled ? "gs://${var.backup_bucket}/${var.consul_backup_object}" : ""
    }
    vault = {
      enabled = var.vault_restore_enabled
      source  = var.vault_restore_enabled ? "gs://${var.backup_bucket}/${var.vault_backup_object}" : ""
    }
    ldap = {
      enabled = var.ldap_restore_enabled
      sources = var.ldap_backup_objects
    }
  })

  depends_on = [
    null_resource.postgres_verify,
    null_resource.capella_verify,
    null_resource.consul_restore,
    null_resource.vault_restore,
    null_resource.ldap_restore,
    null_resource.ldap_access_rules,
    null_resource.ldap_groups,
  ]
}

# --- phase gates -------------------------------------------------------------
# Phase 3 restores two unrelated things, and they have different consumers:
#
#   platform data  - Consul KV, the Vault recovery that follows it, and LDAP.
#                    Phase 5 needs these: the Vault policies and AppRoles it
#                    configures come from the restored Consul data.
#   databases      - Postgres and Capella. Only the application sync in Phase 6
#                    needs these, because that is when app pods first connect.
#
# Exposing one gate per group lets Argo CD and the secrets phase start while
# midpoint is still restoring - measured at ~48 minutes of staging alone, which
# every later phase used to sit behind.
resource "terraform_data" "platform_data_gate" {
  input = "platform-data-restored"

  depends_on = [
    null_resource.consul_restore,
    null_resource.vault_restore,
    null_resource.vault_post_consul_restore,
    null_resource.ldap_restore,
    null_resource.ldap_access_rules,
    null_resource.ldap_groups,
  ]
}

resource "terraform_data" "database_gate" {
  input = "databases-restored"

  depends_on = [
    null_resource.postgres_verify,
    null_resource.capella_verify,
    null_resource.couchbase_rewrite_endpoints,
  ]
}

# Consul, Vault and LDAP restores need the platform running; Postgres and
# Capella do not, which is why the module as a whole no longer waits for it.
resource "terraform_data" "platform_ready" {
  input = var.platform_gate
}
