#!/usr/bin/env bash
# Restore Vault data into the DR Vault.
#
# Runs after the Consul restore: Vault's storage backend is Consul, so a Consul
# restore that lands after this would overwrite it.
set -euo pipefail

: "${NAMESPACE:?}" "${BACKUP_URI:?}" "${VAULT_ROOT_TOKEN:?}"

POD="vault-0"
WORKDIR=$(mktemp -d)
trap 'rm -rf "${WORKDIR}"' EXIT

echo "Downloading ${BACKUP_URI}..."
if [[ -n "${BACKUP_CREDENTIALS_FILE:-}" ]]; then
  CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE="${BACKUP_CREDENTIALS_FILE}" \
    gcloud storage cp "${BACKUP_URI}" "${WORKDIR}/vault-backup.snap"
else
  gcloud storage cp "${BACKUP_URI}" "${WORKDIR}/vault-backup.snap"
fi

kubectl -n "${NAMESPACE}" cp "${WORKDIR}/vault-backup.snap" "${POD}:/tmp/vault-backup.snap"

echo "Restoring Vault snapshot (force: DR cluster id differs from the source)..."
kubectl -n "${NAMESPACE}" exec "${POD}" -- \
  sh -c "VAULT_TOKEN='${VAULT_ROOT_TOKEN}' vault operator raft snapshot restore -force /tmp/vault-backup.snap" \
  || {
    echo "Raft snapshot restore failed - this Vault uses the Consul storage backend," >&2
    echo "so its data arrives with the Consul restore. Set vault_restore_enabled=false" >&2
    echo "if the Vault backup is not a raft snapshot." >&2
    exit 1
  }

# Vault seals itself after a snapshot restore; unseal before continuing.
INIT_JSON=$(kubectl -n "${NAMESPACE}" get secret vault-unseal-keys -o jsonpath='{.data.init\.json}' | base64 -d)
mapfile -t KEYS < <(echo "${INIT_JSON}" | jq -r '.unseal_keys_b64[]' | head -n 3)
for key in ${KEYS[@]+"${KEYS[@]}"}; do
  kubectl -n "${NAMESPACE}" exec "${POD}" -- vault operator unseal "${key}" >/dev/null || true
done

# jq's `//` treats `false` as empty, so `.sealed // true` is always true on an
# unsealed Vault. Read the boolean through has() instead.
SEALED=$(kubectl -n "${NAMESPACE}" exec "${POD}" -- vault status -format=json 2>/dev/null \
  | jq -r 'if has("sealed") then .sealed else true end')
if [[ "${SEALED}" != "false" ]]; then
  echo "ERROR: Vault is sealed after the restore." >&2
  exit 1
fi

echo "Vault restore completed and Vault is unsealed."
