#!/usr/bin/env bash
# Import ONE Couchbase bucket from a cbexport JSON file, from INSIDE the DR
# cluster (the bastion has no cbimport and no python3).
#
# The prod oidcv2 export is a JSON *list* without document keys, so keys are
# rebuilt before import:
#   KEY_MODE=jans_dn      - Janssen key from `dn`: RDN values minus the trailing
#                           base (o=jans), reversed, joined with "_"; the base
#                           entry itself maps to "_". Matches 84,902/84,903 QA
#                           oidcv2 keys (openspec change dr-drill-fixes, E5).
#   KEY_MODE=field:<name> - the value of a body field (kept in the document).
#   KEY_MODE=id_field:<name> - the value of an export-only id field, removed
#                           from the document (e.g. __doc_id__ written by a
#                           N1QL "SELECT META().id AS __doc_id__, b.*" export).
# Input may be a JSON list or JSON lines, optionally gzip-compressed (.gz).
#
# Job layout: an init container (google-cloud-cli, which ships python3)
# downloads the export and writes JSON lines with a helper key field; the
# main container (couchbase/server) runs cbimport, generating the key from
# that field and dropping it from the stored document.
set -euo pipefail

: "${NAMESPACE:?}" "${BUCKET:?}" "${BACKUP_URI:?}" "${BACKUP_GENERATION:?}" "${KEY_MODE:?}" \
  "${CONNECTION_STRING:?}" "${COUCHBASE_USERNAME:?}" "${COUCHBASE_PASSWORD:?}" \
  "${GOOGLE_APPLICATION_CREDENTIALS:?}" "${FETCH_IMAGE:?}" "${COUCHBASE_IMAGE:?}"

TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-14400}"
THREADS="${THREADS:-4}"
# Job names: lowercase RFC 1123, <= 63 chars.
SAFE_BUCKET=$(echo "${BUCKET}" | tr '[:upper:]_' '[:lower:]-' | cut -c1-24)
JOB="cbimport-${SAFE_BUCKET}-${BACKUP_GENERATION: -10}"
KEY_SECRET="dr-backup-reader-key"
CRED_SECRET="${JOB}-cred"

case "${KEY_MODE}" in
  jans_dn|field:?*|id_field:?*) ;;
  *) echo "ERROR: unsupported key mode '${KEY_MODE}' for bucket ${BUCKET} (expected jans_dn, field:<name> or id_field:<name>)." >&2; exit 1 ;;
esac

job_state() {
  local succeeded failed
  succeeded=$(kubectl -n "${NAMESPACE}" get job "${JOB}" -o jsonpath='{.status.succeeded}' 2>/dev/null || true)
  failed=$(kubectl -n "${NAMESPACE}" get job "${JOB}" -o jsonpath='{.status.failed}' 2>/dev/null || true)
  if [[ "${succeeded:-0}" -ge 1 ]]; then echo succeeded
  elif [[ "${failed:-0}" -ge 1 ]]; then echo failed
  else echo running
  fi
}

JOB_PRESENT=no
if kubectl -n "${NAMESPACE}" get job "${JOB}" >/dev/null 2>&1; then
  # Re-attaching to a *failed* Job would make every later attempt fail on the
  # same dead pod, so the import is started again instead.
  if [[ "$(job_state)" == "failed" ]]; then
    echo "Job ${JOB} exists but failed; deleting it and importing again."
    kubectl -n "${NAMESPACE}" logs "job/${JOB}" --tail=40 >&2 || true
    kubectl -n "${NAMESPACE}" delete job "${JOB}" --ignore-not-found >/dev/null
  else
    echo "Job ${JOB} already exists for this backup generation; re-attaching."
    JOB_PRESENT=yes
  fi
fi

if [[ "${JOB_PRESENT}" == "no" ]]; then
  kubectl -n "${NAMESPACE}" create secret generic "${KEY_SECRET}" \
    --from-file=key.json="${GOOGLE_APPLICATION_CREDENTIALS}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null
  kubectl -n "${NAMESPACE}" create secret generic "${CRED_SECRET}" \
    --from-literal=CB_USER="${COUCHBASE_USERNAME}" \
    --from-literal=CB_PASS="${COUCHBASE_PASSWORD}" \
    --dry-run=client -o yaml | kubectl apply -f - >/dev/null

  echo "Creating Job ${JOB}: ${BACKUP_URI} -> bucket ${BUCKET} (key mode ${KEY_MODE})"

  cat <<EOF | kubectl -n "${NAMESPACE}" apply -f - >/dev/null
apiVersion: batch/v1
kind: Job
metadata:
  name: ${JOB}
  labels:
    app.kubernetes.io/name: cbimport-restore
    pps-dr/phase: "3"
spec:
  backoffLimit: 0
  activeDeadlineSeconds: ${TIMEOUT_SECONDS}
  ttlSecondsAfterFinished: 604800
  template:
    metadata:
      labels:
        app.kubernetes.io/name: cbimport-restore
    spec:
      restartPolicy: Never
      volumes:
        - name: work
          emptyDir:
            sizeLimit: 20Gi
        - name: gcp-key
          secret:
            secretName: ${KEY_SECRET}
      initContainers:
        - name: prepare
          image: ${FETCH_IMAGE}
          resources:
            requests: { cpu: 500m, memory: 1Gi }
          volumeMounts:
            - { name: work, mountPath: /work }
            - { name: gcp-key, mountPath: /var/secrets/gcp, readOnly: true }
          env:
            - { name: BACKUP_URI, value: "${BACKUP_URI}" }
            - { name: KEY_MODE, value: "${KEY_MODE}" }
          command: ["/bin/bash", "-c"]
          args:
            - |
              set -euo pipefail
              gcloud auth activate-service-account --key-file=/var/secrets/gcp/key.json >/dev/null
              case "\${BACKUP_URI}" in
                *.gz) gcloud storage cat "\${BACKUP_URI}" | gunzip -c > /work/export.json ;;
                *)    gcloud storage cp "\${BACKUP_URI}" /work/export.json ;;
              esac
              python3 - <<'PY'
              import json, os, sys
              mode = os.environ["KEY_MODE"]
              def key_of(doc):
                  if mode == "jans_dn":
                      dn = doc.get("dn")
                      if not dn:
                          return None
                      values = [rdn.split("=", 1)[1] for rdn in dn.split(",") if "=" in rdn]
                      return "_".join(reversed(values[:-1])) or "_"
                  kind, field = mode.split(":", 1)
                  value = doc.pop(field, None) if kind == "id_field" else doc.get(field)
                  return None if value is None else str(value)
              written = missing = 0
              with open("/work/export.json") as src, open("/work/lines.json", "w") as out:
                  for lineno, raw in enumerate(src, 1):
                      line = raw.strip()
                      if line in ("", "[", "]"):
                          continue
                      # cbexport list layout: "[" / "{doc}," ... "{doc}" / "]",
                      # with the brackets sometimes glued to the first/last doc.
                      if line.startswith("["):
                          line = line[1:]
                      if line.endswith(","):
                          line = line[:-1]
                      if line.endswith("]"):
                          line = line[:-1]
                      if not line:
                          continue
                      try:
                          doc = json.loads(line)
                      except ValueError as exc:
                          sys.exit(f"line {lineno}: not one JSON document per line ({exc}); the export is not in cbexport list/lines layout")
                      if "__dr_key" in doc:
                          sys.exit(f"line {lineno}: document already has a __dr_key field")
                      key = key_of(doc)
                      if key is None:
                          missing += 1
                          continue
                      doc["__dr_key"] = key
                      out.write(json.dumps(doc, separators=(",", ":")) + "\n")
                      written += 1
              print(f"prepared {written} documents, {missing} without a derivable key")
              if missing:
                  sys.exit(f"{missing} documents have no key under mode {mode}; refusing a partial import")
              open("/work/expected", "w").write(str(written))
              PY
              rm -f /work/export.json
      containers:
        - name: cbimport
          image: ${COUCHBASE_IMAGE}
          resources:
            requests: { cpu: "1", memory: 2Gi }
          volumeMounts:
            - { name: work, mountPath: /work }
          envFrom:
            - secretRef: { name: ${CRED_SECRET} }
          env:
            - { name: CONN, value: "${CONNECTION_STRING}" }
            - { name: BUCKET, value: "${BUCKET}" }
            - { name: FLUSH_BEFORE_RESTORE, value: "${FLUSH_BEFORE_RESTORE:-true}" }
          command: ["/bin/bash", "-c"]
          args:
            - |
              set -uo pipefail
              CBIMPORT=/opt/couchbase/bin/cbimport
              if ! "\${CBIMPORT}" json --help 2>&1 | grep -q -- '--ignore-fields'; then
                echo "ERROR: this cbimport has no --ignore-fields; use a newer couchbase_server_image" >&2
                exit 1
              fi
              if [ "\${FLUSH_BEFORE_RESTORE:-true}" = "true" ]; then
                HOST="\${CONN#*://}"; HOST="\${HOST%%[/?,]*}"
                echo "flushing bucket \${BUCKET} on \${HOST}:18091"
                code=\$(curl -sk --max-time 60 -u "\${CB_USER}:\${CB_PASS}" -X POST -o /dev/null -w '%{http_code}' "https://\${HOST}:18091/pools/default/buckets/\${BUCKET}/controller/doFlush")
                case "\${code}" in 200|202) echo flush ok ;; 400|403) echo "WARNING: flush rejected (HTTP \${code}): flushEnabled is off; continuing without flush" >&2 ;; *) echo "ERROR flush \${code}" >&2; exit 1 ;; esac
                for i in \$(seq 1 60); do st=\$(curl -sk --max-time 10 -u "\${CB_USER}:\${CB_PASS}" "https://\${HOST}:18091/pools/default/buckets/\${BUCKET}" | jq -r '.nodes[0].status // "unknown"'); [ "\$st" = "healthy" ] && break; sleep 2; done
              fi
              echo "importing \$(cat /work/expected) documents into \${BUCKET}"
              "\${CBIMPORT}" json -c "\${CONN}" -u "\${CB_USER}" -p "\${CB_PASS}" -b "\${BUCKET}" \
                -d file:///work/lines.json -f lines -g '%__dr_key%' --ignore-fields __dr_key \
                -t ${THREADS} -e /work/errors.log
              rc=\$?
              if [ -s /work/errors.log ]; then
                echo "ERROR: cbimport rejected \$(wc -l < /work/errors.log) documents; first ones:" >&2
                head -c 2000 /work/errors.log >&2
                exit 1
              fi
              exit \${rc}
EOF
fi

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
while true; do
  STATE=$(job_state)
  case "${STATE}" in
    succeeded)
      kubectl -n "${NAMESPACE}" logs "job/${JOB}" -c cbimport --tail=5 || true
      kubectl -n "${NAMESPACE}" delete secret "${CRED_SECRET}" --ignore-not-found >/dev/null 2>&1 || true
      echo "cbimport Job ${JOB} succeeded for bucket ${BUCKET}."
      exit 0
      ;;
    failed)
      echo "ERROR: cbimport Job ${JOB} failed for bucket ${BUCKET}." >&2
      kubectl -n "${NAMESPACE}" logs "job/${JOB}" -c prepare --tail=20 >&2 || true
      kubectl -n "${NAMESPACE}" logs "job/${JOB}" -c cbimport --tail=40 >&2 || true
      echo "Fix the cause, then delete the Job to retry: kubectl -n ${NAMESPACE} delete job ${JOB}" >&2
      exit 1
      ;;
  esac
  if [[ ${SECONDS} -ge ${DEADLINE} ]]; then
    echo "ERROR: Job ${JOB} still running after ${TIMEOUT_SECONDS}s." >&2
    exit 1
  fi
  echo "[$(date -u +%H:%M:%S)] ${JOB}: ${STATE}"
  sleep 30
done
