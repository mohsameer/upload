#!/usr/bin/env bash
# Phase 3, step 1 of 2 per database: empty the DR Cloud SQL database so the
# restore that follows starts from nothing.
#
# Runs from INSIDE the DR cluster over the instance's private IP, like the
# restore itself: the bastion cannot reach the private address and
# sqladmin.googleapis.com is unreachable from it. A short pod runs
#   DROP DATABASE ... WITH (FORCE)  then  CREATE DATABASE
# against the `postgres` maintenance database.
#
# Safety:
#   - Only the one database named in PG_DATABASE is touched, and the platform
#     databases (postgres, template0/1, cloudsqladmin) are refused outright.
#   - It does nothing when the restore Job for this backup generation already
#     exists and is running or succeeded. psql_restore.sh re-attaches to such a
#     Job instead of loading again, so dropping the database here would throw
#     away data that nothing would then reload.
#   - It prints what it is about to remove (table count, size) first.
#
# Cloud SQL and its other databases are not managed here and are untouched.
set -euo pipefail

: "${NAMESPACE:?}" "${PG_HOST:?}" "${PG_DATABASE:?}" "${PG_USER:?}" "${PG_PASSWORD:?}" \
  "${CLIENT_IMAGE:?}" "${BACKUP_GENERATION:?}"

PG_PORT="${PG_PORT:-5432}"
CLEANUP_TIMEOUT_SECONDS="${CLEANUP_TIMEOUT_SECONDS:-300}"
FAILURE_LOG="${FAILURE_LOG:-/tmp/dr-phase-failures.log}"

note_failure() {
  printf '[%s] postgres_cleanup %s: %s\n' "$(date -u +%H:%M:%S)" "${PG_DATABASE}" "$*" >>"${FAILURE_LOG}" 2>/dev/null || true
  echo "ERROR: $*" >&2
}

case "${PG_DATABASE}" in
  postgres|template0|template1|cloudsqladmin)
    note_failure "refusing to clean up the platform database '${PG_DATABASE}'"
    exit 1
    ;;
esac

RESTORE_JOB="pg-restore-${BACKUP_GENERATION}"
if kubectl -n "${NAMESPACE}" get job "${RESTORE_JOB}" >/dev/null 2>&1; then
  succeeded=$(kubectl -n "${NAMESPACE}" get job "${RESTORE_JOB}" -o jsonpath='{.status.succeeded}' 2>/dev/null || true)
  failed=$(kubectl -n "${NAMESPACE}" get job "${RESTORE_JOB}" -o jsonpath='{.status.failed}' 2>/dev/null || true)
  if [[ "${failed:-0}" -lt 1 ]]; then
    state="running"; [[ "${succeeded:-0}" -ge 1 ]] && state="succeeded"
    echo "postgres_cleanup ${PG_DATABASE}: restore Job ${RESTORE_JOB} is already ${state}; leaving the database alone."
    exit 0
  fi
fi

POD="pg-cleanup-$(printf '%s' "${PG_DATABASE}" | tr -c 'a-z0-9' '-' | sed 's/-*$//' | cut -c1-30)"
CRED_SECRET="${POD}-cred"
RENDER_DIR=$(mktemp -d)
cleanup_k8s() {
  kubectl -n "${NAMESPACE}" delete pod "${POD}" --ignore-not-found --wait=false >/dev/null 2>&1 || true
  kubectl -n "${NAMESPACE}" delete secret "${CRED_SECRET}" --ignore-not-found >/dev/null 2>&1 || true
  rm -rf "${RENDER_DIR}"
}
trap cleanup_k8s EXIT

# A pod left behind by an interrupted run would make this one fail on
# AlreadyExists.
kubectl -n "${NAMESPACE}" delete pod "${POD}" --ignore-not-found >/dev/null 2>&1 || true

kubectl -n "${NAMESPACE}" create secret generic "${CRED_SECRET}" \
  --from-literal=PGPASSWORD="${PG_PASSWORD}" \
  --dry-run=client -o yaml >"${RENDER_DIR}/secret.yaml"
kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/secret.yaml" >/dev/null

cat <<EOF >"${RENDER_DIR}/pod.yaml"
apiVersion: v1
kind: Pod
metadata:
  name: ${POD}
  labels:
    app.kubernetes.io/name: pg-cleanup
    pps-dr/phase: "3"
spec:
  restartPolicy: Never
  activeDeadlineSeconds: ${CLEANUP_TIMEOUT_SECONDS}
  containers:
    - name: psql
      image: ${CLIENT_IMAGE}
      env:
        - { name: PGHOST, value: "${PG_HOST}" }
        - { name: PGPORT, value: "${PG_PORT}" }
        - { name: PGUSER, value: "${PG_USER}" }
        - { name: TARGET_DB, value: "${PG_DATABASE}" }
        - name: PGPASSWORD
          valueFrom:
            secretKeyRef: { name: ${CRED_SECRET}, key: PGPASSWORD }
      command: ["/bin/bash", "-c"]
      args:
        - |
          set -uo pipefail
          psql -d postgres -tAc 'SELECT 1' >/dev/null \\
            || { echo "ERROR: cannot connect to \${PGHOST}:\${PGPORT} as \${PGUSER}" >&2; exit 1; }
          EXISTS=\$(psql -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname = '\${TARGET_DB}'")
          if [ "\${EXISTS}" != "1" ]; then
            echo "database \${TARGET_DB} does not exist; nothing to clean up"
            exit 0
          fi
          TABLES=\$(psql -d "\${TARGET_DB}" -tAc "SELECT count(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")
          SIZE=\$(psql -d postgres -tAc "SELECT pg_size_pretty(pg_database_size('\${TARGET_DB}'))")
          echo "removing \${TARGET_DB}: \${TABLES} tables, \${SIZE}"
          psql -d postgres -v ON_ERROR_STOP=1 \\
            -c "DROP DATABASE \"\${TARGET_DB}\" WITH (FORCE)" \\
            -c "CREATE DATABASE \"\${TARGET_DB}\"" \\
            || { echo "ERROR: drop/create of \${TARGET_DB} failed" >&2; exit 1; }
          LEFT=\$(psql -d "\${TARGET_DB}" -tAc "SELECT count(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")
          [ "\${LEFT}" = "0" ] || { echo "ERROR: \${TARGET_DB} still holds \${LEFT} tables" >&2; exit 1; }
          echo "\${TARGET_DB} is empty"
EOF
kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/pod.yaml" >/dev/null
echo "postgres_cleanup ${PG_DATABASE}: pod ${POD} -> ${PG_HOST}:${PG_PORT}"

deadline=$(( $(date -u +%s) + CLEANUP_TIMEOUT_SECONDS ))
phase=""
while :; do
  phase=$(kubectl -n "${NAMESPACE}" get pod "${POD}" -o jsonpath='{.status.phase}' 2>/dev/null || true)
  [[ "${phase}" == "Succeeded" || "${phase}" == "Failed" ]] && break
  if [[ "$(date -u +%s)" -ge "${deadline}" ]]; then
    kubectl -n "${NAMESPACE}" logs "${POD}" --tail=20 >&2 || true
    note_failure "cleanup pod did not finish within ${CLEANUP_TIMEOUT_SECONDS}s"
    exit 1
  fi
  sleep 3
done

kubectl -n "${NAMESPACE}" logs "${POD}" | sed "s/^/  [${PG_DATABASE}] /"
if [[ "${phase}" != "Succeeded" ]]; then
  note_failure "cleanup pod ended ${phase}"
  exit 1
fi
echo "postgres_cleanup ${PG_DATABASE}: done"
