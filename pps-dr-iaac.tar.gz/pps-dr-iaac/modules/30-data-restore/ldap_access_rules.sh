#!/usr/bin/env bash
# Phase 3 - make the LDAP access rules on DR what production's are.
#
# The restore loads cn=config from the restore set, so DR's rules are exactly as
# current as that set. On 2026-10-20 the set predated production's adminRead and
# adminWrite rules on dc=ppspar,dc=PPSDMN: Springboot_PROD (an adminRead member)
# could bind but read nothing - every search returned LDAP error 32 "No such
# object", which is how OpenLDAP says "access denied" without confirming the entry
# exists. This enforces the intended rules whatever the set carried.
#
#   ACCESS_RULES   one "<suffix>|<index>|<rule text>" per line, rule text without the
#                  "{index}" prefix
#
# Per rule: read the current {index}; leave it if identical; otherwise delete and add
# it at the same index. Idempotent. The rules for a suffix are replaced only at the
# indices given, so a database with more rules keeps the rest.
#
# Runs inside the LDAP pod over the ldapi socket as root (EXTERNAL), which the rules
# grant "manage" on cn=config. The previous rule text is saved in the pod
# (/bitnami/openldap/olcAccess-<suffix>-<index>.before) so a change can be undone.
set -euo pipefail

: "${NAMESPACE:?}" "${LDAP_POD:?}"
ACCESS_RULES="${ACCESS_RULES:-}"
LDAPI_URL="${LDAPI_URL:-ldapi://%2Fopt%2Fbitnami%2Fopenldap%2Fvar%2Frun%2Fldapi}"

if [[ -z "${ACCESS_RULES//[[:space:]]/}" ]]; then
  echo "ldap_access_rules: nothing configured."
  exit 0
fi

kubectl -n "${NAMESPACE}" wait --for=condition=Ready "pod/${LDAP_POD}" --timeout=600s >/dev/null

sq() { printf "'%s'" "${1//\'/\'\\\'\'}"; }
{
  echo "LDAPI_URL=$(sq "${LDAPI_URL}")"
  echo "ACCESS_RULES=$(sq "${ACCESS_RULES}")"
  cat <<'REMOTE'
CHANGED=0
printf '%s\n' "${ACCESS_RULES}" | while IFS='|' read -r suffix idx rule; do
  [ -z "${suffix}" ] && continue
  db=$(ldapsearch -Y EXTERNAL -H "${LDAPI_URL}" -LLL -b cn=config "(olcSuffix=${suffix})" dn 2>/dev/null | sed -n 's/^dn: //p' | head -n1)
  if [ -z "${db}" ]; then echo "  ${suffix}: database not found - skipped"; continue; fi
  cur=$(ldapsearch -Y EXTERNAL -H "${LDAPI_URL}" -LLL -o ldif-wrap=no -b "${db}" -s base olcAccess 2>/dev/null | sed -n "s/^olcAccess: {${idx}}//p")
  if [ "${cur}" = "${rule}" ]; then
    echo "  ${suffix} rule {${idx}}: already as intended"; continue
  fi
  safe=$(printf '%s' "${suffix}" | tr -c 'A-Za-z0-9' '_')
  { printf '%s\n' "${cur}" > "/bitnami/openldap/olcAccess-${safe}-${idx}.before"; } 2>/dev/null || true
  {
    echo "dn: ${db}"; echo "changetype: modify"
    [ -n "${cur}" ] && { echo "delete: olcAccess"; echo "olcAccess: {${idx}}"; echo "-"; }
    echo "add: olcAccess"; echo "olcAccess: {${idx}}${rule}"
  } > /tmp/lar.ldif
  if ldapmodify -Y EXTERNAL -H "${LDAPI_URL}" -f /tmp/lar.ldif >/dev/null 2>&1; then
    echo "  ${suffix} rule {${idx}}: replaced (previous text saved in the pod)"
  else
    echo "  ${suffix} rule {${idx}}: ldapmodify FAILED" >&2; rm -f /tmp/lar.ldif; exit 1
  fi
  rm -f /tmp/lar.ldif
done
REMOTE
} | kubectl -n "${NAMESPACE}" exec -i "${LDAP_POD}" -- sh -s
