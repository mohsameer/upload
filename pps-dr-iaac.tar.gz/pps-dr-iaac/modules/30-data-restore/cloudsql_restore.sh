#!/usr/bin/env bash
# Import the PostgreSQL dump from GCS into the pre-existing Cloud SQL instance.
#
# There is no Terraform resource for a Cloud SQL SQL-dump import, so this wraps
# `gcloud sql import sql` and polls the returned operation to a terminal state.
# The instance itself is never created or modified here.
set -euo pipefail

: "${PROJECT_ID:?}" "${CLOUDSQL_INSTANCE:?}" "${DATABASE_NAME:?}" "${IMPORT_USER:?}" "${BACKUP_URI:?}"

gcloud auth activate-service-account \
  --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" \
  --project="${PROJECT_ID}" >/dev/null

echo "Cloud SQL instance service account: ${CLOUDSQL_SERVICE_ACCOUNT:-unknown}"
echo "It must have objectViewer on the backup object. Grant it before the run if the import fails with a permission error."

STATE=$(gcloud sql instances describe "${CLOUDSQL_INSTANCE}" \
  --project="${PROJECT_ID}" --format='value(state)')
if [[ "${STATE}" != "RUNNABLE" ]]; then
  echo "ERROR: Cloud SQL instance ${CLOUDSQL_INSTANCE} is '${STATE}', expected RUNNABLE." >&2
  exit 1
fi

echo "Importing ${BACKUP_URI} into ${CLOUDSQL_INSTANCE}/${DATABASE_NAME} as ${IMPORT_USER}..."

# --async so the operation id can be polled explicitly; a synchronous import
# hides the operation id that the failure message needs to quote.
OPERATION=$(gcloud sql import sql "${CLOUDSQL_INSTANCE}" "${BACKUP_URI}" \
  --project="${PROJECT_ID}" \
  --database="${DATABASE_NAME}" \
  --user="${IMPORT_USER}" \
  --quiet --async --format='value(name)')

if [[ -z "${OPERATION}" ]]; then
  echo "ERROR: gcloud did not return an import operation id." >&2
  exit 1
fi

echo "Import operation: ${OPERATION}. Waiting for it to reach a terminal state..."

# Cloud SQL imports of a large IDM dump can run well past the default wait.
if ! gcloud sql operations wait "${OPERATION}" \
      --project="${PROJECT_ID}" --timeout=unlimited; then
  echo "ERROR: import operation ${OPERATION} did not complete cleanly." >&2
fi

STATUS=$(gcloud sql operations describe "${OPERATION}" \
  --project="${PROJECT_ID}" --format='value(status)')
ERROR=$(gcloud sql operations describe "${OPERATION}" \
  --project="${PROJECT_ID}" --format='value(error.errors[0].message)' 2>/dev/null || true)

if [[ "${STATUS}" != "DONE" || -n "${ERROR}" ]]; then
  echo "ERROR: Cloud SQL import failed." >&2
  echo "  operation: ${OPERATION}" >&2
  echo "  status:    ${STATUS}" >&2
  echo "  error:     ${ERROR:-<none reported>}" >&2
  echo "Recovery: drop and recreate database '${DATABASE_NAME}', then re-run this phase." >&2
  exit 1
fi

echo "Cloud SQL import completed: operation ${OPERATION} status ${STATUS}."
