#!/usr/bin/env bash
# Phase 3 - give the DR LDAP the same TLS certificate production's LDAP serves.
#
# Production's LDAP keeps its self-signed certificate on a persistent volume
# (/opt/bitnami/openldap/certs, generated once on 2025-07-01, valid to 2035), so
# every client that pins it - token-exchange-service reads the expected
# certificate from Vault - keeps trusting it. A fresh DR build mints a new
# self-signed one on its first start, which no client of the restored data has
# ever seen. This copies production's openldap.crt, openldap.key and
# openldapCA.crt over it, before the LDAP restore restarts the pod so that one
# restart loads them.
#
# The three files come from the restore set (ldap/tls/ under the backup prefix,
# written once from the production pod). The private key is handled as a file
# with mode 600 only and shredded afterwards; it is never printed.
#
# Idempotent: when the pod already holds a certificate with the wanted
# fingerprint it does nothing, so a retried wave does not restart LDAP again.
set -euo pipefail

: "${NAMESPACE:?}" "${LDAP_POD:?}" "${BACKUP_BUCKET:?}"
TLS_OBJECTS="${TLS_OBJECTS:-}"
CERT_DIR="${CERT_DIR:-/opt/bitnami/openldap/certs}"
SLAPD_OWNER="${SLAPD_OWNER:-slapd:slapd}"

if [[ -z "${TLS_OBJECTS//[[:space:]]/}" ]]; then
  echo "ldap_tls: no TLS objects configured; leaving the LDAP's own certificate."
  exit 0
fi

WORKDIR=$(mktemp -d)
chmod 700 "${WORKDIR}"
cleanup() { shred -u "${WORKDIR}"/* 2>/dev/null || true; rm -rf "${WORKDIR}"; }
trap cleanup EXIT
umask 077

for obj in ${TLS_OBJECTS}; do
  if [[ -n "${BACKUP_CREDENTIALS_FILE:-}" ]]; then
    CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE="${BACKUP_CREDENTIALS_FILE}" \
      gcloud storage cp "gs://${BACKUP_BUCKET}/${obj}" "${WORKDIR}/$(basename "${obj}")" >/dev/null
  else
    gcloud storage cp "gs://${BACKUP_BUCKET}/${obj}" "${WORKDIR}/$(basename "${obj}")" >/dev/null
  fi
done

for f in openldap.crt openldap.key openldapCA.crt; do
  [[ -s "${WORKDIR}/${f}" ]] || { echo "ERROR: ${f} is missing from TLS_OBJECTS (got: ${TLS_OBJECTS})" >&2; exit 1; }
done

# The key has to belong to the certificate, or slapd would refuse to start with it.
cert_mod=$(openssl x509 -in "${WORKDIR}/openldap.crt" -noout -modulus | openssl md5)
key_mod=$(openssl rsa -in "${WORKDIR}/openldap.key" -noout -modulus 2>/dev/null | openssl md5)
[[ "${cert_mod}" == "${key_mod}" ]] || { echo "ERROR: openldap.key does not match openldap.crt." >&2; exit 1; }
# openssl prints "sha256 Fingerprint=" on 1.x and "SHA256 Fingerprint=" on 3.x, and
# the bastion and the LDAP image run different versions, so compare only the
# hex digest, upper-cased.
fingerprint() { sed -e 's/^.*=//' | tr -d '[:space:]' | tr 'a-f' 'A-F'; }
want=$(openssl x509 -in "${WORKDIR}/openldap.crt" -noout -fingerprint -sha256 | fingerprint)

kubectl -n "${NAMESPACE}" wait --for=condition=Ready "pod/${LDAP_POD}" --timeout=600s >/dev/null

have=$(kubectl -n "${NAMESPACE}" exec "${LDAP_POD}" -- sh -c "openssl x509 -in ${CERT_DIR}/openldap.crt -noout -fingerprint -sha256 2>/dev/null" | fingerprint || true)
if [[ "${have}" == "${want}" ]]; then
  echo "ldap_tls: ${LDAP_POD} already has the wanted certificate (${want}); nothing to do."
  exit 0
fi

echo "ldap_tls: replacing the certificate on ${LDAP_POD}"
echo "  wanted ${want}"
echo "  found  ${have}"

# Keep what the image generated, so this can be undone.
kubectl -n "${NAMESPACE}" exec "${LDAP_POD}" -- sh -c \
  "cd ${CERT_DIR} && for f in openldap.crt openldap.key openldapCA.crt; do [ -e \$f.dr-generated ] || cp -p \$f \$f.dr-generated 2>/dev/null || true; done"

for f in openldap.crt openldap.key openldapCA.crt; do
  kubectl -n "${NAMESPACE}" exec -i "${LDAP_POD}" -- sh -c "cat > ${CERT_DIR}/${f}.new" <"${WORKDIR}/${f}"
done
kubectl -n "${NAMESPACE}" exec "${LDAP_POD}" -- sh -c "cd ${CERT_DIR} \
  && chown ${SLAPD_OWNER} openldap.crt.new openldap.key.new openldapCA.crt.new \
  && chmod 644 openldap.crt.new openldapCA.crt.new && chmod 600 openldap.key.new \
  && mv -f openldap.crt.new openldap.crt && mv -f openldap.key.new openldap.key && mv -f openldapCA.crt.new openldapCA.crt"

# slapd reads the files at start-up. The StatefulSet recreates the pod; the
# certificate volume is a PVC, so the files survive.
kubectl -n "${NAMESPACE}" delete pod "${LDAP_POD}" --wait=true >/dev/null
for _ in $(seq 1 60); do
  kubectl -n "${NAMESPACE}" get pod "${LDAP_POD}" >/dev/null 2>&1 && break
  sleep 2
done
kubectl -n "${NAMESPACE}" wait --for=condition=Ready "pod/${LDAP_POD}" --timeout=600s >/dev/null

now=$(kubectl -n "${NAMESPACE}" exec "${LDAP_POD}" -- sh -c "openssl x509 -in ${CERT_DIR}/openldap.crt -noout -fingerprint -sha256" | fingerprint)
[[ "${now}" == "${want}" ]] || { echo "ERROR: after the restart ${LDAP_POD} holds ${now}, not ${want} - the image regenerated its certificate." >&2; exit 1; }
echo "ldap_tls: ${LDAP_POD} now serves ${want}"
