#!/usr/bin/env bash
# Bring Vault back after the Consul restore replaced its storage underneath it.
#
# Vault keeps its master key in memory and loads its barrier keys and mounts at
# unseal time, so after the import it is still serving the Vault that Phase 2
# initialised while the storage now holds the source Vault. Every request fails
# with "decryption failed: cipher: message authentication failed", and the
# source cluster's HA lock comes across in the import, so the pods also log
# "failed to acquire lock: Existing key does not match lock use" forever.
#
# Clearing the two coordination keys and restarting the pods is enough: Vault
# then reads the restored master/keyring and auto-unseals through the same KMS
# key the source used. No key material is touched - only vault/core/lock and
# vault/core/leader/<id>, which Vault recreates when a node takes leadership.
set -euo pipefail

: "${NAMESPACE:?}" "${CONSUL_POD:?}" "${VAULT_LABEL:?}" "${TIMEOUT_SECONDS:?}"

VAULT_PREFIX="${VAULT_PREFIX:-vault/}"

echo "Clearing the source cluster's HA lock under ${VAULT_PREFIX}core/..."
kubectl -n "${NAMESPACE}" exec "${CONSUL_POD}" -- \
  sh -c "consul kv delete ${VAULT_PREFIX}core/lock; consul kv delete -recurse ${VAULT_PREFIX}core/leader/" >/dev/null

# The request counters have to go too, and clearing the lock alone is not
# enough. They were written by THIS cluster before the restore, encrypted with
# the keyring it had then; the imported data brings the source's keyring, so
# every node now fails post-unseal setup with
#   post-unseal setup failed: failed to read request counters:
#   decryption failed: cipher: message authentication failed
# and with no node completing post-unseal there is no active instance at all -
# every API call answers 503 "no active Vault instance found", which is how
# Phase 5 failed. Vault recreates these counters from scratch; they hold
# request totals for telemetry, no key material and no secrets.
echo "Clearing request counters this cluster wrote under its previous keyring..."
kubectl -n "${NAMESPACE}" exec "${CONSUL_POD}" -- \
  sh -c "consul kv delete -recurse ${VAULT_PREFIX}sys/counters/" >/dev/null 2>&1 || true

PODS=$(kubectl -n "${NAMESPACE}" get pods -l "${VAULT_LABEL}" -o jsonpath='{range .items[*]}{.metadata.name}{" "}{end}')
[[ -n "${PODS}" ]] || { echo "ERROR: no Vault pods matched ${VAULT_LABEL} in ${NAMESPACE}." >&2; exit 1; }

echo "Restarting Vault so it reads the restored storage: ${PODS}"
# shellcheck disable=SC2086
kubectl -n "${NAMESPACE}" delete pod ${PODS} --wait=false >/dev/null

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
while [[ ${SECONDS} -lt ${DEADLINE} ]]; do
  sleep 10
  READY=$(kubectl -n "${NAMESPACE}" get pods -l "${VAULT_LABEL}" \
    -o jsonpath='{range .items[*]}{.status.containerStatuses[0].ready}{"\n"}{end}' 2>/dev/null | grep -c true || true)
  TOTAL=$(kubectl -n "${NAMESPACE}" get pods -l "${VAULT_LABEL}" --no-headers 2>/dev/null | wc -l | tr -d ' ')
  if [[ "${TOTAL}" -gt 0 && "${READY}" == "${TOTAL}" ]]; then
    echo "Vault is unsealed on ${READY}/${TOTAL} pod(s) against the restored storage."
    exit 0
  fi
done

echo "ERROR: Vault did not become ready within ${TIMEOUT_SECONDS}s of the restart." >&2
kubectl -n "${NAMESPACE}" logs -l "${VAULT_LABEL}" --tail=20 >&2 || true
exit 1
