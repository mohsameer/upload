#!/usr/bin/env bash
# Rewrite Capella hostnames carried inside restored documents so they name this
# site's cluster.
#
# The restore brings the source site's data verbatim, and some of that data is
# configuration - including code. On the PPS DR site the "PPS Password
# expiration scope" custom script has production's Capella host written into
# its Java source, stored in the jansScr field of
# scripts_b58818fa-597a-43f8-a5c9-055f1e7e4c28 in bucket oidcv2.
#
# jans-auth runs that script at startup, and it opens a Couchbase connection of
# its own: two SDK cores in one JVM, the ORM on this site's cluster and the
# script on the source site's. Capella's private endpoint routes by name, so
# the SNI does not match and the SDK reports
# "AuthenticationFailureException: Authentication Failure" - which looks like a
# bad password and is not one. The auth server never reaches health-check 200,
# its liveness probe kills it, and the Applications waiting on it never start.
#
# Repointing Vault and the Argo CD parameters is not enough on its own, because
# this copy lives in the data. Nothing outside the database can fix it.
set -euo pipefail

: "${QUERY_HOST:?}" "${COUCHBASE_USERNAME:?}" "${COUCHBASE_PASSWORD:?}" "${BUCKETS:?}"

QUERY_URL="https://${QUERY_HOST}:18093/query/service"
# Documents are found through an indexed predicate: a bucket restored from a
# backup has no primary index, and asking for one is a full scan the index
# service will refuse.
DOC_CLASSES="${DOC_CLASSES:-jansCustomScr jansClnt jansAppConf jansScope}"
CONFIG_KEYS="${CONFIG_KEYS:-configuration configuration_jans-auth configuration_admin-ui configuration_casa configuration_jans-config-api configuration_jans-scim}"

CA_ARGS=()
if [[ -n "${COUCHBASE_CA_CERT_FILE:-}" ]]; then
  [[ -s "${COUCHBASE_CA_CERT_FILE}" ]] || { echo "ERROR: COUCHBASE_CA_CERT_FILE='${COUCHBASE_CA_CERT_FILE}' is missing or empty." >&2; exit 1; }
  CA_ARGS=(--cacert "${COUCHBASE_CA_CERT_FILE}")
else
  echo "WARNING: no couchbase_ca_cert_file set; the Capella certificate will not be verified." >&2
  CA_ARGS=(--insecure)
fi

run_query() {
  curl -sS --max-time 300 "${CA_ARGS[@]}" \
    -u "${COUCHBASE_USERNAME}:${COUCHBASE_PASSWORD}" \
    "${QUERY_URL}" --data-urlencode "statement=$1"
}

# The host this site's documents should name.
DR_HOST="${CAPELLA_HOST:-${QUERY_HOST}}"
HOST_PATTERN='cb\\.[a-zA-Z0-9-]+\\.cloud\\.couchbase\\.com'

# sed program that sets the Java constants CAPELLA_USERNAME and CAPELLA_PASSWORD in
# the JSON-encoded document (so the quotes around their values appear as \"). The
# values are escaped for JSON, then for sed's replacement.
json_str() { printf '%s' "$1" | jq -Rs '.' | sed -e 's/^"//' -e 's/"$//'; }
sed_repl() { printf '%s' "$1" | sed -e 's/[\\&#]/\\&/g'; }
CRED_USER="$(sed_repl "$(json_str "${COUCHBASE_USERNAME}")")"
CRED_PASS="$(sed_repl "$(json_str "${COUCHBASE_PASSWORD}")")"
CRED_SED=$(printf 's#(CAPELLA_USERNAME = \\\\")[^\\\\"]*(\\\\")#\\1%s\\2#; s#(CAPELLA_PASSWORD = \\\\")[^\\\\"]*(\\\\")#\\1%s\\2#' "${CRED_USER}" "${CRED_PASS}")

REWRITTEN=0

for bucket in ${BUCKETS}; do
  ids=""

  for class in ${DOC_CLASSES}; do
    # The status is checked rather than the rows, because `.results[]?` on an
    # error body prints nothing and exits 0: a query that could not be served
    # (no index available for the objectClass predicate - which is the state
    # every restored index is in until the build step runs) looked exactly
    # like "no documents matched", and this step reported success while
    # skipping the document it exists to fix.
    resp=$(run_query "SELECT RAW META().id FROM \`${bucket}\` WHERE objectClass = '${class}' AND ENCODE_JSON(self) LIKE '%cloud.couchbase.com%'")
    if [[ "$(printf '%s' "${resp}" | jq -r '.status // "unknown"' 2>/dev/null)" != "success" ]]; then
      # Code 4000 is "No index available ... to serve your query". A bucket
      # that does not hold jans documents has no index on objectClass and never
      # will - icrypto_persistent_ha indexes userId/class instead - so for that
      # bucket the predicate is unservable by design and there is nothing to
      # rewrite. Anything else is a real failure and must stop the build: the
      # alternative is the swallowed error this check replaced, where the step
      # reported "0 documents" while skipping the document it exists to fix.
      if [[ "$(printf '%s' "${resp}" | jq -r '[.errors[]?.code] | index(4000) != null' 2>/dev/null)" == "true" ]]; then
        echo "  ${bucket}: no index serves objectClass=${class}; this bucket holds no such documents, skipping"
        continue
      fi
      echo "ERROR: searching ${bucket} for objectClass=${class} failed: $(printf '%s' "${resp}" | jq -c '.errors' 2>/dev/null | cut -c1-300)" >&2
      exit 1
    fi
    found=$(printf '%s' "${resp}" | jq -r '.results[]?')
    [[ -n "${found}" ]] && ids="${ids} ${found}"
  done

  # The configuration documents have no indexed class of their own, so they are
  # looked up by key.
  keylist=$(printf '"%s",' ${CONFIG_KEYS} | sed 's/,$//')
  # USE KEYS needs no index, so a failure here is always real.
  resp=$(run_query "SELECT RAW META().id FROM \`${bucket}\` USE KEYS [${keylist}] WHERE ENCODE_JSON(self) LIKE '%cloud.couchbase.com%'")
  if [[ "$(printf '%s' "${resp}" | jq -r '.status // "unknown"' 2>/dev/null)" != "success" ]]; then
    echo "ERROR: key lookup in ${bucket} failed: $(printf '%s' "${resp}" | jq -c '.errors' 2>/dev/null | cut -c1-300)" >&2
    exit 1
  fi
  found=$(printf '%s' "${resp}" | jq -r '.results[]?')
  [[ -n "${found}" ]] && ids="${ids} ${found}"

  for id in ${ids}; do
    doc=$(run_query "SELECT RAW self FROM \`${bucket}\` USE KEYS ['${id}']" | jq -c '.results[0]? // empty')
    [[ -z "${doc}" ]] && continue

    # Only the host is replaced, wherever it appears and however deeply nested,
    # so code, URLs and connection strings all survive intact.
    patched=$(printf '%s' "${doc}" | sed -E "s#cb\.[a-zA-Z0-9-]+\.cloud\.couchbase\.com#${DR_HOST}#g")
    # The host is not all that is written into that script's source: it also holds
    # production's Capella ACCOUNT and PASSWORD as Java constants. Repointing only the
    # host sends production's account to this site's cluster, which refuses it - and
    # the SDK reports the same "Authentication Failure" as before, so the symptom did
    # not move (2026-10-21: ~1 failure a second from jans-auth, and SSO login at
    # sso.pps.co.za answered "unable to validate your credentials"). The constants are
    # replaced by name, so nothing else in the source is touched.
    if [[ "${REWRITE_CAPELLA_CREDENTIALS:-true}" == "true" ]]; then
      patched=$(printf '%s' "${patched}" | sed -E "${CRED_SED}")
    fi
    if [[ "${patched}" == "${doc}" ]]; then
      continue
    fi

    result=$(run_query "UPSERT INTO \`${bucket}\` (KEY, VALUE) VALUES ('${id}', ${patched})")
    if [[ "$(printf '%s' "${result}" | jq -r '.status // "unknown"')" != "success" ]]; then
      echo "ERROR: could not rewrite ${bucket}/${id}: $(printf '%s' "${result}" | jq -c '.errors' | cut -c1-240)" >&2
      exit 1
    fi
    echo "  ${bucket}/${id}: Capella host rewritten to ${DR_HOST}$([[ "${REWRITE_CAPELLA_CREDENTIALS:-true}" == "true" ]] && echo ", account set to ${COUCHBASE_USERNAME}")"
    REWRITTEN=$((REWRITTEN + 1))
  done
done

echo "Documents repointed at ${DR_HOST}: ${REWRITTEN}."
