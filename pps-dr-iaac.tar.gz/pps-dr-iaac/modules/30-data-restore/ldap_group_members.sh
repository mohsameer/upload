#!/usr/bin/env bash
# Phase 3 - make LDAP group membership on DR match how DR is actually used.
#
# The restored directory carries production's group membership. On production most
# of the application service accounts under ou=services are in adminRead only; on
# DR they also have to write (IAA, ProFiT and the others create and update users
# through the directory), and the access rules grant write to the adminWrite group.
# So this adds every account found one level under a search base to a named group.
#
#   GROUP_ADDITIONS   one "<group DN>|<search base DN>" per line
#   GROUP_MEMBERS     one "<group DN>|<member DN>" per line: named accounts
#
# (A pipe, because both sides are DNs and a DN is full of '=' and ','.)
#
# Idempotent: only accounts that are not members yet are added, and a group that is
# already complete is left alone. Runs inside the LDAP pod as the directory admin,
# after the LDAP restore has loaded the data.
#
# This widens access beyond production's: a member of adminWrite can change any
# entry under the suffix, userPassword included. It is a DR decision, and it is
# visible in tfvars (ldap_group_additions) rather than hidden in this script.
set -euo pipefail

: "${NAMESPACE:?}" "${LDAP_POD:?}" "${LDAP_ADMIN_PASSWORD:?}" "${LDAP_ADMIN_DN:?}"
GROUP_ADDITIONS="${GROUP_ADDITIONS:-}"
GROUP_MEMBERS="${GROUP_MEMBERS:-}"
LDAP_PORT="${LDAP_PORT:-1389}"

if [[ -z "${GROUP_ADDITIONS//[[:space:]]/}" && -z "${GROUP_MEMBERS//[[:space:]]/}" ]]; then
  echo "ldap_group_members: nothing configured."
  exit 0
fi

kubectl -n "${NAMESPACE}" wait --for=condition=Ready "pod/${LDAP_POD}" --timeout=600s >/dev/null

# Values reach the pod on stdin as single-quoted assignments, never as arguments.
sq() { printf "'%s'" "${1//\'/\'\\\'\'}"; }
{
  echo "LDAP_ADMIN_PASSWORD=$(sq "${LDAP_ADMIN_PASSWORD}")"
  echo "LDAP_ADMIN_DN=$(sq "${LDAP_ADMIN_DN}")"
  echo "LDAP_PORT=$(sq "${LDAP_PORT}")"
  echo "GROUP_ADDITIONS=$(sq "${GROUP_ADDITIONS}")"
  echo "GROUP_MEMBERS=$(sq "${GROUP_MEMBERS}")"
  cat <<'REMOTE'
q() { ldapsearch -x -LLL -H "ldap://localhost:${LDAP_PORT}" -D "${LDAP_ADMIN_DN}" -w "${LDAP_ADMIN_PASSWORD}" "$@" 2>/dev/null; }
printf '%s\n' "${GROUP_ADDITIONS}" | while IFS='|' read -r group base; do
  [ -z "${group}" ] && continue
  if ! q -b "${group}" -s base dn | grep -q '^dn:'; then
    echo "  ${group}: group not found - skipped"; continue
  fi
  q -b "${group}" -s base member | grep '^member:' | sed 's/^member: //' > /tmp/lgm.members
  q -b "${base}" -s one '(objectClass=inetOrgPerson)' dn | grep '^dn:' | sed 's/^dn: //' > /tmp/lgm.candidates
  { echo "dn: ${group}"; echo "changetype: modify"; echo "add: member"
    while read -r dn; do
      [ -z "${dn}" ] && continue
      grep -qixF "${dn}" /tmp/lgm.members || echo "member: ${dn}"
    done < /tmp/lgm.candidates; } > /tmp/lgm.ldif
  n=$(grep -c '^member:' /tmp/lgm.ldif || true)
  have=$(wc -l < /tmp/lgm.candidates | tr -d ' ')
  if [ "${n}" -eq 0 ]; then
    echo "  ${group}: all ${have} account(s) under ${base} are already members"
  else
    if ldapmodify -x -H "ldap://localhost:${LDAP_PORT}" -D "${LDAP_ADMIN_DN}" -w "${LDAP_ADMIN_PASSWORD}" -f /tmp/lgm.ldif >/dev/null; then
      echo "  ${group}: added ${n} of ${have} account(s) under ${base}"
    else
      echo "  ${group}: ldapmodify failed" >&2; rm -f /tmp/lgm.*; exit 1
    fi
  fi
  rm -f /tmp/lgm.*
done
printf '%s\n' "${GROUP_MEMBERS}" | while IFS='|' read -r group member; do
  [ -z "${group}" ] && continue
  if ! q -b "${group}" -s base dn | grep -q '^dn:'; then
    echo "  ${group}: group not found - skipped"; continue
  fi
  if ! q -b "${member}" -s base dn | grep -q '^dn:'; then
    echo "  ${member}: no such account - skipped"; continue
  fi
  if q -b "${group}" -s base "(member=${member})" dn | grep -q '^dn:'; then
    echo "  ${group}: ${member%%,*} is already a member"; continue
  fi
  printf 'dn: %s\nchangetype: modify\nadd: member\nmember: %s\n' "${group}" "${member}" > /tmp/lgm.one
  ldapmodify -x -H "ldap://localhost:${LDAP_PORT}" -D "${LDAP_ADMIN_DN}" -w "${LDAP_ADMIN_PASSWORD}" -f /tmp/lgm.one >/dev/null \
    && echo "  ${group}: added ${member%%,*}" \
    || { echo "  ${group}: could not add ${member%%,*}" >&2; rm -f /tmp/lgm.one; exit 1; }
  rm -f /tmp/lgm.one
done
REMOTE
} | kubectl -n "${NAMESPACE}" exec -i "${LDAP_POD}" -- sh -s
