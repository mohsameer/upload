#!/usr/bin/env bash
# Restore the OpenLDAP directory from slapcat LDIF backups.
#
# Mirrors the procedure proven on PPS QA/PPD (Bitnami OpenLDAP image, as
# deployed by the openldap-stack-ha chart in Phase 2):
#   1. scale the StatefulSet to one replica so no peer replicates into the
#      pod while it is being loaded;
#   2. clear the on-disk databases (LDAP_WIPE_BEFORE_RESTORE, default true on
#      a freshly built DR cluster - the chart bootstrap seeds entries that
#      would make slapadd fail on duplicates);
#   3. slapadd each LDIF into its database, config first:
#        *config*  -> -n 0 into an emptied slapd.d (LDAP_RESTORE_CONFIG, default
#                     true). A fresh chart install has no secauthority DB; it
#                     only exists in the source cn=config, so on a new DR
#                     cluster the config must come across. (PPS-to-PPS restores
#                     onto an existing instance keep their own config instead.)
#                     The source config also carries the source admin
#                     password, so LDAP_ADMIN_PASSWORD must be the SOURCE one.
#        *secauth* -> -n 3
#        other     -> -n 2 (the data DB under LDAP_BASE_DN)
#      These are the numbers slapcat produced on the source.
#   4. restart the pod, scale back, and verify a search returns entries.
set -euo pipefail

: "${NAMESPACE:?}" "${BACKUP_BUCKET:?}" "${LDIF_OBJECTS:?}" "${LDAP_BASE_DN:?}" "${LDAP_ADMIN_PASSWORD:?}"

POD="${LDAP_POD:-openldap-0}"
# The statefulset name follows the pod's, which differs per chart: the PPS OCI
# chart makes ldap-pps-ldap-0, the local directory chart ldap-openldap-0.
STS="${LDAP_STATEFULSET:-${POD%-*}}"

# Quick mode, on by default. SLAPADD_QUICK=false falls back to a fully checked,
# very much slower load.
SLAPADD_QUICK="${SLAPADD_QUICK:-true}"
SLAPADD_FLAGS=""
[[ "${SLAPADD_QUICK}" == "true" ]] && SLAPADD_FLAGS="-q"
SLAPD_D="${LDAP_SLAPD_CONFIG_DIR:-/opt/bitnami/openldap/etc/slapd.d}"
DATA_DIRS="${LDAP_DATA_DIRS:-/bitnami/openldap/data /bitnami/openldap/secauthority}"
WIPE="${LDAP_WIPE_BEFORE_RESTORE:-true}"
RESTORE_CONFIG="${LDAP_RESTORE_CONFIG:-true}"
LDAP_PORT="${LDAP_PORT:-1389}"

WORKDIR=$(mktemp -d)
trap 'rm -rf "${WORKDIR}"' EXIT

echo "Staging LDIF backups..."
for obj in ${LDIF_OBJECTS}; do
  if [[ -n "${BACKUP_CREDENTIALS_FILE:-}" ]]; then
    CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE="${BACKUP_CREDENTIALS_FILE}" \
      gcloud storage cp "gs://${BACKUP_BUCKET}/${obj}" "${WORKDIR}/$(basename "${obj}")"
  else
    gcloud storage cp "gs://${BACKUP_BUCKET}/${obj}" "${WORKDIR}/$(basename "${obj}")"
  fi
done

REPLICAS=$(kubectl -n "${NAMESPACE}" get statefulset "${STS}" -o jsonpath='{.spec.replicas}')
echo "Scaling statefulset ${STS} from ${REPLICAS} to 1 replica for the restore..."
kubectl -n "${NAMESPACE}" scale statefulset "${STS}" --replicas=1
kubectl -n "${NAMESPACE}" rollout status statefulset "${STS}" --timeout=600s
kubectl -n "${NAMESPACE}" wait --for=condition=Ready "pod/${POD}" --timeout=600s

for obj in ${LDIF_OBJECTS}; do
  f=$(basename "${obj}")
  kubectl -n "${NAMESPACE}" cp "${WORKDIR}/${f}" "${POD}:/tmp/${f}"
done

if [[ "${WIPE}" == "true" ]]; then
  WIPE_DIRS="${DATA_DIRS}"
  [[ "${RESTORE_CONFIG}" == "true" ]] && WIPE_DIRS="${SLAPD_D} ${WIPE_DIRS}"
  for d in ${WIPE_DIRS}; do
    echo "Clearing ${d} in ${POD}..."
    kubectl -n "${NAMESPACE}" exec "${POD}" -- sh -c "rm -rf '${d}'/*"
  done
fi

# cn=config first: it defines the databases the other LDIFs load into.
ORDERED=$(for obj in ${LDIF_OBJECTS}; do
  case "$(basename "${obj}")" in (*config*) echo "0 ${obj}" ;; (*secauth*) echo "1 ${obj}" ;; (*) echo "2 ${obj}" ;; esac
done | sort -n | cut -d' ' -f2)

for obj in ${ORDERED}; do
  f=$(basename "${obj}")
  case "${f}" in
    *config*)
      if [[ "${RESTORE_CONFIG}" != "true" ]]; then
        echo "Skipping ${f}: LDAP_RESTORE_CONFIG=false keeps the chart-generated cn=config."
        continue
      fi
      db=0
      ;;
    *secauth*) db=3 ;;
    *)         db=2 ;;
  esac
  echo "Loading ${f} into database -n ${db}${SLAPADD_QUICK:+ (quick mode)}..."
  # -q defers index maintenance and skips the per-entry consistency checks,
  # which is what makes a bulk load of a slapcat dump viable: without it this
  # restore wrote roughly 0.5 MB/min, because each of 155,569 entries was its
  # own transaction with an fsync and up to 15 index updates - on a disk with
  # about 75 write IOPS. -q is safe for an LDIF produced by slapcat from a
  # healthy directory, which is exactly what the collector takes, and the
  # search check at the end of this script is the proof.
  kubectl -n "${NAMESPACE}" exec "${POD}" -- \
    slapadd ${SLAPADD_FLAGS} -F "${SLAPD_D}" -n "${db}" -l "/tmp/${f}"
done

echo "Restarting ${POD} and restoring ${REPLICAS} replicas..."
kubectl -n "${NAMESPACE}" delete pod "${POD}" --wait=true

# The StatefulSet recreates the pod a moment later, and `kubectl wait` fails
# outright on a pod that does not exist yet rather than waiting for it - so
# this has to wait for the object to appear first. The old load took long
# enough to hide the race; once slapadd -q finished in 89 seconds it failed
# every time, with the real error swallowed because this provisioner's output
# is suppressed.
echo "Waiting for ${POD} to be recreated..."
for _ in $(seq 1 60); do
  kubectl -n "${NAMESPACE}" get pod "${POD}" >/dev/null 2>&1 && break
  sleep 5
done
kubectl -n "${NAMESPACE}" get pod "${POD}" >/dev/null 2>&1 \
  || { echo "ERROR: ${POD} was not recreated within 300s." >&2; exit 1; }
kubectl -n "${NAMESPACE}" wait --for=condition=Ready "pod/${POD}" --timeout=600s
kubectl -n "${NAMESPACE}" scale statefulset "${STS}" --replicas="${REPLICAS}"
kubectl -n "${NAMESPACE}" rollout status statefulset "${STS}" --timeout=900s

echo "Verifying the directory answers a search under ${LDAP_BASE_DN}..."
ENTRIES=$(kubectl -n "${NAMESPACE}" exec "${POD}" -- \
  ldapsearch -x -LLL -H "ldap://localhost:${LDAP_PORT}" \
    -D "cn=admin,${LDAP_BASE_DN}" -w "${LDAP_ADMIN_PASSWORD}" \
    -b "${LDAP_BASE_DN}" dn 2>/dev/null | grep -c '^dn:' || true)

if [[ -z "${ENTRIES}" || "${ENTRIES}" -eq 0 ]]; then
  echo "ERROR: no entries returned under ${LDAP_BASE_DN} after the restore." >&2
  exit 1
fi

echo "LDAP restore completed: ${ENTRIES} entries under ${LDAP_BASE_DN}."
