variable "project_id" {
  type = string
}

variable "gcp_credentials_file" {
  type = string
}

variable "kubeconfig_path" {
  type = string
}

variable "platform_namespace" {
  type = string
}

variable "backup_bucket" {
  type = string
}

variable "backup_credentials_file" {
  type        = string
  description = "Key that can read backup_bucket: used by bastion-side gcloud downloads and mounted into the in-cluster restore Jobs."
}

# --- Cloud SQL (prerequisite, restored into) -------------------------------

variable "cloudsql_instance_name" {
  type = string
}

variable "cloudsql_database_name" {
  type = string
}

variable "cloudsql_import_user" {
  type = string
}

variable "cloudsql_import_password" {
  type      = string
  sensitive = true
}

variable "postgres_backup_object" {
  type = string
}

variable "postgres_restore_enabled" {
  type = bool
}

variable "postgres_min_expected_tables" {
  type        = number
  description = "Post-restore assertion: the restored database must contain at least this many tables."
  default     = 1
}

variable "cloudsql_proxy_image" {
  type        = string
  description = "Image used for the in-cluster connectivity and verification checks."
  default     = "gcr.io/cloud-sql-connectors/cloud-sql-proxy:2.14.1"
}

variable "postgres_client_image" {
  type        = string
  description = "Image used to run psql from inside the DR cluster. >= 17.6 for pg_dump 17 output."
  default     = "postgres:17"
}

variable "postgres_restore_method" {
  type        = string
  description = "psql_pod or gcloud_sql_import. See root variables.tf."
}

variable "allow_gcloud_sql_import" {
  type = bool
}

variable "cloudsql_private_ip" {
  type        = string
  description = "Overrides the IP read from the instance; required on psql_pod."
}

variable "postgres_recreate_database" {
  type = bool
}

variable "postgres_cleanup_before_restore" {
  type = bool
}

variable "postgres_future_partitions" {
  type = number
}

variable "postgres_future_partition_dbs" {
  type = list(string)
}

variable "postgres_on_error_stop" {
  type = bool
}

variable "postgres_restore_timeout_seconds" {
  type = number
}

variable "postgres_globals_object" {
  type        = string
  description = "Optional roles/globals SQL loaded before the dump (psql_pod)."
}

variable "postgres_fetch_image" {
  type = string
}

# --- Capella (prerequisite, restored into) ---------------------------------

variable "capella_api_url" {
  type = string
}

variable "capella_api_token" {
  type      = string
  sensitive = true
}

variable "capella_organization_id" {
  type = string
}

variable "capella_project_id" {
  type = string
}

variable "capella_cluster_id" {
  type = string
}

variable "capella_connection_string" {
  type = string
}

variable "capella_buckets" {
  type = list(string)
}

variable "couchbase_username" {
  type = string
}

variable "couchbase_password" {
  type      = string
  sensitive = true
}

variable "couchbase_restore_enabled" {
  type = bool
}

variable "couchbase_flush_before_restore" {
  type = bool
}

variable "couchbase_restore_methods" {
  type        = map(string)
  description = "Bucket -> capella_api | cbbackupmgr | cbimport."
}

variable "couchbase_backup_objects" {
  type        = map(string)
  description = "Bucket -> object in backup_bucket (cbbackupmgr tarball or cbexport JSON)."
}

variable "couchbase_cbimport_key_modes" {
  type        = map(string)
  description = "Bucket -> jans_dn | field:<name>, for buckets restored with cbimport."
}

variable "couchbase_index_definitions_object" {
  type        = string
  description = "Optional GSI index definition file in backup_bucket replayed after the data restore."
}

variable "couchbase_expected_doc_counts" {
  type        = map(number)
  description = "Bucket -> minimum document count after restore."
}

variable "couchbase_server_image" {
  type        = string
  description = "Image providing cbimport for in-cluster imports."
}

# --- In-cluster platform restores ------------------------------------------

variable "consul_backup_object" {
  type = string
}

variable "consul_restore_enabled" {
  type = bool
}

variable "vault_backup_object" {
  type = string
}

variable "vault_restore_enabled" {
  type = bool
}

variable "vault_root_token" {
  type      = string
  sensitive = true
}

variable "ldap_backup_objects" {
  type = list(string)
}

variable "ldap_group_additions" {
  type = map(string)
}

variable "ldap_group_member_dns" {
  type = map(list(string))
}

variable "ldap_access_rules" {
  type = map(list(string))
}

variable "ldap_admin_dn" {
  type = string
}

variable "ldap_tls_objects" {
  type = list(string)
}

variable "ldap_restore_enabled" {
  type = bool
}

variable "ldap_admin_password" {
  type      = string
  sensitive = true
}

variable "ldap_base_dn" {
  type = string
}

variable "ldap_namespace" {
  type        = string
  description = "Namespace of the OpenLDAP StatefulSet restored into."
}

variable "ldap_pod_name" {
  type        = string
  description = "OpenLDAP pod slapadd runs in; its StatefulSet is the name without the ordinal."
  default     = "openldap-0"
}

variable "ldap_slapd_config_dir" {
  type        = string
  description = "slapd.d directory inside the OpenLDAP image (Bitnami layout)."
  default     = "/opt/bitnami/openldap/etc/slapd.d"
}

variable "ldap_wipe_before_restore" {
  type        = bool
  description = "Clear the on-disk databases (and slapd.d when restoring config) before slapadd. Destructive; intended for a freshly built DR instance."
  default     = true
}

variable "ldap_restore_config" {
  type        = bool
  description = "Load the *config* LDIF into cn=config. Needed on a fresh instance: the secauthority DB only exists in the source config."
  default     = true
}

variable "report_path" {
  type        = string
  description = "Where the Phase 3 restore report is written on the bastion."
  default     = ".dr-run/restore-report.json"
}

variable "vault_uses_consul_storage" {
  type = bool
}

variable "vault_recovery_timeout_seconds" {
  type = number
}

variable "postgres_dump_format" {
  type = string
}

variable "postgres_restore_jobs" {
  type = number
}

variable "postgres_stage_size" {
  type = string
}

variable "postgres_session_tuning" {
  type = string
}

variable "postgres_databases" {
  type = map(string)
}

variable "storage_class" {
  type        = string
  default     = "standard-rwo"
  description = "StorageClass for the restore staging volume, which holds the downloaded dump."
}

variable "pin_googleapis" {
  type        = bool
  default     = true
  description = <<-EOT
    Pin the googleapis hostnames to private.googleapis.com in the restore
    pods' /etc/hosts.

    This environment drops the rotating public googleapis addresses - the
    bastion already pins them the same way. Without it `gcloud auth
    activate-service-account` in the fetch container times out against
    oauth2.googleapis.com and the restore fails having staged nothing.
  EOT
}

variable "postgres_stage_storage_class" {
  type        = string
  default     = ""
  description = "StorageClass for the restore staging volume. Empty falls back to storage_class."
}

variable "platform_gate" {
  type        = string
  default     = ""
  description = <<-EOT
    Value threaded in from the platform phase. Only the Consul, Vault and LDAP
    restores wait on it; the Postgres and Capella restores do not need the
    platform at all, so they start as soon as the cluster exists.
  EOT
}

variable "postgres_restore_work_mem" {
  type        = string
  default     = "256MB"
  description = "work_mem applied to the target database for the restore, then reset."
}

variable "postgres_restore_parallel_workers" {
  type        = number
  default     = 4
  description = "max_parallel_workers_per_gather applied for the restore, then reset."
}

variable "ldap_slapadd_quick" {
  type        = bool
  default     = true
  description = "Load the LDIFs with slapadd -q, which defers index maintenance. False loads with full per-entry checks and is far slower."
}

variable "postgres_skip_fk_constraints" {
  type        = list(string)
  default     = ["fk_audit_delta"]
  description = "Foreign keys to leave out of the restore, by constraint name. Validating one scans every existing row."
}

variable "postgres_exclude_table_data" {
  type        = list(string)
  default     = []
  description = "Tables whose rows are left out of the restore, by name prefix (a prefix also covers that table's partitions). Schema and indexes are still restored."
}

variable "couchbase_build_deferred_indexes" {
  type        = bool
  default     = true
  description = "Build every deferred GSI index after the Capella restore and wait for the builds. cbbackupmgr restores definitions deferred, and jans-auth cannot start against a bucket whose indexes are not built."
}

variable "couchbase_index_build_timeout_seconds" {
  type        = number
  default     = 1800
  description = "How long to wait for the GSI builds to come online before failing Phase 3."
}

variable "couchbase_ca_cert_file" {
  type        = string
  default     = ""
  description = "CA certificate for the Capella cluster, used by the query-service calls from the bastion. Empty skips verification."
}

variable "couchbase_rewrite_document_endpoints" {
  type        = bool
  default     = true
  description = "Rewrite Capella hostnames carried inside restored documents (custom scripts, clients, configuration) so they name this site's cluster."
}
