output "cloudsql_connection_name" {
  description = "Connection name of the pre-existing Cloud SQL instance. Empty on the psql_pod path."
  value       = try(data.google_sql_database_instance.dr[0].connection_name, "")
}

output "cloudsql_private_ip" {
  description = "Private IP of the Cloud SQL instance, used by DR workloads."
  value       = local.cloudsql_private_ip
}

output "cloudsql_service_account" {
  description = "Service account the Cloud SQL instance runs as. It needs read access to the backup object."
  value       = local.cloudsql_service_account
}

output "restore_report" {
  description = "Per-component result of the Phase 3 restores."
  value       = jsondecode(local_file.restore_report.content)
}

output "completed" {
  description = "Gate consumed by Phase 4's depends_on."
  value       = local_file.restore_report.id
}

output "platform_data_completed" {
  description = "Gate for consumers of the restored Consul/Vault/LDAP data (Phase 5)."
  value       = terraform_data.platform_data_gate.id
}

output "database_completed" {
  description = "Gate for consumers of the restored databases (Phase 6's app sync)."
  value       = terraform_data.database_gate.id
}
