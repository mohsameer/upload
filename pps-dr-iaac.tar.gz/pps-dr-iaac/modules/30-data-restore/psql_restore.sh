#!/usr/bin/env bash
# Restore the PostgreSQL dump into Cloud SQL from INSIDE the DR cluster, over
# the instance's private IP. This is the default path (postgres_restore_method
# = "psql_pod"): it needs neither the Cloud SQL Admin API nor the instance name,
# so it works while sqladmin.googleapis.com is unreachable from the bastion.
#
# The dump is never staged on disk. A Job runs two containers that share an
# emptyDir holding a FIFO:
#   fetch - gcloud storage cat <object> > FIFO
#   load  - psql -f FIFO
# The load side runs its pre-checks first and only then signals the fetch side
# to start, so a pre-check failure never leaves the fetch side blocked on the
# FIFO. The fetch side records its exit code; the load side refuses to call a
# truncated stream a success.
#
# A ".gz" dump is decompressed in the stream. GLOBALS_URI (optional) is a
# pg_dumpall --globals-only file loaded into the postgres DB first so the
# dump's role references resolve; its errors are reported but not fatal,
# since Cloud SQL refuses SUPERUSER-style attributes and some roles exist.
#
# UNSUPPORTED_GUCS drops `SET <name> = ...` lines that the target server does
# not know, which otherwise abort the whole load on line ~15 under
# ON_ERROR_STOP. pg_dump emits the preamble SETs for the version it ran as, so
# a dump taken by pg_dump 17 against a PostgreSQL 16 target fails on
# `transaction_timeout` (new in 17). Only the first HEADER_LINES lines are
# filtered, so COPY data further down can never be touched.
#
# The Job name is derived from the object generation. Re-running this script
# for the same object re-attaches to the existing Job instead of starting a
# second load. To retry after a failure, delete the Job first (the message
# below says which).
set -euo pipefail

: "${NAMESPACE:?}" "${BACKUP_URI:?}" "${BACKUP_GENERATION:?}" "${PG_HOST:?}" "${PG_DATABASE:?}" "${PG_USER:?}" \
  "${PG_PASSWORD:?}" "${GOOGLE_APPLICATION_CREDENTIALS:?}" "${FETCH_IMAGE:?}" "${CLIENT_IMAGE:?}"

# plain  - a SQL text dump, replayed by psql through one connection. Bound by
#          per-commit WAL flushes, so SESSION_TUNING is what buys speed.
# custom  - pg_dump -Fc. pg_restore can then load with RESTORE_JOBS workers,
#          which is the only way to use more than one core. Parallel restore
#          needs a seekable file, so the dump is staged on disk instead of
#          streamed through the FIFO; STAGE_SIZE has to fit it.
DUMP_FORMAT="${DUMP_FORMAT:-plain}"
RESTORE_JOBS="${RESTORE_JOBS:-8}"
# Applied to the target database for the restore and reset afterwards. 4MB of
# work_mem turned one foreign-key validation into an hour of disk-spilling
# join; see the restore block below.
# Foreign keys whose validation is skipped. Validating one means scanning every
# existing row, and on the partitioned audit tables that is the single longest
# step of the whole restore: fk_audit_delta scans ~102 partitions of
# m_audit_delta against m_audit_event and took over two hours with the default
# 4MB work_mem, still unfinished at 46 minutes with 256MB.
#
# The rows come from a production database where that constraint was validated
# and enforced, so pg_dump cannot have produced rows that violate it - the scan
# re-proves what the source already guaranteed. ADD CONSTRAINT ... NOT VALID
# would normally be the answer, but PostgreSQL 16 refuses it on a partitioned
# table ("cannot add NOT VALID foreign key on partitioned table"), so the
# constraint is left out and its statement printed for a later quiet window.
SKIP_FK_CONSTRAINTS="${SKIP_FK_CONSTRAINTS:-}"
# Tables restored empty: structure, indexes and constraints are loaded, the
# rows are not. Space-separated name prefixes, so one entry covers a
# partitioned table and all of its partitions.
#
# midPoint's audit history is 97% of the midpoint database - m_audit_delta
# 136GB over 100 partitions, m_audit_event 16GB over 100, m_audit_item 16GB,
# against ~5GB for every identity object the DR site actually authenticates
# with. Excluding it is what makes the restore minutes instead of hours.
EXCLUDE_TABLE_DATA="${EXCLUDE_TABLE_DATA:-}"
RESTORE_WORK_MEM="${RESTORE_WORK_MEM:-256MB}"
RESTORE_PARALLEL_WORKERS="${RESTORE_PARALLEL_WORKERS:-4}"
STAGE_SIZE="${STAGE_SIZE:-400Gi}"

# Where the staged dump lives.
#
#   pvc       - a PersistentVolumeClaim, deleted with the Job. The node's
#               ephemeral disk is 98GiB here and midpoint's archive is 117GB,
#               so an emptyDir cannot hold it: the restore failed on a disk
#               that was never big enough, whatever sizeLimit said.
#   emptydir  - node ephemeral storage. Fine for the small databases and for
#               the streamed plain-dump path, which needs only a FIFO.
STAGE_MODE="${STAGE_MODE:-pvc}"
# stream - pipe straight into tar: one pass, half the disk, measured at
#          36 MB/s from a pod here. The default, because it is the only one
#          measured end to end.
# cp     - land the archive first, then extract. Only wins if gcloud's parallel
#          ranges beat a single stream; if 36 MB/s is a cap on the path rather
#          than per stream, this is slower, since it adds a full extract pass
#          over the same disk. Untested: the benchmark pod was OOMKilled twice
#          before it printed. Needs ~2.5x the archive in staging space.
STAGE_DOWNLOAD="${STAGE_DOWNLOAD:-stream}"
STAGE_STORAGE_CLASS="${STAGE_STORAGE_CLASS:-standard-rwo}"

# This environment drops the rotating public googleapis addresses; the bastion
# pins them in /etc/hosts and pods need the same. Without it `gcloud auth
# activate-service-account` times out against oauth2.googleapis.com after 120s
# and the fetch side never stages anything - which is how two of three
# restores failed while the third happened to get through.
PRIVATE_GOOGLEAPIS_IP="${PRIVATE_GOOGLEAPIS_IP:-199.36.153.8}"
PIN_GOOGLEAPIS="${PIN_GOOGLEAPIS:-true}"

case "${DUMP_FORMAT}" in
  plain)
    # Streamed through a FIFO, so the volume only ever holds the globals file.
    MKFIFO_CMD="mkfifo /pipe/dump"
    VOLUME_SIZE="1Gi"
    STAGE_MODE="emptydir"
    ;;
  custom)
    # pg_restore needs to seek, so the dump is written to the volume in full.
    MKFIFO_CMD="echo 'custom format: staging to disk, no FIFO'"
    VOLUME_SIZE="${STAGE_SIZE}"
    ;;
  *) echo "ERROR: postgres_dump_format must be plain or custom, got '${DUMP_FORMAT}'." >&2; exit 1 ;;
esac

# Every failure in this script is invisible from the apply log: the
# provisioner's environment carries a password, so OpenTofu replaces all of its
# output with "(output suppressed due to sensitive value in config)", and a
# provisioner error is printed only once the longest in-flight resource has
# drained - up to an hour for the midpoint restore. On 2026-10-12 the idpv3 and
# oidc-mgmt-portal restores died three seconds in and the log said nothing
# about why.
RENDER_DIR=$(mktemp -d)
trap 'rm -rf "${RENDER_DIR}"' EXIT
FAILURE_LOG="${FAILURE_LOG:-/tmp/dr-phase-failures.log}"
note_failure() {
  printf '[%s] psql_restore %s: %s\n' "$(date -u +%H:%M:%S)" "${PG_DATABASE:-?}" "$*" >>"${FAILURE_LOG}" 2>/dev/null || true
  echo "ERROR: $*" >&2
}
trap 'rc=$?; if [ "${rc}" -ne 0 ]; then note_failure "exited ${rc}"; fi; rm -rf "${RENDER_DIR}"' EXIT

# The databases restore concurrently, so these API writes land in the same
# instant; a single transient rejection took out two of the three.
kretry() {
  local a
  for a in 1 2 3 4; do
    if "$@"; then return 0; fi
    if [ "${a}" -eq 4 ]; then note_failure "giving up after ${a} attempts: $*"; return 1; fi
    sleep $(( a * 3 ))
  done
}

PG_PORT="${PG_PORT:-5432}"
GLOBALS_URI="${GLOBALS_URI:-}"
RECREATE_DATABASE="${RECREATE_DATABASE:-false}"
ON_ERROR_STOP="${ON_ERROR_STOP:-true}"
TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-86400}"
POLL_SECONDS="${POLL_SECONDS:-60}"
# Pipe-separated GUC names, matched against the dump preamble only.
UNSUPPORTED_GUCS="${UNSUPPORTED_GUCS:-transaction_timeout}"
# Session settings prepended to the stream. A plain dump replays
# single-threaded through one connection, so the load is bound by per-commit
# WAL flushes rather than CPU - and on a REGIONAL instance every commit waits
# for the standby. Turning off synchronous_commit for the duration is the one
# large win available without changing the dump format; the rest cut
# checkpointing and speed up the index builds the dump does at the end.
# Safe for a bulk load: losing recent commits on a crash means redoing a
# restore that would be redone anyway.
SESSION_TUNING="${SESSION_TUNING:-SET synchronous_commit = off;\nSET maintenance_work_mem = '2GB';\nSET max_wal_size = '16GB';}"
HEADER_LINES="${HEADER_LINES:-200}"
# Requests equal limits so both containers get Guaranteed QoS: the fetch side
# was node-OOM-killed mid-stream as Burstable, which deadlocked the load side.
FETCH_MEMORY="${FETCH_MEMORY:-2Gi}"
# A full core: the limit is now a hard cap, and the preamble filter has to keep
# up with the whole stream.
FETCH_CPU="${FETCH_CPU:-1}"
LOAD_MEMORY="${LOAD_MEMORY:-2Gi}"
LOAD_CPU="${LOAD_CPU:-1}"
# How long the load side waits for the fetch side to record its exit code
# before calling it dead. A SIGKILLed fetch never writes the file at all.
FETCH_RC_WAIT_SECONDS="${FETCH_RC_WAIT_SECONDS:-300}"

JOB="pg-restore-${BACKUP_GENERATION}"
KEY_SECRET="dr-backup-reader-key"
CRED_SECRET="${JOB}-cred"

job_state() {
  local succeeded failed active
  succeeded=$(kubectl -n "${NAMESPACE}" get job "${JOB}" -o jsonpath='{.status.succeeded}' 2>/dev/null || true)
  failed=$(kubectl -n "${NAMESPACE}" get job "${JOB}" -o jsonpath='{.status.failed}' 2>/dev/null || true)
  active=$(kubectl -n "${NAMESPACE}" get job "${JOB}" -o jsonpath='{.status.active}' 2>/dev/null || true)
  if [[ "${succeeded:-0}" -ge 1 ]]; then echo succeeded
  elif [[ "${failed:-0}" -ge 1 ]]; then echo failed
  elif [[ "${active:-0}" -ge 1 ]]; then echo running
  else echo pending
  fi
}

print_logs() {
  echo "--- fetch (last 20 lines) ---" >&2
  kubectl -n "${NAMESPACE}" logs "job/${JOB}" -c fetch --tail=20 >&2 || true
  echo "--- load (last 40 lines) ---" >&2
  kubectl -n "${NAMESPACE}" logs "job/${JOB}" -c load --tail=40 >&2 || true
}

JOB_PRESENT=no
if kubectl -n "${NAMESPACE}" get job "${JOB}" >/dev/null 2>&1; then
  # Re-attaching to a *failed* Job would make every later attempt fail on the
  # same dead pod. Delete it and restore again; the staging PVC is left alone,
  # so a re-run re-uses the dump it already downloaded.
  if [[ "$(job_state)" == "failed" ]]; then
    echo "Job ${JOB} exists but failed; deleting it and restoring again."
    print_logs
    kretry kubectl -n "${NAMESPACE}" delete job "${JOB}" --ignore-not-found >/dev/null
  else
    echo "Job ${JOB} already exists for this backup generation; re-attaching."
    JOB_PRESENT=yes
  fi
fi

if [[ "${JOB_PRESENT}" == "no" ]]; then
  # Secrets are applied, not created, so a re-run after a partial first run
  # does not fail on AlreadyExists. Neither value is ever printed.
  kubectl -n "${NAMESPACE}" create secret generic "${KEY_SECRET}" \
    --from-file=key.json="${GOOGLE_APPLICATION_CREDENTIALS}" \
    --dry-run=client -o yaml >"${RENDER_DIR}/secret.yaml"
  kretry kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/secret.yaml" >/dev/null
  kubectl -n "${NAMESPACE}" create secret generic "${CRED_SECRET}" \
    --from-literal=PGPASSWORD="${PG_PASSWORD}" \
    --dry-run=client -o yaml >"${RENDER_DIR}/secret.yaml"
  kretry kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/secret.yaml" >/dev/null

  if [[ "${STAGE_MODE}" == "pvc" ]]; then
    PVC="${JOB}-stage"
    echo "Staging on pvc/${PVC} (${STAGE_SIZE}, ${STAGE_STORAGE_CLASS})"
    cat <<PVCEOF >"${RENDER_DIR}/pvc.yaml"
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ${PVC}
  labels:
    app.kubernetes.io/name: pg-restore
spec:
  accessModes: [ReadWriteOnce]
  storageClassName: ${STAGE_STORAGE_CLASS}
  resources:
    requests:
      storage: ${STAGE_SIZE}
PVCEOF
    kretry kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/pvc.yaml" >/dev/null
    STAGE_VOLUME_YAML="          persistentVolumeClaim:
            claimName: ${PVC}"
  else
    STAGE_VOLUME_YAML="          emptyDir:
            sizeLimit: ${VOLUME_SIZE}"
  fi

  if [[ "${PIN_GOOGLEAPIS}" == "true" ]]; then
    HOST_ALIASES_YAML="      hostAliases:
        - ip: ${PRIVATE_GOOGLEAPIS_IP}
          hostnames:
            - oauth2.googleapis.com
            - storage.googleapis.com
            - iamcredentials.googleapis.com
            - www.googleapis.com
            - googleapis.com
"
  else
    HOST_ALIASES_YAML=""
  fi

  echo "Creating Job ${JOB}: ${BACKUP_URI} -> ${PG_HOST}:${PG_PORT}/${PG_DATABASE} (recreate=${RECREATE_DATABASE})"

  cat <<EOF >"${RENDER_DIR}/job.yaml"
apiVersion: batch/v1
kind: Job
metadata:
  name: ${JOB}
  labels:
    app.kubernetes.io/name: pg-restore
    pps-dr/phase: "3"
spec:
  backoffLimit: 0
  activeDeadlineSeconds: ${TIMEOUT_SECONDS}
  ttlSecondsAfterFinished: 604800
  template:
    metadata:
      labels:
        app.kubernetes.io/name: pg-restore
    spec:
      restartPolicy: Never
${HOST_ALIASES_YAML}      volumes:
        - name: pipe
${STAGE_VOLUME_YAML}
        - name: gcp-key
          secret:
            secretName: ${KEY_SECRET}
      initContainers:
        - name: mkfifo
          image: ${CLIENT_IMAGE}
          command: ["/bin/sh", "-c", "${MKFIFO_CMD}"]
          volumeMounts:
            - { name: pipe, mountPath: /pipe }
      containers:
        - name: fetch
          image: ${FETCH_IMAGE}
          resources:
            requests: { cpu: ${FETCH_CPU}, memory: ${FETCH_MEMORY} }
            limits: { cpu: ${FETCH_CPU}, memory: ${FETCH_MEMORY} }
          volumeMounts:
            - { name: pipe, mountPath: /pipe }
            - { name: gcp-key, mountPath: /var/secrets/gcp, readOnly: true }
          env:
            - { name: BACKUP_URI, value: "${BACKUP_URI}" }
            - { name: GLOBALS_URI, value: "${GLOBALS_URI}" }
            - { name: UNSUPPORTED_GUCS, value: "${UNSUPPORTED_GUCS}" }
            - { name: HEADER_LINES, value: "${HEADER_LINES}" }
            - { name: SESSION_TUNING, value: "${SESSION_TUNING}" }
            - { name: DUMP_FORMAT, value: "${DUMP_FORMAT}" }
            - { name: STAGE_DOWNLOAD, value: "${STAGE_DOWNLOAD}" }
          command: ["/bin/bash", "-c"]
          args:
            - |
              set -uo pipefail
              # Any ordinary exit records an rc, so the load side never waits on
              # a writer that has already gone. A SIGKILL (node OOM) cannot be
              # trapped, which is why the load side also bounds its wait.
              rc=1
              trap '[ -e /pipe/fetch.rc ] || echo "\${rc}" > /pipe/fetch.rc' EXIT
              gcloud auth activate-service-account --key-file=/var/secrets/gcp/key.json >/dev/null || exit 1
              if [ -n "\${GLOBALS_URI}" ]; then
                gcloud storage cp "\${GLOBALS_URI}" /pipe/globals.sql || exit 1
                touch /pipe/globals.done
              fi
              echo "waiting for the load side to finish its pre-checks..."
              until [ -e /pipe/ready ] || [ -e /pipe/abort ]; do sleep 2; done
              if [ -e /pipe/abort ]; then echo "load side aborted before streaming"; exit 1; fi
              # Drop preamble SETs the target server does not know. Confined to
              # the first \${HEADER_LINES} lines so COPY data is never rewritten.
              strip_gucs() {
                if [ -z "\${UNSUPPORTED_GUCS}" ]; then cat; return; fi
                awk -v n="\${HEADER_LINES}" -v gucs="\${UNSUPPORTED_GUCS}" '
                  NR <= n && \$0 ~ "^SET (" gucs ") *=" {
                    print "fetch: dropped unsupported preamble line " NR ": " \$0 > "/dev/stderr"
                    next
                  }
                  { print }
                '
              }
              if [ "\${DUMP_FORMAT}" = "custom" ]; then
                # A custom dump is binary: no preamble to filter and no session
                # tuning to prepend, and pg_restore needs a seekable file.
                echo "staging \${BACKUP_URI} for pg_restore"
                case "\${BACKUP_URI}" in
                  */|*.dump.d)
                    # A pg_dump -Fd directory, one object per file. Downloaded
                    # with many parallel streams, which is the whole reason it
                    # is shipped this way: the single-object tar staged at
                    # 40 MB/s and was the restore's bottleneck.
                    mkdir -p /pipe/dumpdir
                    gcloud storage cp -r "\${BACKUP_URI%/}/*" /pipe/dumpdir/
                    inner=\$(find /pipe/dumpdir -maxdepth 2 -name toc.dat -printf '%h\n' 2>/dev/null | head -n1)
                    [ -n "\${inner}" ] || { echo "ERROR: no toc.dat under \${BACKUP_URI}; not a pg_dump -Fd directory" >&2; exit 1; }
                    echo "\${inner}" > /pipe/dumppath
                    ;;
                  *.tar)
                    # Landed first, then extracted. gcloud splits a large
                    # object into ranges and fetches them in parallel, where
                    # `storage cat` is a single stream - measured at 36 MB/s
                    # from a pod on this site, which is what made staging
                    # midpoint's 117GB take 48 minutes. It costs twice the
                    # staging disk for the duration, which is why
                    # postgres_stage_size wants ~2.5x the archive.
                    mkdir -p /pipe/dumpdir
                    if [ "\${STAGE_DOWNLOAD}" = "cp" ]; then
                      gcloud storage cp "\${BACKUP_URI}" /pipe/dump.tar
                      tar -xf /pipe/dump.tar -C /pipe/dumpdir
                      rm -f /pipe/dump.tar
                    else
                      gcloud storage cat "\${BACKUP_URI}" | tar -xf - -C /pipe/dumpdir
                    fi
                    inner=\$(find /pipe/dumpdir -maxdepth 2 -name toc.dat -printf '%h\n' 2>/dev/null | head -n1)
                    [ -n "\${inner}" ] || { echo "ERROR: no toc.dat in \${BACKUP_URI}; not a pg_dump -Fd archive" >&2; exit 1; }
                    echo "\${inner}" > /pipe/dumppath
                    ;;
                  *.tar.gz|*.tgz)
                    # pg_dump -Fd is a directory, so it travels as a tarball
                    # and pg_restore cannot read it compressed. Unpack it and
                    # hand pg_restore the directory, which is also what lets
                    # it restore with several workers.
                    #
                    # Extracted straight off the download: landing the archive
                    # first and then unpacking it needs twice the staging disk,
                    # and these archives are ~100GB. A .tar carries no outer
                    # compression because every file inside a -Fd dump is
                    # already compressed.
                    mkdir -p /pipe/dumpdir
                    case "\${BACKUP_URI}" in
                      *.tar) gcloud storage cat "\${BACKUP_URI}" | tar -xf  - -C /pipe/dumpdir ;;
                      *)     gcloud storage cat "\${BACKUP_URI}" | tar -xzf - -C /pipe/dumpdir ;;
                    esac
                    # The archive holds one directory; point at it, not its parent.
                    inner=\$(find /pipe/dumpdir -maxdepth 2 -name toc.dat -printf '%h\n' 2>/dev/null | head -n1)
                    [ -n "\${inner}" ] || { echo "ERROR: no toc.dat in \${BACKUP_URI}; not a pg_dump -Fd archive" >&2; exit 1; }
                    echo "\${inner}" > /pipe/dumppath
                    ;;
                  *)
                    gcloud storage cp "\${BACKUP_URI}" /pipe/dump.custom
                    echo /pipe/dump.custom > /pipe/dumppath
                    ;;
                esac
                touch /pipe/staged
              else
                echo "streaming \${BACKUP_URI} (dropping preamble SETs: \${UNSUPPORTED_GUCS})"
                # Session tuning goes in ahead of the dump so psql applies it to
                # the connection that does the load.
                {
                  [ -n "\${SESSION_TUNING:-}" ] && printf '%b\n' "\${SESSION_TUNING}"
                  case "\${BACKUP_URI}" in
                    *.gz) gcloud storage cat "\${BACKUP_URI}" | gunzip -c | strip_gucs ;;
                    *)    gcloud storage cat "\${BACKUP_URI}" | strip_gucs ;;
                  esac
                } > /pipe/dump
              fi
              rc=\$?
              echo "\${rc}" > /pipe/fetch.rc
              echo "fetch finished rc=\${rc}"
              exit \${rc}
        - name: load
          image: ${CLIENT_IMAGE}
          resources:
            requests: { cpu: "${LOAD_CPU}", memory: ${LOAD_MEMORY} }
            limits: { cpu: "${LOAD_CPU}", memory: ${LOAD_MEMORY} }
          volumeMounts:
            - { name: pipe, mountPath: /pipe }
          envFrom:
            - secretRef: { name: ${CRED_SECRET} }
          env:
            - { name: PGHOST, value: "${PG_HOST}" }
            - { name: PGPORT, value: "${PG_PORT}" }
            - { name: PGUSER, value: "${PG_USER}" }
            - { name: TARGET_DB, value: "${PG_DATABASE}" }
            - { name: RECREATE, value: "${RECREATE_DATABASE}" }
            - { name: STOP_ON_ERROR, value: "${ON_ERROR_STOP}" }
            - { name: WANT_GLOBALS, value: "$([[ -n "${GLOBALS_URI}" ]] && echo true || echo false)" }
            - { name: FETCH_RC_WAIT_SECONDS, value: "${FETCH_RC_WAIT_SECONDS}" }
            - { name: DUMP_FORMAT, value: "${DUMP_FORMAT}" }
            - { name: STAGE_DOWNLOAD, value: "${STAGE_DOWNLOAD}" }
            - { name: RESTORE_JOBS, value: "${RESTORE_JOBS}" }
            - { name: RESTORE_WORK_MEM, value: "${RESTORE_WORK_MEM}" }
            - { name: SKIP_FK_CONSTRAINTS, value: "${SKIP_FK_CONSTRAINTS}" }
            - { name: EXCLUDE_TABLE_DATA, value: "${EXCLUDE_TABLE_DATA}" }
            - { name: RESTORE_PARALLEL_WORKERS, value: "${RESTORE_PARALLEL_WORKERS}" }
          command: ["/bin/bash", "-c"]
          args:
            - |
              set -uo pipefail
              abort() { echo "ERROR: \$*" >&2; touch /pipe/abort; exit 1; }
              psql --version
              psql -d postgres -tAc 'SELECT 1' >/dev/null || abort "cannot connect to \${PGHOST}:\${PGPORT} as \${PGUSER}"
              if [ "\${WANT_GLOBALS}" = "true" ]; then
                until [ -e /pipe/globals.done ] || [ -e /pipe/fetch.rc ]; do sleep 2; done
                [ -e /pipe/globals.done ] || abort "could not download the globals/roles file"
                echo "loading roles/globals (errors reported, not fatal)"
                psql -d postgres -f /pipe/globals.sql 2>&1 | grep -E 'ERROR|CREATE ROLE|ALTER ROLE' | sort | uniq -c | sort -rn | head -20 || true
              fi
              if [ "\${RECREATE}" = "true" ]; then
                echo "postgres_recreate_database=true: dropping and recreating \${TARGET_DB}"
                psql -d postgres -v ON_ERROR_STOP=1 \
                  -c "DROP DATABASE IF EXISTS \"\${TARGET_DB}\" WITH (FORCE)" \
                  -c "CREATE DATABASE \"\${TARGET_DB}\"" || abort "recreate of \${TARGET_DB} failed"
              fi
              EXISTS=\$(psql -d postgres -tAc "SELECT 1 FROM pg_database WHERE datname = '\${TARGET_DB}'")
              if [ "\${EXISTS}" != "1" ]; then
                echo "database \${TARGET_DB} absent; creating it"
                psql -d postgres -v ON_ERROR_STOP=1 -c "CREATE DATABASE \"\${TARGET_DB}\"" || abort "create of \${TARGET_DB} failed"
              fi
              TABLES=\$(psql -d "\${TARGET_DB}" -tAc "SELECT count(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")
              if [ "\${TABLES}" != "0" ]; then
                abort "\${TARGET_DB} already holds \${TABLES} tables. The plain dump does not clean the target; set postgres_recreate_database = true to drop and recreate it."
              fi
              STOP_FLAG=""
              [ "\${STOP_ON_ERROR}" = "true" ] && STOP_FLAG="-v ON_ERROR_STOP=1"
              # The fetch side only writes fetch.rc early when it failed to authenticate.
              [ -e /pipe/fetch.rc ] && abort "fetch side failed before streaming (GCP key / bucket access)"
              touch /pipe/ready
              if [ "\${DUMP_FORMAT}" = "custom" ]; then
                echo "waiting for the staged dump..."
                until [ -e /pipe/staged ] || [ -e /pipe/fetch.rc ]; do sleep 5; done
                [ -e /pipe/staged ] || abort "the fetch side did not stage the dump"
                echo "restoring into \${TARGET_DB} with \${RESTORE_JOBS} workers"
                # Session settings cannot be prepended to a binary dump, so they
                # are applied to the target database instead and inherited by
                # every pg_restore worker connection.
                # work_mem matters as much as maintenance_work_mem, and only
                # the latter was set. pg_restore's last items are the foreign
                # keys, and validating one is an ordinary join governed by
                # work_mem - which is 4MB on this instance. Validating
                # midpoint's FK on m_audit_delta, ~100 partitions against ~100
                # on the referenced side, spilled to disk and ran for over an
                # hour as the single remaining item while three of four
                # workers sat idle.
                #
                # max_parallel_workers_per_gather is raised for the same
                # statement: it is a query, so it can use parallel workers,
                # and the server default here is 2.
                psql -d "\${TARGET_DB}" -v ON_ERROR_STOP=1 \
                  -c "ALTER DATABASE \"\${TARGET_DB}\" SET synchronous_commit TO off" \
                  -c "ALTER DATABASE \"\${TARGET_DB}\" SET maintenance_work_mem TO '2GB'" \
                  -c "ALTER DATABASE \"\${TARGET_DB}\" SET work_mem TO '\${RESTORE_WORK_MEM}'" \
                  -c "ALTER DATABASE \"\${TARGET_DB}\" SET max_parallel_workers_per_gather TO \${RESTORE_PARALLEL_WORKERS}" >/dev/null || true
                DUMPPATH=\$(cat /pipe/dumppath)
                RESTORE_SELECT=""
                if [ -n "\${SKIP_FK_CONSTRAINTS}" ] || [ -n "\${EXCLUDE_TABLE_DATA}" ]; then
                  # -L takes a table of contents with the unwanted items
                  # removed. Two kinds of line are dropped here:
                  #
                  #   6427; 2606 64614968 FK CONSTRAINT public m_x fk_y postgres
                  #   3456; 0    64614900 TABLE DATA    public m_audit_item postgres
                  #
                  # so field 8 is the constraint name on the first and field 7
                  # the table name on the second. midPoint names its audit
                  # partitions with the schema inside the relation name
                  # ("public.m_audit_delta_132500000"), hence the sub() before
                  # the prefix comparison.
                  pg_restore -l "\${DUMPPATH}" > /pipe/toc.all 2>/dev/null
                  awk -v skip="\${SKIP_FK_CONSTRAINTS}" -v nodata="\${EXCLUDE_TABLE_DATA}" '
                    BEGIN {
                      n = split(skip, a, " "); for (i = 1; i <= n; i++) drop[a[i]] = 1
                      m = split(nodata, b, " "); for (i = 1; i <= m; i++) empty[b[i]] = 1
                    }
                    /FK CONSTRAINT/ && (\$8 in drop) { print "-- deferred: " \$0 > "/pipe/toc.skipped"; next }
                    /TABLE DATA/ {
                      t = \$7; sub(/^public\./, "", t)
                      for (p in empty) {
                        if (t == p || index(t, p "_") == 1) {
                          print "-- no data: " \$0 > "/pipe/toc.nodata"
                          next
                        }
                      }
                    }
                    { print }
                  ' /pipe/toc.all > /pipe/toc.use
                  RESTORE_SELECT="-L /pipe/toc.use"
                  if [ -n "\${SKIP_FK_CONSTRAINTS}" ]; then
                    if [ -s /pipe/toc.skipped ]; then
                      echo "deferring \$(wc -l < /pipe/toc.skipped) foreign key constraint(s):"
                      sed 's/^/  /' /pipe/toc.skipped
                    else
                      echo "WARNING: SKIP_FK_CONSTRAINTS='\${SKIP_FK_CONSTRAINTS}' matched nothing in the archive" >&2
                    fi
                  fi
                  if [ -n "\${EXCLUDE_TABLE_DATA}" ]; then
                    if [ -s /pipe/toc.nodata ]; then
                      echo "restoring \$(wc -l < /pipe/toc.nodata) table(s) empty (EXCLUDE_TABLE_DATA='\${EXCLUDE_TABLE_DATA}'); schema and indexes still load:"
                      awk '{ print \$10 }' /pipe/toc.nodata | sed 's/^/  /' | head -n 8
                      [ "\$(wc -l < /pipe/toc.nodata)" -gt 8 ] && echo "  ... and \$(( \$(wc -l < /pipe/toc.nodata) - 8 )) more"
                    else
                      echo "WARNING: EXCLUDE_TABLE_DATA='\${EXCLUDE_TABLE_DATA}' matched no table in the archive" >&2
                    fi
                  fi
                fi
                # shellcheck disable=SC2086
                pg_restore -d "\${TARGET_DB}" -j "\${RESTORE_JOBS}" --no-owner --no-acl \${RESTORE_SELECT} "\${DUMPPATH}"
                rc=\$?
                if [ -s /pipe/toc.skipped ]; then
                  echo "--- apply these in a quiet window to complete the schema ---"
                  awk '{ print \$9, \$10, \$11 }' /pipe/toc.skipped | while read -r sch tbl con; do
                    echo "  ALTER TABLE \${sch}.\${tbl} ADD CONSTRAINT \${con} ... ;  -- see pg_restore -l"
                  done
                  echo "--- the DR site is not serving writes, so the scan costs nothing there ---"
                fi
                # The restore's settings do not belong to the running site.
                for g in synchronous_commit work_mem maintenance_work_mem max_parallel_workers_per_gather; do
                  psql -d "\${TARGET_DB}" -c "ALTER DATABASE \"\${TARGET_DB}\" RESET \${g}" >/dev/null 2>&1 || true
                done
              else
                echo "loading into \${TARGET_DB} (ON_ERROR_STOP=\${STOP_ON_ERROR})"
                psql -d "\${TARGET_DB}" \${STOP_FLAG} -f /pipe/dump
                rc=\$?
              fi
              # Stop the fetch side immediately if psql gave up, rather than
              # leaving it to push the rest of the dump into a pipe nobody reads.
              [ "\${rc}" != "0" ] && touch /pipe/abort
              # Bounded: a fetch side killed by the node OOM killer never gets
              # to write fetch.rc, and an unbounded wait here hung a failed
              # restore for 10h instead of reporting it.
              waited=0
              until [ -e /pipe/fetch.rc ]; do
                if [ "\${waited}" -ge "\${FETCH_RC_WAIT_SECONDS}" ]; then
                  echo "ERROR: the fetch side never recorded an exit code after \${waited}s; it was killed mid-stream (check for OOMKilled). The restore is incomplete." >&2
                  exit 1
                fi
                sleep 2; waited=\$((waited + 2))
              done
              frc=\$(cat /pipe/fetch.rc)
              if [ "\${rc}" != "0" ]; then echo "ERROR: psql exited \${rc}" >&2; exit "\${rc}"; fi
              if [ "\${frc}" != "0" ]; then echo "ERROR: the dump stream was cut short (fetch rc=\${frc}); the restore is incomplete" >&2; exit 1; fi
              TABLES=\$(psql -d "\${TARGET_DB}" -tAc "SELECT count(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")
              echo "restore complete: \${TABLES} tables in \${TARGET_DB}"
EOF
  kretry kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/job.yaml" >/dev/null
fi

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
while true; do
  STATE=$(job_state)
  case "${STATE}" in
    succeeded)
      kubectl -n "${NAMESPACE}" logs "job/${JOB}" -c load --tail=5 || true
      kubectl -n "${NAMESPACE}" delete secret "${CRED_SECRET}" --ignore-not-found >/dev/null 2>&1 || true
      # The staging disk is only needed while the restore runs, and midpoint's
      # is 160Gi, so it does not stay behind.
      #
      # The pod goes first and neither delete waits. A PVC carries the
      # pvc-protection finalizer, and a *Completed* pod still counts as a
      # consumer, so `delete pvc` blocks for as long as the pod exists - which
      # is ttlSecondsAfterFinished, a week. Two restores sat in that delete for
      # twelve minutes, holding up the apply after their data had loaded.
      # Deleting the pod releases the finalizer; the Job object stays for
      # inspection, and its logs have already been printed above.
      if [[ "${STAGE_MODE}" == "pvc" ]]; then
        kubectl -n "${NAMESPACE}" delete pod -l "job-name=${JOB}" \
          --wait=false --ignore-not-found >/dev/null 2>&1 || true
        kubectl -n "${NAMESPACE}" delete pvc "${JOB}-stage" \
          --wait=false --ignore-not-found >/dev/null 2>&1 || true
      fi
      echo "PostgreSQL restore Job ${JOB} succeeded."
      exit 0
      ;;
    failed)
      echo "ERROR: PostgreSQL restore Job ${JOB} failed." >&2
      print_logs
      echo "Fix the cause, then delete the Job to retry:" >&2
      echo "  kubectl -n ${NAMESPACE} delete job ${JOB}" >&2
      if [[ "${STAGE_MODE}" == "pvc" ]]; then
        # Kept on failure: the staged dump is worth inspecting, and a retry
        # re-uses it rather than downloading 117GB again.
        echo "  kubectl -n ${NAMESPACE} delete pvc ${JOB}-stage   # staged dump, keep it to retry quickly" >&2
      fi
      exit 1
      ;;
  esac
  if [[ ${SECONDS} -ge ${DEADLINE} ]]; then
    echo "ERROR: Job ${JOB} still ${STATE} after ${TIMEOUT_SECONDS}s." >&2
    print_logs
    exit 1
  fi
  echo "[$(date -u +%H:%M:%S)] ${JOB}: ${STATE} | $(kubectl -n "${NAMESPACE}" logs "job/${JOB}" -c load --tail=1 2>/dev/null | cut -c1-120)"
  sleep "${POLL_SECONDS}"
done
