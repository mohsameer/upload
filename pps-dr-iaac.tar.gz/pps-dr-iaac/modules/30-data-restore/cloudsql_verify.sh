#!/usr/bin/env bash
# Verify the restored Cloud SQL database is reachable FROM INSIDE the DR
# cluster and that the restore actually landed data.
#
# The check runs as a Job in the cluster rather than from the bastion, because
# the requirement is that DR workloads can reach the database.
set -euo pipefail

: "${NAMESPACE:?}" "${PG_DATABASE:?}" "${PG_USER:?}" "${MIN_EXPECTED_TABLES:?}"

if [[ -z "${PG_HOST:-}" ]]; then
  echo "ERROR: Cloud SQL instance has no PRIVATE ip_address." >&2
  echo "The DR cluster reaches Cloud SQL over private services access; enable a private IP on the instance or switch this check to the Auth Proxy path." >&2
  exit 1
fi

JOB="cloudsql-verify-$(date +%s)"
SECRET="cloudsql-verify-cred-${JOB}"

cleanup() {
  kubectl -n "${NAMESPACE}" delete job "${JOB}" --ignore-not-found >/dev/null 2>&1 || true
  kubectl -n "${NAMESPACE}" delete secret "${SECRET}" --ignore-not-found >/dev/null 2>&1 || true
}
trap cleanup EXIT

kubectl -n "${NAMESPACE}" create secret generic "${SECRET}" \
  --from-literal=PGPASSWORD="${PG_PASSWORD}" >/dev/null

cat <<EOF | kubectl -n "${NAMESPACE}" apply -f - >/dev/null
apiVersion: batch/v1
kind: Job
metadata:
  name: ${JOB}
spec:
  backoffLimit: 0
  ttlSecondsAfterFinished: 300
  template:
    spec:
      restartPolicy: Never
      containers:
        - name: psql
          image: ${PG_CLIENT_IMAGE}
          envFrom:
            - secretRef:
                name: ${SECRET}
          env:
            - name: PGHOST
              value: "${PG_HOST}"
            - name: PGUSER
              value: "${PG_USER}"
            - name: PGDATABASE
              value: "${PG_DATABASE}"
          command: ["/bin/sh", "-c"]
          args:
            - |
              set -e
              echo "connectivity check..."
              psql -tAc 'SELECT 1' >/dev/null
              TABLES=\$(psql -tAc "SELECT count(*) FROM information_schema.tables WHERE table_schema NOT IN ('pg_catalog','information_schema')")
              echo "restored table count: \$TABLES"
              if [ "\$TABLES" -lt "${MIN_EXPECTED_TABLES}" ]; then
                echo "ERROR: only \$TABLES tables present, expected at least ${MIN_EXPECTED_TABLES}" >&2
                exit 1
              fi
              echo "read/write check..."
              psql -c 'CREATE TABLE IF NOT EXISTS dr_verify_probe (id int primary key, seen_at timestamptz default now())' >/dev/null
              psql -c 'INSERT INTO dr_verify_probe (id) VALUES (1) ON CONFLICT (id) DO UPDATE SET seen_at = now()' >/dev/null
              psql -tAc 'SELECT count(*) FROM dr_verify_probe' >/dev/null
              psql -c 'DROP TABLE dr_verify_probe' >/dev/null
              echo "cloudsql verification passed"
EOF

echo "Waiting for Cloud SQL verification job ${JOB}..."
if ! kubectl -n "${NAMESPACE}" wait --for=condition=complete "job/${JOB}" --timeout=300s; then
  echo "ERROR: Cloud SQL verification failed. Job logs:" >&2
  kubectl -n "${NAMESPACE}" logs "job/${JOB}" >&2 || true
  exit 1
fi

kubectl -n "${NAMESPACE}" logs "job/${JOB}"
echo "Cloud SQL is reachable from the DR cluster and the restore is populated."
