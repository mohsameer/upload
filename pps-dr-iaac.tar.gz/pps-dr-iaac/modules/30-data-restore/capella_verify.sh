#!/usr/bin/env bash
# Post-restore verification: every configured Capella bucket must hold
# documents. A restore that "succeeds" into an empty bucket is a failed DR.
#
# Item counts come from the Capella Management API when a token is set, and
# otherwise from the cluster's own management API (:18091) with the DB user -
# no Capella control-plane token needed (openspec change dr-drill-fixes, E5).
# EXPECTED_COUNTS ("bucket=count ...") turns "non-zero" into "at least N".
set -euo pipefail

: "${CAPELLA_BUCKETS:?}"

declare -A ITEMS=()

if [[ -n "${CAPELLA_API_TOKEN:-}" ]]; then
  : "${CAPELLA_API_URL:?}" "${CAPELLA_ORG_ID:?}" "${CAPELLA_PROJECT_ID:?}" "${CAPELLA_CLUSTER_ID:?}"
  BASE="${CAPELLA_API_URL}/v4/organizations/${CAPELLA_ORG_ID}/projects/${CAPELLA_PROJECT_ID}/clusters/${CAPELLA_CLUSTER_ID}"
  BUCKETS_JSON=$(curl -sS -H "Authorization: Bearer ${CAPELLA_API_TOKEN}" -H "Accept: application/json" "${BASE}/buckets")
  SOURCE="Capella Management API"
  while IFS=$'\t' read -r name count; do
    [[ -n "${name}" ]] && ITEMS["${name}"]="${count}"
  done < <(echo "${BUCKETS_JSON}" | jq -r '.data[]? | [.name, (.stats.itemCount // "")] | @tsv')
else
  : "${CONNECTION_STRING:?}" "${COUCHBASE_USERNAME:?}" "${COUCHBASE_PASSWORD:?}"
  HOST="${CONNECTION_STRING#*://}"
  HOST="${HOST%%[/?,]*}"
  BUCKETS_JSON=$(curl -sk --max-time 60 -u "${COUCHBASE_USERNAME}:${COUCHBASE_PASSWORD}" \
    "https://${HOST}:18091/pools/default/buckets")
  SOURCE="cluster management API on ${HOST}:18091"
  while IFS=$'\t' read -r name count; do
    [[ -n "${name}" ]] && ITEMS["${name}"]="${count}"
  done < <(echo "${BUCKETS_JSON}" | jq -r '.[]? | [.name, (.basicStats.itemCount // "")] | @tsv')
fi

declare -A EXPECTED=()
for pair in ${EXPECTED_COUNTS:-}; do
  EXPECTED["${pair%%=*}"]="${pair#*=}"
done

echo "Item counts from the ${SOURCE}:"
FAILED=()
for bucket in ${CAPELLA_BUCKETS}; do
  count="${ITEMS[${bucket}]:-}"
  want="${EXPECTED[${bucket}]:-1}"
  if [[ -z "${count}" ]]; then
    FAILED+=("${bucket}: not present on the cluster")
  elif [[ "${count}" -lt "${want}" ]]; then
    FAILED+=("${bucket}: ${count} documents, expected at least ${want}")
  else
    echo "  bucket ${bucket}: ${count} documents (expected >= ${want})"
  fi
done

if [[ ${#FAILED[@]} -gt 0 ]]; then
  echo "ERROR: Capella restore verification failed." >&2
  for f in "${FAILED[@]}"; do echo "  - ${f}" >&2; done
  exit 1
fi

echo "All Capella buckets verified."
