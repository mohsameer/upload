#!/usr/bin/env bash
# Restore ONE Couchbase bucket into the pre-existing Capella cluster, from the
# DR bastion. Called once per bucket whose couchbase_restore_methods entry is
# capella_api or cbbackupmgr (cbimport runs in-cluster: cbimport_restore.sh).
#
#   capella_api  - Capella Management API v4 restore from Capella's own backups.
#   cbbackupmgr  - cbbackupmgr restore from a tarball in GCS. The tarball may
#                  hold a full archive (with a .backup marker) or just one
#                  repository directory; the latter is wrapped in a freshly
#                  initialised archive.
#
# The Capella cluster itself is a prerequisite and is never created here.
set -euo pipefail

: "${BUCKET:?}" "${METHOD:?}"

case "${METHOD}" in
  cbbackupmgr)
    : "${BACKUP_URI:?BACKUP_URI required for cbbackupmgr}"
    : "${CONNECTION_STRING:?}" "${COUCHBASE_USERNAME:?}" "${COUCHBASE_PASSWORD:?}"

    if ! command -v cbbackupmgr >/dev/null 2>&1; then
      echo "ERROR: cbbackupmgr not found on the DR bastion, but bucket '${BUCKET}' uses method cbbackupmgr." >&2
      exit 1
    fi

    WORKDIR=$(mktemp -d)
    trap 'rm -rf "${WORKDIR}"' EXIT
    mkdir -p "${WORKDIR}/extract"

    echo "Downloading ${BACKUP_URI}..."
    gcloud storage cp "${BACKUP_URI}" "${WORKDIR}/archive"
    # GNU tar detects .tar / .tar.gz / .tgz on extraction.
    tar -xf "${WORKDIR}/archive" -C "${WORKDIR}/extract"

    MARKER=$(find "${WORKDIR}/extract" -maxdepth 3 -type f -name .backup | head -n1)
    if [[ -n "${MARKER}" ]]; then
      ARCHIVE_DIR=$(dirname "${MARKER}")
      REPO="${COUCHBASE_REPO:-}"
      if [[ -z "${REPO}" ]]; then
        REPO=$(find "${ARCHIVE_DIR}" -mindepth 2 -maxdepth 2 -name backup-meta.json | head -n1 | xargs -r dirname | xargs -r basename)
      fi
    else
      # Repository-only tarball: cbbackupmgr needs an archive around it.
      REPO_META=$(find "${WORKDIR}/extract" -maxdepth 3 -type f -name backup-meta.json | head -n1)
      if [[ -z "${REPO_META}" ]]; then
        echo "ERROR: ${BACKUP_URI} contains neither a cbbackupmgr archive (.backup) nor a repository (backup-meta.json)." >&2
        exit 1
      fi
      REPO_DIR=$(dirname "${REPO_META}")
      REPO=$(basename "${REPO_DIR}")
      ARCHIVE_DIR="${WORKDIR}/archive"
      echo "Tarball holds repository '${REPO}' without an archive root; initialising one."
      cbbackupmgr config --archive "${ARCHIVE_DIR}" --repo __dr_init >/dev/null
      mv "${REPO_DIR}" "${ARCHIVE_DIR}/${REPO}"
    fi

    if [[ -z "${REPO}" ]]; then
      echo "ERROR: could not determine the repository name inside ${BACKUP_URI}." >&2
      exit 1
    fi

    # Flush the target bucket first (COUCHBASE_FLUSH_BEFORE_RESTORE, default
    # true). cbbackupmgr --force-updates only upserts; without a flush, docs
    # that exist in DR but not in prod stay behind. Flush requires flushEnabled
    # on the bucket; on Capella Community this is on by default.
    if [[ "${COUCHBASE_FLUSH_BEFORE_RESTORE:-true}" == "true" ]]; then
      HOST="${CONNECTION_STRING#*://}"; HOST="${HOST%%[/?,]*}"
      echo "Flushing bucket ${BUCKET} on ${HOST}:18091..."
      code=$(curl -sk --max-time 60 -u "${COUCHBASE_USERNAME}:${COUCHBASE_PASSWORD}" \
        -X POST -o /dev/null -w '%{http_code}' \
        "https://${HOST}:18091/pools/default/buckets/${BUCKET}/controller/doFlush")
      case "${code}" in
        200|202) echo "flush ok" ;;
        400|403) echo "WARNING: flush rejected (HTTP ${code}): the bucket does not have flushEnabled. Continuing without flush; documents present in DR but absent from the backup will survive." >&2 ;;
        *)   echo "ERROR: flush returned HTTP ${code} for bucket ${BUCKET}" >&2; exit 1 ;;
      esac
      # Wait for bucket to come back warm.
      for _ in $(seq 1 60); do
        state=$(curl -sk --max-time 10 --retry 2 --retry-delay 3 -u "${COUCHBASE_USERNAME}:${COUCHBASE_PASSWORD}" \
          "https://${HOST}:18091/pools/default/buckets/${BUCKET}" | jq -r '.nodes[0].status // "unknown"')
        [[ "${state}" == "healthy" ]] && break
        sleep 2
      done
    fi

    echo "Restoring repo '${REPO}' (bucket ${BUCKET}) into ${CONNECTION_STRING}..."
    cbbackupmgr info --archive "${ARCHIVE_DIR}" --repo "${REPO}" || true
    cbbackupmgr restore \
      --archive "${ARCHIVE_DIR}" \
      --repo "${REPO}" \
      --cluster "${CONNECTION_STRING}" \
      --username "${COUCHBASE_USERNAME}" \
      --password "${COUCHBASE_PASSWORD}" \
      --include-data "${BUCKET}" \
      --force-updates

    echo "cbbackupmgr restore completed for bucket ${BUCKET}."
    ;;

  capella_api)
    : "${CAPELLA_API_URL:?}" "${CAPELLA_ORG_ID:?}" "${CAPELLA_PROJECT_ID:?}" "${CAPELLA_CLUSTER_ID:?}"
    : "${CAPELLA_API_TOKEN:?CAPELLA_API_TOKEN (TF_VAR_capella_api_token) is required for method capella_api}"

    BASE="${CAPELLA_API_URL}/v4/organizations/${CAPELLA_ORG_ID}/projects/${CAPELLA_PROJECT_ID}/clusters/${CAPELLA_CLUSTER_ID}"
    AUTH=(-H "Authorization: Bearer ${CAPELLA_API_TOKEN}" -H "Content-Type: application/json" -H "Accept: application/json")

    echo "Submitting Capella restore for bucket '${BUCKET}'..."
    BODY=$(mktemp)
    CODE=$(curl -sS -o "${BODY}" -w '%{http_code}' -X POST "${AUTH[@]}" \
      "${BASE}/backups/restore" \
      -d "$(jq -nc --arg b "${BUCKET}" '{sourceClusterId: env.CAPELLA_CLUSTER_ID, targetClusterId: env.CAPELLA_CLUSTER_ID, bucketName: $b, services: ["data"], autoRemoveCollections: false}')")

    if [[ "${CODE}" != "200" && "${CODE}" != "201" && "${CODE}" != "202" ]]; then
      echo "ERROR: Capella restore submission for bucket '${BUCKET}' returned HTTP ${CODE}." >&2
      cat "${BODY}" >&2
      rm -f "${BODY}"
      exit 1
    fi

    ID=$(jq -r '.id // .restoreId // empty' <"${BODY}")
    rm -f "${BODY}"
    if [[ -z "${ID}" ]]; then
      echo "WARNING: no restore job id returned for bucket ${BUCKET}; verify manually."
      exit 0
    fi

    echo "Waiting for restore ${ID} (bucket ${BUCKET})..."
    DEADLINE=$((SECONDS + 7200))
    while [[ ${SECONDS} -lt ${DEADLINE} ]]; do
      # --max-time, or a hung connection blocks forever and DEADLINE above is
      # never re-evaluated; "|| echo unknown" so a blip means "look again"
      # rather than aborting a restore that is actually running.
      STATE=$(curl -sS --max-time 60 --retry 3 --retry-delay 5 "${AUTH[@]}" \
        "${BASE}/backups/restore/${ID}" 2>/dev/null | jq -r '.status // .state // "unknown"' || echo unknown)
      case "${STATE}" in
        complete|completed|succeeded|Complete|Succeeded)
          echo "Capella restore completed for bucket ${BUCKET}: ${STATE}"
          exit 0
          ;;
        failed|Failed|error|Error)
          echo "ERROR: Capella restore ${ID} for bucket ${BUCKET} ended in state '${STATE}'." >&2
          exit 1
          ;;
      esac
      sleep 20
    done
    echo "ERROR: Capella restore ${ID} for bucket ${BUCKET} did not reach a terminal state within 2h." >&2
    exit 1
    ;;

  *)
    echo "ERROR: unsupported method '${METHOD}' for bucket ${BUCKET} in capella_restore.sh." >&2
    exit 1
    ;;
esac
