#!/usr/bin/env bash
# Restore Consul KV into the DR Consul cluster, then assert keys are present.
#
# The export is downloaded with the prod backup reader, but every kubectl call
# runs as the bastion's own DR identity: gke-gcloud-auth-plugin mints a token
# for whatever gcloud credential is active and caches it in
# ~/.kube/gke_gcloud_auth_plugin_cache, so exporting the backup credential for
# the whole script poisons that cache for every later kubectl on this host.
#
# `consul kv import` parses the whole file in the consul container, which is
# capped at 100Mi; a 16MiB export OOM-killed the server mid-import. The file is
# split into CHUNK_KEYS-key pieces so peak memory stays small.
set -euo pipefail

: "${NAMESPACE:?}" "${BACKUP_URI:?}"

POD="consul-server-0"
CHUNK_KEYS="${CONSUL_IMPORT_CHUNK_KEYS:-500}"
WORKDIR=$(mktemp -d)
trap 'rm -rf "${WORKDIR}"' EXIT

echo "Downloading ${BACKUP_URI}..."
if [[ -n "${BACKUP_CREDENTIALS_FILE:-}" ]]; then
  CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE="${BACKUP_CREDENTIALS_FILE}" \
    gcloud storage cp "${BACKUP_URI}" "${WORKDIR}/consul-backup"
else
  gcloud storage cp "${BACKUP_URI}" "${WORKDIR}/consul-backup"
fi

FILENAME=$(basename "${BACKUP_URI}")

if [[ "${FILENAME}" == *.snap ]]; then
  kubectl -n "${NAMESPACE}" cp "${WORKDIR}/consul-backup" "${POD}:/tmp/${FILENAME}"
  echo "Restoring Consul snapshot..."
  kubectl -n "${NAMESPACE}" exec "${POD}" -- consul snapshot restore "/tmp/${FILENAME}"
else
  # KV JSON export produced by `consul kv export`.
  TOTAL=$(jq 'length' "${WORKDIR}/consul-backup")
  echo "Importing Consul KV export: ${TOTAL} keys in chunks of ${CHUNK_KEYS}..."
  CHUNKS=$(( (TOTAL + CHUNK_KEYS - 1) / CHUNK_KEYS ))
  for ((i = 0; i < CHUNKS; i++)); do
    OFFSET=$((i * CHUNK_KEYS))
    jq -c --argjson o "${OFFSET}" --argjson n "${CHUNK_KEYS}" '.[$o:$o+$n]' \
      "${WORKDIR}/consul-backup" > "${WORKDIR}/chunk.json"
    kubectl -n "${NAMESPACE}" cp "${WORKDIR}/chunk.json" "${POD}:/tmp/consul-chunk.json"
    kubectl -n "${NAMESPACE}" exec "${POD}" -- \
      sh -c 'consul kv import @/tmp/consul-chunk.json >/dev/null && rm -f /tmp/consul-chunk.json'
    echo "  chunk $((i + 1))/${CHUNKS} imported (keys ${OFFSET}..$((OFFSET + CHUNK_KEYS - 1)))"
  done
fi

# -keys lists key names only. `consul kv get -recurse /` streams every value
# through the consul container and OOM-kills it once the KV holds the restored
# vault/ tree (~16MiB against a 100Mi limit).
KEY_COUNT=$(kubectl -n "${NAMESPACE}" exec "${POD}" -- \
  sh -c 'consul kv get -keys -separator= / 2>/dev/null | wc -l' | tr -d '[:space:]')

if [[ -z "${KEY_COUNT}" || "${KEY_COUNT}" -eq 0 ]]; then
  echo "ERROR: Consul restore left zero KV keys." >&2
  exit 1
fi

echo "Consul restore completed: ${KEY_COUNT} KV keys present."
