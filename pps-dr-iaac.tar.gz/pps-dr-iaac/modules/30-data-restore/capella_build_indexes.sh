#!/usr/bin/env bash
# Build every deferred GSI index on the DR Capella cluster and wait until the
# builds finish.
#
# cbbackupmgr restores index definitions with defer_build set, which is the
# right default - building while documents are still loading would be wasted
# work - but it means a restored cluster reaches the end of Phase 3 with
# definitions and no usable indexes. Nothing builds them afterwards unless
# something does it here.
#
# This is not a tuning detail. Measured on the DR rebuild of 2026-10-12: 18 of
# the 47 indexes on bucket oidcv2 were left deferred, and jans-auth could not
# start at all. io.jans.orm's CouchbaseConnectionProvider.isConnected() queries
# the bucket, the query had no index to use, so init() failed and
# openWithWaitImpl() retried every 5 seconds for 22 minutes before giving up
# with "Failed to create Couchbase connection pool!". The liveness probe killed
# the container long before that, so it crash-looped forever and took the five
# Applications that wait on it down with it. After BUILD INDEX the same pod
# connected on its first attempt and logged "Configuration loaded
# successfully." The whole build took 45 seconds.
set -euo pipefail

: "${QUERY_HOST:?}" "${COUCHBASE_USERNAME:?}" "${COUCHBASE_PASSWORD:?}"

QUERY_URL="https://${QUERY_HOST}:18093/query/service"
BUCKETS="${BUCKETS:-}"
WAIT_SECONDS="${WAIT_SECONDS:-1800}"
POLL_SECONDS="${POLL_SECONDS:-15}"

# Capella serves a certificate from its own CA, which is not in the bastion's
# trust store: without this curl fails with "Peer's Certificate issuer is not
# recognized" and every statement below would be reported as a failure.
CA_ARGS=()
if [[ -n "${COUCHBASE_CA_CERT_FILE:-}" ]]; then
  if [[ ! -s "${COUCHBASE_CA_CERT_FILE}" ]]; then
    echo "ERROR: COUCHBASE_CA_CERT_FILE='${COUCHBASE_CA_CERT_FILE}' is missing or empty." >&2
    exit 1
  fi
  CA_ARGS=(--cacert "${COUCHBASE_CA_CERT_FILE}")
else
  # The credentials still travel over TLS, but the peer is unverified. Set
  # couchbase_ca_cert_file to the cluster's CA to close this.
  echo "WARNING: no couchbase_ca_cert_file set; the Capella certificate will not be verified." >&2
  CA_ARGS=(--insecure)
fi

# Retried, because this is called roughly 120 times across a 30-minute poll and
# every call is an assignment under `set -euo pipefail`: one 503 from the query
# service, one TLS reset or one timeout would abort the apply in the middle of
# the step whose absence crash-loops jans-auth.
run_query() {
  curl -sS --max-time 300 --retry 3 --retry-delay 5 "${CA_ARGS[@]}" \
    -u "${COUCHBASE_USERNAME}:${COUCHBASE_PASSWORD}" \
    "${QUERY_URL}" --data-urlencode "statement=$1"
}

# A bucket with no scope/collection split reports its indexes with bucket_id
# missing and the bucket in keyspace_id; one with collections reports
# bucket_id.scope_id.keyspace_id. Both shapes are handled.
# "ERR" rather than a number when the query did not succeed. jq's `//`
# substitutes its default whenever .results is absent, so an error body
# ({"errors":[...]}) reads as 0 - and curl without -f exits 0 on 401/503 too.
# One blip would otherwise print "All indexes online" while the builds were
# still running, handing the next phase the state this step exists to prevent.
count_in_state() {
  local resp
  resp=$(run_query "SELECT RAW COUNT(*) FROM system:indexes WHERE ${BUCKET_PREDICATE} AND $1")
  if [[ "$(printf '%s' "${resp}" | jq -r '.status // "unknown"' 2>/dev/null)" != "success" ]]; then
    echo "ERR"
    return 0
  fi
  printf '%s' "${resp}" | jq -r '.results[0] // 0'
}

deferred_count() { count_in_state "state IN ['deferred', 'pending', 'scheduled for creation']"; }
building_count() { count_in_state "state = 'building'"; }

# Scope the counts to the buckets this step manages. Counting cluster-wide
# meant one deferred index anywhere else - another bucket, a leftover, someone
# testing - could never reach zero, so the poll burned its whole WAIT_SECONDS
# and then failed a step that had done its job perfectly.
BUCKET_PREDICATE="false"
for _b in ${BUCKETS}; do
  BUCKET_PREDICATE="${BUCKET_PREDICATE} OR keyspace_id = '${_b}' OR bucket_id = '${_b}'"
done
BUCKET_PREDICATE="(${BUCKET_PREDICATE})"
unset _b

if [[ -z "${BUCKETS}" ]]; then
  echo "No Capella buckets configured; nothing to build."
  exit 0
fi

BEFORE=$(deferred_count)
echo "Deferred indexes before: ${BEFORE}"

BUILT=0
FAILED=0
for bucket in ${BUCKETS}; do
  # Default-collection indexes.
  names=$(run_query "SELECT RAW name FROM system:indexes WHERE keyspace_id = '${bucket}' AND bucket_id IS MISSING AND state = 'deferred'" \
    | jq -r '[.results[] | "`" + . + "`"] | join(",")')
  if [[ -n "${names}" ]]; then
    echo "  BUILD INDEX ON \`${bucket}\` ($(run_query "SELECT RAW COUNT(*) FROM system:indexes WHERE keyspace_id = '${bucket}' AND bucket_id IS MISSING AND state = 'deferred'" | jq -r '.results[0]') index(es))"
    result=$(run_query "BUILD INDEX ON \`${bucket}\`(${names})")
    status=$(echo "${result}" | jq -r '.status // "unknown"')
    if [[ "${status}" != "success" ]]; then
      echo "  FAILED: $(echo "${result}" | jq -c '.errors' | cut -c1-300)" >&2
      FAILED=$((FAILED + 1))
    else
      BUILT=$((BUILT + 1))
    fi
  fi

  # Indexes inside named scopes and collections, one BUILD per keyspace.
  # ${arr[@]} on an empty array is an unbound variable under `set -u`, which is
  # how this failed the whole apply at 11:34 on 2026-10-12 with
  # "keyspaces[@]: unbound variable" - on a cluster where nothing was deferred
  # and there was simply nothing to do.
  keyspaces=()
  mapfile -t keyspaces < <(run_query "SELECT DISTINCT RAW CONCAT(scope_id, '.', keyspace_id) FROM system:indexes WHERE bucket_id = '${bucket}' AND state = 'deferred'" | jq -r '.results[]?')
  for ks in ${keyspaces[@]+"${keyspaces[@]}"}; do
    [[ -z "${ks}" ]] && continue
    scope="${ks%%.*}"
    coll="${ks#*.}"
    names=$(run_query "SELECT RAW name FROM system:indexes WHERE bucket_id = '${bucket}' AND scope_id = '${scope}' AND keyspace_id = '${coll}' AND state = 'deferred'" \
      | jq -r '[.results[] | "`" + . + "`"] | join(",")')
    [[ -z "${names}" ]] && continue
    echo "  BUILD INDEX ON \`${bucket}\`.\`${scope}\`.\`${coll}\`"
    result=$(run_query "BUILD INDEX ON \`${bucket}\`.\`${scope}\`.\`${coll}\`(${names})")
    status=$(echo "${result}" | jq -r '.status // "unknown"')
    if [[ "${status}" != "success" ]]; then
      echo "  FAILED: $(echo "${result}" | jq -c '.errors' | cut -c1-300)" >&2
      FAILED=$((FAILED + 1))
    else
      BUILT=$((BUILT + 1))
    fi
  done
done

if [[ "${FAILED}" -gt 0 ]]; then
  echo "ERROR: ${FAILED} BUILD INDEX statement(s) failed; indexes remain deferred." >&2
  exit 1
fi

if [[ "${BUILT}" -eq 0 ]]; then
  # BUILT counts successes only, so without this a run where every BUILD failed
  # - or where the deferred indexes sit in a shape the queries above do not
  # cover - printed "every index is already built", skipped the wait and
  # exited 0.
  if [[ "${BEFORE}" != "0" && "${BEFORE}" != "ERR" ]]; then
    echo "ERROR: ${BEFORE} index(es) are deferred but none were built; check the bucket/scope shape." >&2
    exit 1
  fi
  echo "Nothing was deferred; every index is already built."
  exit 0
fi

# BUILD INDEX returns as soon as the build is scheduled, so the wait is the
# point of this step: returning early hands the next phase a cluster whose
# indexes are still coming up, which is the state that broke jans-auth.
echo "Waiting up to ${WAIT_SECONDS}s for the builds to finish..."
waited=0
while [[ "${waited}" -lt "${WAIT_SECONDS}" ]]; do
  # A failed read here is a reason to look again, not to fail the phase.
  d=$(deferred_count || echo "")
  b=$(building_count || echo "")
  if [[ -z "${d}" || -z "${b}" ]]; then
    echo "  [${waited}s] could not read index state; retrying"
    sleep "${POLL_SECONDS}"
    waited=$((waited + POLL_SECONDS))
    continue
  fi
  if [[ "${d}" == "0" && "${b}" == "0" ]]; then
    echo "All indexes online after ${waited}s."
    exit 0
  fi
  echo "  [${waited}s] deferred=${d} building=${b}"
  sleep "${POLL_SECONDS}"
  waited=$((waited + POLL_SECONDS))
done

echo "ERROR: indexes were still building after ${WAIT_SECONDS}s (deferred=$(deferred_count) building=$(building_count))." >&2
echo "jans-auth cannot start until they are online; raise couchbase_index_build_timeout_seconds or check the index service." >&2
exit 1
