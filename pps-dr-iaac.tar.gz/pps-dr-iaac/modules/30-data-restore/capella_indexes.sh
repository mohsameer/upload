#!/usr/bin/env bash
# Replay GSI index definitions (e.g. prod-index-definitions.sql) onto the DR
# Capella cluster through the query service REST API, from the bastion.
#
# The prod file pins every index to prod node names ("nodes":[...]) and lists
# some statements twice, so each statement is de-duplicated and its "nodes"
# clause dropped. Indexes are created deferred and then built per keyspace.
# An index that already exists is reported and skipped, so a re-run is safe.
set -euo pipefail

: "${INDEX_URI:?}" "${QUERY_HOST:?}" "${COUCHBASE_USERNAME:?}" "${COUCHBASE_PASSWORD:?}"

QUERY_URL="https://${QUERY_HOST}:18093/query/service"
WORKDIR=$(mktemp -d)
trap 'rm -rf "${WORKDIR}"' EXIT

gcloud storage cp "${INDEX_URI}" "${WORKDIR}/indexes.sql" >/dev/null

# Capella serves a certificate from its own CA, which is not in the bastion's
# trust store: without this curl fails with "Peer's Certificate issuer is not
# recognized" and every statement below is reported as a failure.
CA_ARGS=()
if [[ -n "${COUCHBASE_CA_CERT_FILE:-}" ]]; then
  if [[ ! -s "${COUCHBASE_CA_CERT_FILE}" ]]; then
    echo "ERROR: COUCHBASE_CA_CERT_FILE='${COUCHBASE_CA_CERT_FILE}' is missing or empty." >&2
    exit 1
  fi
  CA_ARGS=(--cacert "${COUCHBASE_CA_CERT_FILE}")
else
  echo "WARNING: no couchbase_ca_cert_file set; the Capella certificate will not be verified." >&2
  CA_ARGS=(--insecure)
fi

run_query() {
  curl -sS --max-time 300 "${CA_ARGS[@]}" \
    -u "${COUCHBASE_USERNAME}:${COUCHBASE_PASSWORD}" \
    "${QUERY_URL}" --data-urlencode "statement=$1"
}

# One statement per line in the export; drop comments, blanks and duplicates,
# strip the node pinning, force defer_build so creation is cheap.
grep -E '^[[:space:]]*CREATE[[:space:]]' "${WORKDIR}/indexes.sql" \
  | sed -E 's/,?[[:space:]]*"nodes"[[:space:]]*:[[:space:]]*\[[^]]*\]//' \
  | sed -E 's/\{[[:space:]]*,/{/' \
  | awk '!seen[$0]++' >"${WORKDIR}/statements.sql"

TOTAL=$(wc -l <"${WORKDIR}/statements.sql" | tr -d '[:space:]')
echo "Replaying ${TOTAL} unique index statements against ${QUERY_HOST}..."

CREATED=0 EXISTING=0 FAILED=0
while IFS= read -r stmt; do
  stmt="${stmt%;}"
  result=$(run_query "${stmt}")
  status=$(echo "${result}" | jq -r '.status // "unknown"')
  if [[ "${status}" == "success" ]]; then
    CREATED=$((CREATED + 1))
  elif echo "${result}" | jq -r '.errors[]?.msg' | grep -qi 'already exist'; then
    EXISTING=$((EXISTING + 1))
  else
    FAILED=$((FAILED + 1))
    echo "FAILED: ${stmt:0:160}" >&2
    echo "  $(echo "${result}" | jq -c '.errors' | cut -c1-300)" >&2
  fi
done <"${WORKDIR}/statements.sql"

echo "Index statements: ${CREATED} created, ${EXISTING} already present, ${FAILED} failed."

# Build every deferred index, keyspace by keyspace.
KEYSPACES=$(run_query "SELECT DISTINCT RAW CONCAT(i.bucket_id, '.', i.scope_id, '.', i.keyspace_id) FROM system:indexes AS i WHERE i.state = 'deferred' AND i.bucket_id IS NOT MISSING UNION SELECT DISTINCT RAW CONCAT('default:', i.keyspace_id) FROM system:indexes AS i WHERE i.state = 'deferred' AND i.bucket_id IS MISSING" \
  | jq -r '.results[]?')
for ks in ${KEYSPACES}; do
  if [[ "${ks}" == default:* ]]; then
    bucket="${ks#default:}"
    names=$(run_query "SELECT RAW name FROM system:indexes WHERE keyspace_id = '${bucket}' AND bucket_id IS MISSING AND state = 'deferred'" | jq -r '[.results[] | "`" + . + "`"] | join(",")')
    target="\`${bucket}\`"
  else
    IFS=. read -r bucket scope coll <<<"${ks}"
    names=$(run_query "SELECT RAW name FROM system:indexes WHERE bucket_id = '${bucket}' AND scope_id = '${scope}' AND keyspace_id = '${coll}' AND state = 'deferred'" | jq -r '[.results[] | "`" + . + "`"] | join(",")')
    target="\`${bucket}\`.\`${scope}\`.\`${coll}\`"
  fi
  [[ -z "${names}" ]] && continue
  echo "BUILD INDEX ON ${target}(${names})"
  run_query "BUILD INDEX ON ${target}(${names})" | jq -r '.status'
done

# Index failures do not fail Phase 3 (data is already restored) unless
# INDEX_FAILURES_FATAL=true; they are listed above for follow-up.
if [[ "${FAILED}" -gt 0 ]]; then
  echo "WARNING: ${FAILED} index statements failed (see above)." >&2
  [[ "${INDEX_FAILURES_FATAL:-false}" == "true" ]] && exit 1
fi
echo "Index replay complete; builds run asynchronously on the index service."
