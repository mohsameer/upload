#!/usr/bin/env bash
# Phase 3, step 3 of 3 per database: create the audit partitions the restored
# midPoint needs from here on.
#
# The restore loads the partitioned audit tables (m_audit_event by id,
# m_audit_delta by record_id, 500000 ids per partition) but, with the audit rows
# excluded, leaves the id sequence at its start while the partitions are the
# ones production had - 98,000,000 to 149,000,000 at the time of writing. The
# first audit INSERT then fails with
#   ERROR: no partition of relation "m_audit_event" found for row
#   Partition key of the failing row contains (id) = (84)
# and midPoint's startup import (ObjectImporter) dies on it.
#
# The database carries its own maintenance functions for this:
#   create_future_partitions_for_m_audit_event(n [, size])
#   create_future_partitions_for_m_audit_delta(n [, size])
# Both start at the partition holding MAX(id), so on an empty audit table they
# create partitions from 0 upward, and on a restored one they extend past the
# newest row. They are idempotent, so a retried wave is harmless.
#
# Runs from a short pod in the DR cluster, like the restore itself. It does
# nothing unless this database is listed in FUTURE_PARTITION_DATABASES and
# FUTURE_PARTITIONS is above 0, and does nothing if the functions are absent.
set -euo pipefail

: "${NAMESPACE:?}" "${PG_HOST:?}" "${PG_DATABASE:?}" "${PG_USER:?}" "${PG_PASSWORD:?}" "${CLIENT_IMAGE:?}"

FUTURE_PARTITIONS="${FUTURE_PARTITIONS:-0}"
FUTURE_PARTITION_DATABASES="${FUTURE_PARTITION_DATABASES:-}"
PG_PORT="${PG_PORT:-5432}"
TIMEOUT_SECONDS="${FUTURE_PARTITIONS_TIMEOUT_SECONDS:-600}"
FAILURE_LOG="${FAILURE_LOG:-/tmp/dr-phase-failures.log}"

note_failure() {
  printf '[%s] postgres_future_partitions %s: %s\n' "$(date -u +%H:%M:%S)" "${PG_DATABASE}" "$*" >>"${FAILURE_LOG}" 2>/dev/null || true
  echo "ERROR: $*" >&2
}

if [[ "${FUTURE_PARTITIONS}" -le 0 ]] || [[ " ${FUTURE_PARTITION_DATABASES} " != *" ${PG_DATABASE} "* ]]; then
  echo "postgres_future_partitions ${PG_DATABASE}: not configured for this database; skipping."
  exit 0
fi

POD="pg-partitions-$(printf '%s' "${PG_DATABASE}" | tr -c 'a-z0-9' '-' | sed 's/-*$//' | cut -c1-30)"
CRED_SECRET="${POD}-cred"
RENDER_DIR=$(mktemp -d)
cleanup_k8s() {
  kubectl -n "${NAMESPACE}" delete pod "${POD}" --ignore-not-found --wait=false >/dev/null 2>&1 || true
  kubectl -n "${NAMESPACE}" delete secret "${CRED_SECRET}" --ignore-not-found >/dev/null 2>&1 || true
  rm -rf "${RENDER_DIR}"
}
trap cleanup_k8s EXIT

kubectl -n "${NAMESPACE}" delete pod "${POD}" --ignore-not-found >/dev/null 2>&1 || true
kubectl -n "${NAMESPACE}" create secret generic "${CRED_SECRET}" \
  --from-literal=PGPASSWORD="${PG_PASSWORD}" --dry-run=client -o yaml >"${RENDER_DIR}/secret.yaml"
kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/secret.yaml" >/dev/null

cat >"${RENDER_DIR}/pod.yaml" <<YAML
apiVersion: v1
kind: Pod
metadata:
  name: ${POD}
  labels:
    app.kubernetes.io/name: pg-partitions
    pps-dr/phase: "3"
spec:
  restartPolicy: Never
  activeDeadlineSeconds: ${TIMEOUT_SECONDS}
  containers:
    - name: psql
      image: ${CLIENT_IMAGE}
      env:
        - { name: PGHOST, value: "${PG_HOST}" }
        - { name: PGPORT, value: "${PG_PORT}" }
        - { name: PGUSER, value: "${PG_USER}" }
        - { name: PGDATABASE, value: "${PG_DATABASE}" }
        # Quoted: unquoted N is a YAML 1.1 boolean, and the API server then
        # rejects the pod with "cannot unmarshal bool into EnvVar.name".
        - { name: "N", value: "${FUTURE_PARTITIONS}" }
        - name: PGPASSWORD
          valueFrom:
            secretKeyRef: { name: ${CRED_SECRET}, key: PGPASSWORD }
      command: ["/bin/bash", "-c"]
      args:
        - |
          set -uo pipefail
          have=\$(psql -tAc "SELECT count(*) FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace WHERE n.nspname = 'public' AND p.proname IN ('create_future_partitions_for_m_audit_event','create_future_partitions_for_m_audit_delta')") \\
            || { echo "ERROR: cannot query \${PGDATABASE}" >&2; exit 1; }
          if [ "\${have}" != "2" ]; then
            echo "the create_future_partitions_for_m_audit_* functions are not in \${PGDATABASE} (found \${have} of 2); nothing to do"
            exit 0
          fi
          before=\$(psql -tAc "SELECT count(*) FROM pg_inherits WHERE inhparent = 'public.m_audit_event'::regclass")
          psql -v ON_ERROR_STOP=1 \\
            -c "SELECT public.create_future_partitions_for_m_audit_event(\${N})" \\
            -c "SELECT public.create_future_partitions_for_m_audit_delta(\${N})" >/dev/null \\
            || { echo "ERROR: creating the partitions failed" >&2; exit 1; }
          after=\$(psql -tAc "SELECT count(*) FROM pg_inherits WHERE inhparent = 'public.m_audit_event'::regclass")
          next=\$(psql -tAc "SELECT last_value FROM m_audit_event_id_seq")
          # Bounds are the two integers in "FOR VALUES FROM ('a') TO ('b')".
          covered=\$(psql -tA -v next="\${next}" <<'SQL'
          SELECT count(*)
            FROM pg_inherits i
            JOIN pg_class c ON c.oid = i.inhrelid
            CROSS JOIN LATERAL (SELECT array_agg(m.a[1]::bigint) AS b
                                  FROM regexp_matches(pg_get_expr(c.relpartbound, c.oid), '\d+', 'g') AS m(a)) x
           WHERE i.inhparent = 'public.m_audit_event'::regclass
             AND x.b[1] <= :next AND x.b[2] > :next;
          SQL
          )
          echo "m_audit_event partitions: \${before} -> \${after}; current id \${next} is covered by \${covered} partition(s)"
          [ "\${covered}" = "1" ] || { echo "ERROR: the current audit id \${next} still has no partition" >&2; exit 1; }
YAML
kubectl -n "${NAMESPACE}" apply -f "${RENDER_DIR}/pod.yaml" >/dev/null
echo "postgres_future_partitions ${PG_DATABASE}: creating ${FUTURE_PARTITIONS} partitions ahead (pod ${POD})"

deadline=$(( $(date -u +%s) + TIMEOUT_SECONDS ))
phase=""
while :; do
  phase=$(kubectl -n "${NAMESPACE}" get pod "${POD}" -o jsonpath='{.status.phase}' 2>/dev/null || true)
  [[ "${phase}" == "Succeeded" || "${phase}" == "Failed" ]] && break
  if [[ "$(date -u +%s)" -ge "${deadline}" ]]; then
    kubectl -n "${NAMESPACE}" logs "${POD}" --tail=20 >&2 || true
    note_failure "pod did not finish within ${TIMEOUT_SECONDS}s"
    exit 1
  fi
  sleep 3
done

kubectl -n "${NAMESPACE}" logs "${POD}" | sed "s/^/  [${PG_DATABASE}] /"
if [[ "${phase}" != "Succeeded" ]]; then
  note_failure "partition pod ended ${phase}"
  exit 1
fi
echo "postgres_future_partitions ${PG_DATABASE}: done"
