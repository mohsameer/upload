#!/usr/bin/env bash
# Apply the application config that no Argo CD Application and no backup carries.
#
# In the source environments these are applied out of band, so they are absent
# from the restored Argo CD bundle and from every backup object. Without them
# the oidcv2 configurator Job never starts (it mounts insert-cert,
# couchbase-patch and couchbase-setup-patch) and the services miss the global
# environment ConfigMap.
#
# Three kinds of input:
#   manifests/   verbatim ConfigMaps - scripts, patches and log templates with
#                nothing environment-specific in them, so they live in git.
#   rendered/    ConfigMaps Terraform templated with this site's values.
#   SECRET_DIR   secret material, which never goes in git. Seeded on the bastion
#                from the source environment: Jans encrypts what is in the
#                restored Couchbase bucket with these keys, so they have to be
#                the source site's, not freshly generated. In practice this is
#                just the cn Secret - oidcv2-cb-pass and oidcv2-cb-crt are
#                already created with this site's values, so seeding them would
#                overwrite correct state with the source site's.
set -euo pipefail

: "${AUTHN_NAMESPACE:?}" "${GLOBAL_CONFIG_NAMESPACES:?}" "${MANIFEST_DIR:?}" "${RENDERED_DIR:?}"

SECRET_DIR="${SECRET_DIR:-}"
COUCHBASE_PASSWORD="${COUCHBASE_PASSWORD:-}"

apply_ns() { kubectl -n "$1" apply -f "$2" >/dev/null; }

# --- verbatim ConfigMaps, authn only ---------------------------------------
for f in "${MANIFEST_DIR}"/*.yaml; do
  [[ -e "${f}" ]] || continue
  apply_ns "${AUTHN_NAMESPACE}" "${f}"
  echo "authn/$(basename "${f}" .yaml) applied"
done

# --- templated ConfigMaps ---------------------------------------------------
for f in "${RENDERED_DIR}"/authn-*.yaml; do
  [[ -e "${f}" ]] || continue
  apply_ns "${AUTHN_NAMESPACE}" "${f}"
  echo "authn/$(basename "${f}" .yaml | sed 's/^authn-//') applied"
done

# icrypto-global-config goes to every application namespace
for ns in ${GLOBAL_CONFIG_NAMESPACES}; do
  apply_ns "${ns}" "${RENDERED_DIR}/icrypto-global-config.yaml"
  echo "${ns}/icrypto-global-config applied"
done

# --- secret material -------------------------------------------------------
if [[ -z "${SECRET_DIR}" ]]; then
  echo "SECRET_DIR not set; skipping secret material. oidcv2 cannot read the"
  echo "restored Couchbase bucket until secret/cn is seeded from the source site." >&2
  exit 0
fi
if [[ ! -d "${SECRET_DIR}" ]]; then
  echo "ERROR: SECRET_DIR ${SECRET_DIR} does not exist on this host." >&2
  exit 1
fi

for f in "${SECRET_DIR}"/*.yaml; do
  [[ -e "${f}" ]] || continue
  apply_ns "${AUTHN_NAMESPACE}" "${f}"
  echo "authn/$(basename "${f}" .yaml) applied from SECRET_DIR"
done

# The seeded Secrets carry the source site's Couchbase credentials alongside
# their other content. The Couchbase connection is the one thing that genuinely
# differs between sites, so those keys are retargeted while everything else is
# left exactly as it was - cn's crypto in particular, without which the
# restored bucket cannot be decrypted.
if [[ -n "${COUCHBASE_PASSWORD}" ]]; then
  enc=$(printf '%s' "${COUCHBASE_PASSWORD}" | base64 | tr -d '\n')
  for secret in cn oidcv2-cb-pass; do
    kubectl -n "${AUTHN_NAMESPACE}" get secret "${secret}" >/dev/null 2>&1 || continue
    kubectl -n "${AUTHN_NAMESPACE}" patch secret "${secret}" --type merge \
      -p "{\"data\":{\"couchbase_password\":\"${enc}\",\"couchbase_superuser_password\":\"${enc}\"}}" >/dev/null
    echo "authn/${secret}: Couchbase credentials retargeted to this site"
  done
fi

echo "application config in place."
