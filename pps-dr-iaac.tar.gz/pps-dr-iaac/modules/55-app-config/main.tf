# Phase 5b - application config the restore cannot carry.
#
# The oidcv2 configurator mounts insert-cert, couchbase-patch and
# couchbase-setup-patch, and the services read icrypto-global-config. None of
# these are in any Argo CD Application or backup object, because the source
# environments apply them out of band - so a DR site built only from the
# backups comes up without them and authn never starts.

locals {
  rendered_dir = "${path.module}/.rendered"

  rendered = merge(
    {
      "icrypto-global-config.yaml" = templatefile("${path.module}/templates/icrypto-global-config.yaml.tftpl", {
        environment = var.environment_name
        icrypto_env = var.icrypto_env
      })
    },
    var.oidcv2_enabled ? {
      "authn-jans-couchbase.yaml" = templatefile("${path.module}/templates/jans-couchbase.yaml.tftpl", {
        couchbase_servers = var.capella_connection_string
      })
      # Was a captured manifest with the version frozen into it. The captured
      # value (1.0.0.90) was older than the data this site restores, and the
      # mismatch stopped the auth server dead - see
      # var.icrypto_oidc_filter_version.
      "authn-icrypto-patch.yaml" = templatefile("${path.module}/templates/icrypto-patch.yaml.tftpl", {
        icrypto_oidc_filter_version = var.icrypto_oidc_filter_version
      })
      "authn-cn.yaml" = templatefile("${path.module}/templates/cn.yaml.tftpl", {
        oidc_hostname = var.oidc_hostname
      })
    } : {}
  )
}

resource "local_file" "rendered" {
  for_each = local.rendered

  filename        = "${local.rendered_dir}/${each.key}"
  content         = each.value
  file_permission = "0600"
}

resource "null_resource" "app_config" {
  triggers = {
    rendered   = sha256(jsonencode(local.rendered))
    manifests  = sha256(join("", [for f in fileset("${path.module}/manifests", "*.yaml") : filesha256("${path.module}/manifests/${f}")]))
    namespaces = join(",", var.global_config_namespaces)
    secret_dir = var.app_config_secret_dir
    script     = filemd5("${path.module}/apply.sh")
  }

  provisioner "local-exec" {
    command     = "./apply.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG               = pathexpand(var.kubeconfig_path)
      AUTHN_NAMESPACE          = var.authn_namespace
      GLOBAL_CONFIG_NAMESPACES = join(" ", var.global_config_namespaces)
      # apply.sh runs with working_dir = path.module, so these are relative to
      # the module, not the root. ${path.module}/... would resolve twice.
      MANIFEST_DIR       = "manifests"
      RENDERED_DIR       = ".rendered"
      SECRET_DIR         = pathexpand(var.app_config_secret_dir)
      COUCHBASE_PASSWORD = var.couchbase_password
    }
  }

  depends_on = [local_file.rendered]
}
