variable "authn_namespace" {
  type = string
}

variable "global_config_namespaces" {
  type = list(string)
}

variable "environment_name" {
  type = string
}

variable "icrypto_env" {
  type = string
}

variable "oidcv2_enabled" {
  type = bool
}

variable "oidc_hostname" {
  type = string
}

variable "capella_connection_string" {
  type = string
}

variable "couchbase_password" {
  type      = string
  sensitive = true
}

variable "app_config_secret_dir" {
  type = string
}

variable "kubeconfig_path" {
  type = string
}

variable "icrypto_oidc_filter_version" {
  type        = string
  description = "Version of icrypto-oidc-filter the auth server downloads, written into the icrypto-patch ConfigMap."
}
