#!/usr/bin/env bash
# Destroy-time teardown of the Kubernetes objects that own this site's GCP
# load balancer resources.
#
# WHY: `tofu destroy` of the DR site fails in Phase 1 with
#   Error: Error waiting for deleting GKE cluster: Failed to delete cluster
# GKE refuses to delete a cluster while load balancer resources still
# reference it, and until now nothing deleted the Ingress / LoadBalancer
# Service objects whose controllers own those resources. The hand cleanup that
# unblocked the destroy found five generations of orphans accumulated from
# earlier destroys: 20 network endpoint groups, 2 regional backend services,
# 2 forwarding rules (k8s2-fr-/k8s2-fs- prefixed), 1 URL map, 1 target proxy,
# 1 firewall rule (k8s-fw-l7--*) and 3 health checks.
#
# The gate is the Kubernetes object leaving the API server, not the delete
# call returning. The GKE ingress controller holds the finalizer
# networking.gke.io/ingress-finalizer-V2 on an Ingress, and
# kube-controller-manager holds service.kubernetes.io/load-balancer-cleanup on
# a LoadBalancer Service, until the GCP resources are actually deleted - so
# "object gone" is the controller's own statement that it has released them.
# A `kubectl delete` that returns immediately proves nothing.
#
# A destroy must never be blocked by this step: an unreachable cluster, a
# missing namespace, an already-deleted object and an expired deadline are all
# reported and then treated as success. The only thing worse than an orphaned
# forwarding rule is a destroy that cannot run at all.
#
# `set -e` is deliberately absent for the same reason: every command here is
# allowed to fail, and the script's contract is "always exit 0".
set -uo pipefail

NAMESPACE="${NAMESPACE:-}"
INGRESS_NAMES="${INGRESS_NAMES:-}"
SERVICE_NAMESPACES="${SERVICE_NAMESPACES:-${NAMESPACE}}"
# ';'-separated, because a label selector contains commas itself
# (app=x,component=y is one selector, not two).
SERVICE_SELECTORS="${SERVICE_SELECTORS:-}"
TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-900}"
POLL_SECONDS="${POLL_SECONDS:-15}"
PROJECT_ID="${PROJECT_ID:-}"
GCP_NAME_FILTER="${GCP_NAME_FILTER:-}"

log() { echo "ingress-teardown: $*"; }
warn() { echo "ingress-teardown: $*" >&2; }

if ! command -v kubectl >/dev/null 2>&1; then
  warn "kubectl not on PATH - skipping teardown. If this site still has an"
  warn "ingress, the GKE cluster delete in Phase 1 will fail."
  exit 0
fi

# A destroy is also run against a half-built or already-deleted site. Probing
# the API server up front keeps the common "cluster is already gone" case from
# spending the whole timeout on kubectl retries.
if ! kubectl --request-timeout=20s get --raw='/version' >/dev/null 2>&1; then
  log "cluster unreachable - nothing to tear down."
  exit 0
fi

# Captured before anything is deleted: this is the token GKE embeds in the
# names of the resources it creates for this cluster, and it is what makes the
# leftover sweep below specific to this cluster instead of to every k8s
# resource in a shared project.
CLUSTER_UID="${GCP_NAME_FILTER}"
if [[ -z "${CLUSTER_UID}" ]]; then
  CLUSTER_UID=$(kubectl -n kube-system get configmap ingress-uid \
    -o jsonpath='{.data.uid}' 2>/dev/null)
fi

# Emits "<kind>|<namespace>|<name>" for everything still present.
list_targets() {
  local name ns selector
  for name in ${INGRESS_NAMES}; do
    [[ -n "${NAMESPACE}" ]] || continue
    if kubectl -n "${NAMESPACE}" get ingress "${name}" >/dev/null 2>&1; then
      echo "ingress|${NAMESPACE}|${name}"
    fi
  done

  for ns in ${SERVICE_NAMESPACES}; do
    while IFS= read -r selector; do
      while IFS= read -r name; do
        [[ -n "${name}" ]] && echo "service|${ns}|${name}"
      done < <(lb_services "${ns}" "${selector}")
    done < <(selectors)
  done
}

# No selector configured means every LoadBalancer Service in the namespace -
# each one owns a forwarding rule and a firewall rule that pin the cluster.
selectors() {
  if [[ -z "${SERVICE_SELECTORS}" ]]; then
    echo ""
    return
  fi
  printf '%s' "${SERVICE_SELECTORS}" | tr ';' '\n'
}

lb_services() {
  local ns="$1" selector="$2"
  local -a args=(-n "${ns}" get svc)
  [[ -n "${selector}" ]] && args+=(-l "${selector}")
  kubectl "${args[@]}" \
    -o jsonpath='{range .items[?(@.spec.type=="LoadBalancer")]}{.metadata.name}{"\n"}{end}' \
    2>/dev/null
}

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
DELETED=""
REMAINING=()
TIMED_OUT=0

while :; do
  REMAINING=()
  # Deduplicated: two selectors can match the same Service, and deleting it
  # twice in one round would log it twice and count it twice.
  while IFS= read -r target; do
    [[ -n "${target}" ]] && REMAINING+=("${target}")
  done < <(list_targets | awk '!seen[$0]++')

  [[ ${#REMAINING[@]} -eq 0 ]] && break

  # Re-issued every round, not once up front. Phase 7 is destroyed before
  # Phase 6 and Phase 4, so Argo CD is still running and still self-healing
  # while this executes: a Service deleted in round one can be recreated by
  # its Application before the loop ends. Deleting again each round converges
  # anyway. --wait=false so all the controllers release their resources
  # concurrently instead of one LB at a time.
  for target in "${REMAINING[@]}"; do
    IFS='|' read -r kind ns name <<<"${target}"
    if [[ "${DELETED}" != *"|${target}|"* ]]; then
      log "deleting ${kind}/${name} in ${ns}"
      DELETED="${DELETED}|${target}|"
    fi
    kubectl -n "${ns}" delete "${kind}" "${name}" \
      --ignore-not-found --wait=false >/dev/null 2>&1
  done

  if [[ ${SECONDS} -ge ${DEADLINE} ]]; then
    warn "${#REMAINING[@]} object(s) still present after ${TIMEOUT_SECONDS}s:"
    for target in "${REMAINING[@]}"; do warn "  - ${target}"; done
    warn "Their finalizers are still held, so GCP load balancer resources may"
    warn "still reference the cluster and the cluster delete can fail with"
    warn "\"Error waiting for deleting GKE cluster\". Continuing anyway."
    TIMED_OUT=1
    break
  fi

  # The API server can also disappear mid-teardown (a parallel destroy of the
  # cluster itself). That is the goal state, not an error.
  if ! kubectl --request-timeout=20s get --raw='/version' >/dev/null 2>&1; then
    log "cluster became unreachable during teardown - treating as done."
    exit 0
  fi

  sleep "${POLL_SECONDS}"
done

if [[ -z "${DELETED}" ]]; then
  log "no ingress or LoadBalancer service present in ${SERVICE_NAMESPACES}."
elif [[ ${TIMED_OUT} -eq 0 ]]; then
  log "all targeted ingress and LoadBalancer objects are gone (finalizers released)."
fi

# Advisory sweep. The Kubernetes wait above is the real gate; this only
# reports what the controllers left behind, because an orphan that is named
# here is one the operator can delete now instead of discovering it as the
# sixth generation on the next destroy.
if ! command -v gcloud >/dev/null 2>&1 || [[ -z "${PROJECT_ID}" ]]; then
  exit 0
fi
if [[ -z "${CLUSTER_UID}" ]]; then
  log "no cluster uid available (kube-system/ingress-uid) - skipping the"
  log "leftover sweep rather than matching another cluster's resources."
  exit 0
fi

LEFTOVERS=()
for kind in network-endpoint-groups backend-services forwarding-rules \
  target-http-proxies target-https-proxies url-maps health-checks \
  firewall-rules; do
  while IFS= read -r name; do
    [[ -n "${name}" ]] && LEFTOVERS+=("${kind}/${name}")
  done < <(gcloud compute "${kind}" list \
    --project "${PROJECT_ID}" \
    --filter="name~${CLUSTER_UID}" \
    --format='value(name)' 2>/dev/null)
done

if [[ ${#LEFTOVERS[@]} -eq 0 ]]; then
  log "no GCP load balancer resource left for cluster uid ${CLUSTER_UID}."
  exit 0
fi

warn "${#LEFTOVERS[@]} GCP resource(s) still carry cluster uid ${CLUSTER_UID}:"
for name in "${LEFTOVERS[@]}"; do warn "  - ${name}"; done
warn "Deletion is asynchronous, so some of these may still be draining. If the"
warn "GKE cluster delete then fails, delete them in this order - forwarding"
warn "rules, proxies, URL maps, backend services, NEGs, health checks,"
warn "firewall rules - and re-run the destroy."
exit 0
