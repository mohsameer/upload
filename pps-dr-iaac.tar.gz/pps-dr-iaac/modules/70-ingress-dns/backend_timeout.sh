#!/usr/bin/env bash
# Phase 7 - raise the GCLB backend request timeout for the ingress backends.
#
# A GKE ingress backend service defaults to 30s, and the DR site is slower than
# production on any path that reaches a resource only production can see: a
# midPoint user ADD fans out to trueLDAP, IAA and Sparkle, and on DR those
# connectors sit in connect timeouts. The caller then gets a GCLB 502 with
# request_time exactly 30.001 - a timeout, not a failure of the service - which
# makes every such test unreadable.
#
# The timeout belongs to the backend service, which GKE derives from the
# Service, so one BackendConfig per Service covers both the external (global)
# and internal (regional) ingress at once. Setting it with gcloud instead would
# be undone whenever ingress-gce next reconciles the backend.
#
# The Services are owned by Argo CD applications with selfHeal, so the
# annotation is a diff Argo would revert. Keep an ignoreDifferences rule for
# the annotation (see argocd_ignore_differences) alongside this.
set -euo pipefail

: "${NAMESPACE:?}" "${TIMEOUT_SECONDS:?}" "${SERVICES:?}" "${CONFIG_NAME:?}"

kubectl -n "${NAMESPACE}" apply -f - >/dev/null <<YAML
apiVersion: cloud.google.com/v1
kind: BackendConfig
metadata:
  name: ${CONFIG_NAME}
spec:
  timeoutSec: ${TIMEOUT_SECONDS}
YAML

for svc in ${SERVICES}; do
  if ! kubectl -n "${NAMESPACE}" get service "${svc}" >/dev/null 2>&1; then
    echo "service/${svc}: absent, skipping" >&2
    continue
  fi
  kubectl -n "${NAMESPACE}" annotate service "${svc}" \
    "cloud.google.com/backend-config={\"default\":\"${CONFIG_NAME}\"}" --overwrite >/dev/null
  echo "service/${svc}: backend timeout ${TIMEOUT_SECONDS}s via BackendConfig/${CONFIG_NAME}"
done
