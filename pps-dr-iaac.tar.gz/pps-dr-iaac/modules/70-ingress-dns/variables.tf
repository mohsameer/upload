variable "ingress_namespace" {
  type = string
}

variable "ingress_class" {
  type = string
}

variable "dr_hostnames" {
  type        = map(string)
  description = "Service key -> hostname requiring a DNS record."
}

variable "pps_cert_file" {
  type = string
}

variable "pps_key_file" {
  type = string
}

variable "tls_secret_name" {
  type = string
}

variable "kubeconfig_path" {
  type = string
}

variable "ingress_names" {
  type        = map(string)
  description = "Ingress objects managed for the DR site."
  default = {
    internal = "icrypto-internal"
    external = "icrypto-external"
    opa      = "opa-internal"
  }
}

variable "ingress_manifest_file" {
  type        = string
  description = "Path to a captured ingress manifest applied instead of the template. Empty = render the template."
  default     = ""
}

variable "backend_services" {
  type        = map(string)
  description = "Hostname key -> backing Kubernetes Service name. Placeholder values until PPS confirms the DR service names."
  default     = {}
}

variable "backend_service_port" {
  type    = number
  default = 80
}

variable "backend_timeout_seconds" {
  type        = number
  description = "GCLB backend request timeout for the ingress backends, applied as a BackendConfig. 0 leaves the GKE default of 30s."
  default     = 0
}

variable "backend_timeout_services" {
  type        = list(string)
  description = "Services in ingress_namespace that get the BackendConfig annotation."
  default     = []
}

variable "backend_timeout_config_name" {
  type    = string
  default = "dr-backend-timeout"
}

variable "address_timeout_seconds" {
  type        = number
  description = "How long to wait for the ingress to be allocated an address. The external global load balancer takes 9-11 minutes to provision (9m35s, 9m52s, 10m14s in recent builds), so 600 sat on the edge and failed a build whose ingress got its address a minute later."
  default     = 1500
}

variable "internal_ingress_vips" {
  type = map(string)
}

variable "ingress_teardown_enabled" {
  type        = bool
  default     = true
  description = <<-EOT
    On destroy, delete this module's ingresses and any LoadBalancer Service in
    the app namespaces, then wait for their controllers to release the GCP load
    balancer resources.

    On by default because without it the destroy fails in Phase 1 with
    "Error waiting for deleting GKE cluster: Failed to delete cluster": GKE
    will not delete a cluster that load balancer resources still reference.
    Set it to false only to keep those resources for inspection - they are not
    cleaned up by anything else, and the last destroy left five generations of
    them behind (20 NEGs, 2 backend services, 2 forwarding rules, 1 URL map,
    1 target proxy, 1 firewall rule, 3 health checks).
  EOT
}

variable "ingress_teardown_timeout_seconds" {
  type        = number
  description = "How long the teardown waits for the ingress and service controllers to delete their GCP resources and drop their finalizers. Longer than address_timeout_seconds on purpose: allocating an address is one API call, tearing an L7 load balancer down is a chain of asynchronous deletions. Expiry never fails the destroy - the step reports what is left and returns."
  default     = 900
}

variable "ingress_teardown_service_namespaces" {
  type        = list(string)
  description = "Namespaces swept for Services of type LoadBalancer on destroy. Empty = ingress_namespace only."
  default     = []
}

variable "ingress_teardown_service_selectors" {
  type        = list(string)
  description = "Label selectors narrowing that sweep. Empty (the default) means every LoadBalancer Service in those namespaces, which is the safe setting: each one owns a forwarding rule and a firewall rule that block the cluster delete, whoever created it."
  default     = []
}

variable "ingress_teardown_gcp_name_filter" {
  type        = string
  description = "Substring identifying this cluster's load balancer resources in the post-teardown leftover report. Empty = read the uid GKE embeds in those names from kube-system/ingress-uid; if that is unreadable the report is skipped rather than widened to another cluster's resources."
  default     = ""
}

variable "dr_region" {
  type = string
}

variable "dr_subnetwork" {
  type = string
}

variable "project_id" {
  type = string
}

variable "wave1_gate" {
  type        = string
  default     = ""
  description = <<-EOT
    Value threaded in from the point where the Applications are released to
    sync - deliberately not from their convergence.

    The ingress has to exist before the applications are Healthy rather than
    after: oidc-mgmt-portal fetches https://oidc.pps.co.za at startup, Phase 2
    has already pointed that name at this site's reserved address, and the
    address answers nothing until this ingress attaches a load balancer to it.
    Gating the ingress on convergence deadlocked the build.

    The DNS change request stays behind the full gate: it is the hand-off to
    PPS and must not go out before the site is complete.
  EOT
}

variable "full_gate" {
  type        = string
  default     = ""
  description = <<-EOT
    Value threaded in from the complete application stack: both sync waves
    converged and the data tier asserted.

    Only the DNS change request waits for this. It is the hand-off to PPS, so
    it must not go out while the deferred Application - idm-server-v2 - is
    still waiting for its database. The ingress and its certificate come up
    earlier, from wave1_gate.

    This is deliberately a threaded value rather than a module-level
    depends_on: a depends_on applies to every resource in the module, which
    would make the ingress wait for the database restore too and undo the
    split entirely.
  EOT
}

variable "dns_change_request_enabled" {
  type        = bool
  default     = true
  description = "Emit the DNS change request. False stops after the ingress and its certificate."
}

variable "self_hostname_redirect_enabled" {
  type        = bool
  default     = true
  description = "Make this site's own hostnames resolve to this site's ingress inside the cluster, so DR workloads never reach the source site through public DNS."
}

variable "endpoint_redirects" {
  type        = map(string)
  default     = {}
  description = "Phase 2's base in-cluster DNS redirects, rewritten together with the ingress hostnames because the ConfigMap is rewritten wholesale."
}

variable "dns_redirect_namespace" {
  type        = string
  default     = "persistent"
  description = "Namespace running the in-cluster DNS redirect."
}

variable "external_ingress_vip_name" {
  type        = string
  default     = ""
  description = "Reserved global address name pinned on the external ingress with kubernetes.io/ingress.global-static-ip-name. Empty leaves GKE to allocate a new address per rebuild."
}
