# Phase 7 - ingress, TLS and the DNS change request.
#
# Ingress objects are applied server-side so an existing ingress is ADOPTED
# rather than recreated. That matters more than it looks: recreating the
# ingress allocates a new load balancer IP, which invalidates the DNS records
# PPS has already created and costs another DNS change cycle.
#
# This module creates no DNS record. DNS is a PPS action; Phase 7 only emits
# the hostname -> IP mapping for the change request.

locals {
  hostnames = values(var.dr_hostnames)

  # A captured manifest (e.g. env/pps-dr/ingresses.yaml) reproduces a site
  # whose ingresses do not fit the template: several classes, per-host
  # backends and ports, pinned static IPs. It is applied as-is.
  use_captured_manifest = var.ingress_manifest_file != ""

  # The captured manifest is applied as-is, so the static-IP annotation is
  # spliced in rather than edited into the file: the external ingress has no
  # such annotation of its own, and without it GKE allocates a new address on
  # every rebuild. Matched on the class line, which only the external ingress
  # carries.
  captured_manifest_raw = local.use_captured_manifest ? file(var.ingress_manifest_file) : ""
  captured_manifest = var.external_ingress_vip_name == "" ? local.captured_manifest_raw : replace(
    local.captured_manifest_raw,
    "kubernetes.io/ingress.class: gce\n",
    "kubernetes.io/ingress.class: gce\n      kubernetes.io/ingress.global-static-ip-name: ${var.external_ingress_vip_name}\n"
  )

  ingress_manifest = local.use_captured_manifest ? local.captured_manifest : templatefile("${path.module}/ingress.yaml.tftpl", {
    namespace        = var.ingress_namespace
    ingress_class    = var.ingress_class
    tls_secret_name  = var.tls_secret_name
    internal_name    = var.ingress_names["internal"]
    external_name    = var.ingress_names["external"]
    hostnames        = var.dr_hostnames
    backend_services = var.backend_services
    service_port     = var.backend_service_port
  })
}

# TLS material is supplied by the operator from outside the repo. The
# certificate and key are never committed.
# The internal ingresses reference these VIPs by name through
# kubernetes.io/ingress.regional-static-ip-name. Reserving them here keeps the
# addresses stable across a rebuild - a GKE-allocated address would change, and
# every DNS record pointing at it would have to be reissued.
# What the ingress and certificate wait for; see var.wave1_gate.
resource "terraform_data" "wave1" {
  input = var.wave1_gate
}

resource "google_compute_address" "internal_vip" {
  for_each = var.internal_ingress_vips

  name         = each.key
  address      = each.value
  address_type = "INTERNAL"
  purpose      = "SHARED_LOADBALANCER_VIP"
  region       = var.dr_region
  subnetwork   = var.dr_subnetwork
  project      = var.project_id
}

resource "null_resource" "tls_secret" {
  triggers = {
    namespace   = var.ingress_namespace
    secret_name = var.tls_secret_name
    cert_path   = var.pps_cert_file
    key_path    = var.pps_key_file
    script      = filemd5("${path.module}/tls_secret.sh")
  }

  provisioner "local-exec" {
    command     = "./tls_secret.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG  = pathexpand(var.kubeconfig_path)
      NAMESPACE   = var.ingress_namespace
      SECRET_NAME = var.tls_secret_name
      CERT_FILE   = var.pps_cert_file
      KEY_FILE    = var.pps_key_file
      HOSTNAMES   = join(" ", local.hostnames)
    }
  }

  depends_on = [terraform_data.wave1]
}

resource "null_resource" "ingress" {

  triggers = {
    manifest = sha256(local.ingress_manifest)
    script   = filemd5("${path.module}/apply_ingress.sh")
  }

  provisioner "local-exec" {
    command     = "./apply_ingress.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG    = pathexpand(var.kubeconfig_path)
      NAMESPACE     = var.ingress_namespace
      MANIFEST      = local.ingress_manifest
      HOSTNAMES     = join(" ", local.hostnames)
      INGRESS_NAMES = join(" ", [var.ingress_names["internal"], var.ingress_names["external"]])
      # A captured manifest is authoritative per ingress; the "every host on
      # every ingress" comparison only applies to the template.
      SKIP_HOST_CHECK = tostring(local.use_captured_manifest)
    }
  }

  depends_on = [
  terraform_data.wave1, null_resource.tls_secret, google_compute_address.internal_vip]
}

resource "null_resource" "backend_timeout" {
  count = var.backend_timeout_seconds > 0 && length(var.backend_timeout_services) > 0 ? 1 : 0

  triggers = {
    timeout  = tostring(var.backend_timeout_seconds)
    services = join(" ", var.backend_timeout_services)
    name     = var.backend_timeout_config_name
    script   = filemd5("${path.module}/backend_timeout.sh")
  }

  provisioner "local-exec" {
    command     = "./backend_timeout.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.ingress_namespace
      TIMEOUT_SECONDS = tostring(var.backend_timeout_seconds)
      SERVICES        = join(" ", var.backend_timeout_services)
      CONFIG_NAME     = var.backend_timeout_config_name
    }
  }

  depends_on = [null_resource.ingress]
}

# Point this site's own hostnames at this site's ingress, inside the cluster.
#
# Public DNS still names the source site until PPS cuts over, so without this a
# DR pod calling the site's own issuer reaches production: oidc.pps.co.za
# resolved in-cluster to production's 34.120.124.233 and oidc-mgmt-portal
# crash-looped on a TLS reset against it. The address cannot be configured in
# advance - the external ingress has no static-IP annotation, so GKE allocates
# a new one per rebuild - which is why this converges after the ingress exists
# instead of being an endpoint_redirects entry.
resource "null_resource" "self_hostname_redirect" {
  count = var.self_hostname_redirect_enabled ? 1 : 0

  triggers = {
    ingress    = null_resource.ingress.id
    namespace  = var.ingress_namespace
    names      = join(" ", values(var.ingress_names))
    redirects  = jsonencode(var.endpoint_redirects)
    script     = filemd5("${path.module}/self_hostname_redirect.sh")
    dns_script = filemd5("${path.root}/modules/common/dns_redirect.sh")
  }

  provisioner "local-exec" {
    command     = "./self_hostname_redirect.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.ingress_namespace
      INGRESS_NAMES   = join(" ", values(var.ingress_names))
      DNS_NAMESPACE   = var.dns_redirect_namespace
      BASE_REDIRECTS  = join("\n", [for k, v in var.endpoint_redirects : "${k}=${v}"])
      REDIRECT_SCRIPT = abspath("${path.root}/modules/common/dns_redirect.sh")
      TIMEOUT_SECONDS = tostring(var.address_timeout_seconds)
    }
  }

  depends_on = [null_resource.ingress]
}

# Resolve the allocated addresses and write the DNS change request.
# The hand-off to PPS, and the one step here that waits for the whole stack.
resource "terraform_data" "full_stack" {
  input = var.full_gate
}

resource "null_resource" "dns_change_request" {
  count = var.dns_change_request_enabled ? 1 : 0

  triggers = {
    ingress_id = null_resource.ingress.id
    full_stack = terraform_data.full_stack.id
    hostnames  = join(",", local.hostnames)
    script     = filemd5("${path.module}/dns_change_request.sh")
  }

  provisioner "local-exec" {
    command     = "./dns_change_request.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.ingress_namespace
      INGRESS_NAMES   = join(" ", values(var.ingress_names))
      HOSTNAMES       = join(" ", local.hostnames)
      TIMEOUT_SECONDS = tostring(var.address_timeout_seconds)
      OUTPUT_PATH     = ".dr-run/dns-change-request.json"
    }
  }

  depends_on = [terraform_data.full_stack]
}

# Gated with the request itself: the file only exists once the script has
# written it, and reading a missing file is a hard error.
data "local_file" "dns_change_request" {
  count      = var.dns_change_request_enabled ? 1 : 0
  filename   = "${path.module}/.dr-run/dns-change-request.json"
  depends_on = [null_resource.dns_change_request]
}

# --- destroy-time teardown --------------------------------------------------
# Nothing above deletes the Ingress objects or the LoadBalancer Services on
# the way out, and GKE refuses to delete a cluster that load balancer
# resources still reference:
#   Error: Error waiting for deleting GKE cluster: Failed to delete cluster
# The hand cleanup that unblocked that destroy found five generations of
# orphans from earlier ones - 20 NEGs, 2 regional backend services, 2
# forwarding rules, 1 URL map, 1 target proxy, 1 firewall rule (k8s-fw-l7--*)
# and 3 health checks - so every destroy so far has leaked a full set.
#
# Its own resource with only stable triggers, exactly like the uninstalls in
# modules/20-platform/main.tf and for the same reason: `triggers` is ForceNew,
# so hanging this provisioner off null_resource.ingress would make any trigger
# change there - the manifest checksum, or an edit to apply_ingress.sh - a
# replacement, and a replacement runs the destroy provisioner first. Editing
# the ingress template would then have torn down the load balancer of a live
# site, taking the address with it and invalidating the DNS records PPS had
# already created. Nothing here is derived from file contents or from the
# manifest; the keys below only change when an operator renames a namespace or
# an ingress, which is a rebuild anyway.
#
# depends_on gives the order: Terraform destroys in reverse dependency order,
# so this runs before the ingresses and the reserved VIPs are removed - the
# VIPs matter too, since releasing an address an ILB forwarding rule still
# holds fails.
resource "null_resource" "ingress_teardown" {
  count = var.ingress_teardown_enabled ? 1 : 0

  # A destroy provisioner may only read `self`, so everything the teardown
  # needs is carried in triggers - a var.* or local.* reference there is a
  # plan-time error, not a runtime one.
  triggers = {
    namespace          = var.ingress_namespace
    ingress_names      = join(" ", values(var.ingress_names))
    service_namespaces = join(" ", length(var.ingress_teardown_service_namespaces) > 0 ? var.ingress_teardown_service_namespaces : [var.ingress_namespace])
    # ';'-separated: a label selector contains commas of its own.
    service_selectors = join(";", var.ingress_teardown_service_selectors)
    kubeconfig        = pathexpand(var.kubeconfig_path)
    timeout           = tostring(var.ingress_teardown_timeout_seconds)
    project_id        = var.project_id
    gcp_name_filter   = var.ingress_teardown_gcp_name_filter
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/ingress_teardown.sh"
    interpreter = ["/bin/bash"]

    environment = {
      KUBECONFIG         = self.triggers.kubeconfig
      NAMESPACE          = self.triggers.namespace
      INGRESS_NAMES      = self.triggers.ingress_names
      SERVICE_NAMESPACES = self.triggers.service_namespaces
      SERVICE_SELECTORS  = self.triggers.service_selectors
      TIMEOUT_SECONDS    = self.triggers.timeout
      PROJECT_ID         = self.triggers.project_id
      GCP_NAME_FILTER    = self.triggers.gcp_name_filter
    }
  }

  depends_on = [null_resource.ingress, google_compute_address.internal_vip]
}
