#!/usr/bin/env bash
# Emit the DNS change request: hostname -> allocated ingress address.
#
# PPS creates the records. This repo deliberately creates none.
set -euo pipefail

: "${NAMESPACE:?}" "${INGRESS_NAMES:?}" "${HOSTNAMES:?}" "${TIMEOUT_SECONDS:?}" "${OUTPUT_PATH:?}"

mkdir -p "$(dirname "${OUTPUT_PATH}")"

get_address() {
  kubectl -n "${NAMESPACE}" get ingress "$1" \
    -o jsonpath='{.status.loadBalancer.ingress[0].ip}{.status.loadBalancer.ingress[0].hostname}' 2>/dev/null || true
}

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
declare -A ADDRESSES

while [[ ${SECONDS} -lt ${DEADLINE} ]]; do
  PENDING=0
  for name in ${INGRESS_NAMES}; do
    kubectl -n "${NAMESPACE}" get ingress "${name}" >/dev/null 2>&1 || continue
    ADDR=$(get_address "${name}")
    if [[ -z "${ADDR}" ]]; then
      PENDING=1
    else
      ADDRESSES["${name}"]="${ADDR}"
    fi
  done
  [[ ${PENDING} -eq 0 ]] && break
  sleep 15
done

if [[ ${#ADDRESSES[@]} -eq 0 ]]; then
  echo "ERROR: no ingress was allocated an address within ${TIMEOUT_SECONDS}s." >&2
  kubectl -n "${NAMESPACE}" get ingress >&2 || true
  exit 1
fi

# Each hostname has to resolve to the ingress that actually serves it. Only
# oidc, sidas and the dashboard are on the external load balancer; admin,
# idmv2 and truetrace are on the internal one and truepolicy is on the OPA
# internal one. Reading the rules off each ingress is the only way to get that
# right - assigning one address to every hostname would publish internal-only
# hosts on the public address.
declare -A HOST_ADDR
for name in ${INGRESS_NAMES}; do
  [[ -n "${ADDRESSES[${name}]:-}" ]] || continue
  while read -r host; do
    [[ -n "${host}" ]] && HOST_ADDR["${host}"]="${ADDRESSES[${name}]}"
  done < <(kubectl -n "${NAMESPACE}" get ingress "${name}" \
            -o jsonpath='{range .spec.rules[*]}{.host}{"\n"}{end}' 2>/dev/null)
done

RECORDS=""
UNSERVED=()
for host in ${HOSTNAMES}; do
  addr="${HOST_ADDR[${host}]:-}"
  if [[ -z "${addr}" ]]; then
    UNSERVED+=("${host}")
    continue
  fi
  RECORDS="${RECORDS}$(printf '{"hostname":"%s","address":"%s"}' "${host}" "${addr}"),"
done
RECORDS="${RECORDS%,}"

if [[ ${#UNSERVED[@]} -gt 0 ]]; then
  echo "ERROR: no ingress rule serves these configured hostnames:" >&2
  for h in "${UNSERVED[@]}"; do echo "  - ${h}" >&2; done
  echo "Either the ingress manifest or dr_hostnames is wrong; a DNS record" >&2
  echo "pointing at the wrong load balancer is worse than a missing one." >&2
  exit 1
fi

INGRESS_JSON=""
for name in "${!ADDRESSES[@]}"; do
  INGRESS_JSON="${INGRESS_JSON}$(printf '{"ingress":"%s","address":"%s"}' "${name}" "${ADDRESSES[${name}]}"),"
done
INGRESS_JSON="${INGRESS_JSON%,}"

cat >"${OUTPUT_PATH}" <<EOF
{
  "generated_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "action_owner": "PPS",
  "records": [${RECORDS}],
  "ingress_addresses": [${INGRESS_JSON}]
}
EOF

echo "DNS change request written to ${OUTPUT_PATH}:"
cat "${OUTPUT_PATH}"
echo
echo "Hand this to PPS. Phase 8 must not run until every hostname resolves."
