#!/usr/bin/env bash
# Create the TLS secret from operator-supplied material.
# Nothing here is committed: the cert and key live on the bastion only.
set -euo pipefail

: "${NAMESPACE:?}" "${SECRET_NAME:?}" "${CERT_FILE:?}" "${KEY_FILE:?}"

CERT_PATH="${CERT_FILE/#\~/${HOME}}"
KEY_PATH="${KEY_FILE/#\~/${HOME}}"

for f in "${CERT_PATH}" "${KEY_PATH}"; do
  if [[ ! -r "${f}" ]]; then
    echo "ERROR: TLS material not readable: ${f}" >&2
    echo "Place the *.pps.co.za certificate and key on the DR bastion and point pps_cert_file / pps_key_file at them." >&2
    exit 1
  fi
done

# Catch a cert/key pair that does not match before ingress serves it.
CERT_MOD=$(openssl x509 -noout -modulus -in "${CERT_PATH}" | openssl md5)
KEY_MOD=$(openssl rsa -noout -modulus -in "${KEY_PATH}" 2>/dev/null | openssl md5 || true)
if [[ -n "${KEY_MOD}" && "${CERT_MOD}" != "${KEY_MOD}" ]]; then
  echo "ERROR: certificate and private key do not match." >&2
  exit 1
fi

kubectl -n "${NAMESPACE}" create secret tls "${SECRET_NAME}" \
  --cert="${CERT_PATH}" --key="${KEY_PATH}" \
  --dry-run=client -o yaml | kubectl apply -f - >/dev/null

echo "secret/${SECRET_NAME} (TLS) ready in namespace ${NAMESPACE} for: ${HOSTNAMES:-}"
