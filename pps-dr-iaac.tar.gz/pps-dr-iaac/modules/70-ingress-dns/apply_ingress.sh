#!/usr/bin/env bash
# Reuse-or-create the DR ingress objects.
#
# `kubectl apply` adopts an existing ingress instead of replacing it, which is
# what keeps the load balancer address stable across re-runs. Before applying,
# an already-present ingress is checked against the configured hostname set so
# a stale ingress from an older DR exercise is reported instead of silently
# reused.
set -euo pipefail

: "${NAMESPACE:?}" "${MANIFEST:?}" "${HOSTNAMES:?}" "${INGRESS_NAMES:?}"

MISMATCH=()

for name in ${INGRESS_NAMES}; do
  if [[ "${SKIP_HOST_CHECK:-false}" == "true" ]]; then
    kubectl -n "${NAMESPACE}" get ingress "${name}" >/dev/null 2>&1 \
      && echo "ingress/${name}: present, adopting (captured manifest)" \
      || echo "ingress/${name}: absent, will be created (captured manifest)"
    continue
  fi
  if ! kubectl -n "${NAMESPACE}" get ingress "${name}" >/dev/null 2>&1; then
    echo "ingress/${name}: absent, will be created"
    continue
  fi

  EXISTING=$(kubectl -n "${NAMESPACE}" get ingress "${name}" \
    -o jsonpath='{range .spec.rules[*]}{.host}{"\n"}{end}' | sort -u | tr '\n' ' ')
  CONFIGURED=$(printf '%s\n' ${HOSTNAMES} | sort -u | tr '\n' ' ')

  if [[ "${EXISTING}" != "${CONFIGURED}" ]]; then
    MISMATCH+=("ingress/${name}: existing hosts [${EXISTING% }] != configured [${CONFIGURED% }]")
  else
    echo "ingress/${name}: present and hostnames match, adopting"
  fi
done

if [[ ${#MISMATCH[@]} -gt 0 ]]; then
  echo "ERROR: an existing ingress does not match the configured DR hostnames:" >&2
  for m in "${MISMATCH[@]}"; do echo "  - ${m}" >&2; done
  echo "Reusing it would serve the wrong hostnames. Reconcile dr_hostnames, or delete the stale ingress (this changes the load balancer IP and needs a new DNS change request)." >&2
  exit 1
fi

printf '%s' "${MANIFEST}" | kubectl -n "${NAMESPACE}" apply -f - >/dev/null
echo "Ingress objects applied in namespace ${NAMESPACE}."
