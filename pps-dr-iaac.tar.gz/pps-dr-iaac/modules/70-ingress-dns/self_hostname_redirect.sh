#!/usr/bin/env bash
# Make this site's own public hostnames resolve, inside the cluster, to this
# site's ingress.
#
# Public DNS still points these names at the source site until PPS cuts over,
# so a DR pod that calls the site's own issuer reaches production. On
# 2026-10-12 oidc.pps.co.za resolved in-cluster to 34.120.124.233 - production's
# address - and oidc-mgmt-portal crash-looped on
#
#   TypeError: fetch failed
#     cause: Client network socket disconnected before secure TLS connection
#            was established  host: 'oidc.pps.co.za' port: 443
#
# which is the kindest possible outcome: the alternative is a DR workload
# quietly reading and writing production.
#
# This cannot be a static entry in endpoint_redirects. The internal ingresses
# pin regional-static-ip-name, but the external one has no static IP
# annotation (see env/pps-dr/ingresses.yaml), so GKE allocates a new address on
# every rebuild and the value is only knowable after Phase 7 has created the
# ingress. So the redirect is converged here, from what the ingresses actually
# report, rather than guessed in advance.
#
# The whole redirect set is rewritten, base entries included, because the
# ConfigMap is rewritten wholesale by the shared script. Phase 2 owns the base
# entries and runs first; this adds the site's own names on top.
set -euo pipefail

: "${NAMESPACE:?}" "${INGRESS_NAMES:?}" "${REDIRECT_SCRIPT:?}"

DNS_NAMESPACE="${DNS_NAMESPACE:-persistent}"
BASE_REDIRECTS="${BASE_REDIRECTS:-}"
TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-1500}"

[[ -x "${REDIRECT_SCRIPT}" || -r "${REDIRECT_SCRIPT}" ]] || {
  echo "ERROR: ${REDIRECT_SCRIPT} is not readable." >&2
  exit 1
}

# An ingress without an address yet would produce "host=" and poison the zone.
declare -a pairs=()
for ing in ${INGRESS_NAMES}; do
  kubectl -n "${NAMESPACE}" get ingress "${ing}" >/dev/null 2>&1 || {
    echo "  ${ing}: not present, skipped"
    continue
  }

  addr=""
  waited=0
  while [[ "${waited}" -lt "${TIMEOUT_SECONDS}" ]]; do
    addr=$(kubectl -n "${NAMESPACE}" get ingress "${ing}" \
      -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null)
    [[ -n "${addr}" ]] && break
    sleep 10
    waited=$((waited + 10))
  done

  if [[ -z "${addr}" ]]; then
    echo "ERROR: ingress ${ing} still had no address after ${waited}s." >&2
    exit 1
  fi

  mapfile -t hosts < <(kubectl -n "${NAMESPACE}" get ingress "${ing}" \
    -o jsonpath='{range .spec.rules[*]}{.host}{"\n"}{end}' 2>/dev/null | grep -v '^$' || true)
  for h in ${hosts[@]+"${hosts[@]}"}; do
    pairs+=("${h}=${addr}")
    echo "  ${h} -> ${addr} (${ing})"
  done
done

if [[ "${#pairs[@]}" -eq 0 ]]; then
  echo "No ingress hostnames to redirect."
  exit 0
fi

ALL="${BASE_REDIRECTS}"
for p in "${pairs[@]}"; do
  ALL="${ALL}
${p}"
done

NAMESPACE="${DNS_NAMESPACE}" REDIRECTS="${ALL}" bash "${REDIRECT_SCRIPT}"
