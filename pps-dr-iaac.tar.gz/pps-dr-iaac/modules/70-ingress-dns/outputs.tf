output "dns_change_request" {
  description = "Hostname -> ingress address mapping PPS must create DNS records for. This repo creates no DNS record."
  value = try(
    jsondecode(data.local_file.dns_change_request[0].content),
    "dns change request not emitted (dns_change_request_enabled = false); the ingress address is in the hostnames output"
  )
}

output "dns_resolution_check_command" {
  description = "Run this after PPS applies the DNS change; Phase 8 runs only when it exits 0."
  value       = "${path.module}/dns_resolution_check.sh \"${join(" ", local.hostnames)}\" ${var.ingress_namespace}"
}

output "hostnames" {
  value = local.hostnames
}

output "completed" {
  # The ingress, not the hand-off: this phase is complete once the ingress and
  # its certificate exist, whether or not the DNS request was emitted.
  value = null_resource.ingress.id
}

output "dns_records_command" {
  description = <<-EOT
    Prints hostname -> ingress address, which is what PPS needs to create the
    DNS records by hand when dns_change_request_enabled is false.
  EOT
  value       = "kubectl -n ${var.ingress_namespace} get ingress -o custom-columns=HOST:.spec.rules[*].host,ADDRESS:.status.loadBalancer.ingress[*].ip"
}
