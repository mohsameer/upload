#!/usr/bin/env bash
# DNS gate between Phase 7 and Phase 8.
#
# Run this after PPS applies the DNS change. Every DR hostname must resolve
# both from inside the cluster and from the bastion (externally). Phase 8 is
# only run once this exits 0.
#
# Usage: ./dns_resolution_check.sh "host1 host2 ..." [namespace]
set -euo pipefail

HOSTNAMES="${1:-${HOSTNAMES:-}}"
NAMESPACE="${2:-${NAMESPACE:-default}}"

if [[ -z "${HOSTNAMES}" ]]; then
  echo "usage: $0 \"host1 host2 ...\" [namespace]" >&2
  exit 2
fi

UNRESOLVED=()

for host in ${HOSTNAMES}; do
  # External: resolved from the DR bastion.
  if ! getent hosts "${host}" >/dev/null 2>&1; then
    UNRESOLVED+=("${host}: does not resolve externally (from the bastion)")
  fi

  # Internal: resolved from inside the DR cluster.
  if ! kubectl -n "${NAMESPACE}" run "dnscheck-$(date +%s%N | tail -c 6)" \
        --rm -i --restart=Never --quiet \
        --image=busybox:1.36 -- nslookup "${host}" >/dev/null 2>&1; then
    UNRESOLVED+=("${host}: does not resolve inside the DR cluster")
  fi
done

if [[ ${#UNRESOLVED[@]} -gt 0 ]]; then
  echo "DNS is not in place yet. Phase 8 must not be run." >&2
  for u in "${UNRESOLVED[@]}"; do echo "  - ${u}" >&2; done
  exit 1
fi

echo "All DR hostnames resolve internally and externally. Phase 8 can run:"
echo "  tofu apply -target=module.validation -var-file=pps-dr.tfvars"
