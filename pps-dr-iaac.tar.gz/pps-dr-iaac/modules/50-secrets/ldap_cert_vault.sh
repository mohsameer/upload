#!/usr/bin/env bash
# Phase 5 - publish this site's LDAP certificate into Vault.
#
# token-exchange-service reads its own KV at runtime
# (secret/token-exchange-service/ldap-certPem, field "value") and trusts only
# that certificate when it binds over LDAPS. The Vault restore brings the
# source site's copy, and the PPS LDAP image generates a fresh self-signed
# certificate on every container start - its certs directory is
# `emptyDir: {medium: Memory}`, overriding the chart's volumeClaimTemplate, so
# nothing about it survives a restart. On 2026-10-15 the restored value was the
# 2025-07-01 certificate while the pod served one minted that morning, two
# different fingerprints, which no amount of waiting fixes.
#
# So this runs on every build, after Phase 2 has brought LDAP up, and it is
# idempotent: identical certificate, no write and no restart.
#
# The certificate is stored the way the application already expects to read it:
# ONE line with literal backslash-n escapes, not a real multi-line PEM. A
# genuine PEM here is a different value as far as the app's parser is
# concerned.
set -euo pipefail

: "${VAULT_NAMESPACE:?}" "${VAULT_TOKEN:?}" "${LDAP_NAMESPACE:?}" "${LDAP_POD:?}" \
  "${LDAP_CERT_PATH:?}" "${KV_CERT_PATH:?}"

KV_FIELD="${KV_FIELD:-value}"
# Sibling KV entries written alongside the certificate, one "path=value" per
# line. The restored ldap-host/ldap-port name the source site's LDAP, which
# does not exist here.
KV_OVERRIDES="${KV_OVERRIDES:-}"
# "namespace/kind/name" per line, restarted only when the certificate changed.
RESTART_WORKLOADS="${RESTART_WORKLOADS:-}"
VAULT_LABEL="${VAULT_LABEL:-app.kubernetes.io/name=vault}"
ACTIVE_SERVICE="${ACTIVE_SERVICE:-vault-active}"
VAULT_ACTIVE_WAIT="${VAULT_ACTIVE_WAIT:-300}"

# --- the certificate the LDAP pod is serving right now ----------------------
PEM=$(kubectl -n "${LDAP_NAMESPACE}" exec "${LDAP_POD}" -- cat "${LDAP_CERT_PATH}" 2>/dev/null || true)
if [[ "${PEM}" != *"BEGIN CERTIFICATE"* ]]; then
  echo "ERROR: ${LDAP_NAMESPACE}/${LDAP_POD}:${LDAP_CERT_PATH} did not yield a PEM certificate." >&2
  exit 1
fi

# Literal backslash-n between lines, no trailing one, matching the stored form.
ESCAPED=$(printf '%s' "${PEM}" | awk 'NR>1 { printf "\\n" } { printf "%s", $0 }')

# --- the active Vault node --------------------------------------------------
# A standby answers every write with
#   500 local node not active but active cluster node not found
# and a pod can be Ready without being the leader, so the vault-active
# endpoint decides. Same logic as vault_config.sh.
POD=""
deadline=$((SECONDS + VAULT_ACTIVE_WAIT))
while [[ ${SECONDS} -lt ${deadline} ]]; do
  POD=$(kubectl -n "${VAULT_NAMESPACE}" get endpoints "${ACTIVE_SERVICE}" \
    -o jsonpath='{.subsets[0].addresses[0].targetRef.name}' 2>/dev/null || true)
  if [[ -n "${POD}" ]]; then
    if kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -c \
      'VAULT_TOKEN="$0" vault status -format=json' "${VAULT_TOKEN}" 2>/dev/null |
      jq -e 'if has("sealed") then (.sealed == false) else false end' >/dev/null; then
      break
    fi
  fi
  POD=""
  echo "waiting for an active Vault node..."
  sleep 10
done
if [[ -z "${POD}" ]]; then
  POD=$(kubectl -n "${VAULT_NAMESPACE}" get pods -l "${VAULT_LABEL}" \
    -o jsonpath='{range .items[?(@.status.containerStatuses[0].ready==true)]}{.metadata.name}{"\n"}{end}' 2>/dev/null | head -n1)
fi
[[ -n "${POD}" ]] || { echo "ERROR: no active Vault node in ${VAULT_NAMESPACE} after ${VAULT_ACTIVE_WAIT}s." >&2; exit 1; }

# The token is exported from stdin rather than passed as a VAR=value prefix or
# an argument: a prefix applies to one command only, and both forms put the
# token in `ps` on the bastion and in the pod.
v() {
  { printf 'VAULT_TOKEN=%s\nexport VAULT_TOKEN\n' "${VAULT_TOKEN}"; cat; } |
    kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -s
}
vc() { printf '%s\n' "$1" | v; }

# Values travel in a quoted heredoc and are read back with `field=@file`: a PEM
# is multi-line even when escaped, and nothing of it should reach a shell word.
write_kv() {
  local kv_path="$1" value="$2"
  {
    echo "cat > /tmp/kvval <<'KVVALUE'"
    printf '%s\n' "${value}"
    echo "KVVALUE"
    printf "vault write '%s' '%s'=@/tmp/kvval\n" "${kv_path}" "${KV_FIELD}"
    echo "rm -f /tmp/kvval"
  } | v >/dev/null
}

# --- write the certificate only when it differs -----------------------------
CURRENT=$(vc "vault read -field='${KV_FIELD}' '${KV_CERT_PATH}'" 2>/dev/null || true)

if [[ "${CURRENT}" == "${ESCAPED}" ]]; then
  echo "${KV_CERT_PATH}: already the certificate ${LDAP_POD} is serving"
  CHANGED=false
else
  write_kv "${KV_CERT_PATH}" "${ESCAPED}"
  echo "${KV_CERT_PATH}: updated from ${LDAP_NAMESPACE}/${LDAP_POD}:${LDAP_CERT_PATH}"
  CHANGED=true
fi

# --- sibling entries --------------------------------------------------------
while IFS= read -r entry; do
  [[ -n "${entry}" ]] || continue
  kv_path="${entry%%=*}"
  value="${entry#*=}"
  existing=$(vc "vault read -field='${KV_FIELD}' '${kv_path}'" 2>/dev/null || true)
  if [[ "${existing}" == "${value}" ]]; then
    echo "${kv_path}: already ${value}"
    continue
  fi
  write_kv "${kv_path}" "${value}"
  echo "${kv_path}: ${value}"
  CHANGED=true
done <<<"${KV_OVERRIDES}"

# --- restart the readers ----------------------------------------------------
# Only on a change: the value is read at startup, so a pod that came up before
# the write keeps the old certificate, and restarting on every build would
# bounce a healthy service for nothing.
if [[ "${CHANGED}" == "true" ]]; then
  while IFS= read -r target; do
    [[ -n "${target}" ]] || continue
    IFS=/ read -r ns kind name <<<"${target}"
    if ! kubectl -n "${ns}" get "${kind}" "${name}" >/dev/null 2>&1; then
      echo "${ns}/${kind}/${name}: absent, not restarted" >&2
      continue
    fi
    kubectl -n "${ns}" rollout restart "${kind}/${name}" >/dev/null
    echo "${ns}/${kind}/${name}: restarted"
  done <<<"${RESTART_WORKLOADS}"
fi

echo "LDAP certificate published to Vault."
