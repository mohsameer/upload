#!/usr/bin/env bash
# Phase 5 sign-off: every ExternalSecret in the target namespaces must reach
# SecretSynced, and the Kubernetes Secret it produces must exist.
#
# Failing here is deliberate: syncing applications against missing Secrets
# produces a cluster full of crash-looping pods and a much slower diagnosis.
set -euo pipefail

: "${TARGET_NAMESPACES:?}" "${TIMEOUT_SECONDS:?}"

# A namespace with no ExternalSecret at all used to satisfy this gate, because
# the loop below simply found nothing to object to. That is the one case the
# gate exists to catch, so require a minimum count explicitly.
MIN_EXTERNAL_SECRETS="${MIN_EXTERNAL_SECRETS:-0}"

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
UNSYNCED=()
FOUND=0

while [[ ${SECONDS} -lt ${DEADLINE} ]]; do
  UNSYNCED=()
  FOUND=0

  for ns in ${TARGET_NAMESPACES}; do
    while read -r name reason secret_name; do
      [[ -z "${name}" ]] && continue

      FOUND=$((FOUND + 1))

      if [[ "${reason}" != "SecretSynced" ]]; then
        UNSYNCED+=("${ns}/${name}: status=${reason:-<none>}")
        continue
      fi

      if ! kubectl -n "${ns}" get secret "${secret_name}" >/dev/null 2>&1; then
        UNSYNCED+=("${ns}/${name}: reports SecretSynced but secret/${secret_name} is missing")
      fi
    done < <(kubectl -n "${ns}" get externalsecrets.external-secrets.io \
              -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.status.conditions[?(@.type=="Ready")].reason}{" "}{.spec.target.name}{"\n"}{end}' 2>/dev/null)
  done

  if [[ ${#UNSYNCED[@]} -eq 0 && ${FOUND} -ge ${MIN_EXTERNAL_SECRETS} ]]; then
    echo "All ${FOUND} ExternalSecret(s) in [${TARGET_NAMESPACES}] report SecretSynced."
    exit 0
  fi

  sleep 15
done

if [[ ${FOUND} -lt ${MIN_EXTERNAL_SECRETS} ]]; then
  echo "ERROR: expected at least ${MIN_EXTERNAL_SECRETS} ExternalSecret(s) in [${TARGET_NAMESPACES}] but found ${FOUND}." >&2
  echo "Applications that mount the Secrets they produce will not start. Phase 6 has not been run." >&2
  exit 1
fi

echo "ERROR: ExternalSecrets did not sync within ${TIMEOUT_SECONDS}s:" >&2
for u in "${UNSYNCED[@]}"; do echo "  - ${u}" >&2; done
echo "Phase 6 has not been run. Fix the store or the Vault paths, then re-apply." >&2
exit 1
