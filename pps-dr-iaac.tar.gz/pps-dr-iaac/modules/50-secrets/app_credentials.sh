#!/usr/bin/env bash
# Create the credentials the SSO application pods mount, which the restore does
# not bring with it:
#
#   vault-<base>-ext-role / -ext-secret   Vault AppRole role_id + secret_id
#   consul-secret                         Consul token
#   aws-secret                            ECR/AWS key pair for the init container
#
# Without these every application pod sits in Init:0/1 on FailedMount, or in
# Init:CreateContainerConfigError, and Phase 6's convergence gate never passes.
#
# The Secret-name -> AppRole-role mapping is NOT derivable from the names and is
# supplied by vault_approle_secrets: on PPS, vault-cred-mgmt-service-ext maps to
# role "credmgmt", vault-idm2-server-ext to "idm-server", vault-mfa-facade-ext
# to "mfa", vault-notification-service-ext to "notification_service" (underscore,
# and a separate "notification-service" role also exists) and vault-oidc-v2-ext
# to "oidcv2" (not "oidc-v2", which also exists). Recover it by matching the
# source environment's role_id against the role_id of every AppRole role; the
# only authoritative source is the environment whose Vault was restored.
#
# Both Secrets always use the keys role_id and secret_id; charts that want a
# different filename do it with items[].path, not a different key.
set -euo pipefail

: "${VAULT_TOKEN:?}" "${APPROLE_MAP:?}" "${VAULT_NAMESPACE:?}"
# Legitimately empty when a run only has to create per-pod Secrets.
SHARED_NAMESPACES="${SHARED_NAMESPACES:-}"

# Vault is reached with kubectl exec rather than vault_address. That address is
# a bastion port-forward, which dies whenever its target pod is replaced; a
# forward that dropped mid-run previously failed this script with curl exit 52
# ("empty reply from server") even though Vault itself was healthy.
VAULT_LABEL="${VAULT_LABEL:-app.kubernetes.io/name=vault}"

VAULT_POD=$(kubectl -n "${VAULT_NAMESPACE}" get pods -l "${VAULT_LABEL}"   -o jsonpath='{range .items[?(@.status.containerStatuses[0].ready==true)]}{.metadata.name}{"\n"}{end}' 2>/dev/null | head -n1)
[[ -n "${VAULT_POD}" ]] || { echo "ERROR: no ready Vault pod matched ${VAULT_LABEL} in ${VAULT_NAMESPACE}." >&2; exit 1; }

vault_cli() { kubectl -n "${VAULT_NAMESPACE}" exec "${VAULT_POD}" -- sh -c "VAULT_TOKEN='${VAULT_TOKEN}' $1" 2>/dev/null; }

CONSUL_TOKEN="${CONSUL_TOKEN:-}"
AWS_ACCESS_KEY_ID="${AWS_ACCESS_KEY_ID:-}"
AWS_SECRET_ACCESS_KEY="${AWS_SECRET_ACCESS_KEY:-}"

apply_secret() { kubectl -n "$1" create secret generic "$2" "${@:3}" --dry-run=client -o yaml | kubectl apply -f - >/dev/null; }

# --- per-service AppRole credentials ---------------------------------------
# APPROLE_MAP entries are namespace:secret_basename:approle_role[:layout]
#
# layout "pair" (the default) makes <base>-role and <base>-secret. "combined"
# makes a single Secret named <base> holding both keys, which is what
# authn/oidc-v3 mounts:
#
#   secret: { secretName: vault-oidc-v3,
#             items: [{key: role_id}, {key: secret_id}] }
#
# Getting that wrong leaves the pod on
# "MountVolume.SetUp failed ... secret not found", stuck before its first init
# container even starts - which is how oidc-v3, oidcv2-loader and
# oidc-mgmt-portal sat in Init:0/2 for an hour and a half on 2026-10-12.
for entry in ${APPROLE_MAP}; do
  IFS=: read -r ns base role layout mount <<<"${entry}"
  layout="${layout:-pair}"
  # Not every AppRole lives in the default "approle" mount. oidc-mgmt-portal
  # authenticates against its own: PUT auth/oidc-mgmt-portal/login. A role_id
  # minted from the default mount is rejected there with
  # "Code: 400 ... * invalid role ID", and the Vault agent sidecar then retries
  # forever while the pod restarts.
  mount="${mount:-approle}"

  role_id=$(vault_cli "vault read -field=role_id auth/${mount}/role/${role}/role-id")
  [[ -n "${role_id}" ]] || { echo "ERROR: AppRole role '${role}' has no role_id under auth/${mount}; check the mapping in vault_approle_secrets." >&2; exit 1; }

  secret_id=$(vault_cli "vault write -f -field=secret_id auth/${mount}/role/${role}/secret-id")
  [[ -n "${secret_id}" ]] || { echo "ERROR: could not mint a secret_id for AppRole role '${role}' under auth/${mount}." >&2; exit 1; }

  if [[ "${layout}" == "combined" ]]; then
    apply_secret "${ns}" "${base}" \
      --from-literal=role_id="${role_id}" \
      --from-literal=secret_id="${secret_id}"
    echo "${ns}/${base} (role_id+secret_id) <- approle ${role}"
  else
    apply_secret "${ns}" "${base}-role"   --from-literal=role_id="${role_id}"
    apply_secret "${ns}" "${base}-secret" --from-literal=secret_id="${secret_id}"
    echo "${ns}/${base}-{role,secret} <- approle ${role}"
  fi
done

# --- per-pod Capella credential Secrets ------------------------------------
# Some charts read Capella credentials from a Secret of their own rather than
# from Vault, and the restore does not bring it: oidcv2-loader takes CB_USER
# and CB_PASS from authn/oidcv2-loader-capella-secrets and without it the pod
# never starts, failing with
# "Error: secret \"oidcv2-loader-capella-secrets\" not found"
# (CreateContainerConfigError, which no amount of waiting resolves).
#
# Entries are namespace/secret-name:username_key:password_key.
for entry in ${CAPELLA_SECRETS:-}; do
  target="${entry%%:*}"
  rest="${entry#*:}"
  user_key="${rest%%:*}"
  pass_key="${rest##*:}"
  ns="${target%%/*}"
  name="${target##*/}"
  if [[ -z "${CAPELLA_USERNAME:-}" || -z "${CAPELLA_PASSWORD:-}" ]]; then
    echo "ERROR: ${target} needs CAPELLA_USERNAME and CAPELLA_PASSWORD." >&2
    exit 1
  fi
  apply_secret "${ns}" "${name}" \
    --from-literal="${user_key}=${CAPELLA_USERNAME}" \
    --from-literal="${pass_key}=${CAPELLA_PASSWORD}"
  echo "${ns}/${name} (${user_key}, ${pass_key}) <- this site's Capella credentials"
done

# --- credentials shared by every application namespace ----------------------
for ns in ${SHARED_NAMESPACES}; do
  # The init container refuses to start on an empty CONSUL_TOKEN even where the
  # Consul ACL system is disabled and the value is never checked.
  if [[ -n "${CONSUL_TOKEN}" ]]; then
    apply_secret "${ns}" consul-secret --from-literal=consul_token="${CONSUL_TOKEN}"
    echo "${ns}/consul-secret"
  fi
  if [[ -n "${AWS_ACCESS_KEY_ID}" && -n "${AWS_SECRET_ACCESS_KEY}" ]]; then
    apply_secret "${ns}" aws-secret \
      --from-literal=access_key_id="${AWS_ACCESS_KEY_ID}" \
      --from-literal=access_key_secret="${AWS_SECRET_ACCESS_KEY}"
    echo "${ns}/aws-secret"
  fi
done

echo "application credentials in place."
