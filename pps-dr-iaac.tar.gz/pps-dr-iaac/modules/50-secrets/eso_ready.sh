#!/usr/bin/env bash
# Wait for External Secrets Operator and confirm its CRDs are established.
set -euo pipefail

: "${NAMESPACE:?}" "${TIMEOUT_SECONDS:?}"

for deploy in external-secrets external-secrets-webhook external-secrets-cert-controller; do
  echo "Waiting for deployment/${deploy}..."
  if ! kubectl -n "${NAMESPACE}" rollout status "deployment/${deploy}" --timeout="${TIMEOUT_SECONDS}s"; then
    echo "ERROR: ${deploy} did not become available within ${TIMEOUT_SECONDS}s." >&2
    kubectl -n "${NAMESPACE}" get pods >&2 || true
    exit 1
  fi
done

for crd in externalsecrets.external-secrets.io secretstores.external-secrets.io clustersecretstores.external-secrets.io; do
  if ! kubectl wait --for=condition=Established "crd/${crd}" --timeout=120s >/dev/null; then
    echo "ERROR: CRD ${crd} is not Established." >&2
    exit 1
  fi
  echo "crd/${crd} established"
done

echo "External Secrets Operator is Ready."
