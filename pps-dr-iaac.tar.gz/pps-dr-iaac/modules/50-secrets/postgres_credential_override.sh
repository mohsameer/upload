#!/usr/bin/env bash
# Point the restored per-service Postgres credentials at THIS site's instance.
#
# Same problem as capella_endpoint_override.sh, different store: the Vault
# restore brings the source site's database credentials, and they do not work
# here. Found on 2026-10-12, after the auth server was finally healthy:
#
#   secret/idm/db-passwd              the source site's password; midPoint
#                                     mounts it at
#                                     /etc/secrets/mp_database_password.txt and
#                                     died with
#                                     "FATAL: password authentication failed
#                                     for user postgres"
#   secret/oidc-v3/db.pass            the same password, same result
#   secret/oidc-mgmt-portal/db.url    postgres://oidc_user:<pw>@host/db - and
#                                     oidc_user does not exist on this
#                                     instance at all
#
# That last one is not an oversight to fix in the dump: no roles are restored
# here (postgres_globals_object is empty, because pg_dumpall needs read access
# to pg_authid that the source does not grant), so `postgres` is the only login
# role that exists. Everything therefore connects as `postgres`, and a URL
# keeps its host and database while its credentials are replaced.
#
# The host needs no rewriting: cloud-sql-ha.pps.co.za is redirected to this
# site's instance by the Phase 2 DNS redirect.
set -euo pipefail

: "${VAULT_NAMESPACE:?}" "${VAULT_TOKEN:?}" "${PG_PASSWORD:?}" "${OVERRIDES:?}"

PG_USER="${PG_USER:-postgres}"
ACTIVE_SERVICE="${ACTIVE_SERVICE:-vault-active}"
VAULT_LABEL="${VAULT_LABEL:-app.kubernetes.io/name=vault}"

POD=$(kubectl -n "${VAULT_NAMESPACE}" get endpoints "${ACTIVE_SERVICE}" \
  -o jsonpath='{.subsets[0].addresses[0].targetRef.name}' 2>/dev/null || true)
if [[ -z "${POD}" ]]; then
  POD=$(kubectl -n "${VAULT_NAMESPACE}" get pods -l "${VAULT_LABEL}" \
    -o jsonpath='{range .items[?(@.status.containerStatuses[0].ready==true)]}{.metadata.name}{"\n"}{end}' 2>/dev/null | head -n1)
fi
[[ -n "${POD}" ]] || { echo "ERROR: no Vault pod available in ${VAULT_NAMESPACE}." >&2; exit 1; }

# Command text on stdin, so no password reaches argv.
v() { { printf 'VAULT_TOKEN=%s\nexport VAULT_TOKEN\n' "${VAULT_TOKEN}"; cat; } \
        | kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -s; }

# Percent-encode for a URL userinfo field; a password with a '@' or ':' in it
# would otherwise silently produce a URL pointing somewhere else.
PG_PASSWORD_ENC=$(printf '%s' "${PG_PASSWORD}" | jq -sRr @uri)

# The password is interpolated into a single-quoted string that runs inside the
# Vault pod, and the Vault CLI reinterprets two prefixes: "value=@file" reads a
# file and "value=-" reads stdin. Any of these would write the wrong thing over
# a live credential and still report success.
case "${PG_PASSWORD}" in
  *\'*) echo "ERROR: the database password contains a single quote, which would break the remote shell command." >&2; exit 1 ;;
  @*)   echo "ERROR: the database password starts with '@', which the Vault CLI reads as a filename." >&2; exit 1 ;;
  -)    echo "ERROR: the database password is '-', which the Vault CLI reads as stdin." >&2; exit 1 ;;
esac

CHANGED=0
# OVERRIDES entries are vault/path:kind, kind in password|username|url
for entry in ${OVERRIDES}; do
  path="${entry%:*}"
  kind="${entry##*:}"

  case "${kind}" in
    password)
      printf "vault write %s value='%s' >/dev/null\n" "${path}" "${PG_PASSWORD}" | v >/dev/null
      echo "  ${path}: password set to this site's ${PG_USER}"
      ;;
    username)
      printf "vault write %s value='%s' >/dev/null\n" "${path}" "${PG_USER}" | v >/dev/null
      echo "  ${path}: username set to ${PG_USER}"
      ;;
    url)
      current=$(printf 'vault read -field=value %s 2>/dev/null\n' "${path}" | v 2>/dev/null || true)
      if [[ -z "${current}" ]]; then
        echo "  WARNING: ${path} holds no value; skipped" >&2
        continue
      fi
      # Refuse anything that is not a URL rather than mangling it: without this
      # a value like "host:5432/db" (no scheme) or a JSON blob produced
      # "host:5432/db://postgres:...@host:5432/db" written over a live
      # credential, and still exited 0.
      if [[ "${current}" != *"://"* ]]; then
        echo "ERROR: ${path} is not a URL ('${current}'); refusing to rewrite it." >&2
        exit 1
      fi
      scheme="${current%%://*}"
      rest="${current#*://}"
      # Drop any existing credentials, keep host, port and database.
      #
      # The userinfo is everything before the LAST '@' in the authority, not
      # the first: "${rest#*@}" on
      # postgres://oidc_user:Pa@ss@cloud-sql-ha.pps.co.za:5432/db left
      # "ss@cloud-sql-ha..." and wrote a URL whose host was "ss".
      authority="${rest%%/*}"
      pathpart="${rest#"${authority}"}"
      authority="${authority##*@}"
      rest="${authority}${pathpart}"
      printf "vault write %s value='%s' >/dev/null\n" "${path}" "${scheme}://${PG_USER}:${PG_PASSWORD_ENC}@${rest}" | v >/dev/null
      echo "  ${path}: ${scheme}://${PG_USER}@${rest}"
      ;;
    *)
      echo "ERROR: unknown kind '${kind}' for ${path}; expected password, username or url." >&2
      exit 1
      ;;
  esac
  CHANGED=$((CHANGED + 1))
done

echo "Postgres credentials repointed at this site: ${CHANGED} key(s)."
