#!/usr/bin/env bash
# Create the ClusterSecretStore backed by the in-cluster Vault and assert it
# reports Valid. Authentication is Kubernetes auth - no Vault token is stored
# in git or in Terraform state.
set -euo pipefail

: "${ESO_NAMESPACE:?}" "${VAULT_SERVICE:?}" "${VAULT_KV_MOUNT:?}" "${VAULT_ROLE:?}" "${TIMEOUT_SECONDS:?}"
# Must match the mount: a v2 store reads <mount>/data/<key>, which does not
# exist on the kv v1 mounts the prod restore brings in.
VAULT_KV_VERSION="${VAULT_KV_VERSION:-2}"

STORE_NAME="vault-backend"

cat <<EOF | kubectl apply -f - >/dev/null
apiVersion: external-secrets.io/v1beta1
kind: ClusterSecretStore
metadata:
  name: ${STORE_NAME}
spec:
  provider:
    vault:
      server: "${VAULT_SERVICE}"
      path: "${VAULT_KV_MOUNT}"
      version: v${VAULT_KV_VERSION}
      auth:
        kubernetes:
          mountPath: "kubernetes"
          role: "${VAULT_ROLE}"
          serviceAccountRef:
            name: external-secrets
            namespace: ${ESO_NAMESPACE}
EOF

echo "ClusterSecretStore/${STORE_NAME} applied. Waiting for it to report Valid..."

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
while [[ ${SECONDS} -lt ${DEADLINE} ]]; do
  STATUS=$(kubectl get clustersecretstore "${STORE_NAME}" \
    -o jsonpath='{.status.conditions[?(@.type=="Ready")].reason}' 2>/dev/null || true)
  if [[ "${STATUS}" == "Valid" ]]; then
    echo "ClusterSecretStore/${STORE_NAME} is Valid."
    exit 0
  fi
  sleep 10
done

echo "ERROR: ClusterSecretStore/${STORE_NAME} did not reach Valid within ${TIMEOUT_SECONDS}s." >&2
kubectl describe clustersecretstore "${STORE_NAME}" >&2 || true
exit 1
