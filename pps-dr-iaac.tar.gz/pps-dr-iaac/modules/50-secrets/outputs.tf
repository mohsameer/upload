output "cluster_secret_store" {
  description = "Name of the ClusterSecretStore backed by the DR Vault."
  value       = "vault-backend"
}

output "kv_mount" {
  value = var.vault_kv_mount
}

output "rotated_roles" {
  description = "Vault static roles under automatic rotation."
  value       = keys(var.rotated_credentials)
}

output "rotation_period_seconds" {
  value = var.vault_rotation_period_seconds
}

output "completed" {
  description = "Gate consumed by Phase 6's depends_on. Set only after every ExternalSecret is synced."
  value       = null_resource.external_secrets_sync_gate.id
}
