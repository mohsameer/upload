#!/usr/bin/env bash
# Sync the external-secrets Argo CD Application early.
#
# ESO is delivered by Argo CD, not by a Helm release here, so that one owner
# manages it. Phase 4 holds auto-sync on every Application until Phase 6, but
# Phase 5 needs the CRDs and the controller before it can create a
# ClusterSecretStore - so this one Application is synced out of order.
set -euo pipefail

: "${ARGOCD_NAMESPACE:?}" "${APP_NAME:?}" "${TIMEOUT_SECONDS:?}"

kubectl -n "${ARGOCD_NAMESPACE}" get application "${APP_NAME}" >/dev/null 2>&1 || {
  echo "ERROR: Application ${APP_NAME} is not present. The Argo CD restore must"
  echo "include it, or eso_managed_by_argocd should be false." >&2
  exit 1
}

# Argo CD syncs on its own once refreshed; nudging it avoids waiting for the
# next poll.
# No revision: this Application's source is a Helm chart in an OCI registry,
# where the revision is a semver constraint and "HEAD" is rejected outright -
# "invalid revision 'HEAD': improper constraint: HEAD". Omitting it lets Argo CD
# use the Application's own targetRevision, which is what should deploy anyway.
kubectl -n "${ARGOCD_NAMESPACE}" patch application "${APP_NAME}" --type merge \
  -p '{"operation":{"initiatedBy":{"username":"pps-dr-iaac"},"sync":{"syncStrategy":{"apply":{"force":false}}}}}' >/dev/null 2>&1 || true

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
while [[ ${SECONDS} -lt ${DEADLINE} ]]; do
  # `read` returns non-zero at EOF, and under `set -e` that killed the script
  # with no output at all - which is how this phase failed one second after the
  # Argo CD restore, before the Application's .status was populated. An empty
  # status is "not ready yet", not an error.
  sync=""; health=""
  read -r sync health < <(kubectl -n "${ARGOCD_NAMESPACE}" get application "${APP_NAME}" \
    -o jsonpath='{.status.sync.status}{" "}{.status.health.status}' 2>/dev/null) || true
  if [[ "${sync}" == "Synced" && "${health}" == "Healthy" ]]; then
    echo "${APP_NAME}: Synced + Healthy."
    exit 0
  fi

  # sync=Unknown means Argo CD could not even compare against the source -
  # usually a registry login failure, which is invisible from sync/health
  # alone. Print the condition so the log says why instead of just waiting.
  if [[ "${sync}" == "Unknown" ]]; then
    kubectl -n "${ARGOCD_NAMESPACE}" get application "${APP_NAME}" \
      -o jsonpath='{range .status.conditions[*]}    {.type}: {.message}{"\n"}{end}' 2>/dev/null \
      | head -2 || true
  fi
  echo "  ${APP_NAME}: sync=${sync:-<none>} health=${health:-<none>}"
  sleep 15
done

echo "ERROR: ${APP_NAME} did not reach Synced + Healthy within ${TIMEOUT_SECONDS}s." >&2
kubectl -n "${ARGOCD_NAMESPACE}" get application "${APP_NAME}" -o yaml >&2 2>/dev/null | tail -30 || true
exit 1
