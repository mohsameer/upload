#!/usr/bin/env bash
# Point the restored per-service Capella credentials at THIS site's cluster.
#
# The Vault restore brings production's values, so every service's
# secret/<service>/capella-url reads
#   couchbases://cb.hspduwrqqqqblf19.cloud.couchbase.com
# with production's username. This site has its own Capella cluster, reachable
# on a private endpoint, and production's is firewalled from here - measured:
# port 18091 filtered from a pod, while this site's answers. Left alone, every
# service that uses Capella starts up pointed at a cluster it cannot reach and
# could not authenticate against if it could.
#
# Only the endpoint and its credentials are rewritten. Everything else the
# restore brought is left exactly as it is.
set -euo pipefail

: "${VAULT_NAMESPACE:?}" "${VAULT_TOKEN:?}" "${CAPELLA_URL:?}" "${SERVICES:?}"

CAPELLA_USERNAME="${CAPELLA_USERNAME:-}"
CAPELLA_PASSWORD="${CAPELLA_PASSWORD:-}"
ACTIVE_SERVICE="${ACTIVE_SERVICE:-vault-active}"
VAULT_LABEL="${VAULT_LABEL:-app.kubernetes.io/name=vault}"
KEY_URL="${KEY_URL:-capella-url}"
KEY_USER="${KEY_USER:-capella-username}"
KEY_PASS="${KEY_PASS:-capella-pass}"

# The active node, for the same reason vault_config.sh needs it: a standby
# answers writes with 500 "local node not active".
POD=$(kubectl -n "${VAULT_NAMESPACE}" get endpoints "${ACTIVE_SERVICE}" \
  -o jsonpath='{.subsets[0].addresses[0].targetRef.name}' 2>/dev/null || true)
if [[ -z "${POD}" ]]; then
  POD=$(kubectl -n "${VAULT_NAMESPACE}" get pods -l "${VAULT_LABEL}" \
    -o jsonpath='{range .items[?(@.status.containerStatuses[0].ready==true)]}{.metadata.name}{"\n"}{end}' 2>/dev/null | head -n1)
fi
[[ -n "${POD}" ]] || { echo "ERROR: no Vault pod available in ${VAULT_NAMESPACE}." >&2; exit 1; }

# Command text on stdin, so neither the token nor a password reaches argv.
v() { { printf 'VAULT_TOKEN=%s\nexport VAULT_TOKEN\n' "${VAULT_TOKEN}"; cat; } \
        | kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -s; }

CHANGED=0
SKIPPED=0
for svc in ${SERVICES}; do
  current=$(printf 'vault read -field=value secret/%s/%s 2>/dev/null\n' "${svc}" "${KEY_URL}" | v 2>/dev/null || true)
  if [[ -z "${current}" ]]; then
    # Not every service keeps Capella credentials; the ones that do were
    # discovered by probing, and the list is configurable.
    SKIPPED=$((SKIPPED + 1))
    continue
  fi
  if [[ "${current}" == "${CAPELLA_URL}" ]]; then
    echo "  ${svc}: already pointed at this site's Capella"
    continue
  fi

  {
    printf "vault write secret/%s/%s value='%s' >/dev/null\n" "${svc}" "${KEY_URL}" "${CAPELLA_URL}"
    [[ -n "${CAPELLA_USERNAME}" ]] && printf "vault write secret/%s/%s value='%s' >/dev/null\n" "${svc}" "${KEY_USER}" "${CAPELLA_USERNAME}"
    [[ -n "${CAPELLA_PASSWORD}" ]] && printf "vault write secret/%s/%s value='%s' >/dev/null\n" "${svc}" "${KEY_PASS}" "${CAPELLA_PASSWORD}"
  } | v >/dev/null
  echo "  ${svc}: repointed from ${current} to ${CAPELLA_URL}"
  CHANGED=$((CHANGED + 1))
done

echo "Capella endpoints repointed for ${CHANGED} service(s); ${SKIPPED} carry none."

# --- sweep every mount for any other Capella endpoint ------------------------
# The loop above only knows three key names under the services it is given, and
# that is not how the restored Vault is laid out. Four keys were still pointing
# at production after the 2026-10-12 rebuild, each under a different name and
# two under mounts that are not in the service list at all:
#
#   secret/idm/idmDirectory-capella-connection-string
#   secret/oidc-v3/couchbase.capella.connectionString
#   secret/oidcv2/passwordExpiredScopeScript-capella-url
#   secret/sage-autotermination/couchbase-url
#
# The third is the one that cost the day. jans-auth's iCrypto filter reads it
# and opens a second Couchbase connection of its own, so the auth server ran
# with the ORM correctly on this site's cluster and the filter pointed at
# production's. Capella's private endpoint routes by name, so the SNI did not
# match and every attempt came back as "AuthenticationFailureException:
# Authentication Failure" against cb.hspduwrqqqqblf19...:11207 - which reads
# like a bad password and is not one; the same credentials authenticate against
# this site's host. The auth server never became ready and took the five
# Applications that wait on it down with it.
#
# Hunting these by name is a losing game, so every key under every secret/
# mount is checked and any Capella host that is not this site's is rewritten.
# A service added later, or a key renamed, is covered without editing this file.
DR_HOST="${CAPELLA_HOST:-}"
if [[ -z "${DR_HOST}" ]]; then
  DR_HOST=$(printf '%s' "${CAPELLA_URL}" | sed -E 's#^[a-z]+://##; s#[/?].*$##; s#,.*$##')
fi
[[ -n "${DR_HOST}" ]] || {
  echo "ERROR: cannot derive this site's Capella host from CAPELLA_URL='${CAPELLA_URL}'." >&2
  exit 1
}

SWEEP_SCRIPT="$(dirname "$0")/capella_sweep_vault.sh"
[[ -s "${SWEEP_SCRIPT}" ]] || { echo "ERROR: ${SWEEP_SCRIPT} is missing." >&2; exit 1; }

# Same contract as v(): the program arrives on stdin with its inputs exported
# ahead of it, so no token or value is ever an argument.
sweep() {
  {
    printf 'VAULT_TOKEN=%s\nexport VAULT_TOKEN\n' "${VAULT_TOKEN}"
    printf 'DR_HOST=%s\nexport DR_HOST\n' "${DR_HOST}"
    printf 'MODE=%s\nexport MODE\n' "$1"
    cat "${SWEEP_SCRIPT}"
  } | kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -s
}

echo "Sweeping every Vault mount for Capella endpoints that are not ${DR_HOST}..."
sweep sweep

# A key left pointing at another site is exactly the failure this script exists
# to prevent, so it is reported here rather than left for a pod to discover
# three phases later.
REMAINING=$(sweep verify | grep -v "${DR_HOST}" || true)
if [[ -n "${REMAINING}" ]]; then
  echo "ERROR: Vault still holds Capella endpoints for another cluster:" >&2
  printf '%s\n' "${REMAINING}" | sed 's/^/  /' >&2
  exit 1
fi
echo "Every Capella endpoint in Vault now names ${DR_HOST}."
