#!/usr/bin/env bash
# Configure Vault: KV mount, Kubernetes auth, policies and the ESO role.
#
# Driven through the vault CLI inside a Vault pod rather than the terraform
# vault provider. A provider has to be configured before it can create
# anything, so pointing one at a Vault this same apply installs makes a cold
# single-shot apply impossible - and it forced vault_address to be a bastion
# port-forward, which is not created by this repo and drops when its target pod
# is replaced.
#
# Going through the CLI also sidesteps the provider/server version coupling:
# provider 4.x reads an auth mount via sys/mounts/auth/:path, which only exists
# from Vault 1.10, so it answered 405 against the restored 1.8.3 Vault.
set -euo pipefail

: "${VAULT_NAMESPACE:?}" "${VAULT_TOKEN:?}" "${KV_MOUNT:?}" "${KV_VERSION:?}" \
  "${AUTH_PATH:?}" "${ESO_ROLE:?}" "${ESO_NAMESPACE:?}" "${POLICIES_JSON:?}"

# The role's bound service account, which is not necessarily the role name.
ESO_SERVICE_ACCOUNT="${ESO_SERVICE_ACCOUNT:-external-secrets}"
# Database secrets engine, empty unless rotated_credentials is set.
ROTATED_JSON="${ROTATED_JSON:-{\}}"
DATABASE_MOUNT="${DATABASE_MOUNT:-database}"
ROTATION_PERIOD="${ROTATION_PERIOD:-86400}"

MANAGE_KV_MOUNT="${MANAGE_KV_MOUNT:-false}"
VAULT_LABEL="${VAULT_LABEL:-app.kubernetes.io/name=vault}"
TOKEN_TTL="${TOKEN_TTL:-3600}"

# The ACTIVE pod, and only once one exists.
#
# Phase 3 restores Consul, which is Vault's storage, then rolls the Vault pods
# to clear the stale lock. Leader election takes a little while afterwards, and
# a standby answers every write with
#   500 local node not active but active cluster node not found
# which is how this phase failed: a pod can be Ready and still not be the
# leader. The vault-active Service's endpoint names the leader, so ask it.
ACTIVE_SERVICE="${ACTIVE_SERVICE:-vault-active}"
VAULT_ACTIVE_WAIT="${VAULT_ACTIVE_WAIT:-300}"

POD=""
deadline=$((SECONDS + VAULT_ACTIVE_WAIT))
while [[ ${SECONDS} -lt ${deadline} ]]; do
  POD=$(kubectl -n "${VAULT_NAMESPACE}" get endpoints "${ACTIVE_SERVICE}" \
    -o jsonpath='{.subsets[0].addresses[0].targetRef.name}' 2>/dev/null || true)
  if [[ -n "${POD}" ]]; then
    # Confirm it really answers as the leader before trusting the endpoint.
    if kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -c \
         'VAULT_TOKEN="$0" vault status -format=json' "${VAULT_TOKEN}" 2>/dev/null \
         | jq -e 'if has("sealed") then (.sealed == false) else false end' >/dev/null; then
      break
    fi
  fi
  POD=""
  echo "waiting for an active Vault node..."
  sleep 10
done

if [[ -z "${POD}" ]]; then
  # Last resort: any ready pod, which is what this used to do unconditionally.
  POD=$(kubectl -n "${VAULT_NAMESPACE}" get pods -l "${VAULT_LABEL}" \
    -o jsonpath='{range .items[?(@.status.containerStatuses[0].ready==true)]}{.metadata.name}{"\n"}{end}' 2>/dev/null | head -n1)
fi
[[ -n "${POD}" ]] || { echo "ERROR: no active Vault node in ${VAULT_NAMESPACE} after ${VAULT_ACTIVE_WAIT}s." >&2; exit 1; }
echo "using Vault pod ${POD}"

# The command text arrives on stdin, and the token is exported ahead of it.
#
# Two reasons it is not `sh -c "VAULT_TOKEN=... cmd"`: a VAR=value prefix
# applies to one command only, so in `cat > f && vault policy write f` the
# write ran with no token at all and failed with "missing client token"; and
# both the token and the command were visible in ps, on the bastion and in the
# pod.
v() {
  { printf 'VAULT_TOKEN=%s\nexport VAULT_TOKEN\n' "${VAULT_TOKEN}"; cat; } \
    | kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -s
}

# Same, for the callers that have nothing to send on stdin.
vc() { printf '%s\n' "$1" | v; }

# --- KV mount ---------------------------------------------------------------
# A restored Vault already carries its mounts, and Vault refuses a mount at a
# path that prefixes existing ones, so secret/ fails when secret/<service>/
# exists.
if [[ "${MANAGE_KV_MOUNT}" == "true" ]]; then
  if vc "vault secrets list -format=json" | jq -e --arg p "${KV_MOUNT}/" 'has($p)' >/dev/null; then
    echo "kv mount ${KV_MOUNT}/ already present"
  else
    vc "vault secrets enable -path='${KV_MOUNT}' -version=${KV_VERSION} kv"
    echo "kv mount ${KV_MOUNT}/ enabled (v${KV_VERSION})"
  fi
else
  echo "kv mount not managed here (vault_manage_kv_mount=false)"
fi

# --- Kubernetes auth --------------------------------------------------------
# One more guard: the endpoint can name a leader a moment before it serves
# writes, so give the first real call a few attempts rather than failing the
# whole phase on a transient 500.
for attempt in 1 2 3 4 5 6; do
  if vc "vault auth list -format=json" >/dev/null 2>&1; then break; fi
  echo "Vault not serving yet (attempt ${attempt}); retrying in 10s..."
  sleep 10
done

if vc "vault auth list -format=json" | jq -e --arg p "${AUTH_PATH}/" 'has($p)' >/dev/null; then
  echo "auth/${AUTH_PATH} already enabled"
else
  vc "vault auth enable -path='${AUTH_PATH}' kubernetes"
  echo "auth/${AUTH_PATH} enabled"
fi

# disable_iss_validation: Vault <= 1.8 checks the service account token's iss
# claim against kubernetes/serviceaccount, but GKE issues tokens from
# https://container.googleapis.com/..., so every login fails with
# 'claim "iss" is invalid'. Vault 1.9 dropped the check.
vc "vault write auth/${AUTH_PATH}/config \
    kubernetes_host='https://kubernetes.default.svc' \
    disable_local_ca_jwt=false \
    disable_iss_validation=true" >/dev/null
echo "auth/${AUTH_PATH}/config written"

# --- policies ---------------------------------------------------------------
# mapfile, not a pipe into `while read`: v() runs kubectl, which reads stdin,
# and inside a piped loop it drains the remaining rows - every row after the
# first was silently skipped.
mapfile -t POLICY_ROWS < <(echo "${POLICIES_JSON}" | jq -r 'to_entries[] | @base64')
for row in "${POLICY_ROWS[@]}"; do
  name=$(echo "${row}" | base64 -d | jq -r '.key')
  body=$(echo "${row}" | base64 -d | jq -r '.value')
  # The policy body travels inside a quoted heredoc, so HCL quoting is left
  # alone and nothing of it reaches a shell word.
  {
    echo "cat > /tmp/pol.hcl <<'VAULTPOLICY'"
    printf '%s\n' "${body}"
    echo "VAULTPOLICY"
    printf "vault policy write '%s' /tmp/pol.hcl\n" "${name}"
    echo "rm -f /tmp/pol.hcl"
  } | v >/dev/null
  echo "policy ${name} written"
done

# --- ESO role ---------------------------------------------------------------
vc "vault write auth/${AUTH_PATH}/role/${ESO_ROLE} \
    bound_service_account_names='${ESO_SERVICE_ACCOUNT}' \
    bound_service_account_namespaces='${ESO_NAMESPACE}' \
    token_policies='${ESO_ROLE}' \
    token_ttl=${TOKEN_TTL}" >/dev/null
echo "auth/${AUTH_PATH}/role/${ESO_ROLE} written"

# --- database secrets engine (auto-rotation) ---------------------------------
# Empty until PPS supplies the real credential set; the wiring is here so that
# adding an entry to rotated_credentials is the only change needed.
if [[ "$(echo "${ROTATED_JSON}" | jq 'length')" -gt 0 ]]; then
  if vc "vault secrets list -format=json" | jq -e --arg p "${DATABASE_MOUNT}/" 'has($p)' >/dev/null; then
    echo "database mount ${DATABASE_MOUNT}/ already present"
  else
    vc "vault secrets enable -path='${DATABASE_MOUNT}' database"
    echo "database mount ${DATABASE_MOUNT}/ enabled"
  fi

  mapfile -t ROTATED_ROWS < <(echo "${ROTATED_JSON}" | jq -r 'to_entries[] | @base64')
  for row in "${ROTATED_ROWS[@]}"; do
    name=$(echo "${row}" | base64 -d | jq -r '.key')
    url=$(echo "${row}" | base64 -d | jq -r '.value.db_connection_url')
    user=$(echo "${row}" | base64 -d | jq -r '.value.db_username')
    # A connection URL carries a password and can contain a quote, so the
    # values go through the remote shell's own variables rather than being
    # pasted into a single-quoted command.
    {
      echo "cat > /tmp/dbvals <<'DBVALS'"
      printf '%s\n%s\n%s\n' "${name}" "${url}" "${user}"
      echo "DBVALS"
      echo 'NAME=$(sed -n 1p /tmp/dbvals); URL=$(sed -n 2p /tmp/dbvals); USER=$(sed -n 3p /tmp/dbvals)'
      echo 'vault write "'"${DATABASE_MOUNT}"'/config/${NAME}" plugin_name=postgresql-database-plugin allowed_roles="${NAME}" connection_url="${URL}" username="${USER}"'
      echo 'vault write "'"${DATABASE_MOUNT}"'/static-roles/${NAME}" db_name="${NAME}" username="${USER}" rotation_period='"${ROTATION_PERIOD}"
      echo 'rm -f /tmp/dbvals'
    } | v >/dev/null
    echo "static role ${DATABASE_MOUNT}/${name} written"
  done
else
  echo "no rotated credentials configured"
fi

echo "Vault configuration complete."
