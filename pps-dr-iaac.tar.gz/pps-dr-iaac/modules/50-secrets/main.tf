# Phase 5 - secrets.
#
# Terraform configures Vault and installs ESO. It never reads an application
# secret value: ESO resolves those at runtime, so no secret material lands in
# Terraform state or in an output.

locals {
  # KV v2 splits a secret into data/ and metadata/ subpaths; v1 addresses it
  # directly. The restored prod Vault mounts kv v1 per service under secret/,
  # so a v2-shaped path grants nothing at all there.
  kv_read = var.vault_kv_version == 2 ? format(<<-EOT
    path "%[1]s/data/*" {
      capabilities = ["read", "list"]
    }
    path "%[1]s/metadata/*" {
      capabilities = ["read", "list"]
    }
  EOT
    , var.vault_kv_mount) : format(<<-EOT
    path "%[1]s/*" {
      capabilities = ["read", "list"]
    }
  EOT
  , var.vault_kv_mount)

  default_policies = {
    # Read-only policy the SSO services use (carried over from the v1
    # all-read.hcl).
    "all-read" = local.kv_read

    # ESO needs the same read access plus token self-renewal.
    "${var.eso_vault_role}" = <<-EOT
      ${local.kv_read}
      path "auth/token/renew-self" {
        capabilities = ["update"]
      }
    EOT
  }

  policies = merge(local.default_policies, var.vault_policies)

  eso_values = templatefile("${path.module}/values/external-secrets.yaml.tftpl", {})
}

# --- Vault: engines, auth, policies ----------------------------------------
#
# Driven through the vault CLI inside the Vault pod, not the terraform vault
# provider. A provider is configured before any resource in the apply runs, so
# one pointed at a Vault that this same apply installs cannot work - that is
# what kept the DR build from being a single pass. It also needed
# vault_address to be a bastion port-forward this repo does not create, and
# provider 4.x spoke a protocol the restored Vault 1.8.3 answers with 405.
resource "null_resource" "vault_config" {
  triggers = {
    policies       = md5(jsonencode(local.policies))
    auth_path      = "kubernetes"
    eso_role       = var.eso_vault_role
    eso_namespace  = var.external_secrets_namespace
    rotation       = tostring(var.vault_rotation_period_seconds)
    database_mount = var.database_mount_path
    kv             = "${var.vault_kv_mount}|${var.vault_kv_version}|${var.vault_manage_kv_mount}"
    rotated        = md5(jsonencode(var.rotated_credentials))
    script         = filemd5("${path.module}/vault_config.sh")
  }

  provisioner "local-exec" {
    command     = "./vault_config.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG          = pathexpand(var.kubeconfig_path)
      VAULT_NAMESPACE     = var.platform_namespace
      VAULT_TOKEN         = var.vault_root_token
      KV_MOUNT            = var.vault_kv_mount
      KV_VERSION          = tostring(var.vault_kv_version)
      MANAGE_KV_MOUNT     = tostring(var.vault_manage_kv_mount)
      AUTH_PATH           = "kubernetes"
      ESO_ROLE            = var.eso_vault_role
      ESO_SERVICE_ACCOUNT = "external-secrets"
      ESO_NAMESPACE       = var.external_secrets_namespace
      POLICIES_JSON       = jsonencode(local.policies)
      ROTATED_JSON        = jsonencode(var.rotated_credentials)
      DATABASE_MOUNT      = var.database_mount_path
      ROTATION_PERIOD     = tostring(var.vault_rotation_period_seconds)
    }
  }
}

# The Vault restore brings production's Capella endpoint and credentials for
# every service that uses it. This site has its own cluster, and production's
# is firewalled from here, so they are repointed before any application starts.
# Not gated on capella_credential_services any more. The sweep inside the
# script has to run wherever a Capella endpoint might be recorded, and the four
# keys it caught on 2026-10-12 sat under names and mounts that list does not
# cover - including secret/sage-autotermination/, which is not a service at all.
resource "null_resource" "capella_endpoints" {
  count = var.capella_connection_string != "" ? 1 : 0

  triggers = {
    services     = join(",", var.capella_credential_services)
    connection   = var.capella_connection_string
    username     = var.couchbase_username
    vault        = null_resource.vault_config.id
    script       = filemd5("${path.module}/capella_endpoint_override.sh")
    sweep_script = filemd5("${path.module}/capella_sweep_vault.sh")
  }

  provisioner "local-exec" {
    command     = "./capella_endpoint_override.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      VAULT_NAMESPACE  = var.platform_namespace
      VAULT_TOKEN      = var.vault_root_token
      SERVICES         = join(" ", var.capella_credential_services)
      CAPELLA_URL      = var.capella_connection_string
      CAPELLA_USERNAME = var.couchbase_username
      CAPELLA_PASSWORD = var.couchbase_password
    }
  }
}

# The restored Vault holds the source site's database credentials, and they do
# not work here: midPoint died on "FATAL: password authentication failed for
# user postgres", and oidc-mgmt-portal's URL names oidc_user, a role this
# instance does not have because no globals are restored.
resource "null_resource" "postgres_credentials" {
  count = length(var.postgres_credential_overrides) > 0 && var.postgres_app_password != "" ? 1 : 0

  triggers = {
    overrides = jsonencode(var.postgres_credential_overrides)
    user      = var.postgres_app_user
    vault     = null_resource.vault_config.id
    script    = filemd5("${path.module}/postgres_credential_override.sh")
  }

  provisioner "local-exec" {
    command     = "./postgres_credential_override.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      VAULT_NAMESPACE = var.platform_namespace
      VAULT_TOKEN     = var.vault_root_token
      PG_USER         = var.postgres_app_user
      PG_PASSWORD     = var.postgres_app_password
      OVERRIDES       = join(" ", [for path, kind in var.postgres_credential_overrides : "${path}:${kind}"])
    }
  }

  depends_on = [null_resource.vault_config]
}

# token-exchange-service trusts exactly the LDAP certificate recorded in its
# own KV entry, and the PPS LDAP image mints a new self-signed one on every
# container start (its certs directory is a memory-backed emptyDir), so the
# restored value is always stale. Runs on every build: triggers carry the
# vault_config id, so a rebuild - which replaces that resource - replays this.
# The restored Vault names production's Capella account and hosts. See
# vault_overrides.sh for what each override fixes.
resource "null_resource" "vault_overrides" {
  count = length(var.vault_kv_overrides) > 0 || length(var.vault_kv_couchbase_overrides) > 0 ? 1 : 0

  triggers = {
    overrides = jsonencode(var.vault_kv_overrides)
    couchbase = jsonencode(var.vault_kv_couchbase_overrides)
    username  = var.couchbase_username
    password  = sha256(var.couchbase_password)
    restarts  = join(",", var.vault_overrides_restart_workloads)
    vault     = null_resource.vault_config.id
    script    = filemd5("${path.module}/vault_overrides.sh")
  }

  provisioner "local-exec" {
    command     = "./vault_overrides.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG         = pathexpand(var.kubeconfig_path)
      VAULT_NAMESPACE    = var.platform_namespace
      VAULT_TOKEN        = var.vault_root_token
      KV_OVERRIDES       = join("\n", [for p, v in var.vault_kv_overrides : "${p}=${v}"])
      KV_COUCHBASE       = join("\n", [for p, w in var.vault_kv_couchbase_overrides : "${p}=${w}"])
      COUCHBASE_USERNAME = var.couchbase_username
      COUCHBASE_PASSWORD = var.couchbase_password
      RESTART_WORKLOADS  = join("\n", var.vault_overrides_restart_workloads)
    }
  }

  depends_on = [null_resource.vault_config]
}

resource "null_resource" "ldap_cert_vault" {
  count = var.ldap_cert_vault_path != "" && var.ldap_pod != "" ? 1 : 0

  triggers = {
    kv_path   = var.ldap_cert_vault_path
    ldap      = "${var.ldap_namespace}/${var.ldap_pod}:${var.ldap_cert_path}"
    overrides = jsonencode(var.ldap_cert_vault_overrides)
    restarts  = join(",", var.ldap_cert_restart_workloads)
    vault     = null_resource.vault_config.id
    script    = filemd5("${path.module}/ldap_cert_vault.sh")
  }

  provisioner "local-exec" {
    command     = "./ldap_cert_vault.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG        = pathexpand(var.kubeconfig_path)
      VAULT_NAMESPACE   = var.platform_namespace
      VAULT_TOKEN       = var.vault_root_token
      LDAP_NAMESPACE    = var.ldap_namespace
      LDAP_POD          = var.ldap_pod
      LDAP_CERT_PATH    = var.ldap_cert_path
      KV_CERT_PATH      = var.ldap_cert_vault_path
      KV_OVERRIDES      = join("\n", [for p, v in var.ldap_cert_vault_overrides : "${p}=${v}"])
      RESTART_WORKLOADS = join("\n", var.ldap_cert_restart_workloads)
    }
  }

  depends_on = [null_resource.vault_config]
}

# --- External Secrets Operator ---------------------------------------------

resource "null_resource" "external_secrets" {
  count = var.eso_managed_by_argocd ? 0 : 1

  triggers = {
    release    = "external-secrets"
    namespace  = var.external_secrets_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
    chart      = "${var.eso_chart_repository}|external-secrets|${var.eso_chart_version}"
    values     = md5(local.eso_values)
    script     = filemd5("${path.module}/../common/helm_apply.sh")
  }

  provisioner "local-exec" {
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      RELEASE          = "external-secrets"
      NAMESPACE        = var.external_secrets_namespace
      REPO             = var.eso_chart_repository
      CHART            = "external-secrets"
      VERSION          = var.eso_chart_version
      ECR_ACCESS_KEY   = var.ecr_access_key
      ECR_SECRET_KEY   = var.ecr_secret_key
      VALUES_CONTENT   = local.eso_values
      CREATE_NAMESPACE = "true"
      WAIT             = "true"
      TIMEOUT_SECONDS  = tostring(var.readiness_timeout_seconds)
    }
  }
}

# ESO is delivered by the Argo CD Application instead of a Helm release here,
# so a single owner manages it. Phase 4 holds auto-sync until Phase 6, but this
# phase needs the CRDs and controller first, so this one Application is synced
# out of order.
resource "null_resource" "eso_sync" {
  count = var.eso_managed_by_argocd ? 1 : 0

  triggers = {
    app    = var.eso_application_name
    script = filemd5("${path.module}/eso_sync.sh")
  }

  provisioner "local-exec" {
    command     = "./eso_sync.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      ARGOCD_NAMESPACE = var.argocd_namespace
      APP_NAME         = var.eso_application_name
      TIMEOUT_SECONDS  = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "eso_ready" {
  triggers = {
    source = var.eso_managed_by_argocd ? join(",", [for r in null_resource.eso_sync : r.id]) : join(",", [for r in null_resource.external_secrets : r.id])
    script = filemd5("${path.module}/eso_ready.sh")
  }

  provisioner "local-exec" {
    command     = "./eso_ready.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.external_secrets_namespace
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

# ClusterSecretStore pointing at the in-cluster Vault. Authentication is
# Kubernetes-auth: no token is committed anywhere.
resource "null_resource" "cluster_secret_store" {
  triggers = {
    eso_id     = null_resource.eso_ready.id
    vault_role = var.eso_vault_role
    kv_mount   = var.vault_kv_mount
    kv_version = var.vault_kv_version
    manifest   = filemd5("${path.module}/cluster_secret_store.sh")
  }

  provisioner "local-exec" {
    command     = "./cluster_secret_store.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      ESO_NAMESPACE    = var.external_secrets_namespace
      VAULT_SERVICE    = "http://vault.${var.platform_namespace}.svc:8200"
      VAULT_KV_MOUNT   = var.vault_kv_mount
      VAULT_KV_VERSION = tostring(var.vault_kv_version)
      VAULT_ROLE       = var.eso_vault_role
      TIMEOUT_SECONDS  = tostring(var.readiness_timeout_seconds)
    }
  }

  depends_on = [null_resource.vault_config]
}

# The application pods mount Vault AppRole credentials plus a Consul token and
# an AWS key pair. Nothing else creates them: the Vault restore brings the roles
# but not the Kubernetes Secrets, so without this every app pod stays in
# Init:0/1 and Phase 6 can never converge.
resource "null_resource" "app_credentials" {
  count = length(var.vault_approle_secrets) > 0 || length(var.capella_credential_secrets) > 0 ? 1 : 0

  triggers = {
    approles   = jsonencode(var.vault_approle_secrets)
    capella    = jsonencode(var.capella_credential_secrets)
    namespaces = join(",", var.app_credential_namespaces)
    script     = filemd5("${path.module}/app_credentials.sh")
  }

  provisioner "local-exec" {
    command     = "./app_credentials.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG            = pathexpand(var.kubeconfig_path)
      VAULT_NAMESPACE       = var.platform_namespace
      VAULT_TOKEN           = var.vault_root_token
      APPROLE_MAP           = join(" ", [for name, cfg in var.vault_approle_secrets : "${cfg.namespace}:${name}:${cfg.role}:${cfg.layout}:${cfg.mount}"])
      CAPELLA_SECRETS       = join(" ", [for target, cfg in var.capella_credential_secrets : "${target}:${cfg.username_key}:${cfg.password_key}"])
      CAPELLA_USERNAME      = var.couchbase_username
      CAPELLA_PASSWORD      = var.couchbase_password
      SHARED_NAMESPACES     = join(" ", var.app_credential_namespaces)
      CONSUL_TOKEN          = var.app_consul_token
      AWS_ACCESS_KEY_ID     = var.ecr_access_key
      AWS_SECRET_ACCESS_KEY = var.ecr_secret_key
    }
  }

  depends_on = [null_resource.vault_config]
}

# Phase 5's sign-off check: every ExternalSecret in the target namespaces must
# be synced before any application is allowed to sync.
resource "null_resource" "external_secrets_sync_gate" {
  triggers = {
    store_id   = null_resource.cluster_secret_store.id
    overrides  = join(",", [for r in null_resource.vault_overrides : r.id])
    app_creds  = join(",", [for r in null_resource.app_credentials : r.id])
    namespaces = join(",", var.eso_target_namespaces)
    script     = filemd5("${path.module}/sync_gate.sh")
  }

  provisioner "local-exec" {
    command     = "./sync_gate.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG           = pathexpand(var.kubeconfig_path)
      TARGET_NAMESPACES    = join(" ", var.eso_target_namespaces)
      TIMEOUT_SECONDS      = tostring(var.readiness_timeout_seconds)
      MIN_EXTERNAL_SECRETS = tostring(var.min_external_secrets)
    }
  }
}

# --- uninstalls -------------------------------------------------------------
# The uninstall of each release lives in its own resource, deliberately.
#
# `triggers` is ForceNew: with the destroy provisioner on the install resource,
# any trigger change - a new chart version, edited values, even an edit to
# helm_apply.sh, whose checksum is a trigger - replaces the resource, and a
# replacement runs the destroy provisioner first. Editing that one script would
# have run `helm uninstall` against Consul (Vault's storage backend), Vault,
# OpenLDAP and Argo CD on a live site before reinstalling them.
#
# Here the uninstall resources carry only stable triggers, so they are never
# replaced, and a change to an install resource is just an idempotent
# `helm upgrade --install`. depends_on gives the right destroy order: Terraform
# destroys in reverse dependency order, so the uninstall runs before the
# install resource it depends on is removed.

resource "null_resource" "external_secrets_uninstall" {
  count = var.eso_managed_by_argocd ? 0 : 1

  triggers = {
    release    = "external-secrets"
    namespace  = var.external_secrets_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.external_secrets]
}
