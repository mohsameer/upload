#!/usr/bin/env bash
# Phase 5 - point the restored Vault values that name the SOURCE site at this one.
#
# The Vault restore brings production's values. Most are right on DR; a few name
# something that does not exist or cannot be reached from here, and the service
# that reads them fails at start-up in a way that looks like an application bug:
#
#   secret/idm/idmDirectory-capella-user / -capella-password
#       production's Capella account. The host is rewritten to DR's by the Capella
#       step, the account is not, so the IdM Directory resource's Test connection
#       fails with "Failed to retrieve test data from couchbase".
#   secret/idm/trueLDAP-host, secret/idm/pro-fit-serviceHost
#       trueldap-az1.pps.co.za, which does not resolve here (UnknownHostException).
#   secret/idm/mfa-domain
#       https://mfa.pps.co.za, which does not resolve here. The MFA resource's
#       serviceAddress is rendered from it; the in-cluster Service is the target.
#
# Two kinds of override, both "write only when different":
#   KV_OVERRIDES    path=value               a plain value
#   KV_COUCHBASE    path=username|password   the DR Capella account, taken from the
#                                            environment so the password never
#                                            appears in a tfvars file or in argv
#
# Only the value of each named key is written. Nothing else the restore brought is
# touched. Runs before Phase 6 syncs the applications, so a fresh build starts them
# with the right values. On a live site the readers have already started: set
# RESTART_WORKLOADS (namespace/kind/name, one per line) to restart them when a
# value actually changed.
set -euo pipefail

: "${VAULT_NAMESPACE:?}" "${VAULT_TOKEN:?}"
KV_OVERRIDES="${KV_OVERRIDES:-}"
KV_COUCHBASE="${KV_COUCHBASE:-}"
COUCHBASE_USERNAME="${COUCHBASE_USERNAME:-}"
COUCHBASE_PASSWORD="${COUCHBASE_PASSWORD:-}"
RESTART_WORKLOADS="${RESTART_WORKLOADS:-}"
ACTIVE_SERVICE="${ACTIVE_SERVICE:-vault-active}"
VAULT_LABEL="${VAULT_LABEL:-app.kubernetes.io/name=vault}"
KV_FIELD="${KV_FIELD:-value}"

if [[ -z "${KV_OVERRIDES//[[:space:]]/}" && -z "${KV_COUCHBASE//[[:space:]]/}" ]]; then
  echo "vault_overrides: nothing configured."
  exit 0
fi

POD=""
for _ in $(seq 1 60); do
  POD=$(kubectl -n "${VAULT_NAMESPACE}" get endpoints "${ACTIVE_SERVICE}" \
    -o jsonpath='{.subsets[0].addresses[0].targetRef.name}' 2>/dev/null || true)
  [[ -n "${POD}" ]] && break
  echo "waiting for an active Vault node..."
  sleep 5
done
[[ -n "${POD}" ]] || { echo "ERROR: no active Vault node in ${VAULT_NAMESPACE}." >&2; exit 1; }

# Command text on stdin, so neither the token nor a value reaches argv.
v() { { printf 'VAULT_TOKEN=%s\nexport VAULT_TOKEN\n' "${VAULT_TOKEN}"; cat; } | kubectl -n "${VAULT_NAMESPACE}" exec -i "${POD}" -- sh -s 2>/dev/null; }
current() { printf "vault read -field='%s' '%s' 2>/dev/null\n" "${KV_FIELD}" "$1" | v || true; }
# Stored size in bytes. $(...) drops a trailing newline, so comparing text alone
# cannot tell "value" from "value\n" - and a newline inside a Vault value breaks
# whatever renders it into JSON (the oidc-v3 realm import crashed on it).
current_bytes() { printf "vault read -field='%s' '%s' 2>/dev/null | wc -c\n" "${KV_FIELD}" "$1" | v | tr -d '[:space:]' || true; }
# The value is written without the newline the here-document adds, because
# "vault write key=@file" stores the file byte for byte.
write_kv() {
  {
    echo "cat > /tmp/kvov.raw <<'KVVALUE'"
    printf '%s\n' "$2"
    echo "KVVALUE"
    echo "printf '%s' \"\$(cat /tmp/kvov.raw)\" > /tmp/kvov"
    printf "vault write '%s' '%s'=@/tmp/kvov >/dev/null\n" "$1" "${KV_FIELD}"
    echo "rm -f /tmp/kvov /tmp/kvov.raw"
  } | v >/dev/null
}

CHANGED=0
apply() {
  local path="$1" want="$2" label="$3" have have_bytes want_bytes
  have=$(current "${path}")
  have_bytes=$(current_bytes "${path}")
  want_bytes=$(printf '%s' "${want}" | wc -c | tr -d '[:space:]')
  if [[ "${have}" == "${want}" && "${have_bytes}" == "${want_bytes}" ]]; then
    echo "  ${path}: already set${label:+ (${label})}"
    return 0
  fi
  write_kv "${path}" "${want}"
  CHANGED=$((CHANGED + 1))
  echo "  ${path}: updated${label:+ (${label})}"
}

while IFS= read -r line; do
  [[ -z "${line//[[:space:]]/}" ]] && continue
  apply "${line%%=*}" "${line#*=}" ""
done <<<"${KV_OVERRIDES}"

while IFS= read -r line; do
  [[ -z "${line//[[:space:]]/}" ]] && continue
  path="${line%%=*}"; what="${line#*=}"
  case "${what}" in
    username) val="${COUCHBASE_USERNAME}" ;;
    password) val="${COUCHBASE_PASSWORD}" ;;
    *) echo "ERROR: '${line}': expected path=username or path=password" >&2; exit 1 ;;
  esac
  if [[ -z "${val}" ]]; then
    echo "  ${path}: skipped - the DR Capella ${what} is not set"
    continue
  fi
  apply "${path}" "${val}" "DR Capella ${what}"
done <<<"${KV_COUCHBASE}"

echo "vault_overrides: ${CHANGED} value(s) changed."

if [[ "${CHANGED}" -gt 0 && -n "${RESTART_WORKLOADS//[[:space:]]/}" ]]; then
  while IFS= read -r w; do
    [[ -z "${w//[[:space:]]/}" ]] && continue
    ns="${w%%/*}"; rest="${w#*/}"; kind="${rest%%/*}"; name="${rest#*/}"
    echo "  restarting ${ns}/${kind}/${name}"
    kubectl -n "${ns}" rollout restart "${kind}/${name}" >/dev/null 2>&1 || echo "  (could not restart ${w}; not deployed yet?)"
  done <<<"${RESTART_WORKLOADS}"
fi
