variable "external_secrets_namespace" {
  type = string
}

variable "platform_namespace" {
  type = string
}

variable "eso_chart_version" {
  type = string
}

variable "eso_vault_role" {
  type = string
}

variable "eso_target_namespaces" {
  type        = list(string)
  description = "Namespaces whose ExternalSecrets must reach SecretSynced before Phase 6 runs."
}

variable "vault_manage_kv_mount" {
  type = bool
}

variable "vault_kv_version" {
  type = number
}

variable "vault_kv_mount" {
  type = string
}

variable "vault_rotation_period_seconds" {
  type = number
}

variable "kubeconfig_path" {
  type = string
}

variable "readiness_timeout_seconds" {
  type = number
}

variable "eso_chart_repository" {
  type    = string
  default = "https://charts.external-secrets.io"
}

variable "vault_policies" {
  type        = map(string)
  description = "Vault policy name -> HCL policy document. Defaults cover the read-only policy the SSO services use."
  default     = {}
}

variable "rotated_credentials" {
  type = map(object({
    db_connection_url = string
    db_username       = string
    plugin_name       = string
  }))
  description = <<-EOT
    Database credentials Vault rotates automatically, keyed by static role name.
    Empty by default: the real set arrives with the PPS values. Each entry
    becomes a database secrets engine connection plus a static role whose
    rotation_period is vault_rotation_period_seconds.
  EOT
  default     = {}
}

variable "database_mount_path" {
  type    = string
  default = "database"
}

variable "vault_approle_secrets" {
  type = map(object({
    namespace = string
    role      = string
    layout    = optional(string, "pair")
    mount     = optional(string, "approle")
  }))
}

variable "app_credential_namespaces" {
  type = list(string)
}

variable "app_consul_token" {
  type      = string
  sensitive = true
}

variable "vault_root_token" {
  type      = string
  sensitive = true
}

variable "ecr_access_key" {
  type      = string
  sensitive = true
}

variable "ecr_secret_key" {
  type      = string
  sensitive = true
}

variable "eso_managed_by_argocd" {
  type = bool
}

variable "eso_application_name" {
  type = string
}

variable "argocd_namespace" {
  type = string
}

variable "capella_credential_services" {
  type        = list(string)
  default     = []
  description = "Services whose Vault capella-url/username/pass are repointed at this site's Capella."
}

variable "capella_connection_string" {
  type        = string
  default     = ""
  description = "This site's Capella connection string."
}

variable "couchbase_username" {
  type        = string
  default     = ""
  description = "This site's Capella username."
}

variable "couchbase_password" {
  type        = string
  default     = ""
  sensitive   = true
  description = "This site's Capella password."
}

variable "capella_credential_secrets" {
  type = map(object({
    username_key = string
    password_key = string
  }))
  default     = {}
  description = "\"namespace/secret-name\" -> keys holding this site's Capella username and password, for charts that read them from their own Secret."
}

variable "postgres_credential_overrides" {
  type        = map(string)
  default     = {}
  description = "Vault path -> kind (password|username|url) for the restored database credentials that must name this site's instance."
}

variable "postgres_app_user" {
  type        = string
  default     = "postgres"
  description = "Database role the applications connect as on this site."
}

variable "postgres_app_password" {
  type        = string
  default     = ""
  sensitive   = true
  description = "Password for postgres_app_user. Empty skips the rewrite."
}

variable "min_external_secrets" {
  type        = number
  default     = 0
  description = <<-EOT
    Fewest ExternalSecrets the Phase 5 gate must see before it passes.

    Zero, and it has to be: the ExternalSecret objects are created by the Argo
    CD Applications, which sync in Phase 6 - and Phase 6 waits for Phase 5. A
    non-zero minimum here deadlocks the build, which is what happened on the
    2026-10-12 rebuild: the gate sat at "All 0 ExternalSecret(s)" waiting for
    objects that could not exist until it had already passed.

    An adversarial review flagged the 0 default as "the gate's safety net is
    not wired up", and in isolation that reads correctly - a gate that always
    passes checks nothing. But the invariant available at this point is not
    "some secrets exist", it is "ESO is running and every ExternalSecret that
    does exist is synced", which is what the gate actually asserts. Requiring a
    count would only be meaningful in a check that runs after Phase 6.
  EOT
}

variable "vault_kv_overrides" {
  type        = map(string)
  default     = {}
  description = "Restored Vault values that name the source site, as KV path -> value. Written only when different. See vault_overrides.sh."
}

variable "vault_kv_couchbase_overrides" {
  type        = map(string)
  default     = {}
  description = "KV path -> \"username\" or \"password\": set to the DR Capella account (couchbase_username / couchbase_password)."
}

variable "vault_overrides_restart_workloads" {
  type        = list(string)
  default     = []
  description = "Workloads restarted when an override actually changed a value, as namespace/kind/name. Empty on a cold build, where the readers have not started yet."
}

variable "ldap_cert_vault_path" {
  type        = string
  default     = ""
  description = "KV path holding the LDAP certificate token-exchange-service trusts, e.g. secret/token-exchange-service/ldap-certPem. Empty skips the step."
}

variable "ldap_namespace" {
  type        = string
  default     = ""
  description = "Namespace of the LDAP release the certificate is read from."
}

variable "ldap_pod" {
  type        = string
  default     = ""
  description = "LDAP pod the certificate is read from."
}

variable "ldap_cert_path" {
  type        = string
  default     = "/opt/bitnami/openldap/certs/openldap.crt"
  description = "Certificate file inside the LDAP container. Bitnami layout, which the PPS image follows."
}

variable "ldap_cert_vault_overrides" {
  type        = map(string)
  default     = {}
  description = "Sibling KV entries written with the certificate, as path -> value. The restored ldap-host and ldap-port name the source site's LDAP, so the certificate alone leaves the bind failing on connect."
}

variable "ldap_cert_restart_workloads" {
  type        = list(string)
  default     = []
  description = "Workloads restarted when the stored certificate changes, as namespace/kind/name. They read the KV entry at startup, so one that came up before the write keeps the old certificate."
}
