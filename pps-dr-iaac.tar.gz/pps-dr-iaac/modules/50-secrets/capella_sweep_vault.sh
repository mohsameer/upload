# Runs INSIDE the Vault pod (POSIX sh, no jq): rewrite every Capella host in
# every secret/ mount to this site's, then report what is left.
#
# Fed to `kubectl exec -i ... -- sh -s` with VAULT_TOKEN, DR_HOST and MODE
# exported ahead of it, so neither the token nor a value reaches argv. One
# program per run: a kubectl exec per key would be hundreds of round trips.
#
# MODE=sweep   rewrite and print what changed
# MODE=verify  print "<path> <value>" for every Capella endpoint found
changed=0
checked=0
mounts=$(vault secrets list 2>/dev/null | awk '$1 ~ /^secret\// { print $1 }')

for m in ${mounts}; do
  keys=$(vault kv list "${m}" 2>/dev/null | sed -e '1,2d')
  for k in ${keys}; do
    # A nested path, not a key.
    case "${k}" in
      */) continue ;;
    esac

    val=$(vault read -field=value "${m}${k}" 2>/dev/null) || continue
    [ -z "${val}" ] && continue
    checked=$(( checked + 1 ))

    case "${val}" in
      *.cloud.couchbase.com*) ;;
      *) continue ;;
    esac

    if [ "${MODE}" = "verify" ]; then
      echo "${m}${k} ${val}"
      continue
    fi

    # Only the host is replaced, so a scheme, port, parameters or a
    # comma-separated node list all survive.
    new=$(printf '%s' "${val}" | sed -E "s#cb\.[a-zA-Z0-9-]+\.cloud\.couchbase\.com#${DR_HOST}#g")
    [ "${new}" = "${val}" ] && continue

    # An empty result is not equal to the old value, so the check above lets it
    # through - and `vault write value=` would then blank a live endpoint while
    # this printed "repointed". There is no set -e here (the program is piped
    # into `sh -s`), so sed failing is not otherwise caught.
    if [ -z "${new}" ]; then
      echo "  FAILED to rewrite ${m}${k}: the substitution produced nothing" >&2
      continue
    fi

    # `vault write` replaces the whole secret rather than merging, so a key
    # that holds more than the one field would lose the rest. Skip those loudly
    # instead of quietly destroying them.
    # `vault read` on a kv v1 path always prints refresh_interval as a row, so
    # a naive "any field other than value?" test sees one on EVERY key and
    # skips the lot - which is exactly what happened: the sweep repointed
    # nothing and the verify step below caught it.
    others=$(vault read "${m}${k}" 2>/dev/null \
      | awk 'NR>2 { print $1 }' \
      | grep -vE '^(value|refresh_interval|lease_duration|lease_id|renewable|---|$)' \
      | head -3)
    if [ -n "${others}" ]; then
      echo "  SKIPPED ${m}${k}: it also holds $(echo ${others} | tr '\n' ' ')- writing would drop them" >&2
      continue
    fi

    if vault write "${m}${k}" value="${new}" >/dev/null 2>&1; then
      echo "  repointed ${m}${k}"
      changed=$(( changed + 1 ))
    else
      echo "  FAILED to write ${m}${k}" >&2
    fi
  done
done

[ "${MODE}" = "verify" ] || echo "sweep: ${changed} key(s) repointed, ${checked} checked"
