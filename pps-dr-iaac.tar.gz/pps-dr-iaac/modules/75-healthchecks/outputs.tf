output "report_path" {
  description = "Healthcheck report on the bastion. Written on success and failure."
  value       = var.report_path
}

output "completed" {
  value = null_resource.healthchecks.id
}
