# Stage 8 - healthcheck validation of what is running on DR.
#
# The catalog is what QA's own readiness probes say "healthy" means. Only the
# workloads that are deployed on DR (and scaled above 0) are checked; the rest
# are reported as skipped. See healthchecks.sh.
#
# To run it again on a site that has not changed:
#   tofu apply -replace=module.healthchecks[0].null_resource.healthchecks -var-file=pps-dr.tfvars
# or, without OpenTofu, scripts/dr_healthcheck.sh.

resource "null_resource" "healthchecks" {
  triggers = {
    gate    = var.gate
    catalog = filemd5(var.catalog_file)
    script  = filemd5("${path.module}/healthchecks.sh")
    skip    = join(",", var.skip_workloads)
    image   = var.probe_image
    fail    = tostring(var.fail_on_error)
  }

  provisioner "local-exec" {
    command     = "./healthchecks.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      CATALOG         = abspath(var.catalog_file)
      PROBE_IMAGE     = var.probe_image
      PROBE_NAMESPACE = var.probe_namespace
      TIMEOUT_SECONDS = tostring(var.timeout_seconds)
      SKIP_WORKLOADS  = join(" ", var.skip_workloads)
      FAIL_ON_ERROR   = tostring(var.fail_on_error)
      REPORT_PATH     = abspath(var.report_path)
    }
  }
}
