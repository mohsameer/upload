#!/usr/bin/env bash
# Stage 8 - healthcheck validation of the workloads running on DR.
#
# The catalog (healthchecks.json) is collected from QA by
# scripts/collect_healthchecks.sh: one entry per QA workload that has a
# readiness probe. This runs only the entries whose workload is actually
# deployed on DR:
#
#   not deployed on DR            -> skipped, never a failure
#   deployed but scaled to 0      -> skipped
#   in SKIP_WORKLOADS             -> skipped
#   deployed with replicas > 0    -> checked, and a failure fails the phase
#
# An HTTP check is curl'ed from a short-lived pod inside the cluster, through
# the workload's Service when DR has one and straight to a Ready pod's IP when
# it does not. An exec check runs the probe command inside the workload. Each
# check retries until TIMEOUT_SECONDS, since the apps have only just converged.
#
# The report is written on success and failure alike.
set -uo pipefail

: "${CATALOG:?}" "${REPORT_PATH:?}" "${PROBE_IMAGE:?}"

PROBE_NAMESPACE="${PROBE_NAMESPACE:-default}"
TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-180}"
INTERVAL_SECONDS="${INTERVAL_SECONDS:-5}"
SKIP_WORKLOADS="${SKIP_WORKLOADS:-}"
FAIL_ON_ERROR="${FAIL_ON_ERROR:-true}"
PROBE_POD="dr-healthcheck-probe"
FAILURE_LOG="${FAILURE_LOG:-/tmp/dr-phase-failures.log}"

command -v jq >/dev/null || { echo "ERROR: jq is required" >&2; exit 1; }
[[ -r "${CATALOG}" ]] || { echo "ERROR: catalog ${CATALOG} not found - run scripts/collect_healthchecks.sh" >&2; exit 1; }

DIR=$(mktemp -d)
cleanup() {
  kubectl -n "${PROBE_NAMESPACE}" delete pod "${PROBE_POD}" --ignore-not-found --wait=false >/dev/null 2>&1 || true
  rm -rf "${DIR}"
}
trap cleanup EXIT

TOTAL=$(jq '.checks | length' "${CATALOG}")
echo "== Healthchecks: ${TOTAL} in the catalog =="

# --- decide, per catalogued check, whether it applies on DR -----------------
# A "skip" is decided here once; the rest are run in parallel below.
: >"${DIR}/todo"
for ((i = 0; i < TOTAL; i++)); do
  read -r ns name kind < <(jq -r ".checks[$i] | \"\(.namespace) \(.workload) \(.kind | ascii_downcase)\"" "${CATALOG}")
  if [[ " ${SKIP_WORKLOADS} " == *" ${ns}/${name} "* || " ${SKIP_WORKLOADS} " == *" ${name} "* ]]; then
    echo "skipped|skipped by configuration (healthchecks_skip_workloads)" >"${DIR}/${i}.result"
    continue
  fi
  replicas=$(kubectl -n "${ns}" get "${kind}" "${name}" -o jsonpath='{.spec.replicas}' 2>&1); rc=$?
  if [[ "${rc}" -ne 0 ]]; then
    # Only a definite NotFound means "not deployed". Any other error (the API
    # unreachable, forbidden) must not hide a workload behind a skip: it goes
    # on to be checked, and fails there with the real reason.
    if [[ "${replicas}" == *NotFound* || "${replicas}" == *"not found"* ]]; then
      echo "skipped|not deployed on DR" >"${DIR}/${i}.result"
      continue
    fi
    replicas=1
  fi
  if [[ "${replicas:-1}" == "0" ]]; then
    echo "skipped|deployed on DR but scaled to 0" >"${DIR}/${i}.result"
    continue
  fi
  echo "${i}" >>"${DIR}/todo"
done

NEED_PROBE=$(for i in $(cat "${DIR}/todo"); do jq -r ".checks[$i].type" "${CATALOG}"; done | grep -c '^http$' || true)

if [[ "${NEED_PROBE}" -gt 0 ]]; then
  kubectl -n "${PROBE_NAMESPACE}" delete pod "${PROBE_POD}" --ignore-not-found >/dev/null 2>&1 || true
  kubectl -n "${PROBE_NAMESPACE}" apply -f - >/dev/null <<YAML || { echo "ERROR: could not create the probe pod" >&2; exit 1; }
apiVersion: v1
kind: Pod
metadata:
  name: ${PROBE_POD}
  labels:
    app.kubernetes.io/name: dr-healthcheck-probe
spec:
  restartPolicy: Never
  activeDeadlineSeconds: $(( TIMEOUT_SECONDS * 4 + 600 ))
  containers:
    - name: curl
      image: ${PROBE_IMAGE}
      command: ["sleep", "infinity"]
      resources:
        requests: { cpu: 50m, memory: 64Mi }
        limits: { cpu: 500m, memory: 256Mi }
YAML
  if ! kubectl -n "${PROBE_NAMESPACE}" wait --for=condition=Ready "pod/${PROBE_POD}" --timeout=180s >/dev/null 2>&1; then
    echo "ERROR: probe pod did not become Ready (image ${PROBE_IMAGE} pullable from the nodes?)" >&2
    kubectl -n "${PROBE_NAMESPACE}" describe pod "${PROBE_POD}" 2>/dev/null | tail -8 >&2
    printf '[%s] healthchecks: probe pod not Ready\n' "$(date -u +%H:%M:%S)" >>"${FAILURE_LOG}" 2>/dev/null || true
    exit 1
  fi
fi

# --- run one check, retrying until its deadline -----------------------------
run_check() {
  local i="$1" type ns name kind container scheme port path svc svcport detail="" code url ip selector
  type=$(jq -r ".checks[$i].type" "${CATALOG}")
  ns=$(jq -r ".checks[$i].namespace" "${CATALOG}")
  name=$(jq -r ".checks[$i].workload" "${CATALOG}")
  kind=$(jq -r ".checks[$i].kind | ascii_downcase" "${CATALOG}")
  container=$(jq -r ".checks[$i].container" "${CATALOG}")
  local deadline=$(( $(date -u +%s) + TIMEOUT_SECONDS ))

  while :; do
    if [[ "${type}" == "exec" ]]; then
      local cmd
      cmd=$(jq -r ".checks[$i].command | map(@sh) | join(\" \")" "${CATALOG}")
      if out=$(eval "kubectl -n '${ns}' exec '${kind}/${name}' -c '${container}' -- ${cmd}" 2>&1); then
        echo "pass|exec probe ok: $(jq -r ".checks[$i].command | join(\" \")" "${CATALOG}")" >"${DIR}/${i}.result"
        return
      fi
      detail="exec probe failed: $(printf '%s' "${out}" | tail -n1 | cut -c1-120)"
    else
      scheme=$(jq -r ".checks[$i].scheme | ascii_downcase" "${CATALOG}")
      port=$(jq -r ".checks[$i].port" "${CATALOG}")
      path=$(jq -r ".checks[$i].path" "${CATALOG}")
      svc=$(jq -r ".checks[$i].service // empty" "${CATALOG}")
      svcport=$(jq -r ".checks[$i].service_port // empty" "${CATALOG}")
      url=""
      if [[ -n "${svc}" && -n "${svcport}" ]] && kubectl -n "${ns}" get svc "${svc}" >/dev/null 2>&1; then
        url="${scheme}://${svc}.${ns}.svc.cluster.local:${svcport}${path}"
      else
        selector=$(kubectl -n "${ns}" get "${kind}" "${name}" -o json 2>/dev/null \
          | jq -r '.spec.selector.matchLabels // {} | to_entries | map("\(.key)=\(.value)") | join(",")')
        ip=""
        [[ -n "${selector}" ]] && ip=$(kubectl -n "${ns}" get pods -l "${selector}" \
          -o jsonpath='{range .items[?(@.status.phase=="Running")]}{.status.podIP}{"\n"}{end}' 2>/dev/null | head -n1)
        [[ -n "${ip}" ]] && url="${scheme}://${ip}:${port}${path}"
      fi
      if [[ -z "${url}" ]]; then
        detail="no Service on DR and no running pod to reach"
      else
        out=$(kubectl -n "${PROBE_NAMESPACE}" exec "${PROBE_POD}" -- \
          curl -sk -o /dev/null -w '%{http_code}' --max-time 10 "${url}" 2>&1 || true)
        code=$(printf '%s' "${out}" | tail -n1)
        if [[ "${code}" =~ ^2[0-9][0-9]$ ]]; then
          echo "pass|HTTP ${code} from ${url}" >"${DIR}/${i}.result"
          return
        fi
        if [[ "${code}" =~ ^[0-9]{3}$ ]]; then
          detail="HTTP ${code} from ${url}"
        else
          # No status at all: the exec itself failed (no curl in the image, pod gone),
          # which is not the same as the service answering badly.
          detail="probe could not run curl (${code:-no output} - does ${PROBE_IMAGE} contain curl?) for ${url}"
        fi
      fi
    fi
    if [[ "$(date -u +%s)" -ge "${deadline}" ]]; then
      echo "fail|${detail} (after ${TIMEOUT_SECONDS}s)" >"${DIR}/${i}.result"
      return
    fi
    sleep "${INTERVAL_SECONDS}"
  done
}

RUNNING=$(wc -l <"${DIR}/todo" | tr -d ' ')
echo "running ${RUNNING} check(s) on workloads deployed on DR (retrying up to ${TIMEOUT_SECONDS}s each)"
for i in $(cat "${DIR}/todo"); do run_check "${i}" & done
wait

# --- report -------------------------------------------------------------------
PASS=0; FAIL=0; SKIP=0
ENTRIES=()
echo
printf '  %-8s %-34s %s\n' "RESULT" "WORKLOAD" "DETAIL"
for ((i = 0; i < TOTAL; i++)); do
  IFS='|' read -r status detail <"${DIR}/${i}.result"
  ns=$(jq -r ".checks[$i].namespace" "${CATALOG}"); name=$(jq -r ".checks[$i].workload" "${CATALOG}")
  case "${status}" in pass) PASS=$((PASS + 1)) ;; fail) FAIL=$((FAIL + 1)) ;; *) SKIP=$((SKIP + 1)) ;; esac
  printf '  %-8s %-34s %s\n' "${status}" "${ns}/${name}" "${detail}"
  ENTRIES+=("$(jq -nc --arg ns "${ns}" --arg w "${name}" --arg s "${status}" --arg d "${detail}" '{namespace:$ns, workload:$w, status:$s, detail:$d}')")
  [[ "${status}" == "fail" ]] && printf '[%s] healthchecks %s/%s: %s\n' "$(date -u +%H:%M:%S)" "${ns}" "${name}" "${detail}" >>"${FAILURE_LOG}" 2>/dev/null || true
done

mkdir -p "$(dirname "${REPORT_PATH}")"
printf '%s\n' "${ENTRIES[@]}" | jq -s --arg at "$(date -u +%Y-%m-%dT%H:%M:%SZ)" \
  --argjson pass "${PASS}" --argjson fail "${FAIL}" --argjson skip "${SKIP}" \
  '{phase: "8 - healthchecks", timestamp: $at, result: (if $fail == 0 then "pass" else "fail" end), passed: $pass, failed: $fail, skipped: $skip, checks: .}' >"${REPORT_PATH}"

echo
echo "healthchecks: ${PASS} passed, ${FAIL} failed, ${SKIP} skipped (not deployed on DR, scaled to 0, or configured off). Report: ${REPORT_PATH}"
if [[ "${FAIL}" -gt 0 && "${FAIL_ON_ERROR}" == "true" ]]; then
  exit 1
fi
exit 0
