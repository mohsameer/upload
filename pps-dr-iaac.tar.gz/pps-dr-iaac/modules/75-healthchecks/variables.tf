variable "kubeconfig_path" {
  type = string
}

variable "catalog_file" {
  type        = string
  description = "Healthcheck catalog collected from QA (scripts/collect_healthchecks.sh)."
}

variable "probe_image" {
  type        = string
  description = "Image of the short-lived pod the HTTP checks are curl'ed from. Must contain curl."
}

variable "probe_namespace" {
  type    = string
  default = "default"
}

variable "timeout_seconds" {
  type        = number
  description = "How long each check retries before it is a failure."
  default     = 180
}

variable "skip_workloads" {
  type        = list(string)
  description = "Workloads left out of the checks, as namespace/name or name."
  default     = []
}

variable "fail_on_error" {
  type        = bool
  description = "Fail the apply when a deployed workload's healthcheck fails. False reports without failing."
  default     = true
}

variable "report_path" {
  type    = string
  default = ".dr-run/healthcheck-report.json"
}

variable "gate" {
  type        = string
  description = "Value threaded in from the phases that must be finished first."
  default     = ""
}
