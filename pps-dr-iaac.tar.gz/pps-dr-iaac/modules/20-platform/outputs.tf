output "consul_address" {
  description = "In-cluster Consul address."
  value       = "consul-server.${var.platform_namespace}.svc:8500"
}

output "vault_service" {
  description = "In-cluster Vault service address."
  value       = "vault.${var.platform_namespace}.svc:8200"
}

output "ldap_service" {
  description = "In-cluster OpenLDAP service address."
  value       = var.openldap_deployment == "pps_chart" ? "${var.ldap_release_name}-openldap.${var.ldap_namespace}.svc:389" : "openldap.${var.platform_namespace}.svc:389"
}

output "unseal_keys_secret_name" {
  description = "Name of the Kubernetes Secret holding the Vault unseal keys. The key material itself is never output."
  value       = var.unseal_keys_secret_name
}

output "components" {
  description = "Platform components deployed by this phase."
  value       = local.components
}

output "completed" {
  description = "Gate consumed by Phase 3's depends_on."
  value = join(",", [
    null_resource.consul_ready.id,
    null_resource.vault_init.id,
    try(null_resource.openldap_ready[0].id, null_resource.openldap_pps_ready[0].id),
    try(null_resource.zeebe_ready[0].id, "zeebe-skipped"),
    try(null_resource.cert_manager[0].id, "cert-manager-skipped"),
  ])
}
