variable "platform_namespace" {
  type = string
}

variable "storage_class" {
  type = string
}

variable "chart_versions" {
  type        = map(string)
  description = "Pinned chart versions keyed by consul, vault, openldap, zeebe."
}

variable "storage_sizes" {
  type = map(string)
}

variable "replicas" {
  type = map(number)
}

variable "readiness_timeout_seconds" {
  type = number
}

variable "kubeconfig_path" {
  type = string
}

variable "ldap_admin_password" {
  type      = string
  sensitive = true
}

variable "ldap_base_dn" {
  type = string
}

variable "chart_repositories" {
  type        = map(string)
  description = "Helm repository URL per component."
  default = {
    consul   = "https://helm.releases.hashicorp.com"
    vault    = "https://helm.releases.hashicorp.com"
    openldap = "https://jp-gouin.github.io/helm-openldap"
    zeebe    = "https://helm.camunda.io"
  }
}

variable "chart_names" {
  type        = map(string)
  description = "Chart name per component."
  default = {
    consul   = "consul"
    vault    = "vault"
    openldap = "openldap-stack-ha"
    zeebe    = "camunda-platform"
  }
}

variable "unseal_keys_secret_name" {
  type        = string
  description = "Kubernetes Secret holding the Vault unseal keys and root token. Never surfaced as a Terraform output."
  default     = "vault-unseal-keys"
}

variable "vault_key_shares" {
  type    = number
  default = 5
}

variable "vault_key_threshold" {
  type    = number
  default = 3
}

variable "openldap_deployment" {
  type        = string
  description = "stack_ha (public openldap-stack-ha chart in platform_namespace) or pps_chart (PPS chart from ldap_chart_path)."
  default     = "stack_ha"
}

variable "ldap_release_name" {
  type    = string
  default = "ldap"
}

variable "ldap_namespace" {
  type    = string
  default = "ldap-v2"
}

variable "ldap_chart_path" {
  type        = string
  description = "pps_chart only: chart directory on the bastion."
  default     = ""
}

variable "ldap_values_file" {
  type        = string
  description = "pps_chart only: values file on the bastion (holds LDAP passwords; never committed)."
  default     = ""
}

variable "image_pull_secret_name" {
  type    = string
  default = "icrypto-registry"
}

variable "vault_seal_type" {
  type        = string
  description = "shamir (operator unseal) or gcpckms (auto-unseal; the restored Vault keeps unsealing itself)."
  default     = "shamir"
  validation {
    condition     = contains(["shamir", "gcpckms"], var.vault_seal_type)
    error_message = "vault_seal_type must be shamir or gcpckms."
  }
}

variable "vault_kms_sa_file" {
  type        = string
  description = "gcpckms only: SA key JSON on the bastion with cloudkms.cryptoKeyEncrypterDecrypter on the key."
  default     = ""
}

variable "vault_kms_project" {
  type    = string
  default = ""
}

variable "vault_kms_region" {
  type    = string
  default = "global"
}

variable "vault_kms_keyring" {
  type    = string
  default = ""
}

variable "vault_kms_crypto_key" {
  type    = string
  default = ""
}

variable "vault_kms_secret_name" {
  type    = string
  default = "vault-kms-sa"
}

variable "vault_kms_secret_key" {
  type    = string
  default = "sa_credentials.json"
}

variable "vault_root_token" {
  type        = string
  description = "Pre-known root token on the restored source. Written to unseal_keys_secret_name so Phase 5 can configure Vault."
  sensitive   = true
  default     = ""
}

variable "zeebe_enabled" {
  type        = bool
  description = "Install Zeebe (camunda-platform) in Phase 2. On the PPS DR site this is false: bpmn-engine is an Argo CD Application restored in Phase 4."
  default     = true
}

variable "cert_manager_enabled" {
  type        = bool
  description = "Install cert-manager in Phase 2."
  default     = false
}

variable "cert_manager_namespace" {
  type    = string
  default = "cert-manager"
}

variable "cert_manager_version" {
  type        = string
  description = "cert-manager chart version. Keep this close to the current site version (old DR runs v1.5.4)."
  default     = "v1.5.4"
}

variable "cert_manager_chart_repo" {
  type    = string
  default = "https://charts.jetstack.io"
}

variable "ldap_chart_name" {
  type = string
}

variable "ldap_chart_version" {
  type = string
}

variable "registry_server" {
  type = string
}

variable "ecr_access_key" {
  type        = string
  sensitive   = true
  default     = ""
  description = "AWS key used to mint an ECR token when the OCI LDAP chart is pulled before the cluster pull secret exists."
}

variable "ecr_secret_key" {
  type        = string
  sensitive   = true
  default     = ""
  description = "Secret half of ecr_access_key."
}

variable "ldap_ready_selector" {
  type        = string
  default     = ""
  description = <<-EOT
    Label selector the LDAP readiness gate waits on. Empty selects on the
    release alone (release=<ldap_release_name>), which matches both the PPS OCI
    chart (app=pps-ldap) and the local directory chart (app=openldap).
  EOT
}

variable "endpoint_redirects" {
  type        = map(string)
  default     = {}
  description = "Source-site domain -> this site's host, redirected in cluster DNS. Empty leaves DNS alone."
}

variable "ldap_service_ldap_port" {
  type        = number
  description = "Port the LDAP Service listens on for plain LDAP (chart value service.ldapPort). The pod listens on 1389."
  default     = 1389
}

variable "ldap_service_ssl_port" {
  type        = number
  description = "Port the LDAP Service listens on for LDAPS (chart value service.sslLdapPort). The pod listens on 1636."
  default     = 1636
}

variable "ldap_lb_ip" {
  type        = string
  description = "Fixed address for the LDAP internal load balancer (chart value service.loadBalancerIP). Empty lets GKE pick one."
  default     = ""
}

variable "ldap_service_aliases" {
  type        = map(string)
  default     = {}
  description = "Extra Service names for LDAP, as name -> \"port:targetPort\". The applications resolve the source site's Service name."
}
