# Phase 2 - stateful platform: Consul, Vault, OpenLDAP, Zeebe.
#
# Deliberately absent: PostgreSQL, Couchbase and the Couchbase Operator. Both
# data tiers are managed services (Cloud SQL, Capella) and are restored into
# in Phase 3, never installed here.

locals {
  components = ["consul", "vault", "openldap", "zeebe"]

  # Helm runs through the CLI from a null_resource, not through the helm
  # provider: a provider is configured before any resource in the apply runs,
  # so one pointed at a cluster this same apply creates cannot work. That is
  # what forced the build into two passes. See modules/common/helm_apply.sh.
  helm_apply = "${path.module}/../common/helm_apply.sh"

  consul_values = templatefile("${path.module}/values/consul.yaml.tftpl", {
    replicas      = var.replicas["consul"]
    storage_class = var.storage_class
    storage_size  = var.storage_sizes["consul"]
  })

  vault_values = templatefile("${path.module}/values/vault.yaml.tftpl", {
    replicas           = var.replicas["vault"]
    storage_class      = var.storage_class
    storage_size       = var.storage_sizes["vault"]
    consul_address     = "consul-server.${var.platform_namespace}.svc:8500"
    platform_namespace = var.platform_namespace
    seal_type          = var.vault_seal_type
    kms_project        = var.vault_kms_project
    kms_region         = var.vault_kms_region
    kms_keyring        = var.vault_kms_keyring
    kms_crypto_key     = var.vault_kms_crypto_key
    kms_secret_name    = var.vault_kms_secret_name
    kms_secret_key     = var.vault_kms_secret_key
  })

  openldap_values = templatefile("${path.module}/values/openldap.yaml.tftpl", {
    replicas      = var.replicas["openldap"]
    storage_class = var.storage_class
    storage_size  = var.storage_sizes["openldap"]
    base_dn       = var.ldap_base_dn
  })

  zeebe_values = templatefile("${path.module}/values/zeebe.yaml.tftpl", {
    replicas      = var.replicas["zeebe"]
    storage_class = var.storage_class
    storage_size  = var.storage_sizes["zeebe"]
  })
}

# --- Consul: Vault's storage backend, so it starts first --------------------
# Redirects the source site's data-tier hostnames to this site's, in-cluster
# only. Must land before any application pod starts; see dns_redirect.sh for
# the measurement that made it necessary.
resource "null_resource" "dns_redirect" {
  count = length(var.endpoint_redirects) > 0 ? 1 : 0

  triggers = {
    redirects = join(",", [for k, v in var.endpoint_redirects : "${k}=${v}"])
    namespace = var.platform_namespace
    script    = filemd5("${path.root}/modules/common/dns_redirect.sh")
  }

  provisioner "local-exec" {
    # abspath, because path.root is relative and working_dir is this module:
    # "${path.root}/modules/common/..." then resolves to
    # modules/20-platform/modules/common/... and the provisioner fails with
    # exit status 127, command not found.
    command     = abspath("${path.root}/modules/common/dns_redirect.sh")
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.platform_namespace
      REDIRECTS  = join("\n", [for k, v in var.endpoint_redirects : "${k}=${v}"])
    }
  }
}

resource "null_resource" "consul" {
  # A destroy provisioner may only read `self`, so everything the uninstall
  # needs is carried in triggers.
  triggers = {
    release    = "consul"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
    chart      = "${var.chart_repositories["consul"]}|${var.chart_names["consul"]}|${var.chart_versions["consul"]}"
    values     = md5(local.consul_values)
    script     = filemd5("${path.module}/../common/helm_apply.sh")
  }

  provisioner "local-exec" {
    command     = local.helm_apply
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      RELEASE         = "consul"
      NAMESPACE       = var.platform_namespace
      REPO            = var.chart_repositories["consul"]
      CHART           = var.chart_names["consul"]
      VERSION         = var.chart_versions["consul"]
      VALUES_CONTENT  = local.consul_values
      WAIT            = "true"
      WAIT_FOR_JOBS   = "true"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "consul_ready" {
  triggers = {
    release = null_resource.consul.id
    script  = filemd5("${path.module}/wait_ready.sh")
  }

  provisioner "local-exec" {
    command     = "./wait_ready.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module
    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.platform_namespace
      COMPONENT       = "consul"
      LABEL_SELECTOR  = "app=consul,component=server"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

# --- Vault: depends on Consul ----------------------------------------------
# gcpckms auto-unseal: the SA key file on the bastion is projected into
# platform_namespace as a Secret and mounted into every Vault pod. The seal
# block in the Helm values points at the same KMS key the source Vault used,
# so after Phase 3 restores Consul the pods unseal themselves.
resource "null_resource" "vault_kms_sa" {
  count = var.vault_seal_type == "gcpckms" ? 1 : 0

  # kubectl rather than the kubernetes provider, for the same reason Helm goes
  # through its CLI: the provider would have to be configured before the
  # cluster exists. The key file is read by kubectl on the host, so its
  # contents never pass through Terraform state.
  triggers = {
    name       = var.vault_kms_secret_name
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    key        = var.vault_kms_secret_key
    sa_file    = filemd5(var.vault_kms_sa_file)
  }

  provisioner "local-exec" {
    interpreter = ["/bin/bash", "-ec"]
    command     = <<-EOT
      kubectl create secret generic "${var.vault_kms_secret_name}" \
        --namespace "${var.platform_namespace}" \
        --from-file="${var.vault_kms_secret_key}=${pathexpand(var.vault_kms_sa_file)}" \
        --dry-run=client -o yaml | kubectl apply -f -
    EOT
    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
    }
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    interpreter = ["/bin/bash", "-ec"]
    command     = "kubectl -n '${self.triggers.namespace}' delete secret '${self.triggers.name}' --ignore-not-found"
    environment = {
      KUBECONFIG = self.triggers.kubeconfig
    }
  }
}

resource "null_resource" "vault" {
  triggers = {
    release    = "vault"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
    chart      = "${var.chart_repositories["vault"]}|${var.chart_names["vault"]}|${var.chart_versions["vault"]}"
    values     = md5(local.vault_values)
    script     = filemd5("${path.module}/../common/helm_apply.sh")
  }

  provisioner "local-exec" {
    command     = local.helm_apply
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG     = pathexpand(var.kubeconfig_path)
      RELEASE        = "vault"
      NAMESPACE      = var.platform_namespace
      REPO           = var.chart_repositories["vault"]
      CHART          = var.chart_names["vault"]
      VERSION        = var.chart_versions["vault"]
      VALUES_CONTENT = local.vault_values
      # Vault pods stay NotReady until they are unsealed, so Helm must not
      # block on readiness here - vault_init.sh below is the real gate.
      WAIT            = "false"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }

  depends_on = [null_resource.consul_ready, null_resource.vault_kms_sa]
}

# Initialise and unseal. Unseal keys and the root token are written to a
# Kubernetes Secret, never to Terraform state or outputs.
resource "null_resource" "vault_init" {
  triggers = {
    release = null_resource.vault.id
    script  = filemd5("${path.module}/vault_init.sh")
  }

  provisioner "local-exec" {
    command     = "./vault_init.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module
    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.platform_namespace
      REPLICAS        = tostring(var.replicas["vault"])
      KEY_SHARES      = tostring(var.vault_key_shares)
      KEY_THRESHOLD   = tostring(var.vault_key_threshold)
      SECRET_NAME     = var.unseal_keys_secret_name
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
      SEAL_TYPE       = var.vault_seal_type
      ROOT_TOKEN      = var.vault_root_token
    }
  }
}

# --- OpenLDAP: independent of Consul/Vault, runs in parallel ---------------
#
# Two ways to stand it up (openldap_deployment):
#   stack_ha  - public openldap-stack-ha chart (Bitnami image) in
#               platform_namespace. A fresh instance has no secauthority DB,
#               so Phase 3 must restore the source cn=config.
#   pps_chart - the PPS chart + values PPS environments run (pps-ldap image,
#               release "ldap", StatefulSet ldap-openldap), from a chart
#               directory and values file on the bastion - they carry
#               passwords, so they never live in git. The image builds the
#               secauthority DB itself; Phase 3 loads data only.
locals {
  ldap_pps_chart = var.openldap_deployment == "pps_chart"
}

resource "null_resource" "openldap_pps" {
  count = local.ldap_pps_chart ? 1 : 0

  triggers = {
    release     = var.ldap_release_name
    namespace   = var.ldap_namespace
    kubeconfig  = pathexpand(var.kubeconfig_path)
    timeout     = tostring(var.readiness_timeout_seconds)
    chart       = "${var.ldap_chart_version == "" ? var.ldap_chart_path : var.ldap_chart_name}|${var.ldap_chart_version}"
    pull_secret = var.image_pull_secret_name
    service     = "${var.ldap_service_ldap_port}:${var.ldap_service_ssl_port}:${var.ldap_lb_ip}"
    values      = filemd5(var.ldap_values_file)
    script      = filemd5("${path.module}/../common/helm_apply.sh")
  }

  provisioner "local-exec" {
    command     = local.helm_apply
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG  = pathexpand(var.kubeconfig_path)
      RELEASE     = var.ldap_release_name
      NAMESPACE   = var.ldap_namespace
      REPO        = var.ldap_chart_version == "" ? "" : "oci://${var.registry_server}"
      CHART       = var.ldap_chart_version == "" ? var.ldap_chart_path : var.ldap_chart_name
      VERSION     = var.ldap_chart_version
      VALUES_FILE = var.ldap_values_file
      # The chart's own values file sets 389/636; the pod listens on 1389/1636
      # and production's clients use those, so the Service is published on
      # them. --set wins over the values file.
      SET_ARGS = join("\n", compact([
        "imagePullSecrets[0].name=${var.image_pull_secret_name}",
        "service.ldapPort=${var.ldap_service_ldap_port}",
        "service.sslLdapPort=${var.ldap_service_ssl_port}",
        var.ldap_lb_ip != "" ? "service.loadBalancerIP=${var.ldap_lb_ip}" : "",
      ]))
      REGISTRY_SECRET           = var.image_pull_secret_name
      REGISTRY_SECRET_NAMESPACE = var.ldap_namespace
      ECR_ACCESS_KEY            = var.ecr_access_key
      ECR_SECRET_KEY            = var.ecr_secret_key
      WAIT                      = "true"
      TIMEOUT_SECONDS           = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "openldap_pps_ready" {
  count = local.ldap_pps_chart ? 1 : 0

  triggers = {
    release = null_resource.openldap_pps[0].id
    script  = filemd5("${path.module}/wait_ready.sh")
  }

  provisioner "local-exec" {
    command     = "./wait_ready.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module
    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.ldap_namespace
      COMPONENT  = "openldap"
      # The chart decides the app label: the PPS OCI chart labels its pods
      # app=pps-ldap, the local directory chart app=openldap. Selecting on the
      # release alone matches either, and nothing else in this namespace
      # carries it. The first build against the OCI chart failed here with "no
      # matching resources found" while the pod was in fact Running.
      LABEL_SELECTOR  = var.ldap_ready_selector != "" ? var.ldap_ready_selector : "release=${var.ldap_release_name}"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "openldap" {
  count = local.ldap_pps_chart ? 0 : 1

  triggers = {
    release    = "openldap"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
    chart      = "${var.chart_names["openldap"]}|${var.chart_versions["openldap"]}"
    values     = md5(local.openldap_values)
    # Not in the values file, so a rotated password would otherwise not
    # re-run the upgrade.
    admin_password = sha256(var.ldap_admin_password)
    script         = filemd5("${path.module}/../common/helm_apply.sh")
  }

  provisioner "local-exec" {
    command     = local.helm_apply
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG     = pathexpand(var.kubeconfig_path)
      RELEASE        = "openldap"
      NAMESPACE      = var.platform_namespace
      REPO           = var.chart_repositories["openldap"]
      CHART          = var.chart_names["openldap"]
      VERSION        = var.chart_versions["openldap"]
      VALUES_CONTENT = local.openldap_values
      # Through a file, not argv: see SET_SECRET_ARGS in helm_apply.sh.
      SET_SECRET_ARGS = "global.adminPassword=${var.ldap_admin_password}"
      WAIT            = "true"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "openldap_ready" {
  count = local.ldap_pps_chart ? 0 : 1

  triggers = {
    release = null_resource.openldap[0].id
    script  = filemd5("${path.module}/wait_ready.sh")
  }

  provisioner "local-exec" {
    command     = "./wait_ready.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module
    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.platform_namespace
      COMPONENT       = "openldap"
      LABEL_SELECTOR  = "app.kubernetes.io/name=openldap-stack-ha"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

# Publishes the LDAP Service under the name the restored applications expect;
# see ldap_service_aliases.sh for the measurement.
resource "null_resource" "ldap_service_aliases" {
  count = length(var.ldap_service_aliases) > 0 ? 1 : 0

  triggers = {
    aliases  = join(",", [for k, v in var.ldap_service_aliases : "${k}=${v}"])
    selector = "release=${var.ldap_release_name}"
    script   = filemd5("${path.module}/ldap_service_aliases.sh")
  }

  provisioner "local-exec" {
    command     = "./ldap_service_aliases.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.ldap_namespace
      SELECTOR   = "release=${var.ldap_release_name}"
      ALIASES    = join("\n", [for k, v in var.ldap_service_aliases : "${k}=${v}"])
    }
  }

  depends_on = [null_resource.openldap_pps_ready]
}

# --- Zeebe ------------------------------------------------------------------
# PPS delivers Zeebe as an Argo CD Application (chart `bpmn-engine` from ECR,
# namespace bpmnv2), so Phase 2 does not install the public camunda-platform
# chart on this site. zeebe_enabled=false (default on the DR site) skips both
# the Helm release and the readiness gate; Phase 4 restores the Argo CD app
# bpmn-engine and Phase 6 waits for it to converge.
resource "null_resource" "zeebe" {
  count = var.zeebe_enabled ? 1 : 0

  triggers = {
    release    = "zeebe"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
    chart      = "${var.chart_names["zeebe"]}|${var.chart_versions["zeebe"]}"
    values     = md5(local.zeebe_values)
    script     = filemd5("${path.module}/../common/helm_apply.sh")
  }

  provisioner "local-exec" {
    command     = local.helm_apply
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      RELEASE         = "zeebe"
      NAMESPACE       = var.platform_namespace
      REPO            = var.chart_repositories["zeebe"]
      CHART           = var.chart_names["zeebe"]
      VERSION         = var.chart_versions["zeebe"]
      VALUES_CONTENT  = local.zeebe_values
      WAIT            = "true"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "zeebe_ready" {
  count = var.zeebe_enabled ? 1 : 0

  triggers = {
    release = null_resource.zeebe[0].id
    script  = filemd5("${path.module}/wait_ready.sh")
  }

  provisioner "local-exec" {
    command     = "./wait_ready.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module
    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.platform_namespace
      COMPONENT       = "zeebe"
      LABEL_SELECTOR  = "app.kubernetes.io/app=zeebe"
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

# --- cert-manager (if the site runs it; the old DR has v1.5.4 in cert-manager ns) ---
resource "null_resource" "cert_manager" {
  count = var.cert_manager_enabled ? 1 : 0

  triggers = {
    release    = "cert-manager"
    namespace  = var.cert_manager_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
    chart      = "${"cert-manager"}|${var.cert_manager_version}"
    values     = "installCRDs=true"
    script     = filemd5("${path.module}/../common/helm_apply.sh")
  }

  provisioner "local-exec" {
    command     = local.helm_apply
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      RELEASE          = "cert-manager"
      NAMESPACE        = var.cert_manager_namespace
      REPO             = var.cert_manager_chart_repo
      CHART            = "cert-manager"
      VERSION          = var.cert_manager_version
      SET_ARGS         = "installCRDs=true"
      CREATE_NAMESPACE = "true"
      WAIT             = "true"
      TIMEOUT_SECONDS  = tostring(var.readiness_timeout_seconds)
    }
  }
}

# --- uninstalls -------------------------------------------------------------
# The uninstall of each release lives in its own resource, deliberately.
#
# `triggers` is ForceNew: with the destroy provisioner on the install resource,
# any trigger change - a new chart version, edited values, even an edit to
# helm_apply.sh, whose checksum is a trigger - replaces the resource, and a
# replacement runs the destroy provisioner first. Editing that one script would
# have run `helm uninstall` against Consul (Vault's storage backend), Vault,
# OpenLDAP and Argo CD on a live site before reinstalling them.
#
# Here the uninstall resources carry only stable triggers, so they are never
# replaced, and a change to an install resource is just an idempotent
# `helm upgrade --install`. depends_on gives the right destroy order: Terraform
# destroys in reverse dependency order, so the uninstall runs before the
# install resource it depends on is removed.

resource "null_resource" "consul_uninstall" {
  triggers = {
    release    = "consul"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.consul]
}

resource "null_resource" "vault_uninstall" {
  triggers = {
    release    = "vault"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.vault]
}

resource "null_resource" "openldap_pps_uninstall" {
  count = local.ldap_pps_chart ? 1 : 0

  triggers = {
    release    = var.ldap_release_name
    namespace  = var.ldap_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.openldap_pps]
}

resource "null_resource" "openldap_uninstall" {
  count = local.ldap_pps_chart ? 0 : 1

  triggers = {
    release    = "openldap"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.openldap]
}

resource "null_resource" "zeebe_uninstall" {
  count = var.zeebe_enabled ? 1 : 0

  triggers = {
    release    = "zeebe"
    namespace  = var.platform_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.zeebe]
}

resource "null_resource" "cert_manager_uninstall" {
  count = var.cert_manager_enabled ? 1 : 0

  triggers = {
    release    = "cert-manager"
    namespace  = var.cert_manager_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.cert_manager]
}
