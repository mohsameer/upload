#!/usr/bin/env bash
# Initialise and unseal Vault, then leave it reachable for Phase 3 and Phase 5.
#
# Unseal keys and the root token are written to a Kubernetes Secret in the
# platform namespace. They are never written to Terraform state, and never
# exposed as a Terraform output.
set -euo pipefail

: "${NAMESPACE:?}" "${REPLICAS:?}" "${KEY_SHARES:?}" "${KEY_THRESHOLD:?}" "${SECRET_NAME:?}" "${TIMEOUT_SECONDS:?}"
SEAL_TYPE="${SEAL_TYPE:-shamir}"
ROOT_TOKEN="${ROOT_TOKEN:-}"

POD0="vault-0"

wait_for_pod_running() {
  local pod="$1" deadline=$((SECONDS + TIMEOUT_SECONDS))
  while [[ ${SECONDS} -lt ${deadline} ]]; do
    phase=$(kubectl -n "${NAMESPACE}" get pod "${pod}" -o jsonpath='{.status.phase}' 2>/dev/null || true)
    [[ "${phase}" == "Running" ]] && return 0
    sleep 5
  done
  echo "ERROR: ${pod} did not reach Running within ${TIMEOUT_SECONDS}s." >&2
  return 1
}

vault_status() {
  # Exit code 0 = unsealed, 2 = sealed, other = unreachable.
  kubectl -n "${NAMESPACE}" exec "$1" -- vault status -format=json 2>/dev/null || true
}

# jq's `//` treats `false` as empty, so `.sealed // true` is always true on an
# unsealed Vault. Read booleans through has() instead.
status_bool() {
  jq -r --arg k "$1" --arg d "$2" 'if has($k) then .[$k] else ($d == "true") end'
}

# Running is not the same as listening. A pod reaches Running the moment its
# container starts, while Vault needs a few more seconds to bind 8200, and
# `vault operator init` against a port that is not up yet fails immediately -
# which under `set -e` failed the whole apply. On 2026-10-12 the same code
# took 1m10s and succeeded at 10:38 (the pod was already up when it ran) and
# died in 6s at 14:39, when it started the same second the Helm release
# finished. So wait for the API to answer, then retry the init.
wait_for_api() {
  local pod="$1" deadline=$((SECONDS + TIMEOUT_SECONDS)) out=""
  while [[ ${SECONDS} -lt ${deadline} ]]; do
    # `vault status` exits 0 unsealed, 2 sealed and 1 unreachable; anything
    # that parses as JSON means the API is answering.
    out=$(kubectl -n "${NAMESPACE}" exec "${pod}" -- vault status -format=json 2>/dev/null || true)
    if [[ -n "${out}" ]] && echo "${out}" | jq -e . >/dev/null 2>&1; then
      return 0
    fi
    sleep 5
  done
  echo "ERROR: ${pod} did not answer 'vault status' within ${TIMEOUT_SECONDS}s." >&2
  return 1
}

wait_for_pod_running "${POD0}"
wait_for_api "${POD0}"

STATUS_JSON=$(vault_status "${POD0}")
INITIALIZED=$(echo "${STATUS_JSON}" | status_bool initialized false 2>/dev/null || echo "false")

if [[ "${INITIALIZED}" != "true" ]]; then
  echo "Vault is not initialised. Initialising (seal=${SEAL_TYPE})..."

  # Retried: the API can answer and still refuse an init while the seal is
  # still being set up ("core is being initialized"), and a single attempt
  # under `set -e` turns that into a failed apply.
  init_vault() {
    if [[ "${SEAL_TYPE}" == "gcpckms" ]]; then
      kubectl -n "${NAMESPACE}" exec "${POD0}" -- \
        vault operator init \
          -recovery-shares=1 \
          -recovery-threshold=1 \
          -format=json
    else
      kubectl -n "${NAMESPACE}" exec "${POD0}" -- \
        vault operator init \
          -key-shares="${KEY_SHARES}" \
          -key-threshold="${KEY_THRESHOLD}" \
          -format=json
    fi
  }

  INIT_JSON=""
  init_deadline=$((SECONDS + TIMEOUT_SECONDS))
  attempt=0
  while [[ ${SECONDS} -lt ${init_deadline} ]]; do
    attempt=$((attempt + 1))
    if INIT_JSON=$(init_vault 2>/tmp/vault-init-err.$$); then
      [[ -n "${INIT_JSON}" ]] && break
    fi
    # Another replica may have won the race; if Vault is initialised now,
    # there is nothing left to do here and the keys already exist.
    if [[ "$(vault_status "${POD0}" | status_bool initialized false 2>/dev/null || echo false)" == "true" ]]; then
      echo "Vault became initialised while this was retrying; keeping the existing keys."
      INIT_JSON=""
      break
    fi
    echo "  init attempt ${attempt} failed: $(tr -d '\n' </tmp/vault-init-err.$$ | cut -c1-200)" >&2
    sleep 5
  done
  rm -f /tmp/vault-init-err.$$

  if [[ -z "${INIT_JSON}" ]] && \
     [[ "$(vault_status "${POD0}" | status_bool initialized false 2>/dev/null || echo false)" != "true" ]]; then
    echo "ERROR: could not initialise Vault within ${TIMEOUT_SECONDS}s (${attempt} attempts)." >&2
    exit 1
  fi

  # Store immediately - losing this output means losing the DR Vault. Skipped
  # when the retry loop found Vault already initialised by someone else, where
  # overwriting the Secret with an empty value is the one way to actually lose
  # the keys.
  if [[ -n "${INIT_JSON}" ]]; then
    kubectl -n "${NAMESPACE}" create secret generic "${SECRET_NAME}" \
      --from-literal=init.json="${INIT_JSON}" \
      --dry-run=client -o yaml | kubectl apply -f - >/dev/null
    echo "Unseal keys and root token stored in secret/${SECRET_NAME} (namespace ${NAMESPACE})."
  else
    INIT_JSON=$(kubectl -n "${NAMESPACE}" get secret "${SECRET_NAME}" \
      -o jsonpath='{.data.init\.json}' 2>/dev/null | base64 -d 2>/dev/null || true)
    [[ -n "${INIT_JSON}" ]] || {
      echo "ERROR: Vault reports initialised but secret/${SECRET_NAME} holds no keys; this Vault cannot be unsealed." >&2
      exit 1
    }
    echo "Reusing the existing secret/${SECRET_NAME}."
  fi
else
  echo "Vault already initialised; reusing secret/${SECRET_NAME}."
  INIT_JSON=$(kubectl -n "${NAMESPACE}" get secret "${SECRET_NAME}" \
    -o jsonpath='{.data.init\.json}' | base64 -d)
fi

if [[ "${SEAL_TYPE}" == "gcpckms" ]]; then
  # Auto-unseal via KMS; wait for every replica to reach sealed=false.
  for i in $(seq 0 $((REPLICAS - 1))); do
    POD="vault-${i}"
    wait_for_pod_running "${POD}" || exit 1
    # A cold replica reaches the KMS endpoint, decrypts the seal and replays
    # Consul before it answers; on a fresh cluster that measured just over 5m.
    deadline=$((SECONDS + 900))
    while [[ ${SECONDS} -lt ${deadline} ]]; do
      SEALED=$(vault_status "${POD}" | status_bool sealed true)
      [[ "${SEALED}" == "false" ]] && break
      sleep 3
    done
    if [[ "${SEALED}" != "false" ]]; then
      echo "ERROR: ${POD} did not auto-unseal via gcpckms within 5m." >&2
      exit 1
    fi
    echo "${POD} auto-unsealed."
  done
else
  mapfile -t UNSEAL_KEYS < <(echo "${INIT_JSON}" | jq -r '.unseal_keys_b64[]' | head -n "${KEY_THRESHOLD}")
  # A gcpckms init writes recovery_keys_b64 and no unseal_keys_b64, so this
  # comes back empty on a Shamir run against such an init.json - and an empty
  # loop would silently skip the unseal and leave Vault sealed.
  [[ "${#UNSEAL_KEYS[@]}" -gt 0 ]] || {
    echo "ERROR: secret/${SECRET_NAME} holds no unseal_keys_b64; cannot unseal with seal type '${SEAL_TYPE}'." >&2
    exit 1
  }
  for i in $(seq 0 $((REPLICAS - 1))); do
    POD="vault-${i}"
    wait_for_pod_running "${POD}" || exit 1
    SEALED=$(vault_status "${POD}" | status_bool sealed true)
    if [[ "${SEALED}" == "true" ]]; then
      echo "Unsealing ${POD}..."
      for key in ${UNSEAL_KEYS[@]+"${UNSEAL_KEYS[@]}"}; do
        kubectl -n "${NAMESPACE}" exec "${POD}" -- vault operator unseal "${key}" >/dev/null
      done
    fi
    SEALED_AFTER=$(vault_status "${POD}" | status_bool sealed true)
    if [[ "${SEALED_AFTER}" != "false" ]]; then
      echo "ERROR: ${POD} is still sealed after unseal attempt." >&2
      exit 1
    fi
    echo "${POD} is unsealed."
  done
fi

# Final assertion matching the spec: initialized=true, sealed=false.
FINAL=$(vault_status "${POD0}")
if [[ "$(echo "${FINAL}" | jq -r '.initialized')" != "true" ]] \
   || [[ "$(echo "${FINAL}" | jq -r '.sealed')" != "false" ]]; then
  echo "ERROR: Vault did not reach initialized=true / sealed=false." >&2
  echo "${FINAL}" >&2
  exit 1
fi

echo "Vault is initialised and unsealed across ${REPLICAS} replica(s)."
