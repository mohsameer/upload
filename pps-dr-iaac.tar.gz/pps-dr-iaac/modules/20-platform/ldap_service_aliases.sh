#!/usr/bin/env bash
# Publish the LDAP Service under the name the applications expect.
#
# The restored applications resolve ldap-openldap.<ns>.svc:1389, which is what
# the chart is called on the source site. The PPS OCI chart used here names its
# Service after the release - ldap-pps-ldap - and publishes 389/636/9330, so
# every service that checks LDAP on 1389 waited forever on a name that does not
# exist here. Measured: ext-authn-service retried
# ldap-openldap.ldap-v2.svc.cluster.local:1389 indefinitely in Init:0/2.
#
# An alias Service rather than renaming the chart's: the chart stays stock, and
# a Service is the cheapest thing in Kubernetes to add.
set -euo pipefail

: "${NAMESPACE:?}" "${SELECTOR:?}"
ALIASES="${ALIASES:-}"

if [[ -z "${ALIASES//[[:space:]]/}" ]]; then
  echo "No LDAP service aliases configured."
  exit 0
fi

# SELECTOR is "k=v[,k=v]"; turn it into YAML.
SEL_YAML=""
IFS=',' read -ra pairs <<< "${SELECTOR}"
for kv in "${pairs[@]}"; do
  [[ -z "${kv}" ]] && continue
  SEL_YAML+="
    ${kv%%=*}: \"${kv#*=}\""
done

# ALIASES is "<name>=<port>:<targetPort>" per line.
while IFS= read -r spec; do
  [[ -z "${spec//[[:space:]]/}" ]] && continue
  name="${spec%%=*}"
  ports="${spec#*=}"
  port="${ports%%:*}"
  target="${ports#*:}"
  [[ -n "${name}" && -n "${port}" && -n "${target}" ]] \
    || { echo "ERROR: malformed alias '${spec}' (want name=port:targetPort)" >&2; exit 1; }

  kubectl -n "${NAMESPACE}" apply -f - >/dev/null <<EOF
apiVersion: v1
kind: Service
metadata:
  name: ${name}
  labels:
    app.kubernetes.io/managed-by: pps-dr-iaac
    pps-dr/purpose: name-alias
spec:
  type: ClusterIP
  selector:${SEL_YAML}
  ports:
    - name: ldap
      port: ${port}
      targetPort: ${target}
      protocol: TCP
EOF
  echo "  ${name}:${port} -> ${SELECTOR} :${target}"
done <<< "${ALIASES}"

echo "LDAP service aliases in place."
