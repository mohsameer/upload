#!/usr/bin/env bash
# Readiness gate for one platform component.
#
# Fails naming the component and the timeout so the operator sees which
# component blocked the DR run rather than a generic Helm timeout.
set -euo pipefail

: "${NAMESPACE:?}" "${COMPONENT:?}" "${LABEL_SELECTOR:?}" "${TIMEOUT_SECONDS:?}"

echo "Waiting up to ${TIMEOUT_SECONDS}s for ${COMPONENT} pods (${LABEL_SELECTOR}) in ${NAMESPACE}..."

if ! kubectl wait --namespace "${NAMESPACE}" \
      --for=condition=Ready pod \
      --selector "${LABEL_SELECTOR}" \
      --timeout="${TIMEOUT_SECONDS}s"; then
  echo "ERROR: ${COMPONENT} did not become Ready within ${TIMEOUT_SECONDS}s." >&2
  kubectl get pods --namespace "${NAMESPACE}" --selector "${LABEL_SELECTOR}" >&2 || true
  exit 1
fi

echo "${COMPONENT} is Ready."
