output "preflight_report" {
  description = "Per-prerequisite pass/fail result."
  value       = jsondecode(data.local_file.preflight_report.content)
}

output "backup_generations" {
  description = "GCS generation number per backup object. Phase 3 triggers on these instead of timestamp()."
  value       = local.backup_generations
}

output "cloudsql_connection_name" {
  description = "Connection name of the pre-existing Cloud SQL instance. Empty on the psql_pod path."
  value       = try(data.google_sql_database_instance.dr[0].connection_name, "")
}

output "cloudsql_private_ip" {
  description = "Private IP of the pre-existing Cloud SQL instance, if configured. Empty on the psql_pod path."
  value = try(one([
    for ip in data.google_sql_database_instance.dr[0].ip_address : ip.ip_address
    if ip.type == "PRIVATE"
  ]), "")
}

output "completed" {
  description = "Gate consumed by Phase 1's depends_on."
  value       = null_resource.preflight.id
}
