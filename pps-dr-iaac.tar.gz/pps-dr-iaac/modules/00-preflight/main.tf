# Phase 0 - Preflight.
#
# Verifies the six prerequisites from the DR plan. Every check is read-only:
# this module declares no managed resource that touches Cloud SQL, Capella or
# the backup bucket. It runs before Phase 1 so a missing prerequisite is caught
# before a GKE cluster is built.
#
# The live-API checks below delegate to prevalidate/checks.sh - the same
# shared check suite the standalone `./prevalidate.sh` gate runs before
# `tofu init`. This is deliberate (openspec change dr-prevalidation,
# requirement "One check suite behind both entry points"): the Terraform
# module must not carry a second, independent implementation of any check.
#
# The data sources and precondition below are NOT a duplicate implementation
# - they are Terraform's own read of Cloud SQL/backup state, kept because
# their attributes (connection_name, private IP, backup generations) feed
# other modules' outputs. They happen to overlap with prerequisite 3/4 in
# what they observe, the way a second set of eyes overlaps with the first.

locals {
  tfvars_path   = var.tfvars_path != "" ? var.tfvars_path : "${path.root}/pps-dr.tfvars"
  uses_sqladmin = var.postgres_restore_method == "gcloud_sql_import"
}

# Prerequisite 3 - Cloud SQL instance exists. Data source only: the plan must
# never show a create/update/destroy for this instance.
#
# Read only on the gcloud_sql_import path. The default psql_pod path reaches
# the instance by private IP from inside the cluster and must work while the
# Cloud SQL Admin API is unreachable from the bastion (openspec change
# dr-drill-fixes, E3); prevalidate probes the private IP instead.
data "google_sql_database_instance" "dr" {
  count   = local.uses_sqladmin ? 1 : 0
  name    = var.cloudsql_instance_name
  project = var.project_id
}

# Prerequisite 4 - each configured backup object exists. The generation number
# is exported so Phase 3 can trigger on backup content instead of timestamp().
# Uses gcloud CLI (data.external) instead of the google provider: provider
# re-fetches oauth tokens on every refresh, which intermittently times out
# from the DR bastion. gcloud reuses a cached activation token.
data "external" "backups" {
  for_each = toset(var.required_backup_objects)
  program  = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${each.value}"
    credentials_file = var.backup_credentials_file
  }
}

locals {
  cloudsql_state_ok = local.uses_sqladmin ? data.google_sql_database_instance.dr[0].settings[0].activation_policy == "ALWAYS" : true

  backup_generations = {
    for k, o in data.external.backups : k => o.result.generation
  }
}

# Cloud SQL must be serving, not just present. Vacuously true on psql_pod.
resource "terraform_data" "cloudsql_state_gate" {
  input = local.cloudsql_state_ok

  lifecycle {
    precondition {
      condition     = local.cloudsql_state_ok
      error_message = "Prerequisite 3 failed: Cloud SQL instance '${var.cloudsql_instance_name}' in project '${var.project_id}' is not activated (activation_policy != ALWAYS). Start the instance before running the DR pipeline."
    }
  }
}

# Prerequisites 1, 2, 5, 6 plus placeholder/tooling/config-correctness checks
# all need live calls or file inspection, so they run through the shared
# prevalidate suite. TF_VAR_capella_api_token, already exported by the
# operator per the README, passes straight through to the child process -
# no new env plumbing needed here.
resource "null_resource" "preflight" {
  triggers = {
    cloudsql_instance = var.cloudsql_instance_name
    capella_cluster   = var.capella_cluster_id
    backup_bucket     = var.backup_bucket
    backup_generation = jsonencode(local.backup_generations)
    gke_name          = var.dr_gke_name
    create_cluster    = tostring(var.create_gke_cluster)
    tfvars_path       = local.tfvars_path
    lib_script        = filemd5("${path.root}/prevalidate/lib.sh")
    checks_script     = filemd5("${path.root}/prevalidate/checks.sh")
    entry_script      = filemd5("${path.root}/prevalidate.sh")
  }

  provisioner "local-exec" {
    # prevalidate.sh lives at the repo root; run from there, otherwise its
    # own path assumptions (lib.sh, SCRIPT_DIR) break. The command has
    # arguments, so bash needs -c to read it as a script string instead of a
    # file path (TF's default `["/bin/bash"]` only works for single-word
    # commands).
    command     = "\"${path.root}/prevalidate.sh\" --tfvars \"${local.tfvars_path}\" --report \"${var.report_path}\""
    interpreter = ["/bin/bash", "-c"]
    working_dir = path.root
    environment = {
      NET_TIMEOUT_SECONDS = "60"
    }
  }

  provisioner "local-exec" {
    when    = destroy
    command = "true"
  }

  depends_on = [terraform_data.cloudsql_state_gate]
}

data "local_file" "preflight_report" {
  filename   = "${abspath(path.root)}/${var.report_path}"
  depends_on = [null_resource.preflight]
}
