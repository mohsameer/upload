variable "project_id" {
  type = string
}

variable "dr_region" {
  type = string
}

variable "gcp_credentials_file" {
  type = string
}

variable "cloudsql_instance_name" {
  type        = string
  description = "Prerequisite 3. Read-only here. Only read when postgres_restore_method is gcloud_sql_import."
}

variable "postgres_restore_method" {
  type        = string
  description = "psql_pod never touches the Cloud SQL Admin API, so the instance data source is skipped on that path."
}

variable "backup_bucket" {
  type        = string
  description = "Prerequisite 4/5. Read-only here."
}

variable "required_backup_objects" {
  type        = list(string)
  description = "Objects that must exist in backup_bucket before the run starts."
}

variable "capella_api_url" {
  type = string
}

variable "capella_api_token" {
  type      = string
  sensitive = true
}

variable "capella_organization_id" {
  type = string
}

variable "capella_project_id" {
  type = string
}

variable "capella_cluster_id" {
  type        = string
  description = "Prerequisite 2. Read-only here."
}

variable "dr_gke_name" {
  type = string
}

variable "dr_gke_location" {
  type = string
}

variable "create_gke_cluster" {
  type        = bool
  description = "When false, prerequisite 6 requires the cluster to already be describable."
}

variable "report_path" {
  type        = string
  description = "Where the preflight report JSON is written on the bastion."
  default     = ".dr-run/preflight-report.json"
}

variable "tfvars_path" {
  type        = string
  description = <<-EOT
    Path to the tfvars file this DR run was invoked with. Defaults to
    pps-dr.tfvars next to the root module - the same file the operator passed
    to `tofu apply -var-file=pps-dr.tfvars`.

    This lets Phase 0 delegate to the same prevalidate/checks.sh suite the
    standalone `./prevalidate.sh` gate uses, reading the same file, rather
    than carrying a second implementation of any check (see openspec change
    dr-prevalidation). path.root always resolves to the repo root regardless
    of which module references it, so no wiring from the root module is
    needed for the default to be correct.
  EOT
  default     = ""
}

variable "backup_credentials_file" {
  type    = string
  default = ""
}
