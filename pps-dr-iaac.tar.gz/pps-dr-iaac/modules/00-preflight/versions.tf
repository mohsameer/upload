terraform {
  required_providers {
    google = {
      source = "hashicorp/google"
      # google.backups reads the backup bucket with backup_credentials_file
      # (the prod SA can read the prod backup bucket; the DR SA cannot).
      configuration_aliases = [google.backups]
    }
  }
}
