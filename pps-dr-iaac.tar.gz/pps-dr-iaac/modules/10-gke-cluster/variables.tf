variable "project_id" {
  type = string
}

variable "gcp_credentials_file" {
  type = string
}

variable "kubeconfig_path" {
  type = string
}

variable "create_gke_cluster" {
  type        = bool
  description = "true: create the cluster. false: adopt the existing one as a data source."
}

variable "dr_gke_name" {
  type = string
}

variable "dr_gke_location" {
  type = string
}

variable "dr_gke_node_locations" {
  type = list(string)
}

variable "dr_gke_machine_type" {
  type = string
}

variable "dr_gke_disk_size_gb" {
  type = number
}

variable "dr_gke_disk_type" {
  type = string
}

variable "dr_gke_image_type" {
  type = string
}

variable "dr_gke_node_sa_account" {
  type = string
}

variable "dr_gke_network_link" {
  type = string
}

variable "dr_gke_subnetwork_link" {
  type = string
}

variable "dr_gke_networking_mode" {
  type = string
}

variable "dr_gke_cluster_ipv4_cidr_block" {
  type = string
}

variable "dr_gke_services_ipv4_cidr_block" {
  type = string
}

variable "dr_gke_master_ipv4_cidr_block" {
  type = string
}

variable "dr_gke_master_authorized_networks" {
  type = list(object({
    cidr_block   = string
    display_name = string
  }))
}

variable "dr_gke_node_pool_name" {
  type = string
}

variable "dr_gke_node_count" {
  type = number
}

variable "dr_gke_release_channel" {
  type = string
}

variable "platform_namespace" {
  type = string
}

variable "argocd_namespace" {
  type = string
}

variable "external_secrets_namespace" {
  type = string
}

variable "app_namespaces" {
  type = list(string)
}

variable "ingress_namespace" {
  type = string
}

# --- Fidelity with the captured live cluster (design.md E1/E2) --------------
# Defaults reproduce the module's previous output.

variable "dr_gke_datapath_provider" {
  type        = string
  description = "LEGACY_DATAPATH or ADVANCED_DATAPATH. Empty keeps the provider default."
  default     = ""
}

variable "dr_gke_resource_labels" {
  type    = map(string)
  default = {}
}

variable "dr_gke_oauth_scopes" {
  type    = list(string)
  default = ["https://www.googleapis.com/auth/cloud-platform"]
}

variable "dr_gke_enable_integrity_monitoring" {
  type    = bool
  default = true
}

variable "dr_gke_enable_secure_boot" {
  type    = bool
  default = false
}

variable "dr_gke_workload_metadata_mode" {
  type        = string
  description = "GKE_METADATA or GCE_METADATA. Empty leaves it unset."
  default     = ""
}

variable "dr_gke_logging_components" {
  type        = list(string)
  description = "Empty leaves logging_config unset."
  default     = []
}

variable "dr_gke_managed_prometheus" {
  type        = bool
  description = "Null leaves monitoring_config unset."
  default     = null
}

variable "dr_gke_max_pods_per_node" {
  type    = number
  default = 110
}

variable "dr_gke_private_endpoint_enforcement" {
  type    = bool
  default = false
}

variable "dr_gke_cluster_secondary_range_name" {
  type        = string
  description = "Existing subnet secondary range for pods. When set, dr_gke_cluster_ipv4_cidr_block is ignored."
  default     = ""
}

variable "dr_gke_services_secondary_range_name" {
  type        = string
  description = "Existing subnet secondary range for services. When set, dr_gke_services_ipv4_cidr_block is ignored."
  default     = ""
}

variable "cluster_deletion_protection" {
  type = bool
}

variable "dr_gke_node_resource_labels" {
  type        = map(string)
  default     = {}
  description = <<-EOT
    GCP labels applied to the node VMs.

    The org policy custom.requireComputeLabels refuses any Compute instance
    without environment, agile_team and tiering labels - note the underscore in
    agile_team, and that tiering wants the tierN form. A node pool whose
    instances are denied leaves the cluster in ERROR with no nodes.
  EOT
}
