# Phase 1 - DR GKE cluster.
#
# "create GKE cluster (3 nodes) if not exists, else use as data source".
# create_gke_cluster drives count on the managed resource and its inverse on
# the data source; downstream code reads the normalised locals below and does
# not care which branch produced them.

resource "google_container_cluster" "dr" {
  # The google provider defaults this to true, which refuses the delete and
  # stops a single-pass teardown. Unlike lifecycle.prevent_destroy this can be
  # driven by a variable, so the guard stays expressible in configuration. A
  # cluster created with it true has to be applied once with it false before it
  # can be destroyed at all, so a DR site that is meant to be rebuilt sets it
  # false from the start.
  deletion_protection = var.cluster_deletion_protection

  count = var.create_gke_cluster ? 1 : 0

  name     = var.dr_gke_name
  location = var.dr_gke_location
  project  = var.project_id

  # The real workers live in the separate node pool below.
  remove_default_node_pool = true
  initial_node_count       = 1

  node_locations = var.dr_gke_node_locations

  network         = var.dr_gke_network_link
  subnetwork      = var.dr_gke_subnetwork_link
  networking_mode = var.dr_gke_networking_mode

  # Only set logging_service/monitoring_service when the richer *_config
  # blocks are NOT in use (they are mutually exclusive). The DR site uses the
  # config blocks via dr_gke_logging_components / dr_gke_managed_prometheus.
  logging_service    = length(var.dr_gke_logging_components) > 0 ? null : "logging.googleapis.com/kubernetes"
  monitoring_service = var.dr_gke_managed_prometheus == null ? "monitoring.googleapis.com/kubernetes" : null

  # Null keeps the provider default (unchanged behaviour); the live DR cluster
  # runs LEGACY_DATAPATH and the rebuild must not silently switch to Dataplane V2.
  datapath_provider         = var.dr_gke_datapath_provider != "" ? var.dr_gke_datapath_provider : null
  resource_labels           = length(var.dr_gke_resource_labels) > 0 ? var.dr_gke_resource_labels : null
  default_max_pods_per_node = var.dr_gke_max_pods_per_node

  dynamic "logging_config" {
    for_each = length(var.dr_gke_logging_components) > 0 ? [1] : []
    content {
      enable_components = var.dr_gke_logging_components
    }
  }

  dynamic "monitoring_config" {
    for_each = var.dr_gke_managed_prometheus == null ? [] : [1]
    content {
      managed_prometheus {
        enabled = var.dr_gke_managed_prometheus
      }
    }
  }

  release_channel {
    channel = var.dr_gke_release_channel
  }

  workload_identity_config {
    workload_pool = "${var.project_id}.svc.id.goog"
  }

  # Named secondary ranges adopt ranges that already exist on the subnet;
  # otherwise GKE creates them from the CIDR blocks. See design.md E2.
  ip_allocation_policy {
    cluster_secondary_range_name  = var.dr_gke_cluster_secondary_range_name != "" ? var.dr_gke_cluster_secondary_range_name : null
    services_secondary_range_name = var.dr_gke_services_secondary_range_name != "" ? var.dr_gke_services_secondary_range_name : null
    cluster_ipv4_cidr_block       = var.dr_gke_cluster_secondary_range_name != "" ? null : var.dr_gke_cluster_ipv4_cidr_block
    services_ipv4_cidr_block      = var.dr_gke_services_secondary_range_name != "" ? null : var.dr_gke_services_ipv4_cidr_block
  }

  private_cluster_config {
    enable_private_nodes    = true
    enable_private_endpoint = false
    master_ipv4_cidr_block  = var.dr_gke_master_ipv4_cidr_block
  }

  # Control plane is reachable only from the bastion/jumpbox CIDRs. Public
  # access stays off; variable validation rejects 0.0.0.0/0.
  master_authorized_networks_config {
    dynamic "cidr_blocks" {
      for_each = var.dr_gke_master_authorized_networks
      content {
        cidr_block   = cidr_blocks.value.cidr_block
        display_name = cidr_blocks.value.display_name
      }
    }
    gcp_public_cidrs_access_enabled      = false
    private_endpoint_enforcement_enabled = var.dr_gke_private_endpoint_enforcement
  }

  addons_config {
    gce_persistent_disk_csi_driver_config {
      enabled = true
    }
    network_policy_config {
      disabled = true
    }
  }

  node_config {
    preemptible     = false
    machine_type    = var.dr_gke_machine_type
    image_type      = var.dr_gke_image_type
    disk_size_gb    = var.dr_gke_disk_size_gb
    disk_type       = var.dr_gke_disk_type
    service_account = var.dr_gke_node_sa_account
    oauth_scopes    = var.dr_gke_oauth_scopes

    # Labels on the node VMs themselves, not on the cluster. The org policy
    # custom.requireComputeLabels denies creating a Compute instance without
    # environment, agile_team and tiering labels, and a node pool whose
    # instances are refused leaves the cluster in ERROR with zero nodes. The
    # cluster's own resource_labels do not satisfy it: the constraint is
    # evaluated against the instance.
    resource_labels = length(var.dr_gke_node_resource_labels) > 0 ? var.dr_gke_node_resource_labels : null

    shielded_instance_config {
      enable_integrity_monitoring = var.dr_gke_enable_integrity_monitoring
      enable_secure_boot          = var.dr_gke_enable_secure_boot
    }

    dynamic "workload_metadata_config" {
      for_each = var.dr_gke_workload_metadata_mode != "" ? [1] : []
      content {
        mode = var.dr_gke_workload_metadata_mode
      }
    }
  }

  # prevent_destroy is deliberately not set. It cannot be driven by a variable
  # in Terraform or OpenTofu, so leaving it on makes `tofu destroy` impossible
  # to complete in one pass - it fails at plan time with "Instance cannot be
  # destroyed" and the teardown has to be done by hand. The guard is procedural
  # instead: scripts/dr_destroy.sh requires CONFIRM_DESTROY_DR=yes.
}

data "google_container_cluster" "dr" {
  count = var.create_gke_cluster ? 0 : 1

  name     = var.dr_gke_name
  location = var.dr_gke_location
  project  = var.project_id
}

resource "google_container_node_pool" "dr" {
  count = var.create_gke_cluster ? 1 : 0

  name     = var.dr_gke_node_pool_name
  cluster  = google_container_cluster.dr[0].id
  location = var.dr_gke_location
  project  = var.project_id

  node_count     = var.dr_gke_node_count
  node_locations = var.dr_gke_node_locations

  management {
    auto_repair  = true
    auto_upgrade = true
  }

  node_config {
    preemptible     = false
    machine_type    = var.dr_gke_machine_type
    image_type      = var.dr_gke_image_type
    disk_size_gb    = var.dr_gke_disk_size_gb
    disk_type       = var.dr_gke_disk_type
    service_account = var.dr_gke_node_sa_account
    oauth_scopes    = var.dr_gke_oauth_scopes

    # Labels on the node VMs themselves, not on the cluster. The org policy
    # custom.requireComputeLabels denies creating a Compute instance without
    # environment, agile_team and tiering labels, and a node pool whose
    # instances are refused leaves the cluster in ERROR with zero nodes. The
    # cluster's own resource_labels do not satisfy it: the constraint is
    # evaluated against the instance.
    resource_labels = length(var.dr_gke_node_resource_labels) > 0 ? var.dr_gke_node_resource_labels : null

    shielded_instance_config {
      enable_integrity_monitoring = var.dr_gke_enable_integrity_monitoring
      enable_secure_boot          = var.dr_gke_enable_secure_boot
    }

    dynamic "workload_metadata_config" {
      for_each = var.dr_gke_workload_metadata_mode != "" ? [1] : []
      content {
        mode = var.dr_gke_workload_metadata_mode
      }
    }
  }
}

locals {
  # Per attribute, via a splat and one(), not the whole object.
  #
  # Two constraints meet here. Indexing [0] is a hard error during a destroy,
  # when the resource is gone from state while these are still evaluated for
  # the outputs - that failed a destroy which had already removed everything
  # else. But wrapping the whole object in try() taints every output drawn
  # from it as sensitive, because the object contains master_auth: that turned
  # dr_cluster_name into "Output refers to sensitive values" and failed the
  # apply before it created anything.
  #
  # A splat yields an empty list rather than an error when the resource is
  # absent, one() turns that into null, and naming each attribute keeps the
  # non-sensitive ones non-sensitive.
  cluster_name     = var.create_gke_cluster ? one(google_container_cluster.dr[*].name) : one(data.google_container_cluster.dr[*].name)
  cluster_endpoint = var.create_gke_cluster ? one(google_container_cluster.dr[*].endpoint) : one(data.google_container_cluster.dr[*].endpoint)
  # A cluster GKE could not finish creating (GCE_STOCKOUT leaves it in ERROR) has
  # no master_auth at all; indexing it failed every plan, destroy included, with
  # "Attempt to index null value". try() on the one attribute keeps the
  # sensitivity of the rest of the object intact.
  cluster_ca = var.create_gke_cluster ? one([for c in google_container_cluster.dr : try(c.master_auth[0].cluster_ca_certificate, null)]) : one([for c in data.google_container_cluster.dr : try(c.master_auth[0].cluster_ca_certificate, null)])
  cluster_id = var.create_gke_cluster ? one(google_container_cluster.dr[*].id) : one(data.google_container_cluster.dr[*].id)

  all_namespaces = distinct(concat(
    [
      var.platform_namespace,
      var.argocd_namespace,
      var.external_secrets_namespace,
      var.ingress_namespace,
    ],
    var.app_namespaces,
  ))

  # "default" already exists in every cluster and must not be managed here.
  managed_namespaces = [for ns in local.all_namespaces : ns if ns != "default"]
}

# Refresh the kubeconfig the kubernetes/helm providers read. On a first-ever
# build the cluster does not exist at plan time, so this module is applied with
# -target first; see design.md D4a and the README.
resource "null_resource" "get_credentials" {
  triggers = {
    cluster_id = local.cluster_id
    kubeconfig = var.kubeconfig_path
    script     = filemd5("${path.module}/get_credentials.sh")
  }

  provisioner "local-exec" {
    command     = "./get_credentials.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      PROJECT_ID                     = var.project_id
      GOOGLE_APPLICATION_CREDENTIALS = var.gcp_credentials_file
      GKE_NAME                       = var.dr_gke_name
      GKE_LOCATION                   = var.dr_gke_location
      KUBECONFIG_PATH                = pathexpand(var.kubeconfig_path)
    }
  }

  depends_on = [google_container_node_pool.dr]
}

# Namespaces are applied server-side rather than declared as
# kubernetes_namespace: on the adopt path the namespaces usually already
# exist, and `kubernetes_namespace` errors on a pre-existing object instead of
# adopting it. `kubectl apply` is idempotent, and the stable triggers below
# keep a re-apply a no-op.
resource "null_resource" "namespaces" {
  triggers = {
    namespaces = join(",", local.managed_namespaces)
    cluster_id = local.cluster_id
    script     = filemd5("${path.module}/namespaces.sh")
  }

  provisioner "local-exec" {
    command     = "./namespaces.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACES = join(" ", local.managed_namespaces)
    }
  }

  depends_on = [null_resource.get_credentials]
}
