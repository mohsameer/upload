output "cluster_name" {
  description = "Name of the DR cluster, whether created or adopted."
  value       = local.cluster_name
}

output "cluster_endpoint" {
  description = "Control plane endpoint."
  value       = local.cluster_endpoint
  sensitive   = true
}

output "cluster_ca_certificate" {
  description = "Cluster CA certificate, base64 encoded."
  value       = local.cluster_ca
  sensitive   = true
}

output "cluster_was_created" {
  description = "true when this run created the cluster, false when it adopted an existing one."
  value       = var.create_gke_cluster
}

output "namespaces" {
  description = "Namespaces ensured by this phase."
  value       = local.all_namespaces
}

output "completed" {
  description = "Gate consumed by Phase 2's depends_on."
  value       = null_resource.namespaces.id
}
