#!/usr/bin/env bash
# Idempotent namespace creation. Safe against a cluster that was adopted
# rather than created.
set -euo pipefail

: "${NAMESPACES:?}"

for ns in ${NAMESPACES}; do
  kubectl create namespace "${ns}" --dry-run=client -o yaml \
    | kubectl label --local -f - "app.kubernetes.io/managed-by=pps-dr-iaac" -o yaml \
    | kubectl apply -f - >/dev/null
  echo "namespace/${ns} ready"
done
