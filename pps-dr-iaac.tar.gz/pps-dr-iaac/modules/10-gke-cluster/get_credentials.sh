#!/usr/bin/env bash
# Refresh the kubeconfig used by the kubernetes and helm providers.
set -euo pipefail

: "${PROJECT_ID:?}" "${GKE_NAME:?}" "${GKE_LOCATION:?}" "${KUBECONFIG_PATH:?}"

KUBECONFIG_EXPANDED="${KUBECONFIG_PATH/#\~/${HOME}}"
mkdir -p "$(dirname "${KUBECONFIG_EXPANDED}")"

gcloud auth activate-service-account \
  --key-file="${GOOGLE_APPLICATION_CREDENTIALS}" \
  --project="${PROJECT_ID}" >/dev/null

KUBECONFIG="${KUBECONFIG_EXPANDED}" gcloud container clusters get-credentials \
  "${GKE_NAME}" \
  --location="${GKE_LOCATION}" \
  --project="${PROJECT_ID}" \
  --internal-ip

# Fail here rather than letting a later phase fail against an unreachable API.
if ! KUBECONFIG="${KUBECONFIG_EXPANDED}" kubectl version -o json >/dev/null 2>&1; then
  echo "ERROR: kubeconfig written to ${KUBECONFIG_EXPANDED} but the DR cluster API is not reachable." >&2
  echo "Check that this bastion's IP is in dr_gke_master_authorized_networks." >&2
  exit 1
fi

echo "Kubeconfig refreshed at ${KUBECONFIG_EXPANDED} for cluster ${GKE_NAME}."
