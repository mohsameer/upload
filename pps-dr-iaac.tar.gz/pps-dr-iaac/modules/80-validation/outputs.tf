output "signoff_report_path" {
  description = "Path of the sign-off report on the bastion. Written on both success and failure."
  value       = var.signoff_report_path
}

output "restarted_services" {
  value = var.post_restart_services
}

output "completed" {
  value = null_resource.validate.id
}
