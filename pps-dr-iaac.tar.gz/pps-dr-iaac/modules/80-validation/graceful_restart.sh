#!/usr/bin/env bash
# Graceful restart of the configured workloads, waiting for each rollout.
set -euo pipefail

: "${NAMESPACE:?}" "${TIMEOUT_SECONDS:?}"

if [[ -z "${SERVICES:-}" ]]; then
  echo "post_restart_services is empty; nothing to restart."
  exit 0
fi

FAILED=()

for svc in ${SERVICES}; do
  echo "Restarting ${svc} in ${NAMESPACE}..."
  if ! kubectl -n "${NAMESPACE}" rollout restart "${svc}"; then
    FAILED+=("${svc}: rollout restart failed")
    continue
  fi
done

for svc in ${SERVICES}; do
  echo "Waiting for ${svc} rollout..."
  if ! kubectl -n "${NAMESPACE}" rollout status "${svc}" --timeout="${TIMEOUT_SECONDS}s"; then
    FAILED+=("${svc}: rollout did not complete within ${TIMEOUT_SECONDS}s")
  fi
done

if [[ ${#FAILED[@]} -gt 0 ]]; then
  echo "ERROR: graceful restart failed:" >&2
  for f in "${FAILED[@]}"; do echo "  - ${f}" >&2; done
  exit 1
fi

echo "All configured services restarted and rolled out."
