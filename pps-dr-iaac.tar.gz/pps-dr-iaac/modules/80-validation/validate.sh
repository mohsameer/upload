#!/usr/bin/env bash
# Phase 8 validation and sign-off.
#
# Runs every check, records each result, writes the report on BOTH success and
# failure, and exits non-zero if any check failed. The report is the evidence
# the DR exercise is signed off with.
set -uo pipefail

: "${REPORT_PATH:?}"

ENTRIES=()
FAILURES=()

record() {
  local check="$1" status="$2" detail="$3"
  ENTRIES+=("$(printf '{"check":"%s","status":"%s","detail":"%s"}' \
    "${check}" "${status}" "$(printf '%s' "${detail}" | tr '\n' ' ' | sed 's/"/\\"/g')")")
  printf '  [%s] %s - %s\n' "${status}" "${check}" "${detail}"
  [[ "${status}" == "pass" ]] || FAILURES+=("${check}: ${detail}")
}

write_report() {
  local joined
  joined=$(IFS=,; echo "${ENTRIES[*]:-}")
  mkdir -p "$(dirname "${REPORT_PATH}")"
  cat >"${REPORT_PATH}" <<EOF
{
  "phase": "8 - validation and sign-off",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "result": "$([[ ${#FAILURES[@]} -eq 0 ]] && echo pass || echo fail)",
  "checks": [${joined}]
}
EOF
}
trap write_report EXIT

echo "== DNS =="
for host in ${DR_HOSTNAMES:-}; do
  if getent hosts "${host}" >/dev/null 2>&1; then
    record "dns:${host}" "pass" "resolves from the bastion"
  else
    record "dns:${host}" "fail" "does not resolve from the bastion"
  fi
done

echo "== Service health endpoints =="
for pair in ${HEALTH_ENDPOINTS:-}; do
  name="${pair%%=*}"
  url="${pair#*=}"
  CODE=$(curl -sS -o /dev/null -w '%{http_code}' --max-time 20 "${url}" 2>/dev/null || echo "000")
  if [[ "${CODE}" == "200" ]]; then
    record "health:${name}" "pass" "HTTP 200 from ${url}"
  else
    record "health:${name}" "fail" "HTTP ${CODE} from ${url}"
  fi
done

echo "== OIDC flow =="
if [[ -n "${OIDC_DISCOVERY_URL:-}" ]]; then
  DISC=$(mktemp)
  CODE=$(curl -sS -o "${DISC}" -w '%{http_code}' --max-time 20 "${OIDC_DISCOVERY_URL}" 2>/dev/null || echo "000")
  if [[ "${CODE}" == "200" ]] && jq -e '.issuer' <"${DISC}" >/dev/null 2>&1; then
    record "oidc:discovery" "pass" "discovery document served by $(jq -r '.issuer' <"${DISC}")"
    TOKEN_ENDPOINT=$(jq -r '.token_endpoint // empty' <"${DISC}")

    if [[ -n "${TOKEN_ENDPOINT}" && -n "${OIDC_CLIENT_ID:-}" ]]; then
      TOKEN_RESP=$(curl -sS --max-time 20 -X POST "${TOKEN_ENDPOINT}" \
        -u "${OIDC_CLIENT_ID}:${OIDC_CLIENT_SECRET}" \
        -d 'grant_type=client_credentials' 2>/dev/null || true)
      if echo "${TOKEN_RESP}" | jq -e '.access_token' >/dev/null 2>&1; then
        record "oidc:token" "pass" "token issued for client ${OIDC_CLIENT_ID}"
      else
        record "oidc:token" "fail" "no access_token for client ${OIDC_CLIENT_ID}: $(echo "${TOKEN_RESP}" | head -c 200)"
      fi
    else
      record "oidc:token" "fail" "token_endpoint or client id missing"
    fi
  else
    record "oidc:discovery" "fail" "HTTP ${CODE} from ${OIDC_DISCOVERY_URL}"
  fi
  rm -f "${DISC}"
fi

echo "== Couchbase Capella session read/write =="
if command -v cbc >/dev/null 2>&1; then
  for bucket in ${CAPELLA_BUCKETS:-}; do
    KEY="dr-validate-$(date +%s)"
    if cbc create "${KEY}" -V '{"dr":"probe"}' \
         -U "${CAPELLA_CONNECTION_STRING}/${bucket}" \
         -u "${COUCHBASE_USERNAME}" -P "${COUCHBASE_PASSWORD}" >/dev/null 2>&1 \
       && cbc cat "${KEY}" \
         -U "${CAPELLA_CONNECTION_STRING}/${bucket}" \
         -u "${COUCHBASE_USERNAME}" -P "${COUCHBASE_PASSWORD}" >/dev/null 2>&1; then
      cbc rm "${KEY}" -U "${CAPELLA_CONNECTION_STRING}/${bucket}" \
        -u "${COUCHBASE_USERNAME}" -P "${COUCHBASE_PASSWORD}" >/dev/null 2>&1 || true
      record "couchbase:${bucket}" "pass" "write, read and cleanup succeeded"
    else
      record "couchbase:${bucket}" "fail" "session read/write probe failed"
    fi
  done
else
  record "couchbase:client" "fail" "cbc (libcouchbase) not installed on the DR bastion; cannot run the session probe"
fi

echo "== IDM PostgreSQL read/write =="
if command -v psql >/dev/null 2>&1; then
  # Prefer the configured private IP: on the psql_pod path the Cloud SQL Admin
  # API may be unreachable from the bastion and the instance name unknown.
  PGHOST_RESOLVED="${CLOUDSQL_PRIVATE_IP:-}"
  if [[ -z "${PGHOST_RESOLVED}" && -n "${CLOUDSQL_INSTANCE:-}" ]]; then
    PGHOST_RESOLVED=$(gcloud sql instances describe "${CLOUDSQL_INSTANCE}" \
      --format='value(ipAddresses[0].ipAddress)' 2>/dev/null || true)
  fi
  CLOUDSQL_INSTANCE="${CLOUDSQL_INSTANCE:-${PGHOST_RESOLVED}}"
  if [[ -n "${PGHOST_RESOLVED}" ]]; then
    if PGPASSWORD="${PG_PASSWORD}" psql -h "${PGHOST_RESOLVED}" -U "${PG_USER}" -d "${PG_DATABASE}" \
         -c 'CREATE TABLE IF NOT EXISTS dr_signoff_probe (id int primary key, seen_at timestamptz default now())' >/dev/null 2>&1 \
       && PGPASSWORD="${PG_PASSWORD}" psql -h "${PGHOST_RESOLVED}" -U "${PG_USER}" -d "${PG_DATABASE}" \
         -c 'INSERT INTO dr_signoff_probe (id) VALUES (1) ON CONFLICT (id) DO UPDATE SET seen_at = now()' >/dev/null 2>&1 \
       && PGPASSWORD="${PG_PASSWORD}" psql -h "${PGHOST_RESOLVED}" -U "${PG_USER}" -d "${PG_DATABASE}" \
         -tAc 'SELECT count(*) FROM dr_signoff_probe' >/dev/null 2>&1; then
      PGPASSWORD="${PG_PASSWORD}" psql -h "${PGHOST_RESOLVED}" -U "${PG_USER}" -d "${PG_DATABASE}" \
        -c 'DROP TABLE dr_signoff_probe' >/dev/null 2>&1 || true
      record "postgres:idm-rw" "pass" "read and write against ${CLOUDSQL_INSTANCE}/${PG_DATABASE}"
    else
      record "postgres:idm-rw" "fail" "read/write probe failed against ${CLOUDSQL_INSTANCE}/${PG_DATABASE}"
    fi
  else
    record "postgres:idm-rw" "fail" "could not resolve an IP for Cloud SQL instance ${CLOUDSQL_INSTANCE}"
  fi
else
  record "postgres:client" "fail" "psql not installed on the DR bastion"
fi

echo "== Argo CD health =="
UNHEALTHY=()
while read -r name sync health; do
  [[ -z "${name}" ]] && continue
  [[ "${sync}" == "Synced" && "${health}" == "Healthy" ]] && continue
  UNHEALTHY+=("${name}(sync=${sync},health=${health})")
done < <(kubectl -n "${ARGOCD_NAMESPACE}" get applications.argoproj.io \
          -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.status.sync.status}{" "}{.status.health.status}{"\n"}{end}' 2>/dev/null)

if [[ ${#UNHEALTHY[@]} -eq 0 ]]; then
  record "argocd:applications" "pass" "all Applications Synced and Healthy"
else
  record "argocd:applications" "fail" "not Synced/Healthy: ${UNHEALTHY[*]}"
fi

echo
if [[ ${#FAILURES[@]} -gt 0 ]]; then
  echo "SIGN-OFF FAILED - ${#FAILURES[@]} check(s) failed:" >&2
  for f in "${FAILURES[@]}"; do echo "  - ${f}" >&2; done
  echo "Report: ${REPORT_PATH}" >&2
  exit 1
fi

echo "SIGN-OFF PASSED. Report: ${REPORT_PATH}"
