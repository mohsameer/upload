variable "kubeconfig_path" {
  type = string
}

variable "app_namespaces" {
  type = list(string)
}

variable "argocd_namespace" {
  type = string
}

variable "post_restart_services" {
  type        = list(string)
  description = "Workloads restarted once DNS resolves, as kind/name (e.g. deployment/oidc)."
}

variable "health_check_endpoints" {
  type = map(string)
}

variable "oidc_discovery_url" {
  type = string
}

variable "oidc_validation_client_id" {
  type = string
}

variable "oidc_validation_client_secret" {
  type      = string
  sensitive = true
}

variable "capella_connection_string" {
  type = string
}

variable "capella_buckets" {
  type = list(string)
}

variable "couchbase_username" {
  type = string
}

variable "couchbase_password" {
  type      = string
  sensitive = true
}

variable "cloudsql_private_ip" {
  type        = string
  description = "Used for the read/write probe when set; otherwise the IP is looked up from cloudsql_instance_name."
  default     = ""
}

variable "cloudsql_instance_name" {
  type = string
}

variable "cloudsql_database_name" {
  type = string
}

variable "cloudsql_import_user" {
  type = string
}

variable "cloudsql_import_password" {
  type      = string
  sensitive = true
}

variable "dr_hostnames" {
  type = map(string)
}

variable "readiness_timeout_seconds" {
  type = number
}

variable "signoff_report_path" {
  type = string
}

variable "restart_namespace" {
  type        = string
  description = "Namespace the post_restart_services live in."
  default     = "default"
}
