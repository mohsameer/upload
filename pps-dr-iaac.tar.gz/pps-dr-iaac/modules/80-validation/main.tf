# Phase 8 - graceful restart, validation, sign-off.
#
# Applied as a targeted run once PPS has completed the DNS change:
#   tofu apply -target=module.validation -var-file=pps-dr.tfvars
#
# The restart exists because services that started while their hostnames were
# unresolvable cache that failure; they need a clean start once DNS is live.

resource "null_resource" "graceful_restart" {
  triggers = {
    services = join(",", var.post_restart_services)
    script   = filemd5("${path.module}/graceful_restart.sh")
    # Re-running Phase 8 is a legitimate operator action, so this always runs
    # when explicitly targeted.
    run_id = uuid()
  }

  provisioner "local-exec" {
    command     = "./graceful_restart.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.restart_namespace
      SERVICES        = join(" ", var.post_restart_services)
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "validate" {
  triggers = {
    restart_id = null_resource.graceful_restart.id
    script     = filemd5("${path.module}/validate.sh")
  }

  provisioner "local-exec" {
    command     = "./validate.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      ARGOCD_NAMESPACE = var.argocd_namespace
      APP_NAMESPACES   = join(" ", var.app_namespaces)

      HEALTH_ENDPOINTS = join(" ", [
        for name, url in var.health_check_endpoints : "${name}=${url}"
      ])

      OIDC_DISCOVERY_URL = var.oidc_discovery_url
      OIDC_CLIENT_ID     = var.oidc_validation_client_id
      OIDC_CLIENT_SECRET = var.oidc_validation_client_secret

      CAPELLA_CONNECTION_STRING = var.capella_connection_string
      CAPELLA_BUCKETS           = join(" ", var.capella_buckets)
      COUCHBASE_USERNAME        = var.couchbase_username
      COUCHBASE_PASSWORD        = var.couchbase_password

      CLOUDSQL_INSTANCE   = var.cloudsql_instance_name
      CLOUDSQL_PRIVATE_IP = var.cloudsql_private_ip
      PG_DATABASE         = var.cloudsql_database_name
      PG_USER             = var.cloudsql_import_user
      PG_PASSWORD         = var.cloudsql_import_password

      DR_HOSTNAMES = join(" ", values(var.dr_hostnames))
      REPORT_PATH  = var.signoff_report_path
    }
  }
}
