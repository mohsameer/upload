#!/usr/bin/env bash
# Refresh every registry credential in the DR cluster from one token exchange.
#
# Runs twice over its life: once as the bootstrap Job (so later phases are not
# blocked waiting for the first tick), then on the CronJob schedule. Both use
# this same script from the same ConfigMap.
#
# ECR authorization tokens are valid for 12 hours, which is why this exists at
# all: a credential written once at provisioning time is dead by the next day,
# and a DR site is precisely where nobody should be renewing it by hand.
#
# Two consumers, one token:
#   1. dockerconfigjson image pull secret, in every target namespace
#   2. Argo CD repository secret (type: helm, enableOCI) for Helm OCI charts
set -uo pipefail

: "${REGISTRY_SERVER:?}" "${PULL_SECRET_NAME:?}" "${TARGET_NAMESPACES:?}"
: "${ARGOCD_NAMESPACE:?}" "${ARGOCD_REPO_SECRET_NAME:?}"

STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
ATTACH_TO_DEFAULT_SA="${ATTACH_TO_DEFAULT_SA:-true}"
FAILURES=()
SKIPPED=()
UPDATED=()

echo "=== registry credential refresh @ ${STAMP} ==="
echo "registry: ${REGISTRY_SERVER}"

# --- obtain the registry token ---------------------------------------------
if [[ "${REGISTRY_SERVER}" == *".ecr."* ]]; then
  # ECR host format: <acct>.dkr.ecr.<region>.amazonaws.com
  ECR_REGION="$(echo "${REGISTRY_SERVER}" | awk -F. '{print $4}')"
  if [[ -z "${ECR_REGION}" ]]; then
    echo "ERROR: cannot derive an AWS region from registry host '${REGISTRY_SERVER}'." >&2
    exit 1
  fi

  echo "mode: AWS ECR (region ${ECR_REGION})"
  DOCKER_USER="AWS"
  DOCKER_PASS="$(AWS_ACCESS_KEY_ID="${REGISTRY_KEY}" \
                 AWS_SECRET_ACCESS_KEY="${REGISTRY_SECRET}" \
                 aws ecr get-login-password --region "${ECR_REGION}" 2>&1)"

  if [[ -z "${DOCKER_PASS}" || "${DOCKER_PASS}" == *"error"* || "${DOCKER_PASS}" == *"Unable to locate"* ]]; then
    echo "ERROR: ECR token exchange failed for ${REGISTRY_SERVER} in ${ECR_REGION}." >&2
    echo "  ${DOCKER_PASS}" >&2
    exit 1
  fi
  echo "token: obtained (valid 12h)"
else
  echo "mode: generic registry (no token exchange)"
  DOCKER_USER="${REGISTRY_KEY}"
  DOCKER_PASS="${REGISTRY_SECRET}"
fi

DOCKERCONFIG="$(printf '{"auths":{"%s":{"username":"%s","password":"%s","auth":"%s"}}}' \
  "${REGISTRY_SERVER}" "${DOCKER_USER}" "${DOCKER_PASS}" \
  "$(printf '%s:%s' "${DOCKER_USER}" "${DOCKER_PASS}" | base64 -w0 2>/dev/null || printf '%s:%s' "${DOCKER_USER}" "${DOCKER_PASS}" | base64)")"

# --- 1. image pull secrets --------------------------------------------------
echo
echo "--- image pull secrets ---"
for ns in ${TARGET_NAMESPACES}; do
  if ! kubectl get namespace "${ns}" >/dev/null 2>&1; then
    # Expected during bootstrap: some namespaces are created by later phases.
    # Skipping keeps this run useful instead of failing it wholesale.
    SKIPPED+=("namespace/${ns} (does not exist yet)")
    echo "  ${ns}: SKIP (namespace absent)"
    continue
  fi

  if kubectl -n "${ns}" create secret docker-registry "${PULL_SECRET_NAME}" \
       --docker-server="${REGISTRY_SERVER}" \
       --docker-username="${DOCKER_USER}" \
       --docker-password="${DOCKER_PASS}" \
       --dry-run=client -o yaml \
     | kubectl -n "${ns}" apply -f - >/dev/null 2>&1; then

    kubectl -n "${ns}" annotate secret "${PULL_SECRET_NAME}" \
      "pps-dr/last-refresh=${STAMP}" --overwrite >/dev/null 2>&1 || true

    UPDATED+=("${ns}/${PULL_SECRET_NAME}")
    echo "  ${ns}: secret/${PULL_SECRET_NAME} updated"
  else
    FAILURES+=("${ns}/${PULL_SECRET_NAME}: apply failed")
    echo "  ${ns}: FAILED" >&2
    continue
  fi

  # Attach to the default ServiceAccount so workloads that do not declare
  # imagePullSecrets still pull successfully.
  if [[ "${ATTACH_TO_DEFAULT_SA}" == "true" ]]; then
    if kubectl -n "${ns}" patch serviceaccount default \
         -p "{\"imagePullSecrets\":[{\"name\":\"${PULL_SECRET_NAME}\"}]}" >/dev/null 2>&1; then
      echo "  ${ns}: default ServiceAccount patched"
    else
      FAILURES+=("${ns}: could not patch default ServiceAccount")
      echo "  ${ns}: FAILED to patch default ServiceAccount" >&2
    fi
  fi
done

# --- 2. Argo CD Helm OCI repository secret ---------------------------------
echo
echo "--- Argo CD Helm OCI repository secret ---"
if kubectl get namespace "${ARGOCD_NAMESPACE}" >/dev/null 2>&1; then
  # Distinct from the git repository credential that Phase 4 owns: this one
  # lets Argo CD's repo-server pull the iCrypto Helm charts from ECR over OCI.
  if cat <<EOF | kubectl apply -f - >/dev/null 2>&1
apiVersion: v1
kind: Secret
metadata:
  name: ${ARGOCD_REPO_SECRET_NAME}
  namespace: ${ARGOCD_NAMESPACE}
  labels:
    argocd.argoproj.io/secret-type: repository
    app.kubernetes.io/managed-by: pps-dr-iaac
  annotations:
    pps-dr/last-refresh: "${STAMP}"
type: Opaque
stringData:
  name: "${ARGOCD_REPO_SECRET_NAME}"
  type: "helm"
  url: "${REGISTRY_SERVER}"
  enableOCI: "true"
  username: "${DOCKER_USER}"
  password: "${DOCKER_PASS}"
EOF
  then
    UPDATED+=("${ARGOCD_NAMESPACE}/${ARGOCD_REPO_SECRET_NAME}")
    echo "  ${ARGOCD_NAMESPACE}: secret/${ARGOCD_REPO_SECRET_NAME} updated (type=helm, enableOCI=true)"
  else
    FAILURES+=("${ARGOCD_NAMESPACE}/${ARGOCD_REPO_SECRET_NAME}: apply failed")
    echo "  ${ARGOCD_NAMESPACE}: FAILED" >&2
  fi
else
  # Argo CD arrives in Phase 4; during the Phase 1 bootstrap this is normal.
  SKIPPED+=("namespace/${ARGOCD_NAMESPACE} (Argo CD not installed yet)")
  echo "  ${ARGOCD_NAMESPACE}: SKIP (namespace absent)"
fi

# --- summary ----------------------------------------------------------------
echo
echo "=== summary @ ${STAMP} ==="
echo "updated: ${#UPDATED[@]}"
for u in "${UPDATED[@]:-}"; do [[ -n "${u}" ]] && echo "  + ${u}"; done
if [[ ${#SKIPPED[@]} -gt 0 ]]; then
  echo "skipped: ${#SKIPPED[@]}"
  for s in "${SKIPPED[@]}"; do echo "  ~ ${s}"; done
fi

if [[ ${#FAILURES[@]} -gt 0 ]]; then
  echo "FAILED: ${#FAILURES[@]}" >&2
  for f in "${FAILURES[@]}"; do echo "  - ${f}" >&2; done
  echo "Registry credentials are NOT fully refreshed for ${REGISTRY_SERVER}." >&2
  exit 1
fi

echo "All registry credentials refreshed."
