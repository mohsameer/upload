variable "registry_server" {
  type        = string
  description = "Container registry hosting the iCrypto images and Helm OCI charts. An '.ecr.' host selects the AWS token-exchange path."
}

variable "ecr_access_key" {
  type        = string
  description = "AWS access key id with ECR read access (or the registry username for a non-ECR registry)."
  sensitive   = true
}

variable "ecr_secret_key" {
  type        = string
  description = "AWS secret access key (or the registry password for a non-ECR registry)."
  sensitive   = true
}

variable "image_pull_secret_name" {
  type        = string
  description = "Name of the dockerconfigjson pull secret maintained in every target namespace."
  default     = "icrypto-registry"
}

variable "target_namespaces" {
  type        = list(string)
  description = "Namespaces that receive the image pull secret. A namespace that does not exist yet is skipped and picked up on the next refresh."
}

variable "argocd_namespace" {
  type        = string
  description = "Namespace holding the Argo CD Helm OCI repository secret."
}

variable "argocd_repo_secret_name" {
  type        = string
  description = "Name of the Argo CD repository secret for the ECR OCI registry. Matches the name used in the other PPS environments."
  default     = "icrypto-helm"
}

variable "credentials_namespace" {
  type        = string
  description = "Namespace the refresh workload runs in."
  default     = "platform"
}

variable "refresh_schedule" {
  type        = string
  description = "Cron schedule for the refresh. ECR tokens live 12h; the default of every 6h leaves a full missed run of margin."
  default     = "0 */6 * * *"

  validation {
    # Guard against a cadence that cannot keep a 12-hour token alive: daily,
    # weekly, monthly or fixed-hour schedules all leave an expiry window.
    condition     = can(regex("^[0-9*/,-]+ \\*/([1-6]) \\* \\* \\*$", var.refresh_schedule))
    error_message = "refresh_schedule must run at least every 6 hours (e.g. \"0 */6 * * *\"); ECR tokens expire after 12 hours."
  }
}

variable "runner_image" {
  type        = string
  description = <<-EOT
    Image for the bootstrap Job and the refresh CronJob. Needs both `aws` and
    `kubectl`. IMPORTANT: this image must be pullable WITHOUT registry
    credentials - it is the workload that creates them, so it cannot live in
    the ECR registry it authenticates to.
  EOT
  default     = "alpine/k8s:1.31.3"
}

variable "attach_to_default_service_account" {
  type        = bool
  description = "Patch each target namespace's default ServiceAccount with the pull secret, so workloads need not declare imagePullSecrets."
  default     = true
}

variable "kubeconfig_path" {
  type        = string
  description = "Kubeconfig used by the bootstrap wait from the bastion."
}

variable "bootstrap_timeout_seconds" {
  type        = number
  description = "How long to wait for the bootstrap Job before failing the apply."
  default     = 300
}
