#!/usr/bin/env bash
# Apply the refresher's in-cluster resources.
#
# The AWS credential Secret is created separately from the rendered manifests
# so the key material never passes through a templatefile() result, which
# would put it in the Terraform plan output.
set -euo pipefail

: "${NAMESPACE:?}" "${MANIFESTS:?}" "${AWS_SECRET_NAME:?}" "${REGISTRY_KEY:?}" "${REGISTRY_SECRET:?}"

# The credentials namespace may be created by Phase 1, but this module must
# also work when pointed at a namespace of its own.
kubectl create namespace "${NAMESPACE}" --dry-run=client -o yaml \
  | kubectl apply -f - >/dev/null

kubectl -n "${NAMESPACE}" create secret generic "${AWS_SECRET_NAME}" \
  --from-literal=access_key="${REGISTRY_KEY}" \
  --from-literal=secret_key="${REGISTRY_SECRET}" \
  --dry-run=client -o yaml \
  | kubectl apply -f - >/dev/null
echo "secret/${AWS_SECRET_NAME} ready in ${NAMESPACE}"

printf '%s' "${MANIFESTS}" | kubectl apply -f - >/dev/null
echo "registry credential refresher resources applied (ServiceAccount, RBAC, ConfigMap, CronJob)"
