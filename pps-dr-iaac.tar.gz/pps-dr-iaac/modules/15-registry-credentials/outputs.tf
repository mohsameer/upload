output "pull_secret_name" {
  description = "Name of the dockerconfigjson secret maintained in every target namespace."
  value       = var.image_pull_secret_name
}

output "argocd_repo_secret_name" {
  description = "Argo CD repository secret carrying the ECR Helm OCI credential."
  value       = var.argocd_repo_secret_name
}

output "managed_namespaces" {
  description = "Namespaces whose registry credentials are kept current."
  value       = local.namespaces
}

output "refresh_schedule" {
  description = "Cron schedule of the refresh. ECR tokens expire after 12h."
  value       = var.refresh_schedule
}

output "staleness_check_command" {
  description = "Confirms credentials are current without decoding the token."
  value       = "kubectl -n ${var.credentials_namespace} get secret ${var.image_pull_secret_name} -o jsonpath='{.metadata.annotations.pps-dr/last-refresh}'"
}

output "completed" {
  description = "Set only after the bootstrap refresh has succeeded. Consumed by Phase 2 and Phase 4."
  value       = null_resource.bootstrap.id
}
