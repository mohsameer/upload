#!/usr/bin/env bash
# Run the refresh immediately, rather than waiting for the CronJob's first
# tick, and fail the apply if credentials cannot be established.
#
# Without this, Phase 2 could start up to a full schedule interval before any
# pull secret exists.
set -euo pipefail

: "${NAMESPACE:?}" "${CRONJOB_NAME:?}" "${REGISTRY_SERVER:?}" "${PULL_SECRET_NAME:?}" "${TIMEOUT_SECONDS:?}"

JOB="${CRONJOB_NAME}-bootstrap-$(date +%s)"

# Deriving the Job from the CronJob guarantees the bootstrap and the scheduled
# refresh run byte-identical pod specs.
kubectl -n "${NAMESPACE}" create job "${JOB}" --from="cronjob/${CRONJOB_NAME}" >/dev/null
echo "bootstrap job/${JOB} created from cronjob/${CRONJOB_NAME}"

cleanup() {
  kubectl -n "${NAMESPACE}" delete job "${JOB}" --ignore-not-found >/dev/null 2>&1 || true
}

echo "Waiting up to ${TIMEOUT_SECONDS}s for the bootstrap refresh..."
if ! kubectl -n "${NAMESPACE}" wait --for=condition=complete "job/${JOB}" --timeout="${TIMEOUT_SECONDS}s"; then
  echo "ERROR: bootstrap registry credential refresh failed for ${REGISTRY_SERVER}." >&2
  echo "--- job logs ---" >&2
  kubectl -n "${NAMESPACE}" logs "job/${JOB}" --tail=100 >&2 || true
  echo "----------------" >&2
  echo "Check the AWS credentials (TF_VAR_ecr_access_key / TF_VAR_ecr_secret_key) and that they have ECR read access to ${REGISTRY_SERVER}." >&2
  cleanup
  exit 1
fi

kubectl -n "${NAMESPACE}" logs "job/${JOB}" --tail=100 || true
cleanup

# Prove the credential actually landed rather than trusting the exit code.
if ! kubectl -n "${NAMESPACE}" get secret "${PULL_SECRET_NAME}" >/dev/null 2>&1; then
  echo "ERROR: bootstrap reported success but secret/${PULL_SECRET_NAME} is missing in ${NAMESPACE}." >&2
  exit 1
fi

echo "Bootstrap complete: registry credentials are live for ${REGISTRY_SERVER}."
