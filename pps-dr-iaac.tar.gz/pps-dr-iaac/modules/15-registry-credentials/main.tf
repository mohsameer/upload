# Registry credentials for the private ECR registry.
#
# Not one of the eight runbook phases - numbered 15 because it sits between
# the cluster (Phase 1) and the platform (Phase 2), and because it serves
# Phases 1, 4 and 6 rather than belonging to any single one.
#
# This is the one module in the repo that leaves a RUNNING WORKLOAD behind.
# Every other module converges and finishes. An ECR authorization token is
# valid for 12 hours, so a credential written once at provisioning time is
# dead by the next day - and a DR site is exactly where nobody should be
# renewing it by hand. The time-varying behaviour lives in a CronJob rather
# than in a Terraform trigger, which keeps design decision D5 intact: no
# `timestamp()` anywhere, so a re-apply is still a no-op.

locals {
  namespaces = distinct(concat(var.target_namespaces, [var.credentials_namespace]))

  script_hash = filemd5("${path.module}/refresh.sh")

  # Environment shared by the bootstrap Job and the CronJob so there is
  # exactly one code path to reason about.
  job_env = [
    { name = "REGISTRY_SERVER", value = var.registry_server },
    { name = "PULL_SECRET_NAME", value = var.image_pull_secret_name },
    { name = "TARGET_NAMESPACES", value = join(" ", local.namespaces) },
    { name = "ARGOCD_NAMESPACE", value = var.argocd_namespace },
    { name = "ARGOCD_REPO_SECRET_NAME", value = var.argocd_repo_secret_name },
    { name = "ATTACH_TO_DEFAULT_SA", value = tostring(var.attach_to_default_service_account) },
  ]

  manifests = templatefile("${path.module}/manifests.yaml.tftpl", {
    namespace         = var.credentials_namespace
    service_account   = "registry-credential-refresher"
    role_name         = "pps-dr-registry-credential-refresher"
    aws_secret_name   = "registry-refresh-aws-credentials"
    configmap_name    = "registry-refresh-script"
    cronjob_name      = "registry-credential-refresh"
    schedule          = var.refresh_schedule
    runner_image      = var.runner_image
    target_namespaces = local.namespaces
    argocd_namespace  = var.argocd_namespace
    env               = local.job_env
    script            = file("${path.module}/refresh.sh")
    script_hash       = local.script_hash
  })
}

# Namespace, AWS credential Secret, ServiceAccount, RBAC, script ConfigMap and
# the CronJob. Applied server-side so an existing object is adopted rather
# than fought over.
resource "null_resource" "registry_refresh_resources" {
  triggers = {
    manifests       = sha256(local.manifests)
    key_fingerprint = sha256(var.ecr_access_key)
    secret_hash     = sha256(var.ecr_secret_key)
    script          = local.script_hash
    apply_script    = filemd5("${path.module}/apply_manifests.sh")
  }

  provisioner "local-exec" {
    command     = "./apply_manifests.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.credentials_namespace
      MANIFESTS       = local.manifests
      AWS_SECRET_NAME = "registry-refresh-aws-credentials"
      REGISTRY_KEY    = var.ecr_access_key
      REGISTRY_SECRET = var.ecr_secret_key
    }
  }
}

# A CronJob does not run at creation time, so the first scheduled refresh
# could be hours away - long after Phase 2 needs to pull. This Job runs the
# identical script immediately, and the module does not report `completed`
# until it has succeeded.
resource "null_resource" "bootstrap" {
  triggers = {
    resources   = null_resource.registry_refresh_resources.id
    script      = local.script_hash
    namespaces  = join(",", local.namespaces)
    boot_script = filemd5("${path.module}/bootstrap.sh")
  }

  provisioner "local-exec" {
    command     = "./bootstrap.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      NAMESPACE        = var.credentials_namespace
      CRONJOB_NAME     = "registry-credential-refresh"
      REGISTRY_SERVER  = var.registry_server
      PULL_SECRET_NAME = var.image_pull_secret_name
      TIMEOUT_SECONDS  = tostring(var.bootstrap_timeout_seconds)
    }
  }
}
