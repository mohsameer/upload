#!/usr/bin/env bash
# Redirect the source site's data-tier hostnames to this site's, in-cluster only.
#
# The applications' init container runs a connectivity check baked into its
# image, mapping the environment name to a Capella host:
#   "qa") cb.9kuwrvff0yegmxpm...  "ppd") cb.5rjmwcl2y0pxlzmo...
#   "prod") cb.hspduwrqqqqblf19...
# There is no DR entry, and the restored Applications carry ENVIRONMENT=prod_az1,
# so every pod probes production's Capella. Production's Capella does not
# allowlist this cluster - measured from a pod: 18091 filtered on production's
# host, open on this site's private endpoint - so twelve of seventeen
# Applications sat in Init:0/2 indefinitely, waiting on a cluster they must not
# reach anyway.
#
# A Cloud DNS private zone would be tidier, but the DR service account has no
# dns.* permission. kube-dns is the resolver here; it supports stubDomains - a
# domain delegated to a nameserver - but not single-name rewrites, so this
# deploys a small CoreDNS that answers the source domain with a CNAME to this
# site's host, and delegates that domain to it. A CNAME, not an address, so A
# and SRV both resolve correctly through the normal path and nothing here needs
# to know the endpoint's IP.
set -euo pipefail

: "${NAMESPACE:?}"
REDIRECTS="${REDIRECTS:-}"
COREDNS_IMAGE="${COREDNS_IMAGE:-coredns/coredns:1.11.3}"
NAME="${NAME:-dr-dns-redirect}"

if [[ -z "${REDIRECTS//[[:space:]]/}" ]]; then
  echo "No endpoint redirects configured; cluster DNS left alone."
  exit 0
fi

ZONES=""
STUBS=""
while IFS= read -r pair; do
  [[ -z "${pair//[[:space:]]/}" ]] && continue
  src="${pair%%=*}"; dst="${pair#*=}"
  # Trim, then skip a pair with no destination. A hostname whose address is not
  # reserved arrives here with an empty target, and emitting a zone that
  # answers with nothing is worse than not answering: CoreDNS would claim the
  # name and hand back an empty record instead of letting the query fall
  # through. Filtering these out in HCL instead would make the map's keys
  # unknown at plan time and break Phase 2's count.
  src="${src//[[:space:]]/}"; dst="${dst//[[:space:]]/}"
  if [[ -z "${src}" || -z "${dst}" ]]; then
    [[ -n "${src}" ]] && echo "  skipping ${src}: no target address"
    continue
  fi
  [[ -n "${src}" && -n "${dst}" && "${src}" != "${dst}" ]] \
    || { echo "ERROR: malformed redirect '${pair}'" >&2; exit 1; }
  echo "  ${src} -> ${dst}"
  # An address target answers A directly; a hostname answers CNAME so the
  # client resolves it through the normal path and A and SRV both come out
  # right. The DR database is reached by private IP and has no name of its
  # own, which is why both forms are needed.
  #
  # An address target answers A queries only. AAAA gets an empty NOERROR answer:
  # answering "IN ANY" put the A record into AAAA replies too, and nginx's
  # resolver logs "unexpected A record in DNS response" every few seconds.
  if [[ "${dst}" =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    TEMPLATES="template IN A ${src} {
            answer \"{{ .Name }} 60 IN A ${dst}\"
        }
        template IN AAAA ${src} {
            rcode NOERROR
        }"
  else
    TEMPLATES="template IN ANY ${src} {
            answer \"{{ .Name }} 60 IN CNAME ${dst}\"
        }"
  fi
  ZONES+="
    ${src}:53 {
        errors
        ${TEMPLATES}
    }
"
  STUBS+="${STUBS:+,}\\\"${src}\\\": [\\\"CLUSTER_IP\\\"]"
done <<< "${REDIRECTS}"

kubectl -n "${NAMESPACE}" apply -f - >/dev/null <<EOF
apiVersion: v1
kind: ConfigMap
metadata:
  name: ${NAME}
data:
  Corefile: |
    .:53 {
        errors
        health :8080
        reload 10s
        forward . /etc/resolv.conf
        cache 30
    }
${ZONES}
---
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${NAME}
  labels: { app: ${NAME} }
spec:
  replicas: 2
  selector:
    matchLabels: { app: ${NAME} }
  template:
    metadata:
      labels: { app: ${NAME} }
    spec:
      containers:
        - name: coredns
          image: ${COREDNS_IMAGE}
          args: ["-conf", "/etc/coredns/Corefile"]
          ports:
            - { containerPort: 53, protocol: UDP }
            - { containerPort: 53, protocol: TCP }
          livenessProbe:
            httpGet: { path: /health, port: 8080 }
            initialDelaySeconds: 10
          resources:
            requests: { cpu: 50m, memory: 64Mi }
            limits:   { cpu: 200m, memory: 128Mi }
          volumeMounts:
            - { name: config, mountPath: /etc/coredns }
      volumes:
        - name: config
          configMap: { name: ${NAME} }
---
apiVersion: v1
kind: Service
metadata:
  name: ${NAME}
spec:
  selector: { app: ${NAME} }
  ports:
    - { name: dns,     port: 53, protocol: UDP, targetPort: 53 }
    - { name: dns-tcp, port: 53, protocol: TCP, targetPort: 53 }
EOF

# Restarted, not just applied. A ConfigMap change reaches the mounted volume
# within a minute or so and CoreDNS only re-reads it on the reload tick, so
# without this the resolver keeps serving the previous answers - which cost a
# cycle: the Corefile already held the right A record while the pods were
# still answering the old CNAME.
kubectl -n "${NAMESPACE}" rollout restart "deploy/${NAME}" >/dev/null 2>&1 || true
kubectl -n "${NAMESPACE}" rollout status "deploy/${NAME}" --timeout=300s

IP=$(kubectl -n "${NAMESPACE}" get svc "${NAME}" -o jsonpath='{.spec.clusterIP}')
[[ -n "${IP}" ]] || { echo "ERROR: ${NAME} Service has no clusterIP." >&2; exit 1; }

# Patched, not replaced: GKE manages other keys in this ConfigMap.
kubectl -n kube-system patch configmap kube-dns --type merge \
  -p "{\"data\":{\"stubDomains\":\"{${STUBS//CLUSTER_IP/${IP}}}\"}}" >/dev/null
echo "kube-dns stubDomains delegated to ${IP}"

# kube-dns reloads on its own, but the applications start within a minute of
# this, so make it deterministic.
kubectl -n kube-system rollout restart deploy/kube-dns >/dev/null 2>&1 || true
kubectl -n kube-system rollout status deploy/kube-dns --timeout=180s >/dev/null 2>&1 || true
echo "cluster DNS redirects in place."
