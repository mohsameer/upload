#!/usr/bin/env bash
# Install or upgrade one Helm release through the Helm CLI.
#
# Why not the terraform helm provider: a provider is configured before any
# resource in the apply runs, so one pointed at a cluster that this same apply
# creates cannot work. That is what forced the DR build into two passes
# (-target=module.dr_cluster, then everything else). Driving Helm through the
# CLI from a null_resource makes the whole site one `tofu apply`.
#
# Values arrive as content, not as a path: the rendered values of several
# releases carry passwords, and a file written next to the module would leave
# them on disk. Content is written to a 0600 temp file and deleted on exit.
set -euo pipefail

: "${RELEASE:?}" "${NAMESPACE:?}" "${CHART:?}"

ACTION="${ACTION:-install}"
WAIT="${WAIT:-true}"
WAIT_FOR_JOBS="${WAIT_FOR_JOBS:-false}"
ATOMIC="${ATOMIC:-false}"
CREATE_NAMESPACE="${CREATE_NAMESPACE:-false}"
TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-900}"

command -v helm >/dev/null 2>&1 || { echo "ERROR: helm is not on this host." >&2; exit 1; }

if [[ "${ACTION}" == "uninstall" ]]; then
  # A destroy runs before the cluster goes, so this normally succeeds; it must
  # not fail the destroy when the cluster or the release is already gone.
  if helm -n "${NAMESPACE}" status "${RELEASE}" >/dev/null 2>&1; then
    if helm -n "${NAMESPACE}" uninstall "${RELEASE}" --wait --timeout "${TIMEOUT_SECONDS}s"; then
      echo "uninstalled ${RELEASE} from ${NAMESPACE}"
    else
      # Reported, not fatal: a destroy must still be able to remove the
      # cluster underneath a release that will not uninstall cleanly.
      echo "WARNING: helm uninstall of ${RELEASE} in ${NAMESPACE} failed; continuing" >&2
    fi
  else
    echo "${RELEASE} is not installed in ${NAMESPACE}; nothing to uninstall"
  fi
  exit 0
fi

WORKDIR="$(mktemp -d)"
trap 'rm -rf "${WORKDIR}"' EXIT

# An OCI chart is addressed as one reference, not as --repo plus a name:
# `helm upgrade ldap oci://host/path --version X`.
if [[ "${REPO:-}" == oci://* ]]; then
  CHART="${REPO%/}/${CHART}"
  REPO=""
fi

args=(upgrade --install "${RELEASE}" "${CHART}" --namespace "${NAMESPACE}")

[[ -n "${REPO:-}" ]] && args+=(--repo "${REPO}")
[[ -n "${VERSION:-}" ]] && args+=(--version "${VERSION}")
[[ "${CREATE_NAMESPACE}" == "true" ]] && args+=(--create-namespace)
[[ "${ATOMIC}" == "true" ]] && args+=(--atomic)
[[ "${WAIT}" == "true" ]] && args+=(--wait)
[[ "${WAIT_FOR_JOBS}" == "true" ]] && args+=(--wait-for-jobs)
args+=(--timeout "${TIMEOUT_SECONDS}s")

if [[ -n "${VALUES_CONTENT:-}" ]]; then
  printf '%s' "${VALUES_CONTENT}" > "${WORKDIR}/values.yaml"
  chmod 600 "${WORKDIR}/values.yaml"
  args+=(--values "${WORKDIR}/values.yaml")
fi
if [[ -n "${VALUES_FILE:-}" ]]; then
  [[ -f "${VALUES_FILE}" ]] || { echo "ERROR: values file ${VALUES_FILE} not found." >&2; exit 1; }
  args+=(--values "${VALUES_FILE}")
fi

# SET_ARGS / SET_STRING_ARGS: one key=value per line. --set-string is for the
# values that must not be retyped by Helm (bcrypt hashes, passwords).
while IFS= read -r kv; do
  [[ -n "${kv}" ]] && args+=(--set "${kv}")
done <<< "${SET_ARGS:-}"
while IFS= read -r kv; do
  [[ -n "${kv}" ]] && args+=(--set-string "${kv}")
done <<< "${SET_STRING_ARGS:-}"

# SET_SECRET_ARGS: key=value per line, for values that must not appear in argv
# (passwords, bcrypt hashes) - anyone on the host can read helm's command line
# out of ps for as long as the upgrade runs, which is up to the readiness
# timeout. --set-file takes the value from a 0600 file instead, which also
# avoids helm splitting a value on commas the way --set-string does.
secret_i=0
while IFS= read -r kv; do
  [[ -n "${kv}" ]] || continue
  secret_i=$((secret_i + 1))
  printf '%s' "${kv#*=}" > "${WORKDIR}/secret-${secret_i}"
  chmod 600 "${WORKDIR}/secret-${secret_i}"
  args+=(--set-file "${kv%%=*}=${WORKDIR}/secret-${secret_i}")
done <<< "${SET_SECRET_ARGS:-}"

# --- OCI registry login -------------------------------------------------------
# The chart registry is the same ECR that serves the images, and its token
# lasts 12 hours. Rather than add a second credential path, reuse the pull
# secret module 15 already keeps fresh in the cluster.
if [[ "${CHART}" == oci://* ]]; then
  host="${CHART#oci://}"
  host="${host%%/*}"
  logged_in=false

  # First choice: the pull secret module 15 already keeps fresh in the
  # cluster, so there is one credential path rather than two.
  if [[ -n "${REGISTRY_SECRET:-}" ]]; then
    dockercfg=$(kubectl -n "${REGISTRY_SECRET_NAMESPACE:-${NAMESPACE}}" get secret "${REGISTRY_SECRET}" \
      -o jsonpath='{.data.\.dockerconfigjson}' 2>/dev/null | base64 -d || true)
    auth=$(printf '%s' "${dockercfg:-}" | jq -r --arg h "${host}" '.auths[$h].auth // empty' 2>/dev/null | base64 -d 2>/dev/null || true)
    if [[ -n "${auth}" ]]; then
      helm registry login "${host}" --username "${auth%%:*}" --password-stdin <<<"${auth#*:}" >/dev/null
      echo "helm registry login ${host} (from secret/${REGISTRY_SECRET})"
      logged_in=true
    fi
  fi

  # Fallback: mint a token from the ECR keys. The chart has to be pullable
  # even when the pull secret is not there yet, because on a cold build this
  # release can be the first thing that needs the registry.
  if [[ "${logged_in}" == "false" && "${host}" == *".ecr."* && -n "${ECR_ACCESS_KEY:-}" ]]; then
    region=$(echo "${host}" | awk -F. '{print $4}')
    if token=$(AWS_ACCESS_KEY_ID="${ECR_ACCESS_KEY}" AWS_SECRET_ACCESS_KEY="${ECR_SECRET_KEY:-}" \
         aws ecr get-login-password --region "${region}" 2>/dev/null); then
      helm registry login "${host}" --username AWS --password-stdin <<<"${token}" >/dev/null
      echo "helm registry login ${host} (ECR token, region ${region})"
      logged_in=true
    fi
  fi

  [[ "${logged_in}" == "true" ]] || \
    echo "WARNING: no registry credentials for ${host}; relying on an existing helm login" >&2
fi

echo "helm upgrade --install ${RELEASE} ${CHART} ${VERSION:+(${VERSION}) }-> ${NAMESPACE}"
helm "${args[@]}"
