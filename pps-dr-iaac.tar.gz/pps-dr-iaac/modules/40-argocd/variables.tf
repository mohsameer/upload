variable "argocd_namespace" {
  type = string
}

variable "argocd_chart_version" {
  type = string
}

variable "argocd_hostname" {
  type = string
}

variable "argocd_admin_password_bcrypt" {
  type      = string
  sensitive = true
}

variable "argocd_backup_object" {
  type = string
}

variable "backup_bucket" {
  type = string
}

variable "gcp_credentials_file" {
  type = string
}

variable "kubeconfig_path" {
  type = string
}

variable "readiness_timeout_seconds" {
  type = number
}

variable "git_repo_url" {
  type = string
}

variable "git_user" {
  type = string
}

variable "git_pat" {
  type      = string
  sensitive = true
}

variable "dr_gke_name" {
  type        = string
  description = "Used to assert restored Application destinations resolve to the DR cluster."
}

variable "argocd_chart_repository" {
  type    = string
  default = "https://argoproj.github.io/argo-helm"
}

variable "argocd_internal_lb_enabled" {
  type        = bool
  description = "Add an additional internal LoadBalancer Service (argocd-server-int) for operator UI access, mirroring the old DR site."
  default     = false
}

variable "backup_credentials_file" {
  type    = string
  default = ""
}

variable "argocd_retarget_destinations" {
  type = bool
}

variable "argocd_skip_cluster_secrets" {
  type = bool
}

variable "argocd_exclude_applications" {
  type = list(string)
}

variable "upstream_gate" {
  type        = string
  default     = ""
  description = <<-EOT
    Value threaded in from the restored Consul/Vault/LDAP data.

    Argo CD's install and backup restore need nothing from the databases -
    application auto-sync is held until Phase 6 regardless - so this phase
    waits only for the platform data and runs while midpoint is still
    restoring.
  EOT
}

variable "restore_exclude_secrets" {
  type        = list(string)
  default     = []
  description = "Secrets in the Argo CD backup not to apply, by name. This site maintains them itself."
}
