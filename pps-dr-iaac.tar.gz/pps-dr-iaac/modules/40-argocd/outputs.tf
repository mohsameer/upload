output "argocd_namespace" {
  value = var.argocd_namespace
}

output "argocd_server_service" {
  description = "In-cluster Argo CD server service."
  value       = "argocd-server.${var.argocd_namespace}.svc"
}

output "sync_held" {
  description = "Auto-sync is held here and released in Phase 6."
  value       = true
}

output "completed" {
  description = "Gate consumed by Phase 5's depends_on."
  value       = null_resource.argocd_restore.id
}
