# Phase 4 - Argo CD.
#
# Installs Argo CD and restores its backup. Application auto-sync stays HELD
# until Phase 5 has ESO syncing secrets: syncing apps before their Secrets
# exist just produces a namespace full of crash-looping pods.

locals {
  # Helm through its CLI, not the helm provider: a provider cannot be pointed
  # at a cluster that the same apply creates. See modules/common/helm_apply.sh.
  argocd_values = templatefile("${path.module}/values/argocd.yaml.tftpl", {
    hostname            = var.argocd_hostname
    internal_lb_enabled = var.argocd_internal_lb_enabled
  })
}

# What this phase actually waits for; see var.upstream_gate.
resource "terraform_data" "upstream" {
  input = var.upstream_gate
}

resource "null_resource" "argocd" {
  # A destroy provisioner may only read `self`, so the uninstall reads what it
  # needs from triggers.
  triggers = {
    release    = "argocd"
    namespace  = var.argocd_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
    chart      = "${var.argocd_chart_repository}|argo-cd|${var.argocd_chart_version}"
    values     = md5(local.argocd_values)
    # Without this a rotated admin password never reaches the cluster: the
    # value is not in the values file, so nothing else here changes.
    admin_password = sha256(var.argocd_admin_password_bcrypt)
    script         = filemd5("${path.module}/../common/helm_apply.sh")
  }

  depends_on = [terraform_data.upstream]

  provisioner "local-exec" {
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG     = pathexpand(var.kubeconfig_path)
      RELEASE        = "argocd"
      NAMESPACE      = var.argocd_namespace
      REPO           = var.argocd_chart_repository
      CHART          = "argo-cd"
      VERSION        = var.argocd_chart_version
      VALUES_CONTENT = local.argocd_values
      # Through a file, not argv: a bcrypt hash in helm's command line is
      # readable with ps for the whole upgrade. --set-file also leaves the
      # hash's own characters alone.
      SET_SECRET_ARGS  = "configs.secret.argocdServerAdminPassword=${var.argocd_admin_password_bcrypt}"
      CREATE_NAMESPACE = "true"
      WAIT             = "true"
      TIMEOUT_SECONDS  = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "argocd_ready" {
  triggers = {
    release = null_resource.argocd.id
    script  = filemd5("${path.module}/wait_argocd.sh")
  }

  provisioner "local-exec" {
    command     = "./wait_argocd.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG      = pathexpand(var.kubeconfig_path)
      NAMESPACE       = var.argocd_namespace
      TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

# Repository credentials. Recreated rather than stored in state so rotating the
# PAT does not require a state surgery. Skipped when no git repository is used:
# PPS Applications pull Helm OCI charts from ECR, whose credential is the
# icrypto-helm secret maintained by module 15.
resource "null_resource" "repo_credentials" {
  count = var.git_repo_url != "" ? 1 : 0

  triggers = {
    repo      = var.git_repo_url
    user      = var.git_user
    pat_hash  = sha256(var.git_pat)
    argocd_id = null_resource.argocd_ready.id
    script    = filemd5("${path.module}/repo_credentials.sh")
  }

  provisioner "local-exec" {
    command     = "./repo_credentials.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.argocd_namespace
      GIT_REPO   = var.git_repo_url
      GIT_USER   = var.git_user
      GIT_PAT    = var.git_pat
    }
  }
}

data "external" "argocd_backup" {
  program = ["bash", "${path.root}/scripts/gcs_describe.sh"]
  query = {
    uri              = "gs://${var.backup_bucket}/${var.argocd_backup_object}"
    credentials_file = var.backup_credentials_file
  }
}

resource "null_resource" "argocd_restore" {
  triggers = {
    retarget          = "${var.argocd_retarget_destinations}-${var.argocd_skip_cluster_secrets}-${join(",", var.argocd_exclude_applications)}"
    backup_object     = var.argocd_backup_object
    backup_generation = data.external.argocd_backup.result.generation
    argocd_id         = null_resource.argocd_ready.id
    exclude_secrets   = join(",", var.restore_exclude_secrets)
    script            = filemd5("${path.module}/argocd_restore.sh")
  }

  provisioner "local-exec" {
    command     = "./argocd_restore.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG                             = pathexpand(var.kubeconfig_path)
      GOOGLE_APPLICATION_CREDENTIALS         = var.gcp_credentials_file
      CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE = var.gcp_credentials_file
      NAMESPACE                              = var.argocd_namespace
      BACKUP_URI                             = "gs://${var.backup_bucket}/${var.argocd_backup_object}"
      DR_CLUSTER_NAME                        = var.dr_gke_name
      HOLD_SYNC                              = "true"
      RETARGET_DESTINATIONS                  = tostring(var.argocd_retarget_destinations)
      SKIP_CLUSTER_SECRETS                   = tostring(var.argocd_skip_cluster_secrets)
      EXCLUDE_SECRETS                        = join(" ", var.restore_exclude_secrets)
      EXCLUDE_APPLICATIONS                   = join(" ", var.argocd_exclude_applications)
    }
  }

  depends_on = [null_resource.repo_credentials]
}

# --- uninstalls -------------------------------------------------------------
# The uninstall of each release lives in its own resource, deliberately.
#
# `triggers` is ForceNew: with the destroy provisioner on the install resource,
# any trigger change - a new chart version, edited values, even an edit to
# helm_apply.sh, whose checksum is a trigger - replaces the resource, and a
# replacement runs the destroy provisioner first. Editing that one script would
# have run `helm uninstall` against Consul (Vault's storage backend), Vault,
# OpenLDAP and Argo CD on a live site before reinstalling them.
#
# Here the uninstall resources carry only stable triggers, so they are never
# replaced, and a change to an install resource is just an idempotent
# `helm upgrade --install`. depends_on gives the right destroy order: Terraform
# destroys in reverse dependency order, so the uninstall runs before the
# install resource it depends on is removed.

resource "null_resource" "argocd_uninstall" {
  triggers = {
    release    = "argocd"
    namespace  = var.argocd_namespace
    kubeconfig = pathexpand(var.kubeconfig_path)
    timeout    = tostring(var.readiness_timeout_seconds)
  }

  provisioner "local-exec" {
    when        = destroy
    on_failure  = continue
    command     = "${path.module}/../common/helm_apply.sh"
    interpreter = ["/bin/bash"]
    environment = {
      KUBECONFIG      = self.triggers.kubeconfig
      ACTION          = "uninstall"
      RELEASE         = self.triggers.release
      NAMESPACE       = self.triggers.namespace
      CHART           = "unused-on-uninstall"
      TIMEOUT_SECONDS = self.triggers.timeout
    }
  }

  depends_on = [null_resource.argocd]
}
