#!/usr/bin/env bash
# Restore the Argo CD backup: AppProjects, Applications, repository and cluster
# secrets.
#
# Two things are enforced on the way in:
#   1. Every restored Application must target the DR cluster. A backup taken
#      from production carries production destinations; deploying those from
#      the DR site is the worst possible DR outcome.
#   2. Auto-sync is held until Phase 5 has ESO syncing secrets.
set -euo pipefail

: "${NAMESPACE:?}" "${BACKUP_URI:?}" "${DR_CLUSTER_NAME:?}"

# A backup from another site carries that site's destinations and, in
# secrets-cluster.yaml, a working bearer token for its API server. Applying
# those verbatim would let this Argo CD deploy into the source cluster, so both
# are handled before anything is applied rather than detected afterwards.
RETARGET_DESTINATIONS="${RETARGET_DESTINATIONS:-false}"
SKIP_CLUSTER_SECRETS="${SKIP_CLUSTER_SECRETS:-false}"
EXCLUDE_APPLICATIONS="${EXCLUDE_APPLICATIONS:-}"
# Secrets in the backup that must not overwrite what this site already has.
#
# The registry repository secret is the one that matters. Module 15 mints a
# fresh ECR token and writes it before this phase runs; the backup carries the
# same secret name with the token that was valid when the backup was taken.
# Applying it puts a dead credential back - measured: a secret created at
# 05:19 held a token that had expired four days earlier, and every Helm OCI
# chart pull then failed with 403 Forbidden, which stalled ESO and with it the
# whole of Phase 5.
EXCLUDE_SECRETS="${EXCLUDE_SECRETS:-}"

WORKDIR=$(mktemp -d)
trap 'rm -rf "${WORKDIR}"' EXIT

echo "Downloading Argo CD backup ${BACKUP_URI}..."
if ! gcloud storage cp "${BACKUP_URI}" "${WORKDIR}/argocd-backup"; then
  echo "ERROR: cannot read the Argo CD backup at ${BACKUP_URI}." >&2
  exit 1
fi

# Accept a plain manifest export, a gzipped one, or a tarball holding several
# manifest files (the PPS backup bundle has one file per resource kind:
# applications, appprojects, applicationsets, configmaps, argocd-secret and
# repository / repo-creds / cluster secrets). Every manifest is applied.
BACKUP_FILES=()
case "${BACKUP_URI}" in
  *.tar.gz|*.tgz)
    mkdir -p "${WORKDIR}/extract"
    tar -xzf "${WORKDIR}/argocd-backup" -C "${WORKDIR}/extract"
    mapfile -t BACKUP_FILES < <(find "${WORKDIR}/extract" -type f \( -name '*.yaml' -o -name '*.yml' \) -size +0 | sort)
    ;;
  *.gz)
    gunzip -c "${WORKDIR}/argocd-backup" >"${WORKDIR}/argocd-backup.yaml"
    BACKUP_FILES=("${WORKDIR}/argocd-backup.yaml")
    ;;
  *)
    BACKUP_FILES=("${WORKDIR}/argocd-backup")
    ;;
esac

if [[ ${#BACKUP_FILES[@]} -eq 0 || ! -s "${BACKUP_FILES[0]}" ]]; then
  echo "ERROR: Argo CD backup at ${BACKUP_URI} holds no manifest after extraction." >&2
  exit 1
fi

# A kubectl dump of a live cluster carries server-managed metadata; applying
# an object with resourceVersion set onto a fresh cluster is rejected, and a
# stale status is misleading. Strip both before applying.
SANITIZE='walk(if type == "object" and (.metadata | type) == "object"
  then .metadata |= del(.resourceVersion, .uid, .creationTimestamp, .managedFields, .selfLink, .generation)
  else . end)
  | if .kind == "List" then .items |= map(del(.status)) else del(.status) end'

# Never carry another cluster's credentials into this Argo CD.
if [[ "${SKIP_CLUSTER_SECRETS}" == "true" ]]; then
  KEPT=()
  for f in "${BACKUP_FILES[@]}"; do
    if [[ "$(basename "${f}")" == *cluster* ]]; then
      echo "  skipping $(basename "${f}"): it registers the source cluster's API server and token"
      continue
    fi
    KEPT+=("${f}")
  done
  BACKUP_FILES=(${KEPT[@]+"${KEPT[@]}"})
fi

# Point every Application at this cluster before it is applied.
RETARGET='walk(if type == "object" and (.spec? | type) == "object" and (.spec.destination? | type) == "object"
  then .spec.destination |= ({namespace: .namespace} | with_entries(select(.value != null))) + {server: "https://kubernetes.default.svc"}
  else . end)'

# Drop Secrets this site maintains itself, by name.
EXCLUDE_SECRETS_JSON=$(printf '%s\n' ${EXCLUDE_SECRETS} | jq -R . | jq -s .)
FILTER_SECRETS='def dropsec($names): if .kind == "Secret" and (.metadata.name | IN($names[])) then empty else . end;
  if .kind == "List" then .items |= map(dropsec($sx)) else dropsec($sx) end'

# Drop Applications this site does not run.
EXCLUDE_JSON=$(printf '%s\n' ${EXCLUDE_APPLICATIONS} | jq -R . | jq -s .)
FILTER_APPS='def drop($names): if .kind == "Application" and (.metadata.name | IN($names[])) then empty else . end;
  if .kind == "List" then .items |= map(drop($ex)) else drop($ex) end'

echo "Applying ${#BACKUP_FILES[@]} Argo CD manifest file(s) into namespace ${NAMESPACE}..."
[[ "${RETARGET_DESTINATIONS}" == "true" ]] && echo "  destinations will be rewritten to https://kubernetes.default.svc"
[[ -n "${EXCLUDE_APPLICATIONS}" ]] && echo "  excluding Applications: ${EXCLUDE_APPLICATIONS}"
[[ -n "${EXCLUDE_SECRETS}" ]] && echo "  excluding Secrets: ${EXCLUDE_SECRETS} (this site maintains them)"

for f in "${BACKUP_FILES[@]}"; do
  echo "  - ${f#"${WORKDIR}"/extract/}"
  JQ="${SANITIZE}"
  [[ "${RETARGET_DESTINATIONS}" == "true" ]] && JQ="${JQ} | ${RETARGET}"
  [[ -n "${EXCLUDE_APPLICATIONS}" ]] && JQ="${JQ} | ${FILTER_APPS}"
  [[ -n "${EXCLUDE_SECRETS}" ]] && JQ="${JQ} | ${FILTER_SECRETS}"
  kubectl -n "${NAMESPACE}" create --dry-run=client -o json -f "${f}" \
    | jq --argjson ex "${EXCLUDE_JSON}" --argjson sx "${EXCLUDE_SECRETS_JSON}" "${JQ}" \
    | kubectl -n "${NAMESPACE}" apply -f -
done

# --- destination validation -------------------------------------------------
# In-cluster destinations are fine (they resolve to the DR cluster by
# definition). Anything naming another server or cluster is reported.
MISMATCHED=()
while read -r app server name; do
  [[ -z "${app}" ]] && continue
  if [[ "${server}" == "https://kubernetes.default.svc" || -z "${server}" ]]; then
    continue
  fi
  if [[ "${name}" == "in-cluster" || "${name}" == *"${DR_CLUSTER_NAME}"* ]]; then
    continue
  fi
  MISMATCHED+=("${app} -> server=${server} name=${name}")
done < <(kubectl -n "${NAMESPACE}" get applications.argoproj.io \
          -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.spec.destination.server}{" "}{.spec.destination.name}{"\n"}{end}' 2>/dev/null)

if [[ ${#MISMATCHED[@]} -gt 0 ]]; then
  echo "ERROR: restored Applications whose destination does not resolve to the DR cluster '${DR_CLUSTER_NAME}':" >&2
  for m in "${MISMATCHED[@]}"; do echo "  - ${m}" >&2; done
  echo "Repoint them at the DR cluster (or add the DR cluster secret) before continuing." >&2
  exit 1
fi

# --- hold auto-sync until Phase 5 ------------------------------------------
if [[ "${HOLD_SYNC:-true}" == "true" ]]; then
  echo "Holding auto-sync on restored Applications until Phase 5 completes..."
  for app in $(kubectl -n "${NAMESPACE}" get applications.argoproj.io -o name 2>/dev/null); do
    kubectl -n "${NAMESPACE}" patch "${app}" --type=merge \
      -p '{"spec":{"syncPolicy":{"automated":null}},"metadata":{"annotations":{"pps-dr/sync-held-by":"phase-4"}}}' >/dev/null
  done
fi

APPS=$(kubectl -n "${NAMESPACE}" get applications.argoproj.io --no-headers 2>/dev/null | wc -l | tr -d '[:space:]')
PROJECTS=$(kubectl -n "${NAMESPACE}" get appprojects.argoproj.io --no-headers 2>/dev/null | wc -l | tr -d '[:space:]')

echo "Argo CD backup restored: ${APPS} Applications, ${PROJECTS} AppProjects. Auto-sync held."
