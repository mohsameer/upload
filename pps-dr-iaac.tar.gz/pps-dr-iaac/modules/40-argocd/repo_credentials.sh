#!/usr/bin/env bash
# Create or refresh the Argo CD GIT repository credential secret, then confirm
# Argo CD can actually reach the repository.
#
# This owns the git credential only. The ECR Helm OCI repository secret
# (type: helm, enableOCI) is owned by modules/15-registry-credentials, because
# its ECR token expires every 12 hours and has to be refreshed on a schedule.
set -euo pipefail

: "${NAMESPACE:?}" "${GIT_REPO:?}" "${GIT_USER:?}" "${GIT_PAT:?}"

SECRET_NAME="repo-$(printf '%s' "${GIT_REPO}" | shasum | cut -c1-12)"

kubectl -n "${NAMESPACE}" create secret generic "${SECRET_NAME}" \
  --from-literal=type=git \
  --from-literal=url="${GIT_REPO}" \
  --from-literal=username="${GIT_USER}" \
  --from-literal=password="${GIT_PAT}" \
  --dry-run=client -o yaml \
  | kubectl label --local -f - "argocd.argoproj.io/secret-type=repository" -o yaml \
  | kubectl apply -f - >/dev/null

echo "secret/${SECRET_NAME} applied for ${GIT_REPO}"

# Give the repo-server a moment to pick the credential up, then verify.
sleep 10
STATE=$(kubectl -n "${NAMESPACE}" exec deploy/argocd-server -- \
  argocd repo list -o json --core 2>/dev/null \
  | jq -r --arg u "${GIT_REPO}" '.[]? | select(.repo == $u) | .connectionState.status' || true)

if [[ -n "${STATE}" && "${STATE}" != "Successful" ]]; then
  echo "ERROR: Argo CD cannot connect to ${GIT_REPO} (connectionState: ${STATE})." >&2
  exit 1
fi

echo "Repository connection verified: ${GIT_REPO} (${STATE:-pending first refresh})"
