#!/usr/bin/env bash
# Wait for the Argo CD control plane to be Ready.
set -euo pipefail

: "${NAMESPACE:?}" "${TIMEOUT_SECONDS:?}"

for deploy in argocd-server argocd-repo-server; do
  echo "Waiting for deployment/${deploy}..."
  if ! kubectl -n "${NAMESPACE}" rollout status "deployment/${deploy}" --timeout="${TIMEOUT_SECONDS}s"; then
    echo "ERROR: ${deploy} did not become available within ${TIMEOUT_SECONDS}s." >&2
    kubectl -n "${NAMESPACE}" get pods >&2 || true
    exit 1
  fi
done

echo "Waiting for statefulset/argocd-application-controller..."
if ! kubectl -n "${NAMESPACE}" rollout status statefulset/argocd-application-controller --timeout="${TIMEOUT_SECONDS}s"; then
  echo "ERROR: argocd-application-controller did not become Ready within ${TIMEOUT_SECONDS}s." >&2
  kubectl -n "${NAMESPACE}" get pods >&2 || true
  exit 1
fi

echo "Argo CD control plane is Ready."
