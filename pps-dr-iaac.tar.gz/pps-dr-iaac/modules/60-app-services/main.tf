# Phase 6 - iCrypto SSO application services.
#
# Argo CD owns delivery. PPS delivers every service as a Helm OCI chart from
# ECR, and Phase 4 already restored those Applications verbatim, so by default
# this phase pins them to service_versions, releases the Phase 4 sync hold and
# waits for convergence. The git app-of-apps is optional (app_of_apps_enabled)
# for an environment that does use one (openspec change dr-drill-fixes, E8).
# There are no per-service `helm install` scripts here - that was the v1
# approach and it is gone.

locals {
  # Rendered into the app-of-apps as Helm parameters so every service is
  # deployed at an explicitly pinned version for this DR run.
  version_parameters = [
    for name, version in var.service_versions : {
      name  = "services.${name}.version"
      value = version
    }
  ]

  data_tier_parameters = [
    {
      name  = "datasource.postgres.host"
      value = var.cloudsql_private_ip
    },
    {
      name  = "datasource.postgres.connectionName"
      value = var.cloudsql_connection_name
    },
    {
      name  = "datasource.couchbase.connectionString"
      value = var.capella_connection_string
    },
  ]

  app_of_apps_manifest = templatefile("${path.module}/app-of-apps.yaml.tftpl", {
    name             = var.app_of_apps_name
    argocd_namespace = var.argocd_namespace
    project          = var.argocd_project
    repo_url         = var.git_repo_url
    path             = var.app_of_apps_path
    revision         = var.app_of_apps_revision
    parameters       = concat(local.version_parameters, local.data_tier_parameters)
  })
}

# Gates the second sync wave only. The first wave deliberately does not wait
# for it: of the 28 restored Applications, idm-server-v2 is the only one that
# references the Postgres host, and the two others that reference IDM at all
# are already excluded on this site. So everything else syncs and converges
# while midpoint is still restoring - which is most of an hour and a half.
resource "terraform_data" "databases" {
  input = var.database_gate
}

resource "null_resource" "app_of_apps" {
  count = var.app_of_apps_enabled ? 1 : 0

  triggers = {
    manifest = sha256(local.app_of_apps_manifest)
    script   = filemd5("${path.module}/apply_app_of_apps.sh")
  }

  provisioner "local-exec" {
    command     = "./apply_app_of_apps.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.argocd_namespace
      MANIFEST   = local.app_of_apps_manifest
    }
  }

  # NOT depends_on = [terraform_data.databases], which serialised the two waves
  # through a chain nobody expected. null_resource.pin_versions carries
  # try(null_resource.app_of_apps[0].id, "disabled") in its triggers, and a
  # count = 0 resource still keeps its own depends_on edges, so with
  # app_of_apps_enabled = false the graph was still
  #
  #   pin_versions -> app_of_apps -> terraform_data.databases -> var.database_gate
  #
  # and wave 1 waited for the Postgres restore after all. Measured on the
  # 2026-10-12 rebuild: Phases 4, 5 and 5b were finished 18 minutes in, and all
  # 16 Applications sat OutOfSync/Missing while midpoint staged its 117GB dump,
  # with nothing else running. Earlier runs hid it because the restore was
  # already in state, so the gate resolved instantly.
  #
  # The root Application does not need a database: it needs Argo CD, and it
  # needs to run before pin_versions and release_sync_hold, which the trigger
  # chain already gives it. Deferral of git-created children is handled by
  # release_sync_hold's DEFER_APPS, and the wave that genuinely needs the
  # restored data - release_sync_hold_deferred - gates on
  # terraform_data.databases itself.
}

# Repoint any Capella endpoint carried in an Application's Helm parameters at
# this site's cluster, before anything syncs.
#
# Two of the restored Applications hold the source site's Capella cluster as
# parameters instead of reading it from Vault: oidcv2 (cnCouchbaseUrl,
# cnCouchbaseInitUrl, cnCouchbaseUser, cnCouchbaseSuperUser) and oidcv2-loader
# (usrEnvs[1].value). Synced as restored, the DR auth server comes up pointed
# at production - and the only thing standing between it and production's data
# is the DNS redirect in Phase 2.
resource "null_resource" "argocd_capella_parameters" {
  count = var.capella_connection_string != "" ? 1 : 0

  triggers = {
    connection = var.capella_connection_string
    username   = var.couchbase_username
    foreign    = join(",", var.capella_foreign_usernames)
    script     = filemd5("${path.module}/argocd_capella_parameters.sh")
  }

  provisioner "local-exec" {
    command     = "./argocd_capella_parameters.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG          = pathexpand(var.kubeconfig_path)
      NAMESPACE           = var.argocd_namespace
      CAPELLA_URL         = var.capella_connection_string
      CAPELLA_USERNAME    = var.couchbase_username
      CAPELLA_PASSWORD    = var.couchbase_password
      FOREIGN_USERNAMES   = join(" ", var.capella_foreign_usernames)
      PASSWORD_PARAMETERS = join(" ", var.capella_password_parameters)
    }
  }
}

# Pin the restored Applications before the hold is released, so the first
# automated sync already deploys the chosen versions.
resource "null_resource" "pin_versions" {
  triggers = {
    versions    = jsonencode(var.service_versions)
    app_of_apps = try(null_resource.app_of_apps[0].id, "disabled")
    capella     = try(null_resource.argocd_capella_parameters[0].id, "disabled")
    script      = filemd5("${path.module}/pin_versions.sh")
  }

  provisioner "local-exec" {
    command     = "./pin_versions.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG       = pathexpand(var.kubeconfig_path)
      NAMESPACE        = var.argocd_namespace
      SERVICE_VERSIONS = join(" ", [for app, version in var.service_versions : "${app}=${version}"])
    }
  }
}

# Phase 5 has completed by the time this module runs, so the hold placed on
# restored Applications in Phase 4 is released here.
# pps-health is applied out-of-band in the source environments, so it is not in
# the restored Argo CD bundle. nginx-api-gw resolves its upstreams at config
# load and will not start without it.
resource "null_resource" "supporting_workloads" {
  count = var.pps_health_image == "" ? 0 : 1

  triggers = {
    image    = var.pps_health_image
    services = var.services_namespace
    script   = filemd5("${path.module}/supporting_workloads.sh")
  }

  provisioner "local-exec" {
    command     = "./supporting_workloads.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG         = pathexpand(var.kubeconfig_path)
      NAMESPACE          = var.pps_health_namespace
      PPS_HEALTH_IMAGE   = var.pps_health_image
      PULL_SECRET        = var.image_pull_secret_name
      SERVICES_NAMESPACE = var.services_namespace
      TIMEOUT_SECONDS    = tostring(var.readiness_timeout_seconds)
    }
  }
}

# cert-manager rewrites Certificate spec.duration into Go's canonical form
# ("43800h" becomes "43800h0m0s"), so Argo CD diffs the chart value against the
# stored one forever. With selfHeal on that is a permanent sync loop, not drift.
resource "null_resource" "argocd_ignore_differences" {
  count = length(var.argocd_ignore_differences) > 0 ? 1 : 0

  triggers = {
    rules  = jsonencode(var.argocd_ignore_differences)
    script = filemd5("${path.module}/ignore_differences.sh")
  }

  provisioner "local-exec" {
    command     = "./ignore_differences.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.argocd_namespace
      RULES      = jsonencode(var.argocd_ignore_differences)
    }
  }

  depends_on = [null_resource.pin_versions]
}

# Deploy the deferred Applications' objects before wave 1 is released, with
# their pods held at 0 replicas.
#
# nginx-api-gw resolves every upstream when it loads its configuration and
# exits if one does not resolve, so while idm-server-v2 was deferred and
# therefore absent, the gateway crash-looped on
#
#   [emerg] host not found in upstream
#           "idm-server-v2.services.svc.cluster.local:8080"
#
# for as long as the restore took. This runs before release_sync_hold so the
# Service already exists the first time the gateway starts, and nothing starts
# against a database that is not restored yet.
resource "null_resource" "prestage_deferred" {
  count = length(var.deferred_applications) > 0 ? 1 : 0

  triggers = {
    pinned = null_resource.pin_versions.id
    apps   = join(",", var.deferred_applications)
    script = filemd5("${path.module}/prestage_deferred.sh")
  }

  provisioner "local-exec" {
    command     = "./prestage_deferred.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.argocd_namespace
      APPS       = join(" ", var.deferred_applications)
      # Empty falls back to each Application's own destination namespace.
      WORKLOAD_NAMESPACES  = join(" ", var.app_namespaces)
      SYNC_TIMEOUT_SECONDS = tostring(var.readiness_timeout_seconds)
    }
  }
}

resource "null_resource" "release_sync_hold" {
  triggers = {
    pinned    = null_resource.pin_versions.id
    prestaged = try(null_resource.prestage_deferred[0].id, "none")
    script    = filemd5("${path.module}/release_sync_hold.sh")
  }

  provisioner "local-exec" {
    command     = "./release_sync_hold.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.argocd_namespace
      DEFER_APPS = join(" ", var.deferred_applications)
    }
  }
}

resource "null_resource" "convergence_gate" {
  triggers = {
    supporting     = join(",", [for r in null_resource.supporting_workloads : r.id])
    tolerate       = join(",", var.convergence_tolerate_missing_jobs)
    tolerate_apps  = join(",", var.convergence_tolerate_applications)
    ignores        = join(",", [for r in null_resource.argocd_ignore_differences : r.id])
    released       = null_resource.release_sync_hold.id
    service_set    = jsonencode(var.service_versions)
    app_namespaces = join(",", var.app_namespaces)
    script         = filemd5("${path.module}/wait_converged.sh")
  }

  provisioner "local-exec" {
    command     = "./wait_converged.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG                = pathexpand(var.kubeconfig_path)
      NAMESPACE                 = var.argocd_namespace
      APP_NAMESPACES            = join(" ", var.app_namespaces)
      TIMEOUT_SECONDS           = tostring(var.readiness_timeout_seconds)
      TOLERATE_MISSING_JOB_APPS = join(" ", var.convergence_tolerate_missing_jobs)
      IGNORE_APPS               = join(" ", var.deferred_applications)
      TOLERATE_APPS             = join(" ", var.convergence_tolerate_applications)
    }
  }
}

# --- second wave: the Applications that need a restored database ------------
resource "null_resource" "release_sync_hold_deferred" {
  count = length(var.deferred_applications) > 0 ? 1 : 0

  triggers = {
    databases = terraform_data.databases.id
    # The wave-1 *release* is enough: this needs Argo CD up and the hold
    # annotations in place, not the other 27 Applications converged. Waiting
    # for convergence would serialise the waves again, and a wave-1 timeout
    # would stop idm-server-v2 ever syncing.
    released_wave1 = null_resource.release_sync_hold.id
    apps           = join(",", var.deferred_applications)
    script         = filemd5("${path.module}/release_sync_hold.sh")
  }

  provisioner "local-exec" {
    command     = "./release_sync_hold.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG = pathexpand(var.kubeconfig_path)
      NAMESPACE  = var.argocd_namespace
      ONLY_APPS  = join(" ", var.deferred_applications)
    }
  }
}

resource "null_resource" "convergence_gate_deferred" {
  count = length(var.deferred_applications) > 0 ? 1 : 0

  triggers = {
    released = null_resource.release_sync_hold_deferred[0].id
    apps     = join(",", var.deferred_applications)
    script   = filemd5("${path.module}/wait_converged.sh")
  }

  provisioner "local-exec" {
    command     = "./wait_converged.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG                = pathexpand(var.kubeconfig_path)
      NAMESPACE                 = var.argocd_namespace
      APP_NAMESPACES            = join(" ", var.app_namespaces)
      TIMEOUT_SECONDS           = tostring(var.readiness_timeout_seconds)
      TOLERATE_MISSING_JOB_APPS = join(" ", var.convergence_tolerate_missing_jobs)
      TOLERATE_APPS             = join(" ", var.convergence_tolerate_applications)
      ONLY_APPS                 = join(" ", var.deferred_applications)
    }
  }
}

# Assert the deployed services talk to the managed data tier, not to an
# in-cluster PostgreSQL or Couchbase that this repo no longer deploys.
resource "null_resource" "data_tier_assertion" {
  triggers = {
    # After the second wave: idm-server-v2 is the Application whose Postgres
    # host this asserts, and it only starts once the restore is done.
    converged = length(var.deferred_applications) > 0 ? null_resource.convergence_gate_deferred[0].id : null_resource.convergence_gate.id
    script    = filemd5("${path.module}/assert_data_tier.sh")
  }

  provisioner "local-exec" {
    command     = "./assert_data_tier.sh"
    interpreter = ["/bin/bash"]
    working_dir = path.module

    environment = {
      KUBECONFIG          = pathexpand(var.kubeconfig_path)
      APP_NAMESPACES      = join(" ", var.app_namespaces)
      EXPECTED_PG_HOST    = var.cloudsql_private_ip
      EXPECTED_CB_CONNSTR = var.capella_connection_string
    }
  }
}
