#!/usr/bin/env bash
# Deploy the deferred Applications' objects, then scale their workloads to 0
# until the database they need has been restored.
#
# A deferred Application is one that cannot run before Phase 3 finishes -
# idm-server-v2, which needs the midpoint database. Leaving it entirely
# undeployed is not an option: nginx-api-gw resolves every upstream when it
# loads its configuration and exits if one does not resolve, so with no
# idm-server-v2 Service in the cluster the gateway crash-looped -
#
#   [emerg] host not found in upstream
#           "idm-server-v2.services.svc.cluster.local:8080"
#
# - and it would keep crash-looping for the whole hour and a half the restore
# takes. A placeholder Service would fix the lookup, but it would also be a
# fake object for Argo CD to fight over.
#
# So the objects are created from the real Application, and only the pods are
# held back: one sync with auto-sync still held, then replicas 0. Nothing
# starts against a database that is not ready, and every name resolves.
#
# Wave 2 needs no extra step to undo this. release_sync_hold_deferred restores
# the automated sync policy, Argo CD then sees replicas 0 against the chart's
# value, reports OutOfSync and self-heals it back up - by which time the
# restore is done.
set -euo pipefail

: "${NAMESPACE:?}" "${APPS:?}"

WORKLOAD_NAMESPACES="${WORKLOAD_NAMESPACES:-}"
SYNC_TIMEOUT_SECONDS="${SYNC_TIMEOUT_SECONDS:-300}"

for app in ${APPS}; do
  if ! kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" >/dev/null 2>&1; then
    echo "WARNING: Application '${app}' is not in this Argo CD; nothing to pre-stage" >&2
    continue
  fi

  # The hold placed in Phase 4 stays: this is a one-off sync, not a release.
  # Without it Argo CD would keep the workload at the chart's replica count and
  # self-heal the scale-down below.
  held=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" \
    -o jsonpath='{.spec.syncPolicy.automated}' 2>/dev/null)
  if [[ -n "${held}" ]]; then
    echo "ERROR: auto-sync is active on '${app}'; pre-staging it would be undone by selfHeal." >&2
    exit 1
  fi

  echo "Pre-staging ${app}: one sync with auto-sync held..."
  kubectl -n "${NAMESPACE}" patch application.argoproj.io "${app}" --type=merge \
    -p '{"operation":{"initiatedBy":{"username":"pps-dr"},"sync":{"prune":false}}}' >/dev/null

  waited=0
  phase=""
  while [[ "${waited}" -lt "${SYNC_TIMEOUT_SECONDS}" ]]; do
    phase=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" \
      -o jsonpath='{.status.operationState.phase}' 2>/dev/null)
    [[ "${phase}" == "Succeeded" || "${phase}" == "Failed" || "${phase}" == "Error" ]] && break
    sleep 5
    waited=$((waited + 5))
  done

  if [[ "${phase}" != "Succeeded" ]]; then
    echo "ERROR: syncing '${app}' ended as '${phase:-no operation recorded}' after ${waited}s." >&2
    kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" \
      -o jsonpath='{.status.operationState.message}{"\n"}' 2>/dev/null >&2
    exit 1
  fi

  # Scale down wherever the Application put its workloads. The Application's
  # own destination namespace is used when none are configured.
  namespaces="${WORKLOAD_NAMESPACES}"
  if [[ -z "${namespaces}" ]]; then
    namespaces=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" \
      -o jsonpath='{.spec.destination.namespace}' 2>/dev/null)
  fi

  scaled=0
  for ns in ${namespaces}; do
    [[ -z "${ns}" ]] && continue
    workloads=()
    mapfile -t workloads < <(kubectl -n "${ns}" get deploy,statefulset \
      -l "app.kubernetes.io/instance=${app}" -o name 2>/dev/null)
    # Charts that do not set the instance label still name their workload
    # after the release.
    if [[ "${#workloads[@]}" -eq 0 ]]; then
      mapfile -t workloads < <(kubectl -n "${ns}" get deploy,statefulset -o name 2>/dev/null \
        | grep -E "/${app}(-|$)" || true)
    fi
    for w in ${workloads[@]+"${workloads[@]}"}; do
      [[ -z "${w}" ]] && continue
      kubectl -n "${ns}" scale "${w}" --replicas=0 >/dev/null
      echo "  ${ns}/${w} scaled to 0 until the restore finishes"
      scaled=$((scaled + 1))
    done
  done

  if [[ "${scaled}" -eq 0 ]]; then
    # Not a warning. The sync has already happened, so the workload is running
    # at the chart's replica count against a database that is still restoring -
    # the precise outcome this step exists to prevent. Reached when a workload
    # namespace is wrong, the Application's destination namespace is empty, or
    # the kubectl read failed (its stderr is discarded above). The phase is
    # re-runnable, so stopping is cheaper than a false success.
    echo "ERROR: ${app} synced but no Deployment or StatefulSet was found to scale down." >&2
    echo "Its pods are now running against data that is not restored yet; check WORKLOAD_NAMESPACES and the Application's destination." >&2
    exit 1
  fi
done

echo "Deferred Applications pre-staged: their Services resolve, their pods are held at 0."
