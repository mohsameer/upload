#!/usr/bin/env bash
# Workloads the application tier needs that no Argo CD Application provides.
#
# nginx-api-gw resolves every upstream at config load and refuses to start on
# "host not found in upstream pps-health-service...", so the gateway cannot come
# up until pps-health exists. notification-service-lb is the internal load
# balancer that service is reached on. Both are applied out of band in the
# source environments and are therefore absent from the restored Argo CD bundle.
set -euo pipefail

: "${NAMESPACE:?}" "${PPS_HEALTH_IMAGE:?}" "${PULL_SECRET:?}" "${TIMEOUT_SECONDS:?}"

PORT="${PPS_HEALTH_PORT:-8000}"
SERVICES_NAMESPACE="${SERVICES_NAMESPACE:-}"
NOTIFICATION_LB_PORT="${NOTIFICATION_LB_PORT:-8099}"

kubectl apply -f - >/dev/null <<EOF
apiVersion: apps/v1
kind: Deployment
metadata:
  name: pps-health-deployment
  namespace: ${NAMESPACE}
  labels:
    app.kubernetes.io/name: pps-health
    app.kubernetes.io/instance: pps-health
spec:
  replicas: 1
  selector:
    matchLabels:
      app.kubernetes.io/name: pps-health
      app.kubernetes.io/instance: pps-health
  template:
    metadata:
      labels:
        app.kubernetes.io/name: pps-health
        app.kubernetes.io/instance: pps-health
    spec:
      imagePullSecrets:
        - name: ${PULL_SECRET}
      containers:
        - name: pps-health
          image: ${PPS_HEALTH_IMAGE}
          ports:
            - containerPort: ${PORT}
---
apiVersion: v1
kind: Service
metadata:
  name: pps-health-service
  namespace: ${NAMESPACE}
spec:
  selector:
    app.kubernetes.io/name: pps-health
    app.kubernetes.io/instance: pps-health
  ports:
    - port: ${PORT}
      targetPort: ${PORT}
EOF

kubectl -n "${NAMESPACE}" rollout status deploy/pps-health-deployment --timeout="${TIMEOUT_SECONDS}s"
echo "pps-health is serving; nginx-api-gw can resolve its upstream."

# notification-service is reached on an internal load balancer. nodePort is
# deliberately not pinned: the source environment's value is allocated per
# cluster and would collide here.
if [[ -n "${SERVICES_NAMESPACE}" ]]; then
  kubectl apply -f - >/dev/null <<EOF
apiVersion: v1
kind: Service
metadata:
  name: notification-service-lb
  namespace: ${SERVICES_NAMESPACE}
  labels:
    app.kubernetes.io/name: notification-service
  annotations:
    cloud.google.com/load-balancer-type: "Internal"
spec:
  type: LoadBalancer
  externalTrafficPolicy: Cluster
  selector:
    app.kubernetes.io/name: notification-service
  ports:
    - port: ${NOTIFICATION_LB_PORT}
      targetPort: ${NOTIFICATION_LB_PORT}
      protocol: TCP
EOF
  echo "${SERVICES_NAMESPACE}/notification-service-lb applied (internal LB on ${NOTIFICATION_LB_PORT})"
fi
