#!/usr/bin/env bash
# Apply the app-of-apps Application. Everything the SSO services need comes
# from it; adding or removing a service is a change in the Git source, not a
# new Terraform resource.
set -euo pipefail

: "${NAMESPACE:?}" "${MANIFEST:?}"

printf '%s' "${MANIFEST}" | kubectl -n "${NAMESPACE}" apply -f - >/dev/null
echo "app-of-apps applied to namespace ${NAMESPACE}."
