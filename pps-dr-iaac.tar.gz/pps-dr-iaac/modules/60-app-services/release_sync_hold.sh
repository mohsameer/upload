#!/usr/bin/env bash
# Release the auto-sync hold Phase 4 placed on the restored Applications.
# Safe to re-run: an Application that was never held is left alone.
set -euo pipefail

: "${NAMESPACE:?}"

# Released in two waves, because only one Application needs a restored
# database. DEFER_APPS are skipped here and released by the second wave once
# the database restore finishes; ONLY_APPS releases exactly that set.
#
# In the Argo CD backup, idm-server-v2 is the only Application that references
# the Postgres host, and the other two that reference IDM at all
# (sage-kafka-consumer, prometheus-msteams) are already excluded on this site.
# So 27 of 28 Applications can sync while midpoint is still restoring.
DEFER_APPS="${DEFER_APPS:-}"
ONLY_APPS="${ONLY_APPS:-}"

wanted() {
  local name="$1"
  if [[ -n "${ONLY_APPS}" ]]; then
    [[ " ${ONLY_APPS} " == *" ${name} "* ]]
  elif [[ -n "${DEFER_APPS}" ]]; then
    [[ " ${DEFER_APPS} " != *" ${name} "* ]]
  else
    return 0
  fi
}

APPS=$(kubectl -n "${NAMESPACE}" get applications.argoproj.io -o name 2>/dev/null) || true
if [[ -z "${APPS}" ]]; then
  echo "ERROR: no Applications found in ${NAMESPACE}. Argo CD unreachable, or the restore did not land." >&2
  exit 1
fi

RELEASED=0
SKIPPED=0
SEEN=""
for app in ${APPS}; do
  name="${app##*/}"
  SEEN="${SEEN} ${name}"
  if ! wanted "${name}"; then
    SKIPPED=$((SKIPPED + 1))
    continue
  fi
  HELD=$(kubectl -n "${NAMESPACE}" get "${app}" \
    -o jsonpath='{.metadata.annotations.pps-dr/sync-held-by}' 2>/dev/null || true)
  [[ -z "${HELD}" ]] && continue

  kubectl -n "${NAMESPACE}" patch "${app}" --type=merge -p \
    '{"spec":{"syncPolicy":{"automated":{"prune":true,"selfHeal":true}}},"metadata":{"annotations":{"pps-dr/sync-held-by":null}}}' >/dev/null
  RELEASED=$((RELEASED + 1))
done

# A name in ONLY_APPS that matched nothing means the Application this wave
# exists for is absent, and releasing "0 of them" must not look like success:
# the convergence check that follows would pass on an empty set.
for want in ${ONLY_APPS}; do
  if [[ " ${SEEN} " != *" ${want} "* ]]; then
    echo "ERROR: application/${want} is not present in ${NAMESPACE}; nothing to release." >&2
    exit 1
  fi
done

if [[ "${SKIPPED}" -gt 0 ]]; then
  echo "Released the sync hold on ${RELEASED} Application(s), deferred ${SKIPPED}."
else
  echo "Released the sync hold on ${RELEASED} Application(s)."
fi
