#!/usr/bin/env bash
# Repoint any Capella endpoint recorded in an Argo CD Application's Helm
# parameters at this site's cluster, before the sync hold is released.
#
# The Applications come from the source site's backup, and two of them carry
# that site's Capella cluster as Helm parameters rather than reading it from
# Vault:
#
#   oidcv2         config.configmap.cnCouchbaseUrl, cnCouchbaseInitUrl,
#                  cnCouchbaseUser, cnCouchbaseSuperUser
#   oidcv2-loader  usrEnvs[1].value
#
# Helm parameters are the durable override point: patching the rendered
# ConfigMap instead is undone by selfHeal within minutes, and the chart would
# regenerate it on the next sync anyway. Rewriting the parameter means the very
# first sync already produces a ConfigMap naming this site.
#
# This has to run before release_sync_hold. Otherwise the applications sync
# against the source site's Capella, and on a private endpoint that does not
# even fail cleanly: Capella routes by name, so the SNI does not match and the
# SDK reports "AuthenticationFailureException: Authentication Failure", which
# looks like a credential problem and is not one.
#
# Values are matched by content, not by parameter name - a renamed parameter or
# a new Application is covered without editing this file.
set -euo pipefail

: "${NAMESPACE:?}" "${CAPELLA_URL:?}"

CAPELLA_USERNAME="${CAPELLA_USERNAME:-}"
CAPELLA_PASSWORD="${CAPELLA_PASSWORD:-}"
FOREIGN_USERNAMES="${FOREIGN_USERNAMES:-}"

DR_HOST="${CAPELLA_HOST:-}"
if [[ -z "${DR_HOST}" ]]; then
  DR_HOST=$(printf '%s' "${CAPELLA_URL}" | sed -E 's#^[a-z]+://##; s#[/?].*$##; s#,.*$##')
fi
[[ -n "${DR_HOST}" ]] || {
  echo "ERROR: cannot derive this site's Capella host from CAPELLA_URL='${CAPELLA_URL}'." >&2
  exit 1
}

CHANGED=0

mapfile -t apps < <(kubectl -n "${NAMESPACE}" get applications.argoproj.io -o name 2>/dev/null | cut -d/ -f2)

# A failed list is indistinguishable from "no Applications" once 2>/dev/null
# has eaten the error, and every loop below then iterates nothing: no rewrite
# happens, the LEFTOVER audit finds nothing to complain about, and this exits 0
# saying "0 changed". The applications would then sync against the SOURCE
# site's Capella - the one outcome this script exists to prevent. There is
# always at least one Application by the time Phase 6 runs, so an empty list
# here is a failure, not a quiet success.
if [[ "${#apps[@]}" -eq 0 ]]; then
  echo "ERROR: no Argo CD Applications listed in namespace ${NAMESPACE}." >&2
  echo "Refusing to report success: an empty list here would leave every Capella endpoint pointing at the source site." >&2
  exit 1
fi
for app in ${apps[@]+"${apps[@]}"}; do
  [[ -z "${app}" ]] && continue

  current=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" \
    -o jsonpath='{.spec.source.helm.parameters}' 2>/dev/null)
  [[ -z "${current}" || "${current}" == "null" ]] && continue
  [[ "${current}" == *".cloud.couchbase.com"* ]] || continue

  # Rewrite the host everywhere it appears, keeping the scheme and anything
  # after it, and replace a username belonging to the source site. The
  # username list is explicit: a username is not self-identifying the way a
  # hostname is, and guessing one wrong would break an unrelated parameter.
  patched=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" -o json 2>/dev/null \
    | jq -c --arg host "${DR_HOST}" \
           --arg user "${CAPELLA_USERNAME}" \
           --arg pass "${CAPELLA_PASSWORD}" \
           --arg foreign "${FOREIGN_USERNAMES}" '
      ($foreign | split(" ") | map(select(length > 0))) as $fu
      | .spec.source.helm.parameters
      | map(
          if (.value | type) == "string" then
            if (.value | test("cb\\.[a-zA-Z0-9-]+\\.cloud\\.couchbase\\.com")) then
              .value |= sub("cb\\.[a-zA-Z0-9-]+\\.cloud\\.couchbase\\.com"; $host; "g")
            elif ($user != "" and (.value | IN($fu[]))) then
              .value = $user
            else . end
          else . end
        )')

  if [[ -z "${patched}" || "${patched}" == "null" ]]; then
    echo "  WARNING: could not build patched parameters for ${app}" >&2
    continue
  fi

  kubectl -n "${NAMESPACE}" patch application.argoproj.io "${app}" --type=merge \
    -p "$(jq -nc --argjson p "${patched}" '{spec:{source:{helm:{parameters:$p}}}}')" >/dev/null
  echo "  ${app}: Helm parameters repointed at ${DR_HOST}"
  CHANGED=$((CHANGED + 1))
done

# Passwords are handled separately: they are matched by parameter name, since a
# password's value says nothing about which site it belongs to. Only the
# Applications just rewritten are touched.
if [[ -n "${CAPELLA_PASSWORD}" && -n "${PASSWORD_PARAMETERS:-}" ]]; then
  for app in ${apps[@]+"${apps[@]}"}; do
    current=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" \
      -o jsonpath='{.spec.source.helm.parameters}' 2>/dev/null)
    [[ "${current}" == *".cloud.couchbase.com"* ]] || continue
    patched=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" -o json 2>/dev/null \
      | jq -c --arg pass "${CAPELLA_PASSWORD}" --arg names "${PASSWORD_PARAMETERS}" '
        ($names | split(" ") | map(select(length > 0))) as $pn
        | .spec.source.helm.parameters
        | map(if (.name | IN($pn[])) then .value = $pass else . end)')
    [[ -z "${patched}" || "${patched}" == "null" ]] && continue
    kubectl -n "${NAMESPACE}" patch application.argoproj.io "${app}" --type=merge \
      -p "$(jq -nc --argjson p "${patched}" '{spec:{source:{helm:{parameters:$p}}}}')" >/dev/null
    echo "  ${app}: Capella password parameters set for this site"
  done
fi

# Nothing downstream can detect this going wrong except by a pod failing to
# start, so it is checked here.
LEFTOVER=()
for app in ${apps[@]+"${apps[@]}"}; do
  params=$(kubectl -n "${NAMESPACE}" get application.argoproj.io "${app}" \
    -o jsonpath='{.spec.source.helm.parameters}' 2>/dev/null)
  [[ "${params}" == *".cloud.couchbase.com"* ]] || continue
  if printf '%s' "${params}" | grep -oE 'cb\.[a-zA-Z0-9-]+\.cloud\.couchbase\.com' | grep -qv "^${DR_HOST}$"; then
    LEFTOVER+=("${app}")
  fi
done

if [[ "${#LEFTOVER[@]}" -gt 0 ]]; then
  echo "ERROR: these Applications still name another site's Capella cluster: ${LEFTOVER[*]}" >&2
  exit 1
fi

echo "Argo CD Applications repointed at ${DR_HOST}: ${CHANGED} changed."
