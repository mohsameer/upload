#!/usr/bin/env bash
# Assert the deployed services point at the managed data tier.
#
# The v1 DR site ran PostgreSQL and Couchbase inside the cluster. If a stale
# manifest still points at those in-cluster services, the DR site silently
# comes up against a database that does not exist. Catch it here.
set -euo pipefail

: "${APP_NAMESPACES:?}"

# In-cluster endpoints that must no longer appear in application config.
FORBIDDEN_PATTERNS=(
  'postgresql\.[a-z0-9-]*\.svc'
  'postgres\.[a-z0-9-]*\.svc'
  'couchbase\.[a-z0-9-]*\.svc'
  'cb-example'
  'couchbase-cluster'
)

VIOLATIONS=()

for ns in ${APP_NAMESPACES}; do
  CONFIG=$(kubectl -n "${ns}" get configmaps -o yaml 2>/dev/null || true)

  for pattern in "${FORBIDDEN_PATTERNS[@]}"; do
    MATCHES=$(printf '%s' "${CONFIG}" | grep -Eo "${pattern}" | sort -u || true)
    if [[ -n "${MATCHES}" ]]; then
      while read -r m; do
        [[ -z "${m}" ]] && continue
        VIOLATIONS+=("${ns}: config references in-cluster endpoint '${m}'")
      done <<<"${MATCHES}"
    fi
  done
done

if [[ ${#VIOLATIONS[@]} -gt 0 ]]; then
  echo "ERROR: services are configured against an in-cluster data tier that this repo no longer deploys:" >&2
  for v in "${VIOLATIONS[@]}"; do echo "  - ${v}" >&2; done
  echo "Expected PostgreSQL host: ${EXPECTED_PG_HOST:-<unset>}" >&2
  echo "Expected Couchbase connection string: ${EXPECTED_CB_CONNSTR:-<unset>}" >&2
  exit 1
fi

echo "Data tier assertion passed: no in-cluster PostgreSQL or Couchbase endpoints referenced."
