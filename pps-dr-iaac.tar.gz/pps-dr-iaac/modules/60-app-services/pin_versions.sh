#!/usr/bin/env bash
# Pin restored Argo CD Applications to the versions chosen for this DR run.
#
# PPS delivers every service as a Helm OCI chart from ECR, so the restored
# Applications already carry the right repo/chart; only the version changes.
# SERVICE_VERSIONS is "app=version ..." keyed by Application name. Versions
# are normalised the way the PPS Argo CD runbook does it: a leading "img." is
# dropped and "-pps" appended, and two Helm parameters follow the revision
# when the Application already sets them:
#   initContainer.configVersion -> X.Y.Z
#   image.tag                   -> img.X.Y.Z  (without it the pod keeps the old
#                                  image even though Argo reports Synced)
# An unknown Application name fails the phase rather than being skipped.
set -euo pipefail

: "${NAMESPACE:?}"

if [[ -z "${SERVICE_VERSIONS:-}" ]]; then
  echo "service_versions is empty; keeping the revisions restored in Phase 4."
  exit 0
fi

UNKNOWN=()
for pair in ${SERVICE_VERSIONS}; do
  app="${pair%%=*}"
  raw="${pair#*=}"
  base="${raw#img.}"
  base="${base%-pps}"
  if [[ ! "${base}" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
    echo "ERROR: version '${raw}' for ${app} does not normalise to X.Y.Z[-pps]." >&2
    exit 1
  fi
  revision="${base}-pps"

  if ! current=$(kubectl -n "${NAMESPACE}" get "applications.argoproj.io/${app}" -o json 2>/dev/null); then
    UNKNOWN+=("${app}")
    continue
  fi

  echo "${current}" | jq --arg rev "${revision}" --arg base "${base}" '
    del(.metadata.resourceVersion, .metadata.managedFields, .status)
    | .spec.source.targetRevision = $rev
    | if (.spec.source.helm.parameters // []) | length > 0 then
        .spec.source.helm.parameters |= map(
          if .name == "initContainer.configVersion" then .value = $base
          elif .name == "image.tag" then .value = ("img." + $base)
          else . end)
      else . end' \
    | kubectl -n "${NAMESPACE}" apply -f - >/dev/null
  echo "  ${app}: targetRevision=${revision}"
done

if [[ ${#UNKNOWN[@]} -gt 0 ]]; then
  echo "ERROR: service_versions names Applications that do not exist in ${NAMESPACE}: ${UNKNOWN[*]}" >&2
  echo "Keys must be Argo CD Application names (kubectl -n ${NAMESPACE} get applications)." >&2
  exit 1
fi
