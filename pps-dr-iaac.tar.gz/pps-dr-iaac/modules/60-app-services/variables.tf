variable "argocd_namespace" {
  type = string
}

variable "app_namespaces" {
  type = list(string)
}

variable "service_versions" {
  type        = map(string)
  description = "Version pinned per SSO service for this DR run."
}

variable "git_repo_url" {
  type    = string
  default = ""
}

variable "app_of_apps_path" {
  type    = string
  default = ""
}

variable "app_of_apps_revision" {
  type    = string
  default = ""
}

variable "kubeconfig_path" {
  type = string
}

variable "readiness_timeout_seconds" {
  type = number
}

variable "cloudsql_connection_name" {
  type        = string
  description = "Managed PostgreSQL the services must point at."
}

variable "cloudsql_private_ip" {
  type = string
}

variable "capella_connection_string" {
  type        = string
  description = "Managed Couchbase the services must point at."
}

variable "app_of_apps_name" {
  type    = string
  default = "pps-dr-app-of-apps"
}

variable "argocd_project" {
  type    = string
  default = "default"
}

variable "app_of_apps_enabled" {
  type        = bool
  description = "Render and apply the git app-of-apps. Off by default: PPS Applications are restored in Phase 4."
  default     = false
}

variable "pps_health_namespace" {
  type = string
}

variable "pps_health_image" {
  type = string
}

variable "image_pull_secret_name" {
  type = string
}

variable "argocd_ignore_differences" {
  type = map(list(object({
    group         = string
    kind          = string
    json_pointers = list(string)
  })))
}

variable "services_namespace" {
  type = string
}

variable "convergence_tolerate_missing_jobs" {
  type = list(string)
}

variable "database_gate" {
  type        = string
  default     = ""
  description = <<-EOT
    Value threaded in from the restored databases.

    This is the phase that needs them: syncing the applications starts pods
    that connect to midPoint's database and to Capella, so it waits for the
    Postgres and Capella restores even though the earlier phases no longer do.
  EOT
}

variable "deferred_applications" {
  type        = list(string)
  default     = ["idm-server-v2"]
  description = <<-EOT
    Applications held back until the database restore finishes.

    Everything else syncs and converges while midpoint is still restoring,
    which on a measured run is most of an hour and a half of otherwise idle
    time. Established from the Argo CD backup: idm-server-v2 is the only one of
    28 Applications that references the Postgres host, and the two others that
    reference IDM at all - sage-kafka-consumer and prometheus-msteams - are
    already in argocd_exclude_applications on this site.

    Empty makes the build single-wave again.
  EOT
}

variable "convergence_tolerate_applications" {
  type        = list(string)
  default     = []
  description = "Applications whose health does not block the build. Still required to exist, and reported on every pass."
}


variable "couchbase_username" {
  type        = string
  default     = ""
  description = "Capella username for this site, written over the source site's in Application parameters."
}

variable "couchbase_password" {
  type        = string
  default     = ""
  sensitive   = true
  description = "Capella password for this site, written into the parameters named in capella_password_parameters."
}

variable "capella_foreign_usernames" {
  type        = list(string)
  default     = []
  description = <<-EOT
    Capella usernames belonging to the source site, replaced with
    couchbase_username wherever they appear in an Application's Helm
    parameters.

    Explicit rather than inferred: a hostname identifies its cluster, a
    username does not, and rewriting the wrong parameter would break something
    unrelated.
  EOT
}

variable "capella_password_parameters" {
  type        = list(string)
  default     = []
  description = "Helm parameter names holding the Capella password, set to couchbase_password. Matched by name, since a password's value says nothing about which site it belongs to."
}
