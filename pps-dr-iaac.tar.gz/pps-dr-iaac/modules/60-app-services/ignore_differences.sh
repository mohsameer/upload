#!/usr/bin/env bash
# Patch spec.ignoreDifferences onto Argo CD Applications.
#
# Needed where the API server normalises a field the chart also sets, which Argo
# CD then reports as a permanent diff. cert-manager does this to Certificate
# spec.duration ("43800h" is stored as "43800h0m0s"), and with selfHeal enabled
# the Application re-syncs continuously and never reaches Synced.
#
# The Applications come from the restored bundle, so this has to run after the
# restore re-applies them or the patch is lost.
set -euo pipefail

: "${NAMESPACE:?}" "${RULES:?}"

echo "${RULES}" | jq -r 'to_entries[] | @base64' | while read -r row; do
  decoded=$(echo "${row}" | base64 -d)
  app=$(echo "${decoded}" | jq -r '.key')
  rules=$(echo "${decoded}" | jq -c '[.value[] | {group, kind, jsonPointers: .json_pointers}]')

  kubectl -n "${NAMESPACE}" patch application "${app}" --type merge \
    -p "{\"spec\":{\"ignoreDifferences\":${rules}}}" >/dev/null
  kubectl -n "${NAMESPACE}" annotate application "${app}" \
    argocd.argoproj.io/refresh=hard --overwrite >/dev/null
  echo "${app}: ignoreDifferences applied"
done
