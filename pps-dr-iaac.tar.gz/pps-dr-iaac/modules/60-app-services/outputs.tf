output "app_of_apps_name" {
  value = var.app_of_apps_name
}

output "deployed_services" {
  description = "Service -> pinned version deployed by this DR run."
  value       = var.service_versions
}

output "wave1_released" {
  description = "Applications are released to sync. Phase 7's ingress proceeds from here, not from convergence: an app that calls the site's own issuer cannot become Healthy until that hostname is served here."
  value       = null_resource.release_sync_hold.id
}

output "wave1_completed" {
  description = "Every Application except the deferred ones is synced and healthy."
  value       = null_resource.convergence_gate.id
}

output "completed" {
  description = "Gate consumed by Phase 7's sign-off: both waves converged and the data tier asserted."
  value       = null_resource.data_tier_assertion.id
}
