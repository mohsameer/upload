#!/usr/bin/env bash
# Phase 6 sign-off: every Argo CD Application must be Synced + Healthy and
# every workload in the application namespaces must have all replicas Ready.
set -euo pipefail

: "${NAMESPACE:?}" "${APP_NAMESPACES:?}" "${TIMEOUT_SECONDS:?}"

# Applications allowed to report OutOfSync/Missing when the only resources at
# fault are run-once Jobs. A Job that has completed is garbage collected by its
# own ttlSecondsAfterFinished, after which Argo CD still wants it and reports
# the Application Missing - oidcv2 does this with its Jans configurator Job.
# Listing the Application explicitly keeps the exemption auditable instead of
# excusing every missing resource everywhere.
TOLERATE_MISSING_JOB_APPS="${TOLERATE_MISSING_JOB_APPS:-}"
# Applications this pass must not wait for. The first convergence pass runs
# while the database restore is still going, so the one Application that needs
# it is checked by a second pass instead of failing this one.
IGNORE_APPS="${IGNORE_APPS:-}"
# Applications whose health must not block the build. Unlike IGNORE_APPS, these
# are still required to exist and are reported on every pass - they are a
# recorded exception, not a silence. Used on a drill where a known-broken app is
# being worked separately and the rest of the site should still finish.
TOLERATE_APPS="${TOLERATE_APPS:-}"
# Applications this pass waits for, to the exclusion of everything else.
ONLY_APPS="${ONLY_APPS:-}"

# An Application's workloads are named after it but not identically - oidcv2
# owns oidcv2-auth-server - so ownership is matched on the name's prefix.
owned_by_any() {
  local name="$1" app
  shift
  for app in "$@"; do
    [[ "${name}" == "${app}" || "${name}" == "${app}"-* ]] && return 0
  done
  return 1
}

# True when every resource this Application is unhappy about is a Job that is
# no longer present, and there is at least one such resource.
only_missing_jobs() {
  local app="$1" offending
  offending=$(kubectl -n "${NAMESPACE}" get applications.argoproj.io "${app}" -o json 2>/dev/null \
    | jq -r '[.status.resources[]? | select(.status != "Synced" or (.health.status // "") == "Missing")] as $bad
             | if ($bad | length) == 0 then "none"
               elif ($bad | map(select(.kind == "Job" and (.health.status // "") == "Missing")) | length) == ($bad | length)
                 then "jobs" else "other" end')
  [[ "${offending}" == "jobs" ]]
}

DEADLINE=$((SECONDS + TIMEOUT_SECONDS))
FAILING=()
SEEN_ONLY=""

while [[ ${SECONDS} -lt ${DEADLINE} ]]; do
  FAILING=()

  # Read the Applications into an array first, then drive the loop from it.
  # Feeding the loop straight from kubectl meant a failed call - silenced by
  # 2>/dev/null - yielded no rows, so FAILING stayed empty and this reported
  # "All Applications are Synced + Healthy" for a site it had never managed to
  # query. Phase 7 and the DNS hand-off run off that answer.
  mapfile -t APP_ROWS < <(kubectl -n "${NAMESPACE}" get applications.argoproj.io \
    -o jsonpath='{range .items[*]}{.metadata.name}{" "}{.status.sync.status}{" "}{.status.health.status}{"\n"}{end}' 2>/dev/null)
  if [[ "${#APP_ROWS[@]}" -eq 0 ]] || [[ -z "${APP_ROWS[0]//[[:space:]]/}" ]]; then
    echo "could not list Applications in ${NAMESPACE} (empty or failed read); not treating that as converged"
    sleep "${POLL_SECONDS:-20}"
    continue
  fi

  while read -r name sync health; do
    [[ -z "${name}" ]] && continue
    # Wave filtering, before any health judgement.
    if [[ -n "${ONLY_APPS}" ]]; then
      [[ " ${ONLY_APPS} " == *" ${name} "* ]] || continue
      [[ " ${SEEN_ONLY} " == *" ${name} "* ]] || SEEN_ONLY="${SEEN_ONLY} ${name}"
    elif [[ -n "${IGNORE_APPS}" && " ${IGNORE_APPS} " == *" ${name} "* ]]; then
      continue
    fi
    if [[ "${sync}" != "Synced" || "${health}" != "Healthy" ]]; then
      if [[ " ${TOLERATE_APPS} " == *" ${name} "* ]]; then
        echo "application/${name}: sync=${sync:-<none>} health=${health:-<none>} - TOLERATED by configuration, not blocking"
        continue
      fi
      if [[ " ${TOLERATE_MISSING_JOB_APPS} " == *" ${name} "* ]] && only_missing_jobs "${name}"; then
        echo "application/${name}: only a completed Job is missing; treating as converged"
        continue
      fi
      FAILING+=("application/${name}: sync=${sync:-<none>} health=${health:-<none>}")
    fi
  done < <(printf '%s\n' "${APP_ROWS[@]+"${APP_ROWS[@]}"}" | grep -v '^$' || true)

  for ns in ${APP_NAMESPACES}; do
    while read -r kind name desired ready; do
      [[ -z "${name}" ]] && continue
      # The wave filters apply to workloads as well as to Applications. Without
      # this the first pass blocked on deployment/oidc-mgmt-portal while
      # skipping the Application of the same name, so a wave that restored its
      # database quickly - leaving the deferred apps syncing before the pass ran
      # - could never converge. The second pass likewise judged the whole site
      # when it is only meant to judge the deferred Applications.
      if [[ -n "${ONLY_APPS}" ]]; then
        owned_by_any "${name}" ${ONLY_APPS} || continue
      elif [[ -n "${IGNORE_APPS}" ]] && owned_by_any "${name}" ${IGNORE_APPS}; then
        continue
      fi
      # A tolerated Application's workloads are tolerated with it; otherwise
      # the Deployment it owns blocks what the Application no longer does.
      tolerated=false
      if [[ -n "${TOLERATE_APPS}" ]] && owned_by_any "${name}" ${TOLERATE_APPS}; then
        tolerated=true
      fi
      if [[ "${tolerated}" == "true" ]]; then
        echo "${kind}/${name} in ${ns}: ${ready:-0}/${desired} Ready - TOLERATED with its Application"
        continue
      fi
      ready="${ready:-0}"
      if [[ "${ready}" != "${desired}" ]]; then
        FAILING+=("${kind}/${name} in ${ns}: ${ready}/${desired} replicas Ready")
      fi
    done < <(
      kubectl -n "${ns}" get deployments \
        -o jsonpath='{range .items[*]}deployment {.metadata.name}{" "}{.spec.replicas}{" "}{.status.readyReplicas}{"\n"}{end}' 2>/dev/null
      kubectl -n "${ns}" get statefulsets \
        -o jsonpath='{range .items[*]}statefulset {.metadata.name}{" "}{.spec.replicas}{" "}{.status.readyReplicas}{"\n"}{end}' 2>/dev/null
    )
  done

  if [[ ${#FAILING[@]} -eq 0 ]]; then
    # An ONLY_APPS name that matched nothing must not read as converged. With
    # the Application absent - missing from the restore, or renamed - the
    # filter yields no rows, FAILING stays empty, and this would report
    # success for a site that never deployed it. That is the one check on
    # idm-server-v2 in the second wave, and the DNS hand-off follows it.
    if [[ -n "${ONLY_APPS}" ]]; then
      for want in ${ONLY_APPS}; do
        if [[ " ${SEEN_ONLY} " != *" ${want} "* ]]; then
          echo "ERROR: application/${want} was not found in ${NAMESPACE}; refusing to report convergence." >&2
          exit 1
        fi
      done
    fi
    echo "All Applications are Synced + Healthy and all workloads are Ready."
    exit 0
  fi

  sleep 20
done

echo "ERROR: the SSO services did not converge within ${TIMEOUT_SECONDS}s:" >&2
for f in "${FAILING[@]}"; do echo "  - ${f}" >&2; done
echo "Phase 7 has not been run." >&2
exit 1
