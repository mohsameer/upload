#!/usr/bin/env bash
# DR prevalidation gate - standalone entry point.
#
# Run this FIRST, before `tofu init`. It needs no Terraform state, no
# backend, and makes no mutating call anywhere - it is safe to run at any
# time, including against a live DR site, as often as you want.
#
# Usage:
#   ./prevalidate.sh --tfvars pps-dr.tfvars
#   ./prevalidate.sh --tfvars pps-dr.tfvars --offline   # no network calls
#   ./prevalidate.sh --tfvars pps-dr.tfvars --report ./my-report.json
#
# Exit code: 0 when there are no blockers, 1 otherwise. Warnings never
# affect the exit code.
set -uo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

TFVARS="pps-dr.tfvars"
REPORT=".dr-run/prevalidate-report.json"
OFFLINE="false"

usage() {
  cat <<EOF
Usage: $0 [--tfvars FILE] [--report FILE] [--offline]

  --tfvars FILE   tfvars file to validate (default: pps-dr.tfvars)
  --report FILE   where to write the JSON report (default: .dr-run/prevalidate-report.json)
  --offline       skip every check that needs network access (tooling,
                   placeholder and TLS-pair checks still run)
  -h, --help      show this help

This is the first step of a DR run, before 'tofu init'. It never mutates
anything - no cloud resource, no Kubernetes object, no file besides its own
report.
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --tfvars) TFVARS="$2"; shift 2 ;;
    --report) REPORT="$2"; shift 2 ;;
    --offline) OFFLINE="true"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown argument: $1" >&2; usage >&2; exit 2 ;;
  esac
done

if [[ ! -f "${TFVARS}" ]]; then
  echo "ERROR: tfvars file not found: ${TFVARS}" >&2
  echo "Copy pps-dr.tfvars.example to pps-dr.tfvars and fill in real values first." >&2
  exit 2
fi

export OFFLINE
# shellcheck source=prevalidate/checks.sh
source "${SCRIPT_DIR}/prevalidate/checks.sh"

run_prevalidation "${TFVARS}" "${REPORT}"
