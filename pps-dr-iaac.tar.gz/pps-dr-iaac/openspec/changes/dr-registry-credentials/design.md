## Context

All iCrypto SSO container images and Helm charts are served from a private AWS ECR registry (in QA: `320996968493.dkr.ecr.eu-west-1.amazonaws.com`). ECR does not support static credentials — access requires an authorization token obtained via `aws ecr get-login-password`, and that token is valid for **12 hours**.

The v2 DR automation currently handles this in `modules/10-gke-cluster`:

```hcl
resource "null_resource" "image_pull_secret" {
  for_each = toset(local.pull_secret_namespaces)
  triggers = {
    ...
    key_fingerprint = sha256(var.ecr_access_key)
  }
  ...
}
```

`registry_secret.sh` runs `aws ecr get-login-password` **on the bastion**, once, and writes a `dockerconfigjson` secret per namespace. Because the trigger is the hash of the *access key* rather than anything time-varying, Terraform never re-runs it. That is correct for idempotency (design decision D5 bans `timestamp()` triggers) and wrong for correctness: the credential it writes expires 12 hours later.

Two related gaps exist alongside it:

1. `modules/40-argocd/repo_credentials.sh` creates only a `type=git` repository secret. Argo CD also needs a `type=helm`, `enableOCI=true` repository secret to pull the iCrypto charts from ECR. Without it the Phase 6 app-of-apps cannot render. The QA environment works around this manually — the `pps-argocd` runbook's mandatory pre-step copies `icrypto-helm` between namespaces before every deploy, because it keeps expiring.
2. Pull secrets are created only in namespaces known at Phase 1. Phase 6 Argo CD Applications may target namespaces that did not exist then.

Constraint: this is GKE, so there is no IAM-roles-for-service-accounts path to ECR. Reaching ECR requires an AWS access key somewhere. The only question is where it lives and how often the derived token is renewed.

## Goals / Non-Goals

**Goals:**

- Registry credentials that stay valid for the entire life of the DR site with no human action.
- One mechanism, one AWS credential, one token exchange, serving both consumers (pull secrets and the Argo CD OCI repository secret).
- Credentials valid *before* any phase that needs them, not merely eventually.
- Namespace coverage that self-heals as namespaces appear.
- Preserve the repo's idempotency rule: no `timestamp()` triggers in Terraform. Time-varying behaviour lives in a CronJob, which is the Kubernetes-native place for it.

**Non-Goals:**

- Creating or managing the ECR registry, repositories or IAM policies — those are AWS-side and owned outside this repo, like every other prerequisite.
- Replacing Vault/ESO for *application* secrets. This module handles registry credentials only.
- Eliminating the long-lived AWS access key. Without IRSA on GKE, some long-lived credential must exist; this change moves it into a Kubernetes Secret with scoped RBAC, it does not remove it.
- Mirroring images into Artifact Registry to avoid ECR entirely. That is a bigger architectural change and would be its own proposal.

## Decisions

### R1. A dedicated module, not an addition to `10-gke-cluster`

Registry credentials serve Phase 1 (bootstrap), Phase 4 (Argo CD OCI repo secret) and Phase 6 (application image pulls). They belong to no single phase. More importantly, every other module in this repo is *one-shot* — it converges and finishes — whereas this one owns a **continuously running workload**. Putting a CronJob inside the module whose job is "provision a GKE cluster" muddles both.

Numbered `15-` so it sorts between cluster and platform, consistent with decision D1's phase-numbering scheme, while making clear it is not itself one of the eight runbook phases.

*Alternative considered*: leave it in `10-gke-cluster` and add the CronJob there. Rejected — it makes a provisioning module own runtime state, and the Argo CD repository secret has nothing to do with cluster provisioning.

### R2. In-cluster CronJob, not ESO's `ECRAuthorizationToken` generator

External Secrets Operator has a native ECR generator that would produce a refreshing `dockerconfigjson`, and ESO is already part of this stack. It was rejected for this purpose because of **ordering**: ESO is installed in Phase 5, but ECR credentials are needed from Phase 1 onward — Argo CD's own init container comes from ECR, and Phase 4 precedes Phase 5. Making registry access depend on ESO would either invert the phase order or leave a window covered only by a 12-hour bootstrap token.

Secondary reason: the Argo CD repository secret is not a `dockerconfigjson`. It is a bespoke shape (`type: helm`, `enableOCI: "true"`, `url`, `username`, `password`, plus the `argocd.argoproj.io/secret-type=repository` label). ESO can template that, but doing so is fiddlier than the shell that already has the token in hand.

A CronJob is also the mechanism the well-known `aws-ecr-credential` Helm charts use, so it is the least surprising choice for an operator debugging it at 3am.

*Revisit if*: ESO is ever moved before Phase 4, or GKE Workload Identity Federation to AWS is adopted, at which point the access key could be dropped entirely.

### R3. Refresh every 6 hours

Token lifetime is 12 hours; refreshing at 6 gives a full missed run of margin. A missed run then degrades to "credentials still valid for 6 more hours" rather than an immediate outage. Exposed as `refresh_schedule` with a variable validation that rejects intervals not comfortably inside the token lifetime.

### R4. Bootstrap Job plus CronJob

A CronJob alone does not run at creation time, so the first tick could be up to 6 hours away — long after Phase 2 needs to pull. The module therefore applies a Job that runs the identical script immediately and waits for its completion, and only then reports `completed`. The CronJob handles every subsequent refresh.

Both run the same `refresh.sh` from the same ConfigMap, so there is exactly one code path to reason about.

### R5. One script reconciles all consumers each run

`refresh.sh` obtains the token once, then loops:

1. For each configured namespace that exists: upsert the `dockerconfigjson` pull secret; optionally patch the `default` ServiceAccount's `imagePullSecrets`.
2. If the Argo CD namespace exists: upsert the `type: helm` / `enableOCI` repository secret.

Missing namespaces are reported and skipped rather than failing the run — during Phase 1 the Argo CD namespace may not exist yet, and a refresh that fails for that reason would mask real failures. A namespace that appears later is picked up on the next run with no Terraform change.

Each written secret gets an annotation recording the refresh timestamp, so `kubectl get secret -o jsonpath` answers "are these current?" without decoding the token.

### R6. Runner image carries both `aws` and `kubectl`

The refresh needs the AWS CLI (token exchange) and `kubectl` (secret upsert) in one container. `alpine/k8s` bundles both and is exposed as `runner_image` so it can be pinned or swapped for an internally-mirrored image — note this image itself must be pullable *without* ECR credentials, since it is what creates them.

### R7. RBAC scoped to secrets in the configured namespaces

The ServiceAccount gets `get`/`list`/`create`/`patch`/`update` on secrets, plus `get`/`patch` on serviceaccounts when default-SA attachment is enabled. Implemented as a ClusterRole with per-namespace RoleBindings rather than a ClusterRoleBinding, so the workload cannot read secrets in namespaces outside the configured set.

### R8. Non-ECR registries keep working

The ECR path is selected by detecting `.ecr.` in the registry host, exactly as the current `registry_secret.sh` does. For any other registry the access key and secret are used directly as username and password, the refresh becomes a no-op rewrite of the same value, and nothing else changes.

## Risks / Trade-offs

- **Long-lived AWS access key now lives in the cluster** → Scoped to ECR read-only on the AWS side; RBAC prevents other workloads' service accounts from reading it; the Secret is created by Terraform from a `TF_VAR_*` and never appears in an output. This is inherent to in-cluster refresh on GKE — the alternative is a credential that expires in 12 hours.
- **Runner image must be pullable without ECR credentials** → It is the bootstrap; if it were in ECR the module could never start. Documented on the `runner_image` variable.
- **CronJob is one more thing that can silently stop** → Failures surface as failed Jobs, and refreshed secrets carry a timestamp annotation so staleness is directly observable. Worth a Prometheus alert on `kube_job_status_failed` for this CronJob; noted as a follow-up rather than built here.
- **Namespace list is static configuration** → A namespace outside the configured list still gets nothing. Accepted: application namespaces are already declared in `app_namespaces`, and widening this to "all namespaces" would broaden the RBAC well past least privilege.
- **Clock skew between refresh and expiry** → 6h against 12h absorbs a fully missed run.

## Migration Plan

1. Build `modules/15-registry-credentials` alongside the existing code.
2. Remove `null_resource.image_pull_secret` and `registry_secret.sh` from `modules/10-gke-cluster`, along with its registry inputs.
3. Wire the new module into `main.tf` after `module.dr_cluster`; make `module.platform` and `module.argocd` depend on it.
4. On an existing DR deployment, the removed `null_resource` is destroyed and the new module recreates the secrets — no data loss, since the secrets are derived and short-lived by nature. The pull secret name is unchanged, so nothing referencing it needs to change.
5. Verify with `tofu plan` that the only registry-related changes are the removal of the old resources and the creation of the new module's.

## Open Questions

- Which AWS account and IAM principal will PPS/iCrypto issue the DR ECR credentials for, and is it the same key already used in QA?
- Is the DR ECR registry the same `eu-west-1` registry as QA/PROD, or a replicated registry in the DR region? A cross-region pull works but adds latency to every Phase 6 image pull.
- Should the runner image be mirrored into a registry PPS controls, rather than pulled from Docker Hub at bootstrap?
- Is there an existing Prometheus/Alertmanager target in the DR site to alert on a failed refresh Job, or does that arrive with the observability stack?
