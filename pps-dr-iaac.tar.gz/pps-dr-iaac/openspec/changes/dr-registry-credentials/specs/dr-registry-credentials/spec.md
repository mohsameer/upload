## ADDED Requirements

### Requirement: ECR credentials are refreshed on a schedule
The DR cluster SHALL hold a continuously-valid credential for the private container registry. When the registry is an AWS ECR host, the automation MUST exchange the configured AWS access key for an ECR authorization token from inside the cluster on a recurring schedule, and the refresh interval MUST be shorter than the ECR token lifetime of 12 hours.

#### Scenario: Refresh runs on schedule
- **WHEN** the registry credentials module is applied
- **THEN** a CronJob exists that refreshes the registry credentials
- **AND** its schedule interval is at most 6 hours, giving at least a 2x margin against the 12-hour token lifetime

#### Scenario: Credentials remain valid past the token lifetime
- **WHEN** the DR site has been running for longer than 12 hours
- **THEN** the image pull secret in each target namespace contains a token issued within the last refresh interval
- **AND** a newly scheduled pod pulling from the registry starts without an `ImagePullBackOff`

#### Scenario: Non-ECR registry
- **WHEN** `registry_server` is not an ECR host
- **THEN** the configured access key and secret are used directly as the registry username and password
- **AND** no AWS token exchange is attempted

### Requirement: Bootstrap before dependent phases
The automation SHALL create valid credentials immediately when the module is applied, without waiting for the first scheduled refresh, so that Phase 2 and later phases are never blocked on registry access.

#### Scenario: Credentials exist immediately after apply
- **WHEN** the module completes its apply
- **THEN** the image pull secret already exists in every configured namespace
- **AND** the module does not report complete until the bootstrap run has succeeded

#### Scenario: Bootstrap failure stops the run
- **WHEN** the bootstrap run cannot obtain a registry token
- **THEN** the apply fails naming the registry and the reason
- **AND** Phase 2 does not execute

### Requirement: Image pull secrets exist in every target namespace
The automation SHALL maintain a `kubernetes.io/dockerconfigjson` pull secret in every configured namespace, including the platform, Argo CD and application namespaces. Each refresh MUST reconcile the full namespace list, so a namespace created after the initial apply is covered on the next run.

#### Scenario: All configured namespaces covered
- **WHEN** a refresh runs
- **THEN** the pull secret exists and is current in every configured namespace

#### Scenario: Namespace created later
- **WHEN** a namespace in the configured list is created after the module was first applied
- **THEN** the next refresh creates the pull secret in it
- **AND** the refresh does not fail because of the previously missing namespace

#### Scenario: Missing namespace does not abort the run
- **WHEN** a configured namespace does not exist at refresh time
- **THEN** the refresh skips it, reports it, and continues with the remaining namespaces

### Requirement: Argo CD Helm OCI repository secret is maintained
The automation SHALL maintain the Argo CD repository secret that lets Argo CD pull Helm charts from the ECR OCI registry. The secret MUST carry the `argocd.argoproj.io/secret-type=repository` label, `type: helm`, `enableOCI: "true"`, and the registry URL, and MUST be refreshed on the same schedule as the pull secrets.

#### Scenario: Repository secret present and labelled
- **WHEN** the module has been applied
- **THEN** a secret exists in the Argo CD namespace labelled `argocd.argoproj.io/secret-type=repository`
- **AND** it declares `type: helm`, `enableOCI: "true"` and the configured registry URL

#### Scenario: Argo CD can pull an OCI chart after the token rotates
- **WHEN** more than one refresh interval has passed since Argo CD was installed
- **THEN** Argo CD can still resolve and render a Helm chart from the ECR OCI registry

#### Scenario: Argo CD namespace absent
- **WHEN** the Argo CD namespace does not yet exist at refresh time
- **THEN** the repository secret step is skipped and reported
- **AND** the pull secret refresh for the other namespaces still succeeds

### Requirement: Least-privilege access for the refresh workload
The refresh workload SHALL run as a dedicated ServiceAccount whose permissions are limited to managing secrets in the configured namespaces. It MUST NOT be granted cluster-admin, and it MUST NOT be granted permissions over resources other than those it writes.

#### Scenario: RBAC is scoped
- **WHEN** the module is applied
- **THEN** the refresh ServiceAccount's role grants only `get`, `list`, `create`, `patch` and `update` on secrets, plus the permissions needed to attach the pull secret to service accounts
- **AND** no binding to `cluster-admin` is created

#### Scenario: AWS credentials are not exposed in Terraform state or outputs
- **WHEN** `tofu output` is run
- **THEN** no AWS access key, secret key or registry token value is printed
- **AND** the credentials are delivered to the workload through a Kubernetes Secret rather than a Terraform output

### Requirement: Workloads consume the pull secret without per-workload configuration
The automation SHALL make the pull secret usable by workloads that do not declare `imagePullSecrets` themselves, by attaching it to the `default` ServiceAccount of each configured namespace. This behaviour MUST be toggleable.

#### Scenario: Default service account patched
- **WHEN** `attach_to_default_service_account` is true
- **THEN** each configured namespace's `default` ServiceAccount lists the pull secret in `imagePullSecrets`

#### Scenario: Attachment disabled
- **WHEN** `attach_to_default_service_account` is false
- **THEN** no ServiceAccount is modified
- **AND** the pull secrets are still created in every configured namespace

### Requirement: Refresh is observable
Each refresh SHALL report, per consumer, whether the credential was updated, so an operator can confirm from the cluster that credentials are current without decoding secret contents.

#### Scenario: Refresh outcome is visible
- **WHEN** a refresh run completes
- **THEN** its logs list each namespace and each secret it updated
- **AND** the refreshed secrets carry an annotation recording the timestamp of the last refresh

#### Scenario: Refresh failure is visible
- **WHEN** a scheduled refresh fails
- **THEN** the CronJob records a failed Job rather than reporting success
- **AND** the failure names the registry and the step that failed
