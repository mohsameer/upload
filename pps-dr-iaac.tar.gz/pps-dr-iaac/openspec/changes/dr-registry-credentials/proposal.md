## Why

The iCrypto SSO images and Helm charts live in a **private AWS ECR** registry, and an ECR authorization token is valid for **12 hours**. The current implementation creates the image pull secret exactly once, in Phase 1, from a `null_resource` whose trigger is the hash of the AWS access key — so it never refreshes on its own. A DR site that stays up longer than 12 hours starts failing every image pull, and the first thing to hit it is Phase 8's graceful restart.

Two further gaps make this worse:

- Nothing creates the Argo CD **Helm OCI repository secret** for ECR (`icrypto-helm`). Phase 4 creates only the *git* repository credential, so Argo CD cannot pull the iCrypto Helm charts and the Phase 6 app-of-apps cannot render. In QA this secret is refreshed by hand before every deploy precisely because it expires; DR has no equivalent at all.
- Pull secrets are created only in the namespaces known at Phase 1. Any namespace Argo CD creates during Phase 6 has none.

A DR site is exactly the environment where a 12-hour credential cannot be a manual chore.

## What Changes

- Add a new phase module `modules/15-registry-credentials`, ordered between Phase 1 (cluster) and Phase 2 (platform), that owns **every** ECR credential in the DR cluster.
- Exchange the AWS access key for an ECR authorization token **inside the cluster**, on a schedule, instead of once from the bastion.
- Refresh two distinct consumers from one token: the `dockerconfigjson` image pull secrets, and the Argo CD `type: helm` / `enableOCI: true` repository secret.
- Run a bootstrap Job immediately so later phases are never blocked waiting for the first CronJob tick.
- Reconcile every configured namespace on each run, so namespaces that appear after Phase 1 are covered.
- Optionally attach the pull secret to each namespace's `default` ServiceAccount so workloads need not declare `imagePullSecrets`.
- **BREAKING (internal)**: `modules/10-gke-cluster` loses its `image_pull_secret` resource, `registry_secret.sh`, and the `registry_server` / `ecr_access_key` / `ecr_secret_key` / `image_pull_secret_name` inputs. They move to the new module. Supersedes task 3.6 of change `pps-dr-iaac-v2`.
- Non-ECR registries stay supported: the access key and secret are used directly as username/password when `registry_server` is not an ECR host.

## Capabilities

### New Capabilities
- `dr-registry-credentials`: Continuously-valid credentials for the private ECR registry across the DR cluster — image pull secrets and the Argo CD Helm OCI repository secret — including bootstrap, scheduled refresh, and namespace reconciliation.

### Modified Capabilities
<!-- None. `dr-cluster-provisioning` has no spec requirement covering pull secrets (only task 3.6 of pps-dr-iaac-v2, which this change supersedes), so no delta spec is needed. -->

## Impact

- **New module**: `modules/15-registry-credentials` (Terraform + `refresh.sh` + RBAC).
- **Modified**: `main.tf` (new module block; `module.platform` and `module.argocd` gain a dependency on it), `modules/10-gke-cluster` (registry resources removed), root `variables.tf` (registry inputs move scope).
- **New cluster workloads**: one Secret holding the AWS credentials, one ServiceAccount, one ClusterRole + binding scoped to `secrets` in the target namespaces, one bootstrap Job, one CronJob.
- **Security**: long-lived AWS credentials now live in the cluster rather than only on the bastion. This is inherent to any in-cluster refresh mechanism; the credentials are scoped to ECR read and the RBAC is scoped to secrets in the configured namespaces.
- **Operational**: removes the manual "refresh `icrypto-helm` before deploying" step that the QA environment currently depends on.
- **Docs**: `README.md`, `CLAUDE.md` module table, and `DR-EXECUTION-PLAN.md` (new bastion/value prerequisites) all reference the new module.
