## 1. New Module Scaffolding

- [x] 1.1 Create `modules/15-registry-credentials/` with `main.tf`, `variables.tf`, `outputs.tf`
- [x] 1.2 Declare inputs: `registry_server`, `ecr_access_key`, `ecr_secret_key` (both sensitive), `image_pull_secret_name`, `target_namespaces`, `argocd_namespace`, `argocd_repo_secret_name`, `refresh_schedule`, `runner_image`, `attach_to_default_service_account`, `kubeconfig_path`, `credentials_namespace`
- [x] 1.3 Add a `refresh_schedule` validation rejecting a cadence outside the 12-hour ECR token lifetime, defaulting to every 6 hours
- [x] 1.4 Document on `runner_image` that it must be pullable **without** ECR credentials, since it is what creates them

## 2. Refresh Script (`refresh.sh`)

- [x] 2.1 Detect an ECR host (`.ecr.` in `registry_server`) and derive the AWS region from it; fall back to using the key/secret directly for non-ECR registries
- [x] 2.2 Obtain the registry token once per run; fail the run naming the registry when the exchange fails
- [x] 2.3 Upsert the `dockerconfigjson` pull secret in every configured namespace that exists
- [x] 2.4 Skip and report namespaces that do not exist, without failing the run
- [x] 2.5 Upsert the Argo CD repository secret (`type: helm`, `enableOCI: "true"`, registry URL, label `argocd.argoproj.io/secret-type=repository`) when the Argo CD namespace exists
- [x] 2.6 Patch each namespace's `default` ServiceAccount `imagePullSecrets` when `attach_to_default_service_account` is true
- [x] 2.7 Annotate every written secret with the refresh timestamp
- [x] 2.8 Log per-namespace and per-secret outcomes; exit non-zero on any real failure so the Job is recorded as failed

## 3. In-Cluster Resources

- [x] 3.1 Create the namespace that hosts the refresh workload (idempotent, may be the platform namespace)
- [x] 3.2 Create the Secret holding the AWS access key and secret from the `TF_VAR_*` inputs
- [x] 3.3 Ship `refresh.sh` as a ConfigMap so the Job and CronJob share one code path
- [x] 3.4 Create the ServiceAccount for the refresh workload
- [x] 3.5 Create a ClusterRole granting only `get`/`list`/`create`/`patch`/`update` on secrets, plus `get`/`patch` on serviceaccounts
- [x] 3.6 Bind it with per-namespace RoleBindings (not a ClusterRoleBinding) so access stays inside the configured namespaces
- [x] 3.7 Create the CronJob on `refresh_schedule` with `concurrencyPolicy: Forbid` and history limits set

## 4. Bootstrap

- [x] 4.1 Create a bootstrap Job running the same script immediately on apply
- [x] 4.2 Wait for the bootstrap Job to complete; fail the apply naming the registry and step when it does not
- [x] 4.3 Trigger the module's resources on content hashes (`filemd5` of the script, key fingerprint, schedule, namespace list) — no `timestamp()`, per design decision D5
- [x] 4.4 Expose `completed` only after the bootstrap Job has succeeded

## 5. Remove Registry Handling from Phase 1

- [x] 5.1 Delete `null_resource.image_pull_secret` from `modules/10-gke-cluster/main.tf`
- [x] 5.2 Delete `modules/10-gke-cluster/registry_secret.sh`
- [x] 5.3 Remove `registry_server`, `ecr_access_key`, `ecr_secret_key`, `image_pull_secret_name` from `modules/10-gke-cluster/variables.tf`
- [x] 5.4 Repoint `modules/10-gke-cluster/outputs.tf` `completed` at the namespace resource instead of the deleted pull-secret resource
- [x] 5.5 Confirm task 3.6 of change `pps-dr-iaac-v2` is superseded and note it there

## 6. Wire Into the Root Orchestration

- [x] 6.1 Add the `module.registry_credentials` block to `main.tf`, `depends_on = [module.dr_cluster]`
- [x] 6.2 Pass the union of platform, Argo CD and application namespaces as `target_namespaces`
- [x] 6.3 Make `module.platform` and `module.argocd` depend on `module.registry_credentials`
- [x] 6.4 Move the registry inputs off `module.dr_cluster` in `main.tf`
- [x] 6.5 Add `refresh_schedule`, `runner_image`, `attach_to_default_service_account` and `argocd_repo_secret_name` to root `variables.tf` and `pps-dr.tfvars.example`
- [x] 6.6 Add a root output reporting the refresh schedule and the secrets under management

## 7. Argo CD Alignment

- [x] 7.1 Confirm `modules/40-argocd/repo_credentials.sh` keeps owning only the **git** repository secret, with a comment pointing at this module for the Helm OCI one
- [ ] 7.2 Verify Argo CD resolves an ECR OCI chart after the module has run (needs a live cluster; tracked with §10)
- [x] 7.3 Ensure Phase 4 does not race the bootstrap: Argo CD's own init container comes from ECR

## 8. Verification

- [x] 8.1 `tofu fmt -recursive` and `tofu validate` pass
- [x] 8.2 `tofu plan -var-file=pps-dr.tfvars.example` fails only on placeholder validation, not on wiring
- [x] 8.3 `bash -n` clean on `refresh.sh`
- [x] 8.4 Confirm the plan shows no `timestamp()`-driven perpetual diff for the new module
- [x] 8.5 Confirm the plan still shows no create/update/destroy against Cloud SQL, Capella or the backup bucket

## 9. Documentation

- [x] 9.1 Add the module to the `README.md` layout section
- [x] 9.2 Add a row to the `CLAUDE.md` module table and note the CronJob exception to the "every module is one-shot" rule
- [x] 9.3 Add the ECR values and the runner-image question to `DR-EXECUTION-PLAN.md` Stage A
- [x] 9.4 Add a recovery-note row for expired/failed registry credentials (`ImagePullBackOff` across the site, Argo CD unable to resolve OCI charts)

## 10. Live Verification (blocked on a cluster)

- [ ] 10.1 Confirm the bootstrap Job completes and secrets appear in every configured namespace
- [ ] 10.2 Confirm a pod pulls an ECR image using only the default ServiceAccount
- [ ] 10.3 Confirm Argo CD renders a Helm chart from the ECR OCI registry
- [ ] 10.4 Force a refresh and confirm the timestamp annotation advances
- [ ] 10.5 Confirm credentials still work more than 12 hours after the initial apply
