## Why

The existing `pps-dr-iaac` automation (2024) builds the PPS DR site around **in-cluster** PostgreSQL and Couchbase, deploys every SSO service through a pile of imperative `null_resource` + shell scripts, and has no GitOps, no Argo CD, and no External Secrets Operator. The current DR plan for PPS moves the data tier to **managed services** — Cloud SQL PostgreSQL and Couchbase Capella — and moves application delivery to **Argo CD**. The existing code cannot execute that plan.

This change rebuilds the DR automation to match the 8-phase runbook in "iCrypto — Disaster Recovery Plan for PPS", so a DR site can be stood up from a bastion in a single, repeatable, ordered `tofu apply` while the data tier stays managed.

## What Changes

- **BREAKING**: PostgreSQL is no longer installed into the GKE cluster. The Cloud SQL instance in the DR region is a **prerequisite** consumed as a data source; the repo only performs a restore into it from a GCS backup.
- **BREAKING**: Couchbase is no longer installed via the in-cluster Couchbase Operator. The Capella cluster is a **prerequisite**; the repo only triggers a restore through the Capella Management API / `cbrestore`.
- **BREAKING**: Application services are no longer deployed by per-service `*_deploy.sh` helm scripts. Argo CD owns application delivery via an app-of-apps.
- **BREAKING**: `pps-dr.tfvars` is replaced by `pps-dr.tfvars.example` carrying placeholder values only; the real file is git-ignored.
- Add a preflight phase that fails fast when a prerequisite is missing (Cloud SQL reachable, Capella reachable, GCS backup objects present, kubeconfig valid).
- Add Argo CD install + Argo CD backup restore as an explicit phase.
- Add Vault auto-rotation configuration and External Secrets Operator install, with ExternalSecrets syncing into target namespaces.
- Keep the in-cluster stateful platform, now scoped to Consul, Vault, OpenLDAP and Zeebe only.
- Ingress + load balancers are reused when they already exist, and only created when absent; DNS remains a manual PPS action surfaced as a Terraform output.
- Renumber modules to `NN-<phase>` matching the runbook phases, and replace `always_run = timestamp()` triggers with content-hash triggers so re-runs are idempotent.
- All environment-specific values ship as obvious placeholders until PPS provides real values.

## Capabilities

### New Capabilities
- `dr-prerequisites`: Preflight validation of the six documented DR prerequisites, and the placeholder-value contract used until PPS supplies real values.
- `dr-cluster-provisioning`: Phase 1 — GKE DR cluster created-or-adopted, and the kubernetes/helm/vault provider wiring that depends on it.
- `dr-stateful-platform`: Phase 2 — Consul, Vault, OpenLDAP and Zeebe StatefulSets.
- `dr-data-restore`: Phase 3 — Cloud SQL restore from GCS, Couchbase Capella restore, then Consul, Vault and LDAP data restore.
- `dr-gitops-argocd`: Phase 4 — Argo CD installed via Helm and its backup restored.
- `dr-secrets-management`: Phase 5 — Vault auto-rotation plus External Secrets Operator and ExternalSecrets syncing to target namespaces.
- `dr-app-services`: Phase 6 — iCrypto SSO application services delivered through Argo CD.
- `dr-ingress-dns`: Phase 7 — ingress and load balancer reuse-or-create, TLS material, and the DNS change request handed to PPS.
- `dr-validation`: Phase 8 — post-DNS graceful restart and the validation/sign-off checks.

### Modified Capabilities
<!-- None. openspec/specs/ is empty; this is the first change in the repo. -->

## Impact

- **Repo layout**: `modules/` is restructured into phase-numbered modules; `modules/persistent-deployments/{postgresql,couchbase,opensearch}_installation.sh` and `modules/icrypto-services-deployment/*_deploy.sh` are removed or superseded.
- **Root config**: `main.tf`, `variables.tf`, `provider.tf`, `backend.tf` rewritten; `pps-dr.tfvars` replaced by `pps-dr.tfvars.example`.
- **Providers**: adds `kubernetes`, `helm`, `vault`, and `couchbasecloud/couchbase-capella`; pins `google` and OpenTofu versions.
- **External dependencies**: Cloud SQL PostgreSQL (DR region), Couchbase Capella (DR region), GCS backup bucket + credentials, GKE kubeconfig, Argo CD backup archive, `*.pps.co.za` TLS certificate and key.
- **Operational**: DNS cutover stays a PPS-side manual action; the run pauses between Phase 7 and Phase 8 until DNS resolves.
- **Secrets**: `TF_VAR_*` environment variables carry all sensitive inputs; nothing sensitive is committed.
