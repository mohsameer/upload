## ADDED Requirements

### Requirement: In-cluster stateful platform is limited to Consul, Vault, LDAP and Zeebe
Phase 2 SHALL deploy exactly four stateful platform components into the DR cluster as StatefulSets: Consul, Vault, OpenLDAP and Zeebe. The automation MUST NOT deploy in-cluster PostgreSQL, in-cluster Couchbase, or the Couchbase Operator, because those tiers are managed services.

#### Scenario: Only the four platform StatefulSets are deployed
- **WHEN** Phase 2 completes
- **THEN** StatefulSets exist for Consul, Vault, OpenLDAP and Zeebe
- **AND** no PostgreSQL, Couchbase or Couchbase Operator workload is created by this repository

### Requirement: Deterministic startup ordering
Phase 2 SHALL start Consul before Vault, since Vault uses Consul as its storage backend. OpenLDAP and Zeebe MAY start in parallel with each other but MUST NOT be reported complete until their pods are Ready.

#### Scenario: Vault waits for Consul
- **WHEN** Phase 2 is applied
- **THEN** the Vault release depends on the Consul release
- **AND** Vault deployment does not begin until Consul pods report Ready

#### Scenario: Readiness gate per component
- **WHEN** a platform component's pods fail to reach Ready within the configured timeout
- **THEN** the apply fails naming the component and the timeout value
- **AND** later phases do not execute

### Requirement: Vault is initialised and unsealed
Phase 2 SHALL leave Vault initialised, unsealed and reachable by later phases. Unseal keys and the root token MUST NOT be written to the repository or to Terraform outputs in plaintext.

#### Scenario: Vault reachable after Phase 2
- **WHEN** Phase 2 completes
- **THEN** the Vault status endpoint reports `initialized=true` and `sealed=false`

#### Scenario: Vault secrets are not exposed
- **WHEN** `tofu output` is run
- **THEN** no unseal key or root token value is printed in plaintext

### Requirement: Persistent storage for stateful components
Each stateful component SHALL use PersistentVolumeClaims backed by a configurable GKE StorageClass, with per-component sizes exposed as variables. Reruns MUST NOT delete or recreate existing PVCs.

#### Scenario: Storage class and size are configurable
- **WHEN** the operator sets the storage class and per-component sizes
- **THEN** the resulting PVCs use those values

#### Scenario: Rerun preserves data volumes
- **WHEN** Phase 2 is applied a second time without configuration change
- **THEN** the plan shows no destroy action for any PersistentVolumeClaim
