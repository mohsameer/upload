## ADDED Requirements

### Requirement: PostgreSQL is restored into Cloud SQL from GCS
Phase 3 SHALL restore the IDM/application PostgreSQL data into the pre-existing Cloud SQL instance in the DR region by importing the backup object from the GCS bucket. The restore MUST target the Cloud SQL instance identified by variable, MUST wait for the import operation to reach a terminal state, and MUST fail the apply when the import ends in error.

#### Scenario: Successful Cloud SQL import
- **WHEN** the configured dump object exists in GCS and the Cloud SQL instance is RUNNABLE
- **THEN** the import operation is started against that instance
- **AND** the apply waits for the operation to complete and succeeds only when its status is DONE without error

#### Scenario: Import fails
- **WHEN** the Cloud SQL import operation ends with an error
- **THEN** the apply fails with the operation id and the returned error message
- **AND** no later phase executes

#### Scenario: Restore is explicitly gated
- **WHEN** `postgres_restore_enabled` is false
- **THEN** no import operation is started and the phase reports skipped

### Requirement: Cloud SQL access from the DR cluster
The automation SHALL make the restored Cloud SQL instance reachable from workloads in the DR cluster using the configured connectivity method (private services access or Cloud SQL Auth Proxy sidecar/deployment), and SHALL publish the connection details to the platform for consumption by application services.

#### Scenario: Connectivity is verified after restore
- **WHEN** Phase 3 completes the PostgreSQL restore
- **THEN** a read-only connectivity check from inside the DR cluster to the Cloud SQL instance succeeds
- **AND** the apply fails if the check cannot connect

### Requirement: Couchbase data is restored into Capella
Phase 3 SHALL restore Couchbase data into the pre-existing Capella cluster using the Capella Restore API, falling back to `cbrestore` against the configured backup archive when the API path is disabled. The restore MUST target the configured Capella cluster and buckets, and MUST wait for the restore job to reach a terminal state.

#### Scenario: Capella restore via API
- **WHEN** `couchbase_restore_enabled` is true and Capella API credentials are configured
- **THEN** a restore job is submitted for the configured cluster and bucket list
- **AND** the apply waits for the job to complete and fails on a non-successful terminal state

#### Scenario: Bucket documents present after restore
- **WHEN** the Capella restore completes
- **THEN** each configured bucket reports a non-zero document count

### Requirement: Consul, Vault and LDAP data are restored after their platform components are running
Phase 3 SHALL restore Consul KV, Vault data and the OpenLDAP directory only after the corresponding Phase 2 StatefulSets are Ready. Each restore MUST be individually toggleable and MUST fail the apply on error rather than continuing silently.

#### Scenario: Consul KV restore
- **WHEN** Consul is Ready and `consul_restore_enabled` is true
- **THEN** the configured Consul snapshot/KV backup is restored into the DR Consul cluster
- **AND** a post-restore key count check confirms keys are present

#### Scenario: LDAP directory restore
- **WHEN** OpenLDAP is Ready and `ldap_restore_enabled` is true
- **THEN** the configured LDIF backups are loaded into the DR OpenLDAP instance
- **AND** a post-restore search returns the expected base DN entries

#### Scenario: A restore step fails
- **WHEN** any of the Consul, Vault or LDAP restore steps exits non-zero
- **THEN** the apply fails naming the component
- **AND** Phase 4 does not execute

### Requirement: Restores are re-runnable
Each restore step SHALL be safe to re-run. Re-running a restore MUST either be idempotent or be explicitly gated behind its enable flag so an operator cannot double-apply a restore by accident during a routine `tofu apply`.

#### Scenario: Apply re-run after successful restore
- **WHEN** `tofu apply` is re-run with all restore flags left at their post-restore values
- **THEN** no restore operation is re-executed
- **AND** the plan shows no change for the restore resources
