## ADDED Requirements

### Requirement: DR GKE cluster is created or adopted
Phase 1 SHALL ensure a private GKE cluster exists in the DR region with a node pool of the configured size (default 3 nodes). When no cluster with the configured name exists, the automation MUST create it. When a cluster with that name already exists, the automation MUST adopt it as a data source and MUST NOT recreate or destroy it.

#### Scenario: No DR cluster exists
- **WHEN** Phase 1 runs and no GKE cluster matches the configured name and location
- **THEN** a private GKE cluster is created with private nodes, a public control-plane endpoint restricted by master authorized networks, and a node pool of `dr_gke_node_count` nodes

#### Scenario: DR cluster already exists
- **WHEN** Phase 1 runs and a GKE cluster matching the configured name and location already exists
- **THEN** the existing cluster is read as a data source
- **AND** the plan shows no create or destroy action for that cluster or its node pool

#### Scenario: Node pool size is configurable
- **WHEN** `dr_gke_node_count` is set
- **THEN** the created node pool has exactly that node count, defaulting to 3

### Requirement: Cluster hardening baseline
The created cluster SHALL use private nodes, workload identity, a pinned release channel, and master authorized networks restricted to the configured bastion/jumpbox CIDRs. The automation MUST NOT enable unrestricted public control-plane access.

#### Scenario: Master authorized networks are restricted
- **WHEN** the cluster is created
- **THEN** `gcp_public_cidrs_access_enabled` is false
- **AND** every configured authorized CIDR block is present in `master_authorized_networks_config`

#### Scenario: Workload identity enabled
- **WHEN** the cluster is created
- **THEN** the workload identity pool is set to `<project_id>.svc.id.goog`

### Requirement: Cluster credentials and downstream providers
After the cluster exists, the automation SHALL obtain cluster credentials and configure the `kubernetes` and `helm` providers against that cluster. Provider configuration MUST derive endpoint and CA data from the cluster resource or data source, and MUST authenticate with a Google access token rather than a static kubeconfig file committed to the repo.

#### Scenario: Providers target the DR cluster
- **WHEN** Phase 1 completes
- **THEN** the `kubernetes` and `helm` providers are configured with the DR cluster endpoint and cluster CA certificate
- **AND** authentication uses a `google_client_config` access token

#### Scenario: Downstream phases wait for cluster readiness
- **WHEN** Phase 2 or later resources are planned
- **THEN** they depend on Phase 1 completion so no Kubernetes API call is attempted before the cluster is reachable

### Requirement: Required namespaces exist before workloads
Phase 1 SHALL create the namespaces required by later phases, including the platform namespace, the Argo CD namespace, the External Secrets namespace, and the application namespaces. Namespace creation MUST be idempotent.

#### Scenario: Namespaces created once
- **WHEN** Phase 1 is applied twice in a row without configuration change
- **THEN** the second apply reports no change for the namespace resources
