## ADDED Requirements

### Requirement: Graceful restart after DNS is in place
Phase 8 SHALL perform a graceful restart of the configured services once DNS resolves, so services pick up hostnames that were unresolvable at first start. The restart MUST be targetable independently of the rest of the run.

#### Scenario: Targeted restart run
- **WHEN** the operator applies only the validation module target
- **THEN** the configured services are restarted without re-running earlier phases

#### Scenario: Restart waits for rollout
- **WHEN** services are restarted
- **THEN** the phase waits for each rollout to complete
- **AND** fails naming any workload whose rollout does not complete within the configured timeout

### Requirement: Post-restart health checks
Phase 8 SHALL verify service health after the restart and MUST fail when any configured health endpoint is not healthy.

#### Scenario: All health endpoints healthy
- **WHEN** the health checks run after restart
- **THEN** every configured service health endpoint returns a healthy response

#### Scenario: A health endpoint fails
- **WHEN** any configured health endpoint is unhealthy or unreachable
- **THEN** the phase fails listing each failing service and the response received

### Requirement: OIDC flow validation
Phase 8 SHALL validate the end-to-end OIDC flow against the DR site, exercising the discovery document and a token issuance path with the configured validation client.

#### Scenario: OIDC discovery and token issuance succeed
- **WHEN** the OIDC validation runs against the DR OIDC hostname
- **THEN** the discovery document is retrievable
- **AND** a token is successfully issued for the configured validation client

### Requirement: Data tier validation
Phase 8 SHALL validate that the restored data tier is usable: Couchbase Capella session read/write, IDM PostgreSQL read/write against Cloud SQL, and Argo CD health.

#### Scenario: Couchbase session read/write
- **WHEN** the validation writes and reads back a test session document in the configured Capella bucket
- **THEN** both operations succeed and the test document is removed afterwards

#### Scenario: IDM PostgreSQL read/write
- **WHEN** the validation performs a write and a read against the IDM database on Cloud SQL
- **THEN** both operations succeed

#### Scenario: Argo CD health
- **WHEN** the validation queries Argo CD
- **THEN** every Application reports `Healthy` and `Synced`

### Requirement: Sign-off report
Phase 8 SHALL emit a machine-readable sign-off report listing each validation check with its pass/fail result and a timestamp, so the DR exercise can be signed off with evidence.

#### Scenario: Report produced on completion
- **WHEN** Phase 8 completes
- **THEN** a sign-off report is written listing every check, its result, and the run timestamp

#### Scenario: Report produced on failure
- **WHEN** one or more checks fail
- **THEN** the report still lists every check with its result
- **AND** the apply exits non-zero
