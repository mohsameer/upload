## ADDED Requirements

### Requirement: Argo CD is installed via Helm
Phase 4 SHALL install Argo CD into the DR cluster using the Helm provider, with the chart version, namespace and values pinned by variable. The install MUST complete before any application delivery is attempted.

#### Scenario: Argo CD server becomes available
- **WHEN** Phase 4 is applied
- **THEN** the Argo CD Helm release reaches a deployed status
- **AND** the `argocd-server`, `argocd-repo-server` and `argocd-application-controller` workloads report Ready

#### Scenario: Chart version is pinned
- **WHEN** the Argo CD release is planned
- **THEN** an explicit chart version from a variable is used rather than "latest"

### Requirement: Argo CD backup is restored
Phase 4 SHALL restore the Argo CD backup — applications, projects, repository credentials and cluster secrets — from the configured backup archive after the Argo CD install is Ready. The restore MUST fail the apply if the backup archive is missing or cannot be applied.

#### Scenario: Backup restored successfully
- **WHEN** the configured Argo CD backup archive is present and Argo CD is Ready
- **THEN** the backup is applied into the Argo CD namespace
- **AND** the restored AppProjects and Applications are visible in Argo CD

#### Scenario: Backup archive missing
- **WHEN** the configured Argo CD backup archive cannot be read
- **THEN** the apply fails naming the expected archive location
- **AND** Phase 5 does not execute

### Requirement: Argo CD targets the DR cluster and DR-appropriate sources
Restored Argo CD Applications SHALL point at the DR cluster and at repository revisions specified by variable, so a DR run does not silently deploy a production-only revision or target a non-DR cluster.

#### Scenario: Destination is the DR cluster
- **WHEN** the Argo CD backup is restored
- **THEN** every restored Application's destination server resolves to the DR cluster
- **AND** any Application whose destination cannot be resolved to the DR cluster is reported by the phase

#### Scenario: Repository credentials work
- **WHEN** the restore completes
- **THEN** Argo CD can reach each configured repository and report a successful connection state

### Requirement: Applications do not auto-sync before secrets exist
Argo CD Applications SHALL NOT auto-sync application workloads until Phase 5 has installed External Secrets Operator and secrets are syncing. The automation MUST hold sync until the secrets phase completes.

#### Scenario: Sync held until secrets are ready
- **WHEN** Phase 4 completes but Phase 5 has not run
- **THEN** application Applications remain unsynced or paused
- **AND** no application pod is left crash-looping on a missing Secret
