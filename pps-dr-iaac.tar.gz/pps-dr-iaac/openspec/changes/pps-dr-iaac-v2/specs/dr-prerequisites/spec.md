## ADDED Requirements

### Requirement: Prerequisites are consumed, never created
The DR automation SHALL treat the six documented prerequisites as externally-owned resources. It MUST reference them through Terraform data sources or input variables and MUST NOT declare a managed resource that creates, modifies or destroys them. The prerequisites are: (1) IDM PostgreSQL size optimised via partitioning, (2) Couchbase Capella cluster existing and reachable in the DR region, (3) Cloud SQL PostgreSQL instance provisioned in the DR region, (4) all DB backup files present and verified in the GCS bucket, (5) valid GCS bucket credentials accessible from the DR environment, (6) kubeconfig / GKE credentials for the DR cluster held by the iCrypto team.

#### Scenario: Cloud SQL instance is referenced as a data source
- **WHEN** `tofu plan` is run against a configured DR environment
- **THEN** the plan output contains no `google_sql_database_instance` create, update or destroy action
- **AND** the Cloud SQL instance appears only as a read via `data "google_sql_database_instance"`

#### Scenario: Capella cluster is referenced as a data source
- **WHEN** `tofu plan` is run
- **THEN** the plan output contains no create or destroy action for the Capella cluster, project, or organisation

### Requirement: Preflight gate blocks the run when a prerequisite is missing
The automation SHALL run a preflight check before Phase 1 provisioning. The check MUST verify each prerequisite and MUST fail the `tofu apply` with a message naming the specific prerequisite that failed. Checks MUST be read-only.

#### Scenario: Missing PostgreSQL backup object in GCS
- **WHEN** preflight runs and the configured PostgreSQL dump object does not exist in the GCS backup bucket
- **THEN** the apply fails before any GKE resource is created
- **AND** the error names the bucket and the missing object path

#### Scenario: Capella cluster unreachable from the DR environment
- **WHEN** preflight cannot authenticate to the Capella Management API or the target cluster is not in a healthy state
- **THEN** the apply fails before any GKE resource is created
- **AND** the error names the Capella cluster id and the API status returned

#### Scenario: All prerequisites satisfied
- **WHEN** preflight verifies Cloud SQL reachability, Capella health, presence of every configured backup object, GCS credential validity, and cluster credentials
- **THEN** preflight succeeds and Phase 1 proceeds

### Requirement: Placeholder configuration until PPS supplies real values
Until PPS provides real environment values, every environment-specific input SHALL ship as an obvious placeholder. The repository MUST provide `pps-dr.tfvars.example` containing only placeholder values, MUST git-ignore the real `pps-dr.tfvars`, and MUST NOT commit any credential, token, certificate or private key.

#### Scenario: Example tfvars contains only placeholders
- **WHEN** `pps-dr.tfvars.example` is inspected
- **THEN** every environment-specific value is a recognisable placeholder using the `REPLACE_ME_` prefix, a documented dummy CIDR, or a documented dummy identifier
- **AND** no value is a real PPS hostname, IP, project id, account or secret

#### Scenario: Placeholder values are rejected at apply time
- **WHEN** `tofu apply` is run with any variable still set to a `REPLACE_ME_` placeholder
- **THEN** a variable validation rule fails the run
- **AND** the error names each variable still holding a placeholder

#### Scenario: Sensitive inputs come from the environment
- **WHEN** the operator prepares a DR run
- **THEN** all sensitive inputs are supplied as `TF_VAR_*` environment variables
- **AND** each such variable is declared `sensitive = true` in `variables.tf`
