## ADDED Requirements

### Requirement: SSO services are deployed through Argo CD only
Phase 6 SHALL deploy all iCrypto SSO application services through Argo CD. The automation MUST NOT run per-service `helm install` shell scripts. Terraform's role is limited to creating or syncing the Argo CD Application resources and waiting for the result.

#### Scenario: No imperative helm deploys
- **WHEN** Phase 6 is applied
- **THEN** no per-service `*_deploy.sh` script is invoked
- **AND** each service's workloads are owned by an Argo CD Application

#### Scenario: App-of-apps drives the service set
- **WHEN** the service list changes
- **THEN** it changes through the Argo CD app-of-apps source, not through new Terraform resources per service

### Requirement: Service image versions are pinned per DR run
Each SSO service SHALL be deployed at a version pinned by variable for the DR run, so DR reproduces a known-good production version set rather than whatever tag is current.

#### Scenario: Versions supplied per service
- **WHEN** the operator sets the per-service version variables
- **THEN** the Argo CD Applications render those exact versions
- **AND** an unset or placeholder version fails variable validation before apply

### Requirement: All SSO service pods reach Ready
Phase 6 SHALL wait for every configured SSO service to become healthy in Argo CD and Ready in Kubernetes, and MUST fail the apply when any service does not converge within the configured timeout. This is the phase's documented sign-off check.

#### Scenario: All services healthy
- **WHEN** Phase 6 completes
- **THEN** every configured Argo CD Application reports `Synced` and `Healthy`
- **AND** every SSO service Deployment or StatefulSet reports all replicas Ready

#### Scenario: A service fails to converge
- **WHEN** any Application remains `Degraded`, `OutOfSync` or has pods not Ready past the timeout
- **THEN** the apply fails listing each failing Application with its health and sync status
- **AND** Phase 7 does not execute

### Requirement: Services consume the managed data tier
SSO services SHALL be configured to use the Cloud SQL PostgreSQL instance and the Couchbase Capella cluster restored in Phase 3, and MUST NOT be configured against in-cluster PostgreSQL or Couchbase endpoints.

#### Scenario: Database endpoints point at managed services
- **WHEN** the deployed service configuration is inspected
- **THEN** PostgreSQL connection settings resolve to the Cloud SQL instance or its Auth Proxy endpoint
- **AND** Couchbase connection settings resolve to the Capella connection string
