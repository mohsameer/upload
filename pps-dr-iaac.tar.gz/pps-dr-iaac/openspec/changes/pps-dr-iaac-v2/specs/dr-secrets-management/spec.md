## ADDED Requirements

### Requirement: Vault auto-rotation is configured
Phase 5 SHALL configure Vault for the DR site: enable the required secret engines and auth methods, apply the policies used by the SSO services, and enable automatic rotation for the credentials that support it, with rotation periods set by variable.

#### Scenario: Engines, auth and policies applied
- **WHEN** Phase 5 is applied
- **THEN** the configured Vault secret engines and auth methods are enabled
- **AND** each configured policy exists with the expected capabilities

#### Scenario: Auto-rotation enabled
- **WHEN** a credential that supports rotation is configured
- **THEN** its rotation period is set from the corresponding variable
- **AND** the rotation configuration is readable back from Vault

#### Scenario: Rerun is idempotent
- **WHEN** Phase 5 is applied twice without configuration change
- **THEN** the second plan shows no change for the Vault configuration resources

### Requirement: External Secrets Operator is installed
Phase 5 SHALL install External Secrets Operator into the DR cluster via Helm with a pinned chart version, and SHALL create a SecretStore or ClusterSecretStore that authenticates to the in-cluster Vault.

#### Scenario: ESO becomes available
- **WHEN** Phase 5 is applied
- **THEN** the External Secrets Operator workloads report Ready
- **AND** the ExternalSecret, SecretStore and ClusterSecretStore CRDs are established

#### Scenario: Secret store authenticates to Vault
- **WHEN** the ClusterSecretStore is created
- **THEN** its status reports `Valid`
- **AND** the store's Vault authentication does not rely on a token committed to the repository

### Requirement: All ExternalSecrets sync to their target namespaces
Phase 5 SHALL verify that every ExternalSecret in the target namespaces reaches a synced state, and MUST fail the apply when any ExternalSecret is not synced within the configured timeout. This is the phase's documented sign-off check.

#### Scenario: Every ExternalSecret is synced
- **WHEN** Phase 5 completes
- **THEN** every ExternalSecret across the configured target namespaces reports `SecretSynced`
- **AND** the corresponding Kubernetes Secret exists in that namespace

#### Scenario: An ExternalSecret fails to sync
- **WHEN** any ExternalSecret has not reached `SecretSynced` within the configured timeout
- **THEN** the apply fails listing the namespace and name of each unsynced ExternalSecret
- **AND** Phase 6 does not execute

### Requirement: Secret material never lands in state or git in plaintext
Secret values SHALL be resolved at runtime by ESO from Vault. The automation MUST NOT write application secret values into Terraform outputs, and MUST NOT commit secret values to the repository.

#### Scenario: Outputs contain no secret values
- **WHEN** `tofu output` is run after Phase 5
- **THEN** no application secret value is printed
- **AND** any output derived from a secret is marked sensitive
