## ADDED Requirements

### Requirement: Ingress and load balancers are reused when present
Phase 7 SHALL reuse an existing ingress and its load balancer when one already exists for the DR site, and SHALL create it only when absent. A re-run MUST NOT churn the load balancer, because a new load balancer changes the IP address and invalidates the DNS records PPS has already created.

#### Scenario: Ingress already exists
- **WHEN** Phase 7 runs and the expected ingress objects already exist
- **THEN** they are adopted rather than recreated
- **AND** the plan shows no destroy action for the ingress or its load balancer

#### Scenario: Ingress absent
- **WHEN** no ingress exists for the DR site
- **THEN** the internal and external ingress objects are created with the configured hostnames

#### Scenario: Re-run keeps the same address
- **WHEN** Phase 7 is applied a second time without configuration change
- **THEN** the reported ingress IP addresses are unchanged from the previous run

### Requirement: TLS material is supplied, never generated or committed
The `*.pps.co.za` certificate and private key SHALL be supplied by the operator from outside the repository and loaded into the cluster as TLS Secrets. The repository MUST NOT contain the certificate or key.

#### Scenario: TLS secret created from supplied material
- **WHEN** the certificate and key paths are configured and readable
- **THEN** the corresponding Kubernetes TLS Secrets are created in the ingress namespaces

#### Scenario: TLS material missing
- **WHEN** the configured certificate or key file cannot be read
- **THEN** the apply fails naming the missing path

### Requirement: DNS change request is surfaced to PPS
DNS is a PPS-side action. Phase 7 SHALL emit, as Terraform outputs, every hostname that requires a DNS record together with the resolved ingress IP address, so the operator can raise the DNS change request to PPS. The automation MUST NOT attempt to create the external DNS records itself.

#### Scenario: Hostname-to-IP mapping is emitted
- **WHEN** Phase 7 completes
- **THEN** `tofu output` lists each required hostname with its ingress IP address
- **AND** the output includes the DR hostnames configured for the site

#### Scenario: No external DNS records are created
- **WHEN** Phase 7 is planned
- **THEN** the plan contains no managed resource that creates a public DNS record for a `pps.co.za` hostname

### Requirement: DNS resolution gate before Phase 8
Phase 8 SHALL NOT run until the required hostnames resolve. Phase 7 MUST provide an explicit check the operator runs, or a gated wait, that verifies each hostname resolves both from inside the cluster and externally.

#### Scenario: DNS resolves internally and externally
- **WHEN** the resolution check runs after PPS applies the DNS change
- **THEN** every configured hostname resolves from inside the DR cluster and from outside it
- **AND** the check reports success so Phase 8 may run

#### Scenario: DNS not yet in place
- **WHEN** any configured hostname does not resolve
- **THEN** the check fails listing the unresolved hostnames
- **AND** Phase 8 is not executed
