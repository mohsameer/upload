## Context

`pps-dr-iaac` today (last touched 2024) builds a DR site as one flat `main.tf` calling eight modules, most of which are `null_resource` + `local-exec` wrappers around bash scripts. Its data tier is in-cluster: `postgresql_installation.sh`, `couchbase_installation.sh` and `opensearch_cluster_installation.sh` all deploy into GKE. Application delivery is a set of per-service `*_deploy.sh` helm scripts. Several `null_resource`s use `triggers = { always_run = timestamp() }`, so every `tofu apply` re-runs them.

The current DR plan changes the shape of the target:

- PostgreSQL moves to **Cloud SQL** in the DR region (prerequisite, restored from a GCS backup).
- Couchbase moves to **Couchbase Capella** (prerequisite, restored via the Restore API / `cbrestore`).
- Application delivery moves to **Argo CD** (installed in Phase 4, backup restored, app-of-apps in Phase 6).
- Secrets move to **Vault + External Secrets Operator** (Phase 5).
- Prerequisites are explicitly out of this repo's ownership: Cloud SQL instance, Capella cluster, verified GCS backups, GCS credentials, kubeconfig.

Constraint: PPS has not yet supplied real environment values. Everything environment-specific must ship as a placeholder that fails loudly if left unreplaced.

Stakeholders: iCrypto deployment team (runs the DR exercise from the DR bastion), PPS (owns DNS changes and supplies the prerequisites).

## Goals / Non-Goals

**Goals:**

- One ordered, resumable `tofu apply` that executes DR plan Phases 1–7, pauses for PPS DNS, then Phase 8.
- Managed data tier: never create or destroy Cloud SQL or Capella from this repo.
- Argo CD as the only application delivery mechanism.
- Fail-fast preflight so a missing prerequisite is caught before a GKE cluster is built.
- Idempotent re-runs: a second apply with no config change is a no-op, including restores.
- Placeholder-safe: the repo is publishable and runnable-in-plan today, with real values dropped in later.

**Non-Goals:**

- Creating Cloud SQL instances, Capella clusters, GCS buckets, or the backups themselves.
- Creating public DNS records — PPS owns that action.
- Backup *creation* on the production side; this repo only consumes backups.
- Migrating the existing 2024 module tree in place — the phase modules replace it.
- OpenSearch. It was in the old `persistent-deployments` module but is not in the DR plan's 8 phases; it is dropped unless PPS confirms otherwise (see Open Questions).

## Decisions

### D1. Phase-numbered modules mirroring the runbook

```
main.tf                     # phase orchestration + explicit depends_on chain
modules/00-preflight/       # prerequisite verification (read-only)
modules/10-gke-cluster/     # Phase 1: cluster create-or-adopt, namespaces, provider inputs
modules/20-platform/        # Phase 2: consul, vault, ldap, zeebe StatefulSets
modules/30-data-restore/    # Phase 3: cloudsql import, capella restore, consul/vault/ldap restore
modules/40-argocd/          # Phase 4: argocd helm install + backup restore
modules/50-secrets/         # Phase 5: vault config/rotation + ESO + ExternalSecrets sync gate
modules/60-app-services/    # Phase 6: app-of-apps, per-service version pinning, health gate
modules/70-ingress-dns/     # Phase 7: ingress reuse-or-create, TLS secrets, DNS outputs
modules/80-validation/      # Phase 8: graceful restart, health/OIDC/data checks, sign-off report
```

*Alternative considered*: keep the existing names. Rejected — the numbering is the cheapest way to keep the code, the runbook, and an incident-time operator in sync.

### D2. Cloud SQL restore via `gcloud sql import` wrapped in a gated resource

There is no Terraform resource for a Cloud SQL SQL-dump import. Options were (a) `google_sql_database_instance` clone/PITR, (b) `null_resource` running `gcloud sql import sql`, (c) a `restore-job` Kubernetes Job running `pg_restore` through the Auth Proxy.

Chosen: **(b)**, because the prerequisite explicitly says "DB backup files present and verified on GCS bucket" — a file-based import, not a snapshot clone. (a) requires a source instance in the same project/branch of history, which DR cannot assume. (c) adds a moving part inside the cluster for no benefit at this size.

Guard rails: the resource is gated on `postgres_restore_enabled`, triggered on the dump object's generation number (not `timestamp()`), and polls the returned operation to a terminal state.

### D3. Capella restore via Management API, `cbrestore` as fallback

The `couchbasecloud/couchbase-capella` provider covers cluster/bucket/backup objects but Restore is exercised most reliably through the Management API v4 restore endpoint. A `null_resource` submits the restore and polls the job; `cbrestore` against the backup archive stays available behind a flag for the case where the Capella backup lives outside Capella's own backup service.

### D4. Cluster create-or-adopt

Phase 1 must handle both "DR cluster does not exist" and the plan's own wording — "create GKE cluster (3 nodes) if not exists, else use as data source". Implemented with a `create_gke_cluster` boolean input driving `count` on the managed resource and the inverse `count` on the data source, with a single `locals` indirection so downstream modules read one set of attributes regardless of which branch produced them.

*Alternative considered*: always `tofu import`. Rejected — needs an out-of-band step at incident time.

### D4a. Kubernetes/Helm providers authenticate from a kubeconfig, not from unknown resource attributes

Terraform provider blocks cannot depend on values that are unknown at plan time, so configuring `kubernetes`/`helm` directly from a not-yet-created `google_container_cluster` attribute breaks the first plan. Prerequisite 6 states the iCrypto team already holds kubeconfig / GKE credentials for the DR cluster, so the providers read `config_path = var.kubeconfig_path` and Phase 1 refreshes that kubeconfig via `gcloud container clusters get-credentials`.

Consequence: when the DR cluster does **not** yet exist, the run is two-pass — `tofu apply -target=module.dr_cluster` first, then the full apply. When the cluster already exists (the adopt path, and every re-run), a single apply is enough. This is documented in the README rather than hidden.

### D5. Idempotency: content-hash triggers instead of `timestamp()`

Every remaining `null_resource` uses triggers derived from real inputs (file `filemd5`, GCS object generation, chart version, rendered values hash). `always_run = timestamp()` is banned. This is what makes "re-apply is a no-op" testable, which several specs depend on.

### D6. Ordering is explicit `depends_on` between phase modules, plus readiness gates

Terraform's implicit graph is not enough here because most cross-phase dependencies are runtime (pod Ready, ExternalSecret synced) rather than attribute references. Each phase module exposes a `completed` output that the next module's `depends_on` consumes, and each phase ends with a readiness gate that fails the apply rather than letting a later phase start against a half-built site.

### D7. Secrets flow: Vault is the source, ESO is the delivery, Terraform is neither

Terraform configures Vault (engines, policies, rotation) and installs ESO, but never reads an application secret value. This keeps secret material out of Terraform state. Vault's own root token/unseal keys arrive as `TF_VAR_*` and are marked sensitive.

### D8. Placeholder contract

`pps-dr.tfvars.example` holds every input with a `REPLACE_ME_<NAME>` string, a documented dummy CIDR, or a documented dummy identifier. Variables carry a `validation` block rejecting any value that still starts with `REPLACE_ME_`. The real `pps-dr.tfvars` is git-ignored. This makes today's repo pass `tofu validate` and `tofu plan -var-file=pps-dr.tfvars.example` up to the point of provider auth, while making an accidental apply with dummy values impossible.

### D9. DNS stays manual, but gated

Phase 7 emits `dns_change_request` (hostname → ingress IP) as an output. A separate `dns_resolution_check` verifies resolution internally and externally, and Phase 8 is applied as a targeted run after that check passes. This matches the plan's "[PPS action]" annotation without pretending the automation controls it.

## Risks / Trade-offs

- **Dummy values hide integration bugs** → Everything up to provider authentication is exercised via `tofu validate` and `plan -var-file=pps-dr.tfvars.example` in CI; real-value integration is a follow-up once PPS delivers, and the tasks list keeps that as an explicit final group.
- **Cloud SQL import is not transactional** → A failed import can leave a partially-restored database. Mitigation: import into a freshly-created database name per run where possible, verify with row-count/table-count checks before Phase 4, and document the "drop and re-import" recovery step.
- **Capella restore API shape may differ from expectation** → Isolated behind one module with a `cbrestore` fallback flag, so a change there does not ripple.
- **Adopting an existing ingress can adopt a stale one** → Phase 7 asserts the adopted ingress's hostnames match the configured set, and reports a mismatch rather than silently reusing the wrong object.
- **Argo CD backup may reference production destinations** → Phase 4 rewrites/validates Application destinations to the DR cluster and reports any it cannot resolve.
- **RTO risk from serial phases** → The plan's ordering is inherently serial. Within Phase 2 and Phase 3, independent components (LDAP/Zeebe; Capella/Consul) run in parallel to claw back time.
- **Dropping OpenSearch** → If DR needs it, it returns as a Phase 2 component; flagged as an open question rather than silently carried over.

## Migration Plan

1. Build the new phase modules alongside the existing tree on this branch.
2. Delete the superseded modules (`persistent-deployments` postgres/couchbase/opensearch scripts, `icrypto-services-deployment/*_deploy.sh`, `data-restore`, `gke-post-creation`, `ingress`, `restart_after_dns`, `openldap-setup`) once their behaviour is covered by a phase module.
3. Use a **new** GCS state prefix (e.g. `terraform/state-v2`) so the rewrite cannot corrupt the existing state object. The old state stays readable for rollback.
4. Dry run: `tofu validate` + `tofu plan -var-file=pps-dr.tfvars.example` with placeholders, confirming no unexpected create/destroy against prerequisites.
5. When PPS supplies real values: fill a real `pps-dr.tfvars`, run a non-production DR rehearsal end-to-end, capture the Phase 8 sign-off report.
6. Rollback: the old code remains on `main` with its own state prefix; reverting is a branch checkout plus a backend prefix switch.

## Open Questions

- Does the DR site still need **OpenSearch**? It exists in the old module set but appears in none of the 8 phases.
- Is Zeebe backed by Cloud SQL/Elasticsearch in DR, or self-contained?
- Which Capella restore path is authoritative — Capella's own backup service, or an operator-held `cb_backup-prod.tar.gz` archive restored with `cbrestore`?
- Is the Argo CD backup produced by `argocd admin export`, or by a third-party backup tool with a different restore procedure?
- Does the DR Cloud SQL instance already carry the partitioned IDM audit schema (prerequisite 1), or does the restore supply it?
- Confirm the DR hostname set: the 2024 README lists `truepolicy`, `oidc`, `sidas`, `admin`, `idm` under `pps.co.za` — is that still complete?
- Is the DR region still `europe-west4`, and which GCP project owns the DR site?
