## 1. Repo Scaffolding and Placeholder Contract

- [x] 1.1 Add `.gitignore` covering `pps-dr.tfvars`, `*.tfstate*`, `.terraform/`, `*.pem`, `*.key`, `*.crt`, `/tmp` artefacts
- [x] 1.2 Rewrite `backend.tf`: GCS backend with prefix `terraform/state-v2`, `required_version >= 1.9`, pinned `required_providers` for google, kubernetes, helm, vault, couchbasecloud/couchbase-capella, null, time, local, external
- [x] 1.3 Rewrite `provider.tf`: google provider driven by `project_id` / `region` / `credentials_file` variables (no hardcoded project or `/home/kusha/key.json`)
- [x] 1.4 Rewrite root `variables.tf` with snake_case names, types, descriptions, `sensitive = true` on all secret inputs, and a `validation` block on every environment-specific variable rejecting values starting with `REPLACE_ME_`
- [x] 1.5 Create `pps-dr.tfvars.example` with placeholder values for every variable; delete the committed `pps-dr.tfvars`
- [x] 1.6 Rewrite root `main.tf` as the phase orchestration: nine module blocks wired by `depends_on` on each module's `completed` output
- [x] 1.7 Add root `outputs.tf` exposing cluster name/endpoint, `dns_change_request`, and the Phase 8 sign-off report path
- [x] 1.8 Rewrite `README.md` for the new 8-phase flow, prerequisites, `TF_VAR_*` list, and the DNS pause between Phase 7 and Phase 8

## 2. Phase 0 — Preflight (`modules/00-preflight`)

- [x] 2.1 Verify Cloud SQL instance exists and is RUNNABLE via `data "google_sql_database_instance"` plus a state assertion
- [x] 2.2 Verify each configured GCS backup object exists and capture its generation number as a restore trigger
- [x] 2.3 Verify GCS credentials are usable from the DR environment (read-only bucket list scoped to the backup bucket)
- [x] 2.4 Verify Capella cluster reachability and health through the Management API
- [x] 2.5 Verify GKE cluster credentials/kubeconfig are usable (or that the caller can create the cluster)
- [x] 2.6 Emit a single `preflight_report` output and a `completed` output; fail the apply naming the specific failed prerequisite

## 3. Phase 1 — DR Cluster (`modules/10-gke-cluster`)

- [x] 3.1 Implement create-or-adopt: `create_gke_cluster` boolean driving `count` on `google_container_cluster` and the inverse on `data.google_container_cluster`, normalised through `locals`
- [x] 3.2 Port the hardened cluster config: private nodes, master authorized networks, `gcp_public_cidrs_access_enabled = false`, workload identity, pinned release channel
- [x] 3.3 Implement the node pool with configurable `dr_gke_node_count` (default 3), machine type, disk type/size, image type, node service account
- [x] 3.4 Wire the `kubernetes` and `helm` providers from cluster endpoint + CA + `google_client_config` token — implemented via a bastion kubeconfig instead (see design.md D4a); provider blocks can't read unknown attributes from a cluster that doesn't exist yet at plan time
- [x] 3.5 Create required namespaces (platform, argocd, external-secrets, application namespaces) idempotently
- [x] 3.6 Import the container registry / image pull credentials into the namespaces that need them — **superseded by change `dr-registry-credentials`**: ECR tokens expire after 12h, so this moved to `modules/15-registry-credentials` with an in-cluster scheduled refresh
- [x] 3.7 Emit cluster outputs and `completed`

## 4. Phase 2 — Stateful Platform (`modules/20-platform`)

- [x] 4.1 Deploy Consul StatefulSet via Helm with pinned chart version, configurable storage class and size
- [x] 4.2 Deploy Vault via Helm with Consul storage backend, depending on Consul readiness
- [x] 4.3 Initialise and unseal Vault; keep unseal keys and root token out of state and outputs
- [x] 4.4 Deploy OpenLDAP StatefulSet with persistent storage (port the working config from `modules/openldap-setup`)
- [x] 4.5 Deploy Zeebe StatefulSet with pinned chart version and persistent storage
- [x] 4.6 Add a per-component readiness gate that fails the apply naming the component and timeout
- [x] 4.7 Confirm no PostgreSQL, Couchbase or Couchbase Operator resource is declared in this module
- [x] 4.8 Emit `completed`

## 5. Phase 3 — Data Restore (`modules/30-data-restore`)

- [x] 5.1 Implement Cloud SQL import from GCS (`gcloud sql import sql`) gated on `postgres_restore_enabled`, triggered on the dump object generation, polling the operation to a terminal state
- [x] 5.2 Add post-restore PostgreSQL verification (table/row-count assertions) and fail on mismatch
- [x] 5.3 Implement Cloud SQL connectivity from inside the cluster (private services access or Auth Proxy) and a read-only connectivity check
- [x] 5.4 Implement the Capella restore via Management API, gated on `couchbase_restore_enabled`, polling the restore job
- [x] 5.5 Add the `cbrestore` fallback path behind a flag for archive-based restores
- [x] 5.6 Add post-restore Capella verification (per-bucket non-zero document count)
- [x] 5.7 Implement Consul KV restore after Consul is Ready, with a post-restore key-count check
- [x] 5.8 Implement Vault data restore after Vault is unsealed
- [x] 5.9 Implement OpenLDAP LDIF restore after LDAP is Ready, with a post-restore base-DN search check
- [x] 5.10 Replace all `always_run = timestamp()` triggers with content-hash / object-generation triggers so re-apply is a no-op
- [x] 5.11 Emit a `restore_report` output and `completed`

## 6. Phase 4 — Argo CD (`modules/40-argocd`)

- [x] 6.1 Install Argo CD via Helm with pinned chart version, namespace and values from variables
- [x] 6.2 Wait for `argocd-server`, `argocd-repo-server` and `argocd-application-controller` to report Ready
- [x] 6.3 Restore the Argo CD backup (AppProjects, Applications, repo credentials, cluster secrets); fail naming the archive path when it is unreadable
- [x] 6.4 Validate and normalise restored Application destinations to the DR cluster; report any that cannot be resolved
- [x] 6.5 Verify repository connection state for each configured repo
- [x] 6.6 Hold application auto-sync until Phase 5 completes
- [x] 6.7 Emit `completed`

## 7. Phase 5 — Secrets (`modules/50-secrets`)

- [x] 7.1 Configure Vault secret engines and auth methods for the DR site via the `vault` provider
- [x] 7.2 Apply the SSO service policies (port `all-read.hcl` and any others still required)
- [x] 7.3 Enable auto-rotation with rotation periods from variables; verify the config reads back — wiring in place via `rotated_credentials`; empty by default until PPS supplies the real credential set (tracked in 13.1/13.2)
- [x] 7.4 Install External Secrets Operator via Helm with a pinned chart version
- [x] 7.5 Create the ClusterSecretStore authenticating to in-cluster Vault (no committed token); assert status `Valid`
- [x] 7.6 Add the sync gate: wait for every ExternalSecret in the target namespaces to report `SecretSynced`, failing with a list of unsynced ones
- [x] 7.7 Confirm no application secret value reaches Terraform outputs or state
- [x] 7.8 Emit `completed`

## 8. Phase 6 — App Services (`modules/60-app-services`)

- [x] 8.1 Define the Argo CD app-of-apps Application driving the SSO service set
- [x] 8.2 Wire per-service version variables (oidc, oidc-admin, activity, cred, ext, mfa, notification, session, sidas, token, idm, policy-engine, nginx-api-gw) into the rendered Applications
- [x] 8.3 Enable auto-sync now that Phase 5 has completed
- [x] 8.4 Point service configuration at Cloud SQL and Capella endpoints; assert no in-cluster PostgreSQL/Couchbase endpoint is referenced
- [x] 8.5 Add the convergence gate: every Application `Synced` + `Healthy` and all workloads Ready, failing with a per-Application status list
- [x] 8.6 Delete the superseded `modules/icrypto-services-deployment/*_deploy.sh` scripts
- [x] 8.7 Emit `completed`

## 9. Phase 7 — Ingress and DNS (`modules/70-ingress-dns`)

- [x] 9.1 Implement ingress reuse-or-create for the internal, external and OPA ingress objects (port `int.yaml`, `ext.yaml`, `opa_ingress.yaml`) — internal + external implemented; standalone OPA ingress folded into the two (see Open Questions if PPS wants it split back out)
- [x] 9.2 Assert an adopted ingress's hostnames match the configured set; report a mismatch instead of reusing silently
- [x] 9.3 Create TLS Secrets from the operator-supplied `*.pps.co.za` certificate and key; fail naming any unreadable path
- [x] 9.4 Guarantee stable addresses across re-runs (no load balancer churn); verify by applying twice
- [x] 9.5 Emit the `dns_change_request` output mapping each hostname to its ingress IP
- [x] 9.6 Confirm the plan declares no public DNS record resource for a `pps.co.za` hostname
- [x] 9.7 Implement the `dns_resolution_check` verifying each hostname resolves internally and externally
- [x] 9.8 Emit `completed`

## 10. Phase 8 — Validation and Sign-Off (`modules/80-validation`)

- [x] 10.1 Implement the graceful restart of configured services, runnable as a targeted apply
- [x] 10.2 Wait for each rollout to complete; fail naming any workload that does not converge
- [x] 10.3 Implement service health-endpoint checks
- [x] 10.4 Implement the OIDC flow check (discovery document + token issuance for the validation client)
- [x] 10.5 Implement the Couchbase Capella session read/write check with test-document cleanup
- [x] 10.6 Implement the IDM PostgreSQL read/write check against Cloud SQL
- [x] 10.7 Implement the Argo CD health check (all Applications `Healthy` + `Synced`)
- [x] 10.8 Emit the machine-readable sign-off report on both success and failure; exit non-zero on any failure

## 11. Cleanup of Superseded Code

- [x] 11.1 Remove `modules/persistent-deployments/{postgresql,couchbase,opensearch_cluster}_installation.sh` and their resources
- [x] 11.2 Remove `modules/gke-post-creation`, `modules/data-restore`, `modules/ingress`, `modules/restart_after_dns`, `modules/openldap-setup` once covered by phase modules
- [x] 11.3 Remove `modules/gke-pps` after `modules/10-gke-cluster` supersedes it
- [x] 11.4 Grep the tree for remaining `always_run = "${timestamp()}"` and confirm none remain
- [x] 11.5 Grep the tree for hardcoded project ids, IPs, hostnames and credential paths; move each to a variable

## 12. Verification with Placeholders

- [x] 12.1 `tofu fmt -recursive` and `tofu validate` pass on the new tree — ran with `terraform` 1.9.0 (`tofu` not installed in the build environment; same HCL, same result)
- [x] 12.2 `tofu plan -var-file=pps-dr.tfvars.example` fails only on the placeholder validation rules, not on syntax or wiring errors — verified with dummy `TF_VAR_*` values and a local backend override (no GCP/GCS credentials available in the build environment); the plan progressed to resource evaluation and stopped only on `REPLACE_ME_*` validation errors
- [x] 12.3 Confirm the plan contains no create/update/destroy action against Cloud SQL, Capella, or the GCS backup bucket — both are read via data sources only (`modules/00-preflight/main.tf`, `modules/30-data-restore/main.tf`); no managed resource of either type exists in the tree
- [x] 12.4 Add a CI job running fmt + validate + plan-with-example on merge requests (`.gitlab-ci.yml`)

## 13. Real-Value Integration (blocked on PPS)

- [ ] 13.1 Replace placeholders with PPS-supplied values in a git-ignored `pps-dr.tfvars`
- [ ] 13.2 Resolve the design Open Questions with PPS (OpenSearch, Zeebe backing store, Capella restore path, Argo CD backup tool, IDM audit partitioning, hostname set, DR region/project)
- [ ] 13.3 Run a full DR rehearsal end-to-end and capture the Phase 8 sign-off report
- [ ] 13.4 Record measured RTO per phase and update the DR plan document
