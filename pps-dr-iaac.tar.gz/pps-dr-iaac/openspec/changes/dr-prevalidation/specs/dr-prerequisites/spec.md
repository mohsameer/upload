## MODIFIED Requirements

### Requirement: Preflight gate blocks the run when a prerequisite is missing
The automation SHALL run a preflight check before Phase 1 provisioning. The check MUST verify each prerequisite and MUST fail the `tofu apply` with a message naming the specific prerequisite that failed. Checks MUST be read-only. The check logic MUST be the shared prevalidation suite rather than a second implementation, and MUST additionally be runnable standalone before Terraform starts.

#### Scenario: Missing PostgreSQL backup object in GCS
- **WHEN** preflight runs and the configured PostgreSQL dump object does not exist in the GCS backup bucket
- **THEN** the apply fails before any GKE resource is created
- **AND** the error names the bucket and the missing object path

#### Scenario: Capella cluster unreachable from the DR environment
- **WHEN** preflight cannot authenticate to the Capella Management API or the target cluster is not in a healthy state
- **THEN** the apply fails before any GKE resource is created
- **AND** the error names the Capella cluster id and the API status returned

#### Scenario: All prerequisites satisfied
- **WHEN** preflight verifies Cloud SQL reachability, Capella health, presence of every configured backup object, GCS credential validity, and cluster credentials
- **THEN** preflight succeeds and Phase 1 proceeds

#### Scenario: Phase 0 and the standalone gate agree
- **WHEN** the standalone gate passes and `tofu apply` then runs Phase 0 against unchanged configuration
- **THEN** Phase 0 performs the same checks and also passes
