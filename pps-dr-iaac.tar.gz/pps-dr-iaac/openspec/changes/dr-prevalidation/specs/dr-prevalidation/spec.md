## ADDED Requirements

### Requirement: Prevalidation runs before Terraform
The prevalidation gate SHALL be executable without Terraform. It MUST NOT require `tofu init`, backend authentication, a state lock, or any Terraform evaluation, so that failures which occur before Terraform can start are still reported.

#### Scenario: Standalone execution with no Terraform state
- **WHEN** the operator runs the gate with a tfvars file and no `.terraform` directory or state present
- **THEN** every check executes and a report is produced
- **AND** no Terraform command is invoked

#### Scenario: Unwritable state backend is reported, not fatal to the gate
- **WHEN** the configured GCS state bucket is not writable by the supplied credentials
- **THEN** the gate reports that as a blocker naming the bucket
- **AND** the remaining checks still run so the operator sees every problem in one pass

### Requirement: One check suite behind both entry points
The gate SHALL be implemented once and invoked from both the standalone entry point and `modules/00-preflight`. The Terraform module MUST NOT carry a second, independent implementation of any check.

#### Scenario: Module delegates to the shared script
- **WHEN** `modules/00-preflight` runs during `tofu apply`
- **THEN** it executes the same shared check script used by the standalone entry point
- **AND** the set of checks performed is identical in both paths

#### Scenario: Adding a check covers both paths
- **WHEN** a new check is added to the shared script
- **THEN** it takes effect in both the standalone run and the Phase 0 gate with no further change

### Requirement: Every check is read-only
The gate SHALL only read state. It MUST NOT create, modify or destroy any cloud resource, Kubernetes object, or file outside its own report output.

#### Scenario: No mutation during a full run
- **WHEN** the gate runs against a fully configured environment
- **THEN** no Cloud SQL, Capella, GCS, GKE or Kubernetes object is created, modified or deleted
- **AND** the only file written is the prevalidation report

### Requirement: Results are phase-tagged and severity-tiered
Each check SHALL record the phase it protects and a severity of `blocker`, `warning`, or `skipped`. A `blocker` MUST fail the gate; a `warning` MUST NOT. A check whose feature is disabled by configuration MUST be recorded as `skipped` rather than passing or failing silently.

#### Scenario: Failure names the phase it protects
- **WHEN** a check fails
- **THEN** the output states which phase that failure would have broken

#### Scenario: Disabled feature is skipped, not failed
- **WHEN** `couchbase_use_cbrestore` is false and `cbbackupmgr` is absent from the bastion
- **THEN** that check is recorded as `skipped` with the reason
- **AND** the gate does not fail on it

#### Scenario: Warning does not block
- **WHEN** only `warning` severity checks fail
- **THEN** the gate exits zero and the warnings are listed

#### Scenario: Blocker fails the gate
- **WHEN** any `blocker` check fails
- **THEN** the gate exits non-zero listing every blocker

### Requirement: The six documented prerequisites are verified
The gate SHALL verify each of the six DR prerequisites: IDM PostgreSQL partitioning status, Couchbase Capella cluster reachable and healthy, Cloud SQL instance provisioned and serving, every configured backup object present and non-empty in GCS, GCS credentials usable from the DR environment, and DR cluster credentials usable.

#### Scenario: Cloud SQL not serving
- **WHEN** the configured Cloud SQL instance is not in a serving state
- **THEN** the gate reports a blocker naming the instance and its actual state

#### Scenario: Backup object missing or empty
- **WHEN** a configured backup object is absent, or present at zero bytes
- **THEN** the gate reports a blocker naming the bucket and object path

#### Scenario: Capella cluster unhealthy
- **WHEN** the Capella Management API reports the cluster is not healthy, or is unreachable
- **THEN** the gate reports a blocker naming the cluster id and the API status

#### Scenario: Cluster credentials unusable and creation disabled
- **WHEN** the DR cluster is not describable and `create_gke_cluster` is false
- **THEN** the gate reports a blocker

### Requirement: Silent placeholder values are detected
The gate SHALL detect configuration values that pass Terraform variable validation but are still example or dummy data. This MUST cover at minimum: `REPLACE_ME_*` values, the documented dummy CIDRs and TEST-NET bastion ranges, all-zero UUIDs, dummy connection strings and bucket names, `0.0.0-dummy` service versions, dummy backup object paths, and an empty `backend_services` map.

#### Scenario: Empty backend_services is caught
- **WHEN** `backend_services` is unset or empty
- **THEN** the gate reports a blocker explaining that Phase 7 would render ingress backends named `REPLACE-ME-<key>-service`

#### Scenario: Dummy service versions are caught
- **WHEN** any entry in `service_versions` is a dummy version
- **THEN** the gate reports a blocker listing each offending service

#### Scenario: TEST-NET bastion CIDR is caught
- **WHEN** `dr_gke_master_authorized_networks` still contains a documented example range
- **THEN** the gate reports a blocker

### Requirement: Per-phase bastion tooling is verified
The gate SHALL verify every external binary the phase scripts depend on, and MUST report which phase each missing binary would break. Conditionally-required binaries MUST only be required when their feature is enabled.

#### Scenario: Missing Phase 8 tooling
- **WHEN** `psql` or `cbc` is absent from the bastion
- **THEN** the gate reports it, naming Phase 8 as the phase that would fail

#### Scenario: cbbackupmgr required only when selected
- **WHEN** `couchbase_use_cbrestore` is true and `cbbackupmgr` is absent
- **THEN** the gate reports a blocker naming Phase 3

### Requirement: Configuration correctness is verified beyond presence
The gate SHALL verify the configuration facts that later phases depend on, not merely that values are set. This MUST include: the Cloud SQL instance exposes a PRIVATE IP; the Cloud SQL service account can read the dump object; the registry credentials are valid; the TLS certificate and key are readable and form a matching pair; the bastion's egress IP falls inside a configured master authorized network; the pinned Helm chart versions resolve; the configured Capella buckets exist; and the Argo CD backup archive is readable and parseable.

#### Scenario: Cloud SQL has no private IP
- **WHEN** the Cloud SQL instance exposes no PRIVATE IP address
- **THEN** the gate reports a blocker naming Phase 3, because the in-cluster verify Job cannot reach it

#### Scenario: Cloud SQL service account cannot read the dump
- **WHEN** the Cloud SQL instance's service account lacks read access to the configured dump object
- **THEN** the gate reports a blocker naming the service account and the object

#### Scenario: TLS certificate and key do not match
- **WHEN** the configured certificate and private key are not a matching pair
- **THEN** the gate reports a blocker naming Phase 7

#### Scenario: Bastion is not in the authorized networks
- **WHEN** the bastion's egress IP is not covered by any configured master authorized network
- **THEN** the gate reports a blocker warning that the cluster would build and then be unreachable

#### Scenario: Pinned chart version does not resolve
- **WHEN** a configured Helm chart version cannot be resolved from its repository
- **THEN** the gate reports a blocker naming the chart, version and Phase 2

#### Scenario: Argo CD backup is unparseable
- **WHEN** the configured Argo CD backup archive cannot be read or does not parse
- **THEN** the gate reports a blocker naming Phase 4

### Requirement: A machine-readable report is always produced
The gate SHALL write a report listing every check with its id, phase, severity, result and detail, on both success and failure, consistent with the existing preflight and Phase 8 sign-off reports.

#### Scenario: Report written on success
- **WHEN** every check passes
- **THEN** a report is written recording each check and an overall result of pass

#### Scenario: Report written on failure
- **WHEN** one or more blockers fail
- **THEN** the report still records every check and an overall result of fail
- **AND** the gate exits non-zero

### Requirement: The gate is the documented first step of a DR run
The runbook SHALL name the standalone gate as the first action of a DR run, ahead of `tofu init`, replacing the manual placeholder grep currently documented.

#### Scenario: Runbook ordering
- **WHEN** an operator follows the documented DR runbook
- **THEN** the prevalidation gate is the first command, before any Terraform command
