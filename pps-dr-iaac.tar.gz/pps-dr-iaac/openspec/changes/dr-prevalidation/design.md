## Context

`modules/00-preflight` already verifies the six documented DR prerequisites and writes `.dr-run/preflight-report.json`. It works, and it is correctly read-only. Two things limit it under real conditions.

First, it is a Terraform module. Reaching it requires `tofu init`, GCS backend authentication and a state lock. Every failure that happens *before* that point — unwritable state bucket, held lock, expired GCP credentials, a binary missing from the bastion — is invisible to it. During an incident that is the wrong order: the cheapest checks are gated behind the most fragile setup step.

Second, it verifies presence rather than usability, and only for the six named prerequisites. An audit of the phase scripts found nine failure modes that reliably break a run and are not covered, each surfacing only once real infrastructure exists:

| Not checked today | Surfaces at | Cost when it fires |
|---|---|---|
| Silent placeholder values | varies | Site builds wrong; `backend_services={}` yields ingress backends named `REPLACE-ME-<key>-service` |
| Cloud SQL has no PRIVATE IP | Phase 3 | Cluster + platform already built |
| Cloud SQL SA cannot read the dump | Phase 3 | Same; `cloudsql_restore.sh` warns but never verifies |
| ECR credentials invalid | Phase 1 | Bootstrap Job fails |
| TLS cert/key unreadable or mismatched | Phase 7 | Everything before it already built |
| Bastion IP not in authorized networks | Phase 1+ | Cluster builds, operator locked out of its own control plane |
| Pinned Helm chart version unresolvable | Phase 2 | — |
| Capella buckets absent | Phase 3 | — |
| Argo CD backup unparseable | Phase 4 | — |

The tooling check is also short: it verifies `gcloud kubectl helm curl jq`, while the scripts additionally call `psql` (Phases 3, 8), `cbc` (Phase 8), `cbbackupmgr` (Phase 3, conditional), `openssl` (Phase 7), `getent` (Phases 7, 8), plus `tar`/`gunzip` for archive handling.

Constraint that shapes everything below: this runs during an incident. The gate is worth building only if it is fast, read-only, and gives one complete list of problems rather than failing on the first.

## Goals / Non-Goals

**Goals:**

- Catch, before Terraform starts, anything that would fail the run later.
- One check implementation, reachable both standalone and as the Phase 0 gate.
- Report every problem in a single pass, not one per run.
- Say which phase each failure would have broken, so the operator can judge urgency.
- Stay strictly read-only, so the gate is safe to run at any time, including against a live DR site.

**Non-Goals:**

- Fixing anything. The gate reports; the operator or PPS remediates.
- Replacing Phase 8 validation. That verifies a *built* site; this verifies the *inputs*.
- Replacing Terraform variable validation. The `REPLACE_ME_*` rules stay — they are the last line of defence when someone skips the gate.
- Verifying anything that genuinely cannot be known before the run (whether the Postgres dump restores cleanly, whether services converge).

## Decisions

### P1. One script, two entry points

```
prevalidate.sh                     # thin standalone entry point at repo root
prevalidate/
  checks.sh                        # the whole suite - single source of truth
  lib.sh                           # record/report/severity helpers
modules/00-preflight/
  preflight.sh                     # thin wrapper -> ../../prevalidate/checks.sh
```

The alternative — leaving `00-preflight` as-is and adding a separate standalone gate — was rejected because two implementations of "is this environment ready" will drift, and the one that drifts is always the one not exercised in CI.

This is the same pattern already used in `modules/15-registry-credentials`, where one `refresh.sh` is shared by the bootstrap Job and the CronJob. Consistency with an existing decision in this repo is worth more than a marginally simpler layout.

### P2. Parse tfvars directly, do not evaluate Terraform

The standalone path reads `pps-dr.tfvars` with a small HCL-subset parser (scalars, lists, simple maps and the `dr_gke_master_authorized_networks` object list — everything this file actually contains). Sensitive values continue to come from `TF_VAR_*`.

*Alternatives considered*: `tofu console`/`tofu output` (defeats the purpose — needs init and backend); requiring JSON tfvars (changes the operator-facing format for the benefit of the tool). A parser limited to the shapes the file really uses is a bounded amount of code and keeps `pps-dr.tfvars` the single place values live.

Risk accepted: the parser can drift from HCL if the tfvars format grows. Mitigated by keeping the supported shapes narrow and failing loudly on anything unparseable rather than silently skipping a check.

### P3. Severity: blocker / warning / skipped

Three states, because two is not enough:

- `blocker` — will fail the run. Exits non-zero.
- `warning` — suspicious but survivable (e.g. a Capella bucket present but empty, which is fine on a first-ever DR build).
- `skipped` — the feature is disabled, so the check does not apply. Recorded explicitly, because a silently absent check is indistinguishable from a passing one.

`skipped` matters most for conditional tooling: `cbbackupmgr` is only needed when `couchbase_use_cbrestore` is true. Failing on it unconditionally would train operators to ignore the gate, which is the failure mode that makes gates worthless.

### P4. Never stop at the first failure

Every check runs, then the gate reports all of them together. Stopping early would mean one fix-and-rerun cycle per problem, and each cycle is minutes of an incident. This mirrors the existing `preflight.sh` and Phase 8 `validate.sh`, both of which already accumulate results and report at the end.

Consequence: checks must be independent, and a check whose precondition failed records that dependency rather than crashing.

### P5. Phase tagging

Each check carries the phase it protects. A failure reads "would have failed at Phase 7", which tells the operator both how far the run would have got and how much rework a fix costs. This is the difference between a check list and a triage tool.

### P6. Read-only, enforced by construction

Only read verbs: `gcloud ... describe/list`, `gcloud storage objects describe`, `curl` GETs against the Capella API, `helm show chart`, `openssl` on local files, `kubectl auth can-i`/`get`. No `apply`, `create`, `patch` or `delete` anywhere.

The Cloud SQL service-account grant check uses the IAM policy on the object rather than attempting a read as that identity, since the gate cannot impersonate the instance's service account.

### P7. Report shape matches the existing two

Same envelope as `preflight-report.json` and `sign-off-report.json` — `timestamp`, overall `result`, and a `checks` array — extended with `phase` and `severity` per entry. An operator who has read one report can read all three.

## Risks / Trade-offs

- **The tfvars parser is a bespoke HCL subset** → Kept narrow, and unparseable input is a loud failure rather than a skipped check. If the format ever outgrows it, the fallback is to require `-var-file` in JSON form for the gate only.
- **Gate duplicates some Phase 8 checks conceptually** → Different subject: Phase 8 validates a built site, this validates inputs. Overlap is limited to connectivity, and the duplication is cheap.
- **A thorough gate takes longer to run than the current preflight** → Bounded by the slowest external call (Capella API, Helm repo). Still seconds, against phases that take tens of minutes. Network calls are the reason for a `--offline` mode that runs only local checks.
- **Operators may skip the gate** → Terraform variable validation and the in-band Phase 0 gate both remain, so skipping it degrades to today's behaviour rather than removing protection.
- **False blockers erode trust** → The `warning` and `skipped` tiers exist specifically to keep `blocker` meaning "this will definitely fail". Anything uncertain is a warning.

## Migration Plan

1. Build `prevalidate/checks.sh` covering everything the current `preflight.sh` does, and confirm parity.
2. Add the nine new checks and the extended tooling list.
3. Replace `modules/00-preflight/preflight.sh` with a wrapper delegating to the shared script; its inputs and `completed` output are unchanged, so no other module is affected.
4. Update `DR-EXECUTION-PLAN.md` Stage B to call the gate instead of the manual grep, and make it step 1 of Stage D.
5. Add a CI job running `bash -n` and a `--self-test` pass over the check registry.

Rollback: the change is additive apart from step 3; reverting the wrapper restores the previous `preflight.sh` from git.

## Open Questions

- Should the gate check that the DR bastion's clock is in sync? A skewed clock breaks ECR token validity windows and TLS verification, and it is cheap to check — but it has never been observed as a problem here.
- Is there a maximum acceptable runtime for the gate during an incident, beyond which network checks should default off?
- Should `--offline` (local-only checks) be the default, with network checks opt-in, or the reverse? Current assumption: network checks on by default, since they catch the expensive failures.
