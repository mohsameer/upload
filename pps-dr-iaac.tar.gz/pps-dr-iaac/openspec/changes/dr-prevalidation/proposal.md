## Why

A DR run happens during an incident, when time is the scarcest thing available. The existing `modules/00-preflight` verifies the six documented prerequisites, but it has two structural problems that only show up under real conditions.

**It runs too late.** Preflight is a Terraform module, so reaching it requires `tofu init`, GCS backend authentication, and a state lock. Anything that breaks before that point — an unwritable state bucket, a held lock, expired GCP credentials, a missing binary — never reaches the checks at all. A prevalidation gate has to run *before* Terraform is involved.

**It checks too little.** Nine failure modes that reliably break a real run are not covered, and every one of them is discovered deep into the run, after real infrastructure exists:

- Silent placeholder values that pass variable validation (the documented `backend_services = {}` case renders ingress backends literally named `REPLACE-ME-<key>-service`; nothing catches it). Today this is a manual `grep` in `DR-EXECUTION-PLAN.md`.
- Cloud SQL instance without a PRIVATE IP — Phase 3's verify Job hard-fails.
- Cloud SQL service account lacking read on the dump object — Phase 3's import fails. `cloudsql_restore.sh` prints a warning about this but never verifies it.
- Invalid ECR credentials — Phase 1's bootstrap Job fails.
- Unreadable or mismatched TLS cert/key pair — Phase 7.
- The bastion's egress IP missing from `dr_gke_master_authorized_networks` — the cluster builds, then the operator is locked out of its control plane.
- Pinned Helm chart versions that do not resolve — Phase 2.
- Capella buckets that do not exist — Phase 3.
- An Argo CD backup archive that does not parse — Phase 4.

The per-phase tooling check is also incomplete: it verifies 5 binaries, while the run actually depends on `psql`, `cbc`, `cbbackupmgr` (conditionally), `openssl`, `getent`, `tar` and `gunzip` across Phases 3, 7 and 8.

The point of this change is to convert a 40-minute mid-incident failure into a 30-second one.

## What Changes

- Add a **prevalidation gate**: one check suite, exposed through two entry points.
  - **Standalone**: `./prevalidate.sh --tfvars pps-dr.tfvars`, runnable before `tofu init`. No Terraform state, no backend, no cloud mutation.
  - **In-band**: `modules/00-preflight` invokes the same script as the Phase 0 gate, so the checks cannot drift between the two paths. This mirrors the existing pattern in `modules/15-registry-credentials`, where one `refresh.sh` serves both the bootstrap Job and the CronJob.
- Parse `pps-dr.tfvars` directly in the standalone path, so the gate needs no Terraform evaluation.
- Add **silent-placeholder detection** as a first-class check, replacing the manual grep documented in `DR-EXECUTION-PLAN.md`.
- Extend the tooling check to the full per-phase binary set, with conditional requirements (`cbbackupmgr` only when `couchbase_use_cbrestore` is true).
- Add the nine uncovered checks listed above.
- Tag every check with the **phase it protects** and a **severity** (`blocker`, `warning`, `skipped`), so a failure reports which phase it would have broken.
- Emit a machine-readable prevalidation report, consistent with the existing preflight and Phase 8 sign-off reports.
- **BREAKING (internal)**: `modules/00-preflight/preflight.sh` is replaced by a thin wrapper around the shared script. Its check ids change, so anything parsing `preflight-report.json` by id needs updating; nothing in the repo does today.

## Capabilities

### New Capabilities
- `dr-prevalidation`: A read-only gate that verifies every prerequisite, configuration value and bastion dependency the DR run depends on, before any infrastructure is touched — runnable standalone ahead of Terraform and reused in-band as the Phase 0 gate.

### Modified Capabilities
- `dr-prerequisites`: The prerequisite verification requirements gain a standalone execution path and a phase-tagged, severity-tiered result model. The existing scenarios still hold; what changes is that verification is no longer only reachable through `tofu apply`.

## Impact

- **New**: `prevalidate/` (shared check library + entry point), `prevalidate.sh` at repo root.
- **Modified**: `modules/00-preflight` (delegates to the shared script), `README.md`, `CLAUDE.md`, `DR-EXECUTION-PLAN.md` (Stage B gains a real command in place of the manual grep), `.gitlab-ci.yml` (lint the new script).
- **No new infrastructure**: every check is read-only. The gate must never create, modify or destroy anything, and must not require Terraform state.
- **Operational**: becomes the documented first step of a DR run, ahead of `tofu init`.
- **Dependencies**: no new provider or binary requirements beyond what the phases already use; the gate reports missing binaries rather than needing new ones itself.
