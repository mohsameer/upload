## 1. Shared Library (`prevalidate/lib.sh`)

- [ ] 1.1 Implement `record <id> <phase> <severity> <status> <detail>` accumulating results, where severity is `blocker`/`warning`/`skipped`
- [ ] 1.2 Implement `write_report` emitting the same envelope as `preflight-report.json` and `sign-off-report.json`, extended with `phase` and `severity`
- [ ] 1.3 Implement the summary printer: group by severity, blockers first, each line naming the phase it protects
- [ ] 1.4 Implement `require_bin <bin> <phase> <severity>` and a conditional variant for feature-gated tools
- [ ] 1.5 Exit non-zero only when a `blocker` failed; `warning` must not fail the gate

## 2. tfvars Parser (`prevalidate/lib.sh`)

- [ ] 2.1 Parse scalar assignments (`key = "value"`, numbers, booleans) from `pps-dr.tfvars`
- [ ] 2.2 Parse single-line and multi-line list values (`ldap_backup_objects`, `capella_buckets`, `dr_gke_node_locations`)
- [ ] 2.3 Parse simple map values (`service_versions`, `dr_hostnames`, `platform_chart_versions`, `backend_services`, `health_check_endpoints`)
- [ ] 2.4 Parse the `dr_gke_master_authorized_networks` object list into `cidr_block` values
- [ ] 2.5 Fail loudly on an unparseable construct rather than silently skipping the checks that depend on it
- [ ] 2.6 Strip comments and tolerate blank lines and arbitrary whitespace

## 3. Prerequisite Checks (parity with today's `preflight.sh`)

- [ ] 3.1 Prereq 3: Cloud SQL instance exists and is RUNNABLE
- [ ] 3.2 Prereq 5: GCS credentials can list the backup bucket
- [ ] 3.3 Prereq 4: every configured backup object exists and is non-empty
- [ ] 3.4 Prereq 2: Capella cluster reachable and `currentState` healthy
- [ ] 3.5 Prereq 6: DR cluster describable, or absent with `create_gke_cluster=true`
- [ ] 3.6 Prereq 1: record IDM partitioning as verified downstream in Phase 3
- [ ] 3.7 GCP service-account activation from `gcp_credentials_file`
- [ ] 3.8 Confirm parity: every check id in the current `preflight.sh` has an equivalent

## 4. Placeholder Detection

- [ ] 4.1 Detect any `REPLACE_ME_*` value (defence in depth; Terraform also rejects these)
- [ ] 4.2 Detect the documented dummy CIDRs and TEST-NET (`192.0.2.x`) bastion ranges
- [ ] 4.3 Detect all-zero UUIDs in `capella_project_id` / `capella_cluster_id`
- [ ] 4.4 Detect dummy Capella connection string and bucket names
- [ ] 4.5 Detect `0.0.0-dummy` entries in `service_versions`, listing each offending service
- [ ] 4.6 Detect `backups/dummy/` backup object paths
- [ ] 4.7 Detect `.invalid` hostnames (`argocd_hostname`) and `dummy-` prefixed `post_restart_services`
- [ ] 4.8 Detect empty or unset `backend_services`, explaining the `REPLACE-ME-<key>-service` ingress consequence
- [ ] 4.9 Confirm this fully replaces the manual grep documented in `DR-EXECUTION-PLAN.md`

## 5. Per-Phase Tooling Checks

- [ ] 5.1 Always required: `gcloud`, `kubectl`, `helm`, `curl`, `jq`, `tar`, `base64`
- [ ] 5.2 Phase 3 + Phase 8: `psql`
- [ ] 5.3 Phase 8: `cbc`
- [ ] 5.4 Phase 7: `openssl`
- [ ] 5.5 Phase 7 + Phase 8: `getent`
- [ ] 5.6 Phase 3, only when `couchbase_use_cbrestore` is true: `cbbackupmgr`; otherwise record `skipped`
- [ ] 5.7 Report the phase each missing binary would break

## 6. Configuration Correctness Checks

- [ ] 6.1 Cloud SQL exposes a PRIVATE IP (Phase 3 verify Job requirement)
- [ ] 6.2 Cloud SQL service account can read the dump object, via the object/bucket IAM policy
- [ ] 6.3 Registry credentials valid: exchange an ECR token when `aws` is present, else record `skipped` noting the bootstrap Job is the first real test
- [ ] 6.4 TLS certificate and key readable, and a matching pair (`openssl` modulus comparison)
- [ ] 6.5 Bastion egress IP falls inside a configured `dr_gke_master_authorized_networks` CIDR
- [ ] 6.6 Pinned Helm chart versions resolve (`helm show chart` per configured chart/version)
- [ ] 6.7 Configured Capella buckets exist; present-but-empty is a `warning`, absent is a `blocker`
- [ ] 6.8 Argo CD backup object readable and parseable for its declared format
- [ ] 6.9 GCS state backend bucket/prefix writable by the supplied credentials

## 7. Entry Points

- [ ] 7.1 Create `prevalidate/checks.sh` as the single check suite
- [ ] 7.2 Create root `prevalidate.sh` with `--tfvars`, `--report`, `--offline` and `--help`
- [ ] 7.3 `--offline` runs only local checks (tooling, placeholders, TLS pair), skipping network calls
- [ ] 7.4 Replace `modules/00-preflight/preflight.sh` with a wrapper delegating to `prevalidate/checks.sh`
- [ ] 7.5 Keep `modules/00-preflight` inputs and its `completed` output unchanged so no other module is affected
- [ ] 7.6 Update the module's `filemd5` triggers to hash the shared script, so editing a check re-runs Phase 0

## 8. Verification

- [ ] 8.1 `bash -n` clean on every new and modified script
- [ ] 8.2 Parser unit-tested against `pps-dr.tfvars.example` — every variable it declares is extracted correctly
- [ ] 8.3 Full run against `pps-dr.tfvars.example` reports blockers for the known dummy values, and nothing crashes
- [ ] 8.4 `--offline` run needs no network and no cloud credentials
- [ ] 8.5 Exercise severity handling with stubs: blocker fails, warning does not, skipped is recorded
- [ ] 8.6 Confirm no check performs a mutating operation (grep for `apply`/`create`/`patch`/`delete` in the suite)
- [ ] 8.7 `terraform fmt -recursive` and `terraform validate` still pass
- [ ] 8.8 Report parses as valid JSON on both success and failure paths

## 9. Documentation

- [ ] 9.1 `README.md`: prevalidation as the documented first step of a DR run
- [ ] 9.2 `CLAUDE.md`: architecture note on the shared-script pattern and the `prevalidate/` layout
- [ ] 9.3 `DR-EXECUTION-PLAN.md` Stage B: replace the manual grep with the gate command
- [ ] 9.4 `DR-EXECUTION-PLAN.md` Stage D: make the gate step D0, before `tofu init`
- [ ] 9.5 Document the severity tiers and how to read the report
- [ ] 9.6 `.gitlab-ci.yml`: lint the new scripts and run `--offline` against the example tfvars

## 10. Live Verification (blocked on real values / a cluster)

- [ ] 10.1 Run the gate against real PPS values and confirm every check resolves
- [ ] 10.2 Confirm Phase 0 and the standalone gate agree on the same configuration
- [ ] 10.3 Confirm the Cloud SQL SA grant check matches reality on the real instance
- [ ] 10.4 Confirm the bastion-IP check correctly identifies the real DR bastion
- [ ] 10.5 Measure gate runtime and record it in the DR plan
