## Why

The first real DR rehearsal rebuilds the DR GKE cluster from scratch on the existing `pps-dr` network and restores the
**production backups of 2026-09-11** (`gs://pps-k8s-prod-backups/11thseptember2026/`). Preparing it against the live
DR project and the real backup set exposed defects that would break or silently corrupt the run:

- **Phase 1 would not reproduce the live cluster.** `modules/10-gke-cluster` misses settings the running
  `dr-icrypto-gke-cluster` depends on: legacy datapath, resource labels, narrow node OAuth scopes, shielded-node
  integrity monitoring, managed Prometheus, workload logging, and the stage-bastion master authorized network. It also
  cannot adopt the subnet's existing named secondary ranges.
- **Phase 3 cannot restore Postgres while `sqladmin.googleapis.com` is unreachable** from the DR bastion. The only path
  is `gcloud sql import sql`, which needs that API, the instance name, and IAM grants that are not in place yet.
  The prod dump is also a 252 GB plain SQL file from `pg_dump` 17 (it contains the `\restrict` meta-command), which needs
  psql ≥ 17.6. The verify Job pins `postgres:16-alpine`.
- **Phase 3 cannot restore the prod Couchbase backup.** The set has two shapes. `icrypto_persistent_ha` is a
  `cbbackupmgr` 7.6.3 repository tarball with no archive root. `oidcv2` is a `cbexport` JSON **list** without document
  keys (the 2026-09-11 `cbbackupmgr` run failed with HTTP 401 on query metadata). The repo supports only the Capella
  Restore API or one `cbbackupmgr` archive, and the `cbbackupmgr` path still demands a Capella API token.
- **Four drill defects (B1–B4 in `DR-DRILL-QA-TO-DR.md`)**: `backend_services` never reaches Phase 7, the Argo CD
  restore applies one file of N, the LDAP restore uses the wrong `slapd.d` path and DB numbers, and Phase 6 renders a git
  app-of-apps that PPS does not use. PPS delivers every service as a Helm OCI chart from ECR.

## What Changes

- **Phase 1 (`modules/10-gke-cluster`)**: new variables to reproduce the live cluster faithfully. They cover the
  datapath provider, resource labels, node OAuth scopes, shielded/integrity settings, workload metadata mode, logging
  components, managed Prometheus, max pods per node, and optional named secondary ranges (adopt-by-name), all wired
  from root. The defaults keep today's behaviour.
- **Phase 3 Postgres (`modules/30-data-restore`)**: `postgres_restore_method = "psql_pod" | "gcloud_sql_import"`.
  - `psql_pod` (default) runs an in-cluster Job. One container streams the dump from GCS through a FIFO and another
    loads it with psql 17, with no local disk and no Cloud SQL Admin API.
  - `gcloud_sql_import` is **disabled until the sqladmin egress issue is fixed**. It needs an explicit
    `allow_gcloud_sql_import = true`.
  - Every `google_sql_database_instance` data source becomes conditional on the method.
  - New `cloudsql_private_ip` input for the psql path.
  - Opt-in `postgres_recreate_database`.
- **Phase 3 Couchbase**: the per-bucket method map `couchbase_restore_methods`
  (`capella_api` | `cbbackupmgr` | `cbimport`) replaces `couchbase_use_cbrestore`, with per-bucket backup objects.
  - `cbbackupmgr` handles a repository tarball with or without an archive root.
  - `cbimport` runs in-cluster. It converts a JSON list to lines and derives Janssen keys from `dn`, a rule
    validated 84,902 of 84,903 against QA (the only exception is the root entry `o=jans` → `_`).
  - New optional GSI index replay from the prod index-definition file.
  - `capella_verify.sh` falls back to the cluster's own management API when no Capella API token is set.
- **Phase 3 LDAP**: configurable `slapd.d` path and pod name, with Bitnami defaults. DB numbers are config `-n 0`,
  data `-n 2`, secauth `-n 3`.
- **Phase 4**: the Argo CD restore applies every manifest in the archive.
- **Phase 6**: the git app-of-apps becomes optional (`app_of_apps_enabled`, default `false`). Convergence runs on the
  Applications restored in Phase 4, and `service_versions` pins their `targetRevision` by Application name.
- **Phase 7**: `backend_services` is declared at root and passed to the module.
- **Prevalidate**: checks follow the new switches. The Cloud SQL API checks run only for `gcloud_sql_import`.
  `psql_pod` gets a private-IP reachability probe. Tooling and backup-object checks follow the Couchbase per-bucket
  methods.
- **BREAKING (inputs)**: `couchbase_use_cbrestore` and `couchbase_backup_object` are removed in favour of
  `couchbase_restore_methods` / `couchbase_backup_objects`. `cloudsql_instance_name` may be empty on the `psql_pod`
  path.

## Capabilities

### New Capabilities
- `dr-gke-cluster`: Phase 1 reproduces the captured live DR cluster on the existing network.
- `dr-data-restore`: Phase 3 restores Postgres, Couchbase, LDAP and Consul from the prod backup set through selectable,
  network-aware methods.
- `dr-app-delivery`: Phases 4, 6 and 7 restore and converge the real Argo CD Applications and route ingress to real
  services.

### Modified Capabilities (delta added as new requirements; base spec not yet archived)
- `dr-prevalidation`: checks follow `postgres_restore_method` and `couchbase_restore_methods`.

## Impact

- Phase map: Phase 0 (prevalidate), 1, 3, 4, 6, 7. Phases 2, 5 and 8 are untouched apart from root wiring.
- Prerequisites: #3 (Cloud SQL) is consumed by private IP on the default path, so its instance name is optional.
  #4/#5 (backups, GCS credentials) assume a DR-readable bucket. The DR SA cannot read the prod bucket, so the prod
  objects are staged into a DR-project bucket first (operator step, documented, not automated here).
- No resource in this change creates or destroys Cloud SQL, Capella, the VPC, subnet, NAT or peerings.
