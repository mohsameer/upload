## Context

Target is the rebuild of `dr-icrypto-gke-cluster` (project `pps-qa-29102018`, `europe-west4`) on the existing `pps-dr`
VPC, followed by a restore of the prod backup set `gs://pps-k8s-prod-backups/11thseptember2026/`. Everything below was
measured read-only on 2026-10-05. The captured config is in `.dr-run/config-backup-20261005/` (git-ignored) and on
the DR bastion at `~/dr-config-backup-20261005/`.

Measured facts that drive the decisions:

| Fact | Source |
|---|---|
| Live cluster: `LEGACY_DATAPATH`, labels `application=sso,owner=devops_team_sso`, node scopes = GKE default set (not `cloud-platform`), shielded integrity monitoring, `GKE_METADATA`, logging `SYSTEM_COMPONENTS+WORKLOADS`, managed Prometheus on, nodes only in `europe-west4-a`, 110 pods/node | `gke-cluster.yaml` |
| Authorized networks: `34.91.152.93/32` jumpbox, `10.200.16.56/32` Jumpbox01, `10.112.200.0/24`, `10.200.100.77/32` stage-bastion; private endpoint enforcement on | same |
| Subnet `pps-dr` secondary ranges `gke-dr-icrypto-gke-cluster-{pods,services}-c7149c78` (10.108.0.0/14, 10.112.0.0/20), GKE-managed | `subnets.yaml` |
| Cloud NAT `cr-1/external` covers ALL_SUBNETWORKS_ALL_IP_RANGES, so private nodes can pull from Docker Hub | `routers.yaml` |
| `sqladmin.googleapis.com` unreachable from the bastion; a `gcloud sql instances list` in an in-cluster pod also hung | drill doc D0, live 2026-10-05 |
| Cloud SQL private IP `10.221.111.2` (PSA peering ACTIVE) | drill doc |
| DR SA `icryptogkedr@` gets **403** on the prod bucket; the prod SA `icryptogke-prod@pps-analytics-189714` (configured on the bastion) can read it | live 2026-10-05 |
| Postgres dump: `postgres/midpoint-20260911.sql`, 270 GB plain SQL, pg_dump 17.11 against server 16.13, contains `\restrict` | object head |
| `icrypto_persistent_ha.tar.gz`: `cbbackupmgr` 7.6.3 **repository** dir at tar root (no archive `.backup` marker), 4,114 files / 590 MB, complete plan | tar listing |
| `couchbase/cb-backup-20260911/oidcv2/oidcv2-export.json`: `cbexport` JSON **list**, one doc per line, **no key field**; the same run's `cbbackupmgr` failed (401 on `/api/v1/backup`) | object head + `backup-0.log` |
| Janssen `oidcv2` keys = RDN values of `dn` minus the trailing `o=jans`, reversed, joined with `_`; root `o=jans` → `_`. 84,902/84,903 QA docs match | QA Capella N1QL |
| `icrypto_persistent_ha` keys (`idm_<uuid>`, `demo_dynamic_creds`) are **not** derivable from the body (`id` ≠ key for 304,037/304,037) | QA Capella N1QL |
| Bastion: `cbbackupmgr` 7.6.4, no `cbimport`/`cbexport`, no python3; 44 GB free | live |

## Goals / Non-Goals

**Goals:** rebuild the cluster as captured. Restore every prod data tier with what is reachable today. Keep the
blocked path (`gcloud sql import`) one switch away. Fix B1–B4.

**Non-Goals:** creating or changing Cloud SQL, Capella, VPC, subnet, NAT or peerings. Fixing the sqladmin egress
(PPS network action). Staging the prod objects into a DR bucket (operator step). Changing Phases 2, 5 and 8.

## Decisions

### E1 — Faithful Phase 1 through variables, defaults unchanged
New module inputs: `dr_gke_datapath_provider`, `dr_gke_resource_labels`, `dr_gke_oauth_scopes`,
`dr_gke_enable_integrity_monitoring`, `dr_gke_enable_secure_boot`, `dr_gke_workload_metadata_mode`,
`dr_gke_logging_components`, `dr_gke_managed_prometheus`, `dr_gke_max_pods_per_node`,
`dr_gke_private_endpoint_enforcement`, `dr_gke_cluster_secondary_range_name`, `dr_gke_services_secondary_range_name`.
Defaults reproduce today's module output, so an existing tfvars plans the same. `pps-dr.tfvars` sets the captured
values. *Alternative rejected:* hard-coding the captured values into the module would make it single-environment.

### E2 — Secondary ranges: CIDR by default, names to adopt
When `dr_gke_*_secondary_range_name` is non-empty, `ip_allocation_policy` uses the range **names** and ignores the CIDR
inputs. Otherwise GKE creates ranges from the CIDRs. The current ranges are GKE-managed and are normally removed with
the cluster. If they survive the delete, the operator sets the names and adopts them, which avoids touching the shared
subnet.

### E3 — Postgres restore method switch, psql path default
`postgres_restore_method` (`psql_pod` | `gcloud_sql_import`, default `psql_pod`) plus `allow_gcloud_sql_import`
(default `false`). A `terraform_data` precondition in `modules/30-data-restore` rejects `gcloud_sql_import` unless it is
explicitly allowed. A precondition is used instead of a cross-variable validation so the gate does not depend on
OpenTofu/Terraform version support for cross-variable references. Every `google_sql_database_instance` data source
(Phase 0 and Phase 3) is `count`-gated on the method, so the `psql_pod` path never calls the Cloud SQL Admin API.
`cloudsql_private_ip` becomes a root input: required for `psql_pod`, and it overrides the data-source IP when set.

### E4 — psql_pod: two containers and a FIFO, nothing on disk
The Job has an `emptyDir` with a named pipe:
- the `fetch` container (`google-cloud-cli`) activates the SA key mounted from a Secret built from
  `gcp_credentials_file` and runs `gcloud storage cat gs://… > /pipe/dump`;
- the `load` container (`postgres:17`, psql ≥ 17.6 for `\restrict`) runs
  `psql -v ON_ERROR_STOP=1 -f /pipe/dump`.

A failure on either side breaks the pipe and fails the Job (`backoffLimit: 0`). A 270 GB load would not fit the
bastion's 44 GB or a node's 100 GB disk, and streaming avoids both. The Job name is derived from the object
generation, so re-running the script re-attaches to a running or finished Job instead of starting a second load.
`postgres_recreate_database` (default `false`) adds a `DROP DATABASE … WITH (FORCE)` / `CREATE DATABASE` step. Without
it, a non-empty target database is a hard failure, because the plain dump does not clean up first.
*Alternative rejected:* piping from the bastion through `kubectl exec -i` ties a multi-hour load to one SSH session.

### E5 — Couchbase per-bucket methods
`couchbase_restore_methods` (map bucket → `capella_api` | `cbbackupmgr` | `cbimport`) and `couchbase_backup_objects`
(map bucket → object) replace `couchbase_use_cbrestore`/`couchbase_backup_object`. Flat string maps keep the inputs
parseable by `prevalidate/lib.sh`.
- `cbbackupmgr` runs on the bastion, which has 7.6.4 and reaches DR Capella. If the tarball has no archive root
  (`.backup`), the script initialises one with `cbbackupmgr config` and moves the repository in. The repository name is
  the extracted directory. It restores with `--force-updates`.
- `cbimport` runs **in-cluster**, because the bastion has no `cbimport` and no python3. An init container
  (`google-cloud-cli`, which ships python3) downloads the export and converts the JSON list to JSON lines, adding a
  `__dr_key` field. The main container (`couchbase/server`) runs `cbimport json --format lines --generate-key
  %__dr_key% --ignore-fields __dr_key`. The key mode per bucket is set by `couchbase_cbimport_key_modes`: `jans_dn`
  derives the key from `dn` (rule in Context), and `field:<name>` uses a body field.
- `capella_api` keeps today's behaviour. The Capella token is required only when a bucket uses it.
- Optional `couchbase_index_definitions_object`: the prod index file is replayed from the bastion through the query
  REST API on `:18093`. It drops `"nodes":[…]`, de-duplicates statements and keeps `defer_build`, then issues
  `BUILD INDEX` per keyspace.
- Verification uses `couchbase_expected_doc_counts` when set, and the cluster's `:18091/pools/default/buckets` with DB
  credentials when no Capella token is present.

### E6 — LDAP restore matches the Bitnami image
`ldap_pod_name` (default `openldap-0`) and `ldap_slapd_config_dir` (default `/opt/bitnami/openldap/etc/slapd.d`). The
DB numbers are `config` → `-n 0`, `secauth` → `-n 3` and data → `-n 2`, which is what slapcat produced on the source.

### E7 — Argo CD restore applies every manifest
Every `*.yaml|*.yml` from the archive is applied, sorted, and the run fails if none are found. Destination validation
and the sync hold are unchanged.

### E8 — Phase 6 converges restored Applications
`app_of_apps_enabled` (default `false`) gates the app-of-apps resource, and the git inputs become optional. The sync
hold release and the convergence gate run either way. When `service_versions` is non-empty, a step patches
`spec.source.targetRevision` of each Application named by a key; an unknown key is a failure. When it is empty, the
restored revisions are used as-is. The `service_versions` validation now accepts an empty map.

### E9 — `backend_services` wired root → Phase 7
It is declared in root `variables.tf` and passed in `main.tf`. The default stays `{}`, and prevalidate still blocks on
it being empty.

### E10 — Prevalidate follows the switches
- The Cloud SQL checks (`prereq3`, private IP, SA grant) run only for `gcloud_sql_import`.
- `psql_pod` gets a `/dev/tcp` probe to `cloudsql_private_ip:5432`. It is a warning, not a blocker, because the
  bastion may not route to PSA while the cluster does.
- Required backup objects come from `couchbase_backup_objects` and `couchbase_index_definitions_object`.
- `cbbackupmgr` is required only when some bucket uses it.

### E11 — Backups read with a dedicated credential (added 2026-10-05)
The prod backup bucket is readable only by the prod SA. `backup_credentials_file` (default: `gcp_credentials_file`) feeds a
`google.backups` provider alias for every backup-object data source, `CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE` for bastion
downloads and prevalidate, and the Secret mounted into the in-cluster restore Jobs. No staging copy into a DR bucket.
The 2026-10-05 set also adds: gzip inputs (stream-decompressed), plain `.tar` cbbackupmgr archives, `id_field:<name>` key mode
(N1QL exports carry the key in `__doc_id__`), and `postgres_globals_object` (roles loaded before the dump).

## Risks / Trade-offs

- **270 GB psql load duration** (hours). → The Job outlives the apply and the script can re-attach. Run `tofu` in
  tmux.
- **`\restrict` with an older psql** fails at line 5. → The default image is `postgres:17` and the image is a variable.
- **Target DB already populated** (DR `midpoint` has older data). → Hard fail unless `postgres_recreate_database=true`,
  which the operator sets deliberately.
- **`--force-updates` leaves stale docs** that exist in DR but not in prod. → Documented. A bucket flush is a PPS/Capella
  console decision, not automated.
- **Key derivation for `oidcv2`** depends on Janssen's DN→key rule. → Validated against all QA docs. The post-import
  count is checked against `couchbase_expected_doc_counts`.
- **DR SA cannot read the prod bucket.** → The objects must be staged into a DR-readable bucket before Phase 0. The
  preflight data sources fail loudly otherwise.

## Migration Plan

Existing tfvars must replace `couchbase_use_cbrestore`/`couchbase_backup_object` with the map inputs, and set
`postgres_restore_method` explicitly if they want `gcloud_sql_import`, together with `allow_gcloud_sql_import = true`.
`pps-dr.tfvars.example` and `DR-REBUILD-PLAN.md` show the new shape. Rollback is the previous commit on the branch.

## Open Questions

- Consul and Argo CD backup locations (user to supply 2026-10-06).
- DR bucket that will hold the staged prod objects (create one vs reuse), and the prod-SA write grant on it.
- Cloud SQL instance name/project, which only the `gcloud_sql_import` path needs.
