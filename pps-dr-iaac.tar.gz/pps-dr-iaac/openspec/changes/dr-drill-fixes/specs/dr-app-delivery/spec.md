## ADDED Requirements

### Requirement: Argo CD restore applies every manifest in the archive
`modules/40-argocd/argocd_restore.sh` SHALL apply every `*.yaml`/`*.yml` extracted from a tarball backup and fail when none is found.

#### Scenario: Eight-file backup
- **WHEN** the archive contains applications, appprojects, applicationsets, configmaps, argocd-secret and repository/repo-creds/cluster secret files
- **THEN** all eight are applied and the restored Application count equals the count in the archive

### Requirement: Phase 6 converges the restored Applications
`modules/60-app-services` SHALL NOT require a git app-of-apps. With `app_of_apps_enabled = false` it SHALL release the Phase 4 sync hold, pin `spec.source.targetRevision` for each Application named in `service_versions`, and wait for convergence.

#### Scenario: Unknown service key
- **WHEN** `service_versions` names an Application that does not exist in the Argo CD namespace
- **THEN** Phase 6 fails and lists the unknown names

### Requirement: Ingress backends come from root configuration
Root `backend_services` SHALL be passed to `modules/70-ingress-dns`.

#### Scenario: backend_services set in tfvars
- **WHEN** `backend_services` maps every `dr_hostnames` key to a Service
- **THEN** the rendered ingress contains no backend named `REPLACE-ME-*`
