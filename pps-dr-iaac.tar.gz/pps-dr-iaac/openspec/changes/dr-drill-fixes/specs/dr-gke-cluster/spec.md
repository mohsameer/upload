## ADDED Requirements

### Requirement: Phase 1 reproduces the captured DR cluster on the existing network
When `create_gke_cluster = true`, `modules/10-gke-cluster` SHALL create a managed `google_container_cluster` and node pool on the configured existing VPC/subnet, carrying every setting supplied for datapath provider, resource labels, node OAuth scopes, shielded-instance settings, workload metadata mode, logging components, managed Prometheus, max pods per node, master authorized networks and private endpoint enforcement. The VPC, subnet, Cloud NAT and peerings SHALL remain unmanaged.

#### Scenario: Plan against the captured values
- **WHEN** `tofu plan -target=module.dr_cluster` runs with the captured values in `pps-dr.tfvars`
- **THEN** the plan creates exactly one cluster and one node pool
- **AND** shows no create/update/destroy on any network, subnetwork, router or peering

#### Scenario: Recreated cluster matches the capture
- **WHEN** the new cluster is described with `gcloud container clusters describe --format=yaml`
- **THEN** datapath, labels, node scopes, node locations, CIDRs, authorized networks, logging and monitoring settings equal `.dr-run/config-backup-20261005/gke-cluster.yaml`, differing only in ids, versions, endpoints and timestamps

#### Scenario: Defaults keep the previous behaviour
- **WHEN** none of the new inputs are set
- **THEN** the rendered cluster arguments are identical to the module before this change

### Requirement: Secondary ranges can be adopted by name
The module SHALL use `cluster_secondary_range_name` / `services_secondary_range_name` when the corresponding name input is non-empty, and the CIDR inputs otherwise.

#### Scenario: Pre-existing named ranges survive the old cluster's deletion
- **WHEN** the subnet still carries ranges `gke-dr-icrypto-gke-cluster-pods-c7149c78` and `...-services-c7149c78` and both names are set
- **THEN** the cluster is created on those ranges and the plan shows no change to the subnet
