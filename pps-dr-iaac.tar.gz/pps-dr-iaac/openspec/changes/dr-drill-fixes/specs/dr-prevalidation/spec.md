## ADDED Requirements

### Requirement: Checks follow the selected restore methods
The prevalidation suite SHALL run Cloud SQL Admin API checks only when `postgres_restore_method = "gcloud_sql_import"`, SHALL probe `cloudsql_private_ip:5432` when it is `psql_pod`, and SHALL derive required backup objects and the `cbbackupmgr` tooling requirement from `couchbase_restore_methods` / `couchbase_backup_objects`.

#### Scenario: psql_pod with sqladmin blocked
- **WHEN** `postgres_restore_method = "psql_pod"` and the Cloud SQL Admin API is unreachable
- **THEN** no `prereq3` / `config:cloudsql-*` check fails because of it

#### Scenario: A bucket uses cbbackupmgr
- **WHEN** any value in `couchbase_restore_methods` is `cbbackupmgr`
- **THEN** a missing `cbbackupmgr` binary is a blocker
