## ADDED Requirements

### Requirement: Postgres restore method is selectable and gcloud import is gated
`modules/30-data-restore` SHALL restore the dump via `postgres_restore_method`: `psql_pod` (default) or `gcloud_sql_import`. `gcloud_sql_import` MUST be refused unless `allow_gcloud_sql_import = true`. On `psql_pod`, no data source or script SHALL call the Cloud SQL Admin API, and `cloudsql_instance_name` MAY be empty.

#### Scenario: gcloud import selected without opt-in
- **WHEN** `postgres_restore_method = "gcloud_sql_import"` and `allow_gcloud_sql_import = false`
- **THEN** `tofu plan` fails with a message naming the sqladmin network gate and the opt-in variable

#### Scenario: psql path with sqladmin unreachable
- **WHEN** `postgres_restore_method = "psql_pod"` and `sqladmin.googleapis.com` is unreachable
- **THEN** plan and Phase 3 complete without any `google_sql_database_instance` read

### Requirement: psql_pod streams the dump without local staging
On `psql_pod`, Phase 3 SHALL run a Kubernetes Job that streams `gs://<backup_bucket>/<postgres_backup_object>` into `psql -v ON_ERROR_STOP=1` against `cloudsql_private_ip`, using a psql client that understands pg_dump 17 output. Re-running the step SHALL re-attach to the Job for the same object generation rather than start a second load.

#### Scenario: Load error
- **WHEN** any SQL statement fails
- **THEN** the Job fails, the apply fails, and the Job's log tail is printed

#### Scenario: Populated target without recreate
- **WHEN** the target database already contains user tables and `postgres_recreate_database = false`
- **THEN** the Job fails before loading and names the variable that allows a recreate

### Requirement: Couchbase restore method per bucket
Phase 3 SHALL restore each bucket in `couchbase_restore_methods` via `capella_api`, `cbbackupmgr` or `cbimport`, using `couchbase_backup_objects[bucket]`. A Capella API token SHALL be required only for buckets using `capella_api`.

#### Scenario: cbbackupmgr repository tarball without archive root
- **WHEN** the tarball holds only a repository directory
- **THEN** the script initialises an archive, restores that repository into the bucket and exits non-zero on any cbbackupmgr error

#### Scenario: cbimport of a keyless Janssen export
- **WHEN** `oidcv2` uses `cbimport` with key mode `jans_dn`
- **THEN** each document is stored under the key derived from its `dn`, the helper field is not stored, and the doc count is reported

#### Scenario: Verification without a Capella token
- **WHEN** `TF_VAR_capella_api_token` is empty
- **THEN** item counts are read from the cluster's `:18091/pools/default/buckets` using the DB user, and compared with `couchbase_expected_doc_counts` when set

### Requirement: LDAP restore targets the Bitnami layout
The LDAP restore SHALL use `ldap_slapd_config_dir` and `ldap_pod_name`, loading `*config*` into `-n 0`, `*secauth*` into `-n 3` and every other LDIF into `-n 2`.

#### Scenario: Prod LDIF set
- **WHEN** the three prod LDIFs are restored
- **THEN** a search under `ldap_base_dn` returns more than zero entries
