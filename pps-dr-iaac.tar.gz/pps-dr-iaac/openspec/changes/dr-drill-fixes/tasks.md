## 1. Phase 1 cluster fidelity (`modules/10-gke-cluster`, root)

- [x] 1.1 Add inputs: datapath provider, resource labels, OAuth scopes, integrity monitoring, secure boot, workload metadata mode, logging components, managed Prometheus, max pods per node, private endpoint enforcement — `modules/10-gke-cluster/variables.tf`
- [x] 1.2 Render them in `google_container_cluster.dr` and `google_container_node_pool.dr` — `modules/10-gke-cluster/main.tf`
- [x] 1.3 Add optional secondary range names; use names when set, CIDRs otherwise — `modules/10-gke-cluster/main.tf`
- [x] 1.4 Declare root variables with defaults equal to previous behaviour and pass them through — `variables.tf`, `main.tf`

## 2. Postgres method switch (`modules/30-data-restore`, `modules/00-preflight`, root)

- [x] 2.1 Root inputs `postgres_restore_method`, `allow_gcloud_sql_import`, `cloudsql_private_ip`, `postgres_recreate_database`, `postgres_fetch_image`, `postgres_client_image`; relax `cloudsql_instance_name` to allow empty — `variables.tf`
- [x] 2.2 Gate `gcloud_sql_import` behind `allow_gcloud_sql_import` with a precondition — `modules/30-data-restore/main.tf`
- [x] 2.3 `count`-gate every `google_sql_database_instance` data source and the Cloud SQL state gate on the method — `modules/00-preflight/main.tf`, `modules/30-data-restore/main.tf`, outputs
- [x] 2.4 New `psql_restore.sh`: SA-key Secret, fetch+load Job over a FIFO, generation-derived Job name, re-attach, optional recreate, populated-target guard — `modules/30-data-restore/psql_restore.sh`
- [x] 2.5 Verify job uses the private IP input and a psql 17 image by default — `modules/30-data-restore/main.tf`, `variables.tf`

## 3. Couchbase per-bucket restore (`modules/30-data-restore`, root)

- [x] 3.1 Replace `couchbase_use_cbrestore`/`couchbase_backup_object` with `couchbase_restore_methods`, `couchbase_backup_objects`, `couchbase_cbimport_key_modes`, `couchbase_index_definitions_object`, `couchbase_expected_doc_counts`, `couchbase_server_image` — `variables.tf`, `main.tf`, module variables
- [x] 3.2 `capella_restore.sh`: dispatch per bucket; token only for `capella_api`; cbbackupmgr archive-root init — `modules/30-data-restore/capella_restore.sh`
- [x] 3.3 New `cbimport_restore.sh`: in-cluster Job, list→lines conversion with key derivation (`jans_dn`, `field:<name>`) — `modules/30-data-restore/cbimport_restore.sh`
- [x] 3.4 New `capella_indexes.sh`: replay index definitions without `nodes`, de-duplicated, then BUILD — `modules/30-data-restore/capella_indexes.sh`
- [x] 3.5 `capella_verify.sh`: mgmt-API fallback without token; expected counts — `modules/30-data-restore/capella_verify.sh`

## 4. LDAP (`modules/30-data-restore`)

- [x] 4.1 Inputs `ldap_pod_name`, `ldap_slapd_config_dir`; DB numbers 0/2/3 — `ldap_restore.sh`, `main.tf`, `variables.tf`

## 5. Delivery (`modules/40-argocd`, `modules/60-app-services`, `modules/70-ingress-dns`, root)

- [x] 5.1 Apply every extracted manifest — `modules/40-argocd/argocd_restore.sh`
- [x] 5.2 `app_of_apps_enabled` gate; optional git inputs; `pin_versions.sh` patches restored Applications — `modules/60-app-services/*`
- [x] 5.3 Root `backend_services` passed to Phase 7 — `variables.tf`, `main.tf`

## 6. Prevalidate (`prevalidate/checks.sh`)

- [x] 6.1 Cloud SQL API checks only for `gcloud_sql_import`; TCP probe for `psql_pod`
- [x] 6.2 Required objects + `cbbackupmgr` requirement from Couchbase maps; index-definition object

## 7. Docs and example

- [x] 7.1 Update `pps-dr.tfvars.example` to the new inputs
- [x] 7.2 Update `DR-REBUILD-PLAN.md` with the implemented shape and staging step

## 7b. Backup credential and 2026-10-05 formats

- [x] 7b.1 `backup_credentials_file` + `google.backups` alias in Phases 0/3/4 — `provider.tf`, `modules/*/versions.tf`, `main.tf`
- [x] 7b.2 Bastion downloads and prevalidate use the backup credential — `modules/30-data-restore/main.tf`, `modules/40-argocd/main.tf`, `prevalidate/checks.sh`
- [x] 7b.3 gzip inputs, plain `.tar`, `id_field:<name>`, `postgres_globals_object` — `modules/30-data-restore/*.sh`, variables

## 8. Verification

- [x] 8.1 `terraform fmt -check -recursive` and `terraform validate` (local backend override, not committed)
- [x] 8.2 Placeholder plan: example tfvars fails only on `REPLACE_ME_*` validations
- [x] 8.3 `bash -n` + `shellcheck` (if available) on every changed script
- [x] 8.4 `openspec validate dr-drill-fixes --strict`
- [ ] 8.5 Live (blocked until Phase B): `tofu plan` on the bastion with real tfvars shows only cluster/node-pool creates for `module.dr_cluster`
