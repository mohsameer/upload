# ---------------------------------------------------------------------------
# PPS DR site - phase orchestration.
#
# Module numbering matches the phases in the "iCrypto - Disaster Recovery Plan
# for PPS" runbook. Each module exposes a `completed` output; the next phase
# depends on it so a half-built site never advances.
#
# Run from the DR bastion:
#   tofu apply -var-file=pps-dr.tfvars           # Phases 0-7
#   <PPS applies DNS change, then verify>        # dns_resolution_check
#   tofu apply -target=module.validation ...     # Phase 8
# ---------------------------------------------------------------------------

# Backup object paths are relative to backup_prefix (one dated folder per
# backup set), so pointing the run at a new set means changing one value.
# An empty path stays empty (component not restored).
locals {
  backup_root = trim(var.backup_prefix, "/")

  backup_objects = {
    postgres = var.postgres_backup_object == "" ? "" : join("/", compact([local.backup_root, var.postgres_backup_object]))
    globals  = var.postgres_globals_object == "" ? "" : join("/", compact([local.backup_root, var.postgres_globals_object]))
    consul   = var.consul_backup_object == "" ? "" : join("/", compact([local.backup_root, var.consul_backup_object]))
    vault    = var.vault_backup_object == "" ? "" : join("/", compact([local.backup_root, var.vault_backup_object]))
    argocd   = var.argocd_backup_object == "" ? "" : join("/", compact([local.backup_root, var.argocd_backup_object]))
    cb_index = var.couchbase_index_definitions_object == "" ? "" : join("/", compact([local.backup_root, var.couchbase_index_definitions_object]))
  }
  ldap_backup_objects      = [for o in var.ldap_backup_objects : join("/", compact([local.backup_root, o]))]
  ldap_tls_objects         = [for o in var.ldap_tls_objects : join("/", compact([local.backup_root, o]))]
  couchbase_backup_objects = { for b, o in var.couchbase_backup_objects : b => join("/", compact([local.backup_root, o])) }
  # Per-database dumps, prefixed the same way as every other object so the
  # tfvars entry stays relative to the backup set.
  postgres_databases = { for db, o in var.postgres_databases : db => join("/", compact([local.backup_root, o])) }
}

# Phase 0 - Preflight. Read-only verification of the six prerequisites.
# The external ingress had no static IP, so its address was only knowable after
# Phase 7 created it - and that produced a circular dependency that deadlocked
# the build: oidc-mgmt-portal fetches https://oidc.pps.co.za at startup, so it
# needs that name pointed at this site; the redirect needed the ingress
# address; the ingress waits on wave1_gate; and wave 1 cannot converge until
# oidc-mgmt-portal is healthy. Observed on 2026-10-12: the portal crash-looped
# on "fetch failed ... ECONNRESET host: oidc.pps.co.za" while the name still
# resolved to production's 34.120.124.233.
#
# Reserving the address up front is half the fix - Phase 2 can point every one
# of this site's hostnames at this site before a single application syncs, and
# the address stops changing on every rebuild, which until now cost PPS a fresh
# DNS change each time. The other half is Phase 7's wave1_gate: a reserved
# address answers nothing until an ingress attaches a load balancer to it, so
# the ingress is created when the Applications are released, not when they have
# converged.
resource "google_compute_global_address" "external_ingress" {
  count = var.external_ingress_vip_name != "" && var.external_ingress_vip_manage ? 1 : 0

  name    = var.external_ingress_vip_name
  project = var.project_id
}

# With external_ingress_vip_manage = false the address is reserved once, outside
# this state, so a destroy leaves it alone and a rebuild gets the same address.
data "google_compute_global_address" "external_ingress_kept" {
  count = var.external_ingress_vip_name != "" && !var.external_ingress_vip_manage ? 1 : 0

  name    = var.external_ingress_vip_name
  project = var.project_id
}

# The LDAP internal load balancer's address (trueldap.pps.co.za). An internal
# address can be re-reserved by value, so unlike the external one it is simply
# created and deleted with the site and comes back as the same IP. It must be
# free when this is created: on a site whose LDAP Service already holds the
# address, apply it on the next rebuild instead.
resource "google_compute_address" "ldap_lb" {
  count = var.ldap_lb_ip != "" && var.ldap_lb_reserve ? 1 : 0

  name         = var.ldap_lb_address_name
  address      = var.ldap_lb_ip
  address_type = "INTERNAL"
  region       = var.dr_region
  subnetwork   = var.dr_subnetwork
  project      = var.project_id
}

data "google_compute_address" "captured_internal_vip" {
  for_each = local.captured_internal_vip_names

  name    = each.value
  region  = var.dr_region
  project = var.project_id
}

locals {
  external_ingress_ip = var.external_ingress_vip_name == "" ? "" : coalesce(
    one(google_compute_global_address.external_ingress[*].address),
    one(data.google_compute_global_address.external_ingress_kept[*].address),
  )

  # Which ingress serves which hostname, read from the captured manifest rather
  # than restated by hand: an ingress that pins a regional IP is internal and
  # its address is in internal_ingress_vips, anything else is the external one.
  # The captured file is a kind: List wrapper, so the ingresses are under
  # .items. try() also covers the "no captured manifest" case, where there is
  # nothing to map.
  captured_ingresses = try(yamldecode(file(var.ingress_manifest_file)).items, [])

  # The regional VIPs the captured ingresses pin, by name. These are reserved
  # out of band (icrypto-nginx-app-01, icrypto-opa-app-01 both exist already),
  # so they are read rather than created - internal_ingress_vips is for
  # addresses this repo reserves itself and is empty here, which is why
  # looking the names up in it silently fell through to the external address
  # and sent admin/idmv2/truepolicy/truetrace to the external load balancer.
  captured_internal_vip_names = toset(compact([
    for ing in local.captured_ingresses :
    try(ing.metadata.annotations["kubernetes.io/ingress.regional-static-ip-name"], "")
  ]))

  # Hostname -> this site's address for it. Computed unconditionally and then
  # filtered, because a conditional whose branches are {} and a map of strings
  # is a type error in HCL.
  site_hostname_candidates = merge([
    for ing in local.captured_ingresses : {
      for rule in try(ing.spec.rules, []) : rule.host => (
        try(ing.metadata.annotations["kubernetes.io/ingress.regional-static-ip-name"], "") != ""
        ? try(data.google_compute_address.captured_internal_vip[ing.metadata.annotations["kubernetes.io/ingress.regional-static-ip-name"]].address, local.external_ingress_ip)
        : local.external_ingress_ip
      )
      if try(rule.host, "") != ""
    }
  ]...)

  # Not filtered on the address here. The reserved address is unknown until
  # apply, and filtering on an unknown value makes the map's KEYS unknown too -
  # which makes `count = length(var.endpoint_redirects) > 0` in Phase 2 an
  # "Invalid count argument" at plan time. dns_redirect.sh skips a pair whose
  # destination is empty instead.
  site_hostname_redirects = local.site_hostname_candidates
}

module "preflight" {
  source = "./modules/00-preflight"
  providers = {
    google         = google
    google.backups = google.backups
  }

  project_id              = var.project_id
  dr_region               = var.dr_region
  gcp_credentials_file    = var.gcp_credentials_file
  cloudsql_instance_name  = var.cloudsql_instance_name
  postgres_restore_method = var.postgres_restore_method
  backup_bucket           = var.backup_bucket
  backup_credentials_file = local.backup_credentials_file

  required_backup_objects = compact(concat(
    [
      local.backup_objects.postgres,
      local.backup_objects.globals,
      local.backup_objects.consul,
      local.backup_objects.vault,
      local.backup_objects.argocd,
    ],
    local.ldap_backup_objects,
    local.ldap_tls_objects,
    var.couchbase_restore_enabled ? distinct(values(local.couchbase_backup_objects)) : [],
    var.couchbase_restore_enabled ? [local.backup_objects.cb_index] : [],
  ))

  capella_api_url         = var.capella_api_url
  capella_api_token       = var.capella_api_token
  capella_organization_id = var.capella_organization_id
  capella_project_id      = var.capella_project_id
  capella_cluster_id      = var.capella_cluster_id

  dr_gke_name        = var.dr_gke_name
  dr_gke_location    = var.dr_gke_location
  create_gke_cluster = var.create_gke_cluster
}

# Phase 1 - DR GKE cluster (create or adopt), credentials, namespaces.
module "dr_cluster" {
  source     = "./modules/10-gke-cluster"
  depends_on = [module.preflight]

  project_id           = var.project_id
  gcp_credentials_file = var.gcp_credentials_file
  kubeconfig_path      = var.kubeconfig_path

  create_gke_cluster                = var.create_gke_cluster
  cluster_deletion_protection       = var.cluster_deletion_protection
  dr_gke_name                       = var.dr_gke_name
  dr_gke_location                   = var.dr_gke_location
  dr_gke_node_locations             = var.dr_gke_node_locations
  dr_gke_machine_type               = var.dr_gke_machine_type
  dr_gke_disk_size_gb               = var.dr_gke_disk_size_gb
  dr_gke_disk_type                  = var.dr_gke_disk_type
  dr_gke_image_type                 = var.dr_gke_image_type
  dr_gke_node_sa_account            = var.dr_gke_node_sa_account
  dr_gke_network_link               = var.dr_gke_network_link
  dr_gke_subnetwork_link            = var.dr_gke_subnetwork_link
  dr_gke_networking_mode            = var.dr_gke_networking_mode
  dr_gke_cluster_ipv4_cidr_block    = var.dr_gke_cluster_ipv4_cidr_block
  dr_gke_services_ipv4_cidr_block   = var.dr_gke_services_ipv4_cidr_block
  dr_gke_master_ipv4_cidr_block     = var.dr_gke_master_ipv4_cidr_block
  dr_gke_master_authorized_networks = var.dr_gke_master_authorized_networks
  dr_gke_node_pool_name             = var.dr_gke_node_pool_name
  dr_gke_node_count                 = var.dr_gke_node_count
  dr_gke_release_channel            = var.dr_gke_release_channel

  dr_gke_datapath_provider             = var.dr_gke_datapath_provider
  dr_gke_node_resource_labels          = var.dr_gke_node_resource_labels
  dr_gke_resource_labels               = var.dr_gke_resource_labels
  dr_gke_oauth_scopes                  = var.dr_gke_oauth_scopes
  dr_gke_enable_integrity_monitoring   = var.dr_gke_enable_integrity_monitoring
  dr_gke_enable_secure_boot            = var.dr_gke_enable_secure_boot
  dr_gke_workload_metadata_mode        = var.dr_gke_workload_metadata_mode
  dr_gke_logging_components            = var.dr_gke_logging_components
  dr_gke_managed_prometheus            = var.dr_gke_managed_prometheus
  dr_gke_max_pods_per_node             = var.dr_gke_max_pods_per_node
  dr_gke_private_endpoint_enforcement  = var.dr_gke_private_endpoint_enforcement
  dr_gke_cluster_secondary_range_name  = var.dr_gke_cluster_secondary_range_name
  dr_gke_services_secondary_range_name = var.dr_gke_services_secondary_range_name

  platform_namespace         = var.platform_namespace
  argocd_namespace           = var.argocd_namespace
  external_secrets_namespace = var.external_secrets_namespace
  app_namespaces             = var.app_namespaces
  ingress_namespace          = var.ingress_namespace
}

# Registry credentials for the private ECR registry.
#
# Not a runbook phase - it serves Phases 1, 4 and 6, and unlike every other
# module it leaves a running workload behind. ECR authorization tokens expire
# after 12 hours, so the credential is refreshed on a schedule from inside the
# cluster rather than written once from the bastion.
module "registry_credentials" {
  source     = "./modules/15-registry-credentials"
  depends_on = [module.dr_cluster]

  registry_server        = var.registry_server
  ecr_access_key         = var.ecr_access_key
  ecr_secret_key         = var.ecr_secret_key
  image_pull_secret_name = var.image_pull_secret_name

  # external_secrets_namespace belongs here: ESO's own images come from the
  # same ECR, and without the pull secret its three Deployments sit in
  # ImagePullBackOff - which stalls Phase 5, because the ClusterSecretStore
  # needs that controller running. The refresh reported nine namespaces and
  # external-secrets was not one of them.
  #
  # ldap_namespace and services_namespace likewise host workloads with ECR
  # images that are not in app_namespaces.
  target_namespaces = distinct(concat(
    var.app_namespaces,
    [
      var.platform_namespace,
      var.argocd_namespace,
      var.ingress_namespace,
      var.external_secrets_namespace,
      var.ldap_namespace,
      var.services_namespace,
    ],
  ))

  argocd_namespace        = var.argocd_namespace
  argocd_repo_secret_name = var.argocd_repo_secret_name
  credentials_namespace   = var.platform_namespace

  refresh_schedule                  = var.registry_refresh_schedule
  runner_image                      = var.registry_runner_image
  attach_to_default_service_account = var.attach_pull_secret_to_default_sa
  kubeconfig_path                   = var.kubeconfig_path
}

# Phase 2 - Stateful platform: Consul, Vault, OpenLDAP, Zeebe.
# No PostgreSQL and no Couchbase: both tiers are managed services.
module "platform" {
  source     = "./modules/20-platform"
  depends_on = [module.dr_cluster, module.registry_credentials]

  platform_namespace        = var.platform_namespace
  storage_class             = var.storage_class
  chart_versions            = var.platform_chart_versions
  storage_sizes             = var.platform_storage_sizes
  replicas                  = var.platform_replicas
  readiness_timeout_seconds = var.readiness_timeout_seconds
  kubeconfig_path           = var.kubeconfig_path
  ldap_admin_password       = var.ldap_admin_password
  ldap_base_dn              = var.ldap_base_dn

  openldap_deployment    = var.openldap_deployment
  ldap_ready_selector    = var.ldap_ready_selector
  ldap_release_name      = var.ldap_release_name
  ldap_namespace         = var.ldap_namespace
  ldap_chart_path        = var.ldap_chart_path
  ldap_chart_name        = var.ldap_chart_name
  ldap_chart_version     = var.ldap_chart_version
  registry_server        = var.registry_server
  ldap_values_file       = var.ldap_values_file
  image_pull_secret_name = var.image_pull_secret_name

  ldap_service_ldap_port = var.ldap_service_ldap_port
  ldap_service_ssl_port  = var.ldap_service_ssl_port
  ldap_lb_ip             = try(google_compute_address.ldap_lb[0].address, var.ldap_lb_ip)

  zeebe_enabled        = var.zeebe_enabled
  cert_manager_enabled = var.cert_manager_enabled
  cert_manager_version = var.cert_manager_version

  vault_seal_type      = var.vault_seal_type
  vault_kms_sa_file    = var.vault_kms_sa_file
  vault_kms_project    = var.vault_kms_project
  vault_kms_region     = var.vault_kms_region
  vault_kms_keyring    = var.vault_kms_keyring
  vault_kms_crypto_key = var.vault_kms_crypto_key
  vault_root_token     = var.vault_root_token

  # Only used to pull the OCI LDAP chart before the cluster pull secret exists.
  ecr_access_key = var.ecr_access_key
  ecr_secret_key = var.ecr_secret_key

  endpoint_redirects   = merge(var.endpoint_redirects, local.site_hostname_redirects)
  ldap_service_aliases = var.ldap_service_aliases
}

# Phase 3 - Data restore: Cloud SQL from GCS, Capella, then Consul/Vault/LDAP.
module "data_restore" {
  source = "./modules/30-data-restore"
  providers = {
    google         = google
    google.backups = google.backups
  }
  # Only the cluster, deliberately. The Postgres and Capella restores need
  # nothing from the platform phase, and midpoint is the longest single item in
  # the build, so it starts as early as it can. The Consul, Vault and LDAP
  # restores still wait for the platform, through platform_gate below.
  depends_on = [module.dr_cluster, module.registry_credentials]

  project_id              = var.project_id
  gcp_credentials_file    = var.gcp_credentials_file
  kubeconfig_path         = var.kubeconfig_path
  platform_namespace      = var.platform_namespace
  backup_bucket           = var.backup_bucket
  backup_credentials_file = local.backup_credentials_file

  cloudsql_instance_name   = var.cloudsql_instance_name
  cloudsql_database_name   = var.cloudsql_database_name
  cloudsql_import_user     = var.cloudsql_import_user
  cloudsql_import_password = var.cloudsql_import_password
  postgres_backup_object   = local.backup_objects.postgres
  postgres_restore_enabled = var.postgres_restore_enabled
  postgres_databases       = local.postgres_databases
  postgres_dump_format     = var.postgres_dump_format
  postgres_restore_jobs    = var.postgres_restore_jobs
  postgres_stage_size      = var.postgres_stage_size
  postgres_session_tuning  = var.postgres_session_tuning

  postgres_restore_method          = var.postgres_restore_method
  postgres_globals_object          = local.backup_objects.globals
  allow_gcloud_sql_import          = var.allow_gcloud_sql_import
  cloudsql_private_ip              = var.cloudsql_private_ip
  postgres_recreate_database       = var.postgres_recreate_database
  postgres_cleanup_before_restore  = var.postgres_cleanup_before_restore
  postgres_future_partitions       = var.postgres_future_partitions
  postgres_future_partition_dbs    = var.postgres_future_partition_databases
  postgres_on_error_stop           = var.postgres_on_error_stop
  postgres_restore_timeout_seconds = var.postgres_restore_timeout_seconds
  postgres_fetch_image             = var.postgres_fetch_image
  postgres_client_image            = var.postgres_client_image

  capella_api_url                    = var.capella_api_url
  capella_api_token                  = var.capella_api_token
  capella_organization_id            = var.capella_organization_id
  capella_project_id                 = var.capella_project_id
  capella_cluster_id                 = var.capella_cluster_id
  capella_connection_string          = var.capella_connection_string
  capella_buckets                    = var.capella_buckets
  couchbase_username                 = var.couchbase_username
  couchbase_password                 = var.couchbase_password
  couchbase_restore_enabled          = var.couchbase_restore_enabled
  couchbase_flush_before_restore     = var.couchbase_flush_before_restore
  couchbase_restore_methods          = var.couchbase_restore_methods
  couchbase_backup_objects           = local.couchbase_backup_objects
  couchbase_cbimport_key_modes       = var.couchbase_cbimport_key_modes
  couchbase_index_definitions_object = local.backup_objects.cb_index
  couchbase_expected_doc_counts      = var.couchbase_expected_doc_counts
  couchbase_server_image             = var.couchbase_server_image

  consul_backup_object           = local.backup_objects.consul
  consul_restore_enabled         = var.consul_restore_enabled
  vault_uses_consul_storage      = var.vault_uses_consul_storage
  vault_recovery_timeout_seconds = var.readiness_timeout_seconds
  vault_backup_object            = local.backup_objects.vault
  vault_restore_enabled          = var.vault_restore_enabled
  vault_root_token               = var.vault_root_token
  ldap_backup_objects            = local.ldap_backup_objects
  ldap_restore_enabled           = var.ldap_restore_enabled
  ldap_admin_password            = var.ldap_admin_password
  ldap_base_dn                   = var.ldap_base_dn

  ldap_pod_name            = var.ldap_pod_name
  ldap_namespace           = var.openldap_deployment == "pps_chart" ? var.ldap_namespace : var.platform_namespace
  ldap_slapd_config_dir    = var.ldap_slapd_config_dir
  ldap_wipe_before_restore = var.ldap_wipe_before_restore
  ldap_restore_config      = var.ldap_restore_config

  storage_class                = var.storage_class
  postgres_stage_storage_class = var.postgres_stage_storage_class
  pin_googleapis               = var.pin_googleapis

  platform_gate = module.platform.completed

  # 4MB of work_mem made one foreign-key validation the longest single step of
  # the whole build.
  postgres_restore_work_mem         = var.postgres_restore_work_mem
  postgres_restore_parallel_workers = var.postgres_restore_parallel_workers
  ldap_slapadd_quick                = var.ldap_slapadd_quick
  ldap_tls_objects                  = local.ldap_tls_objects
  ldap_group_additions              = var.ldap_group_additions
  ldap_group_member_dns             = var.ldap_group_member_dns
  ldap_access_rules                 = var.ldap_access_rules
  ldap_admin_dn                     = var.ldap_admin_dn
  postgres_skip_fk_constraints      = var.postgres_skip_fk_constraints
  postgres_exclude_table_data       = var.postgres_exclude_table_data

  couchbase_build_deferred_indexes      = var.couchbase_build_deferred_indexes
  couchbase_index_build_timeout_seconds = var.couchbase_index_build_timeout_seconds
  couchbase_ca_cert_file                = var.couchbase_ca_cert_file
  couchbase_rewrite_document_endpoints  = var.couchbase_rewrite_document_endpoints
}

# Phase 4 - Argo CD install + backup restore. Sync stays held until Phase 5.
module "argocd" {
  source = "./modules/40-argocd"
  providers = {
    google         = google
    google.backups = google.backups
  }
  # Not the whole of Phase 3: Argo CD needs the restored Consul/Vault/LDAP
  # data, not the databases, so phases 4, 5 and 5b run while midpoint is still
  # restoring. Phase 6 is where the databases become necessary.
  depends_on = [module.registry_credentials]

  argocd_namespace             = var.argocd_namespace
  argocd_chart_version         = var.argocd_chart_version
  argocd_hostname              = var.argocd_hostname
  argocd_admin_password_bcrypt = var.argocd_admin_password_bcrypt
  argocd_backup_object         = local.backup_objects.argocd
  backup_bucket                = var.backup_bucket
  gcp_credentials_file         = local.backup_credentials_file
  backup_credentials_file      = local.backup_credentials_file
  kubeconfig_path              = var.kubeconfig_path
  readiness_timeout_seconds    = var.readiness_timeout_seconds

  git_repo_url = var.git_repo_url
  git_user     = var.git_user
  git_pat      = var.git_pat
  dr_gke_name  = var.dr_gke_name

  argocd_internal_lb_enabled   = var.argocd_internal_lb_enabled
  argocd_retarget_destinations = var.argocd_retarget_destinations
  argocd_skip_cluster_secrets  = var.argocd_skip_cluster_secrets
  argocd_exclude_applications  = var.argocd_exclude_applications

  upstream_gate = module.data_restore.platform_data_completed

  # The registry repository secret is minted fresh by module 15 each run; the
  # backup carries a token that expired when the backup aged out.
  restore_exclude_secrets = distinct(concat([var.argocd_repo_secret_name], var.restore_exclude_secrets))
}

# Phase 5 - Vault auto-rotation + External Secrets Operator + sync gate.
module "secrets" {
  source     = "./modules/50-secrets"
  depends_on = [module.argocd]

  external_secrets_namespace        = var.external_secrets_namespace
  platform_namespace                = var.platform_namespace
  eso_chart_version                 = var.eso_chart_version
  vault_kv_overrides                = var.vault_kv_overrides
  vault_kv_couchbase_overrides      = var.vault_kv_couchbase_overrides
  vault_overrides_restart_workloads = var.vault_overrides_restart_workloads
  eso_chart_repository              = var.eso_chart_repository != "" ? var.eso_chart_repository : "oci://${var.registry_server}"
  eso_vault_role                    = var.eso_vault_role
  eso_target_namespaces             = length(var.eso_target_namespaces) > 0 ? var.eso_target_namespaces : var.app_namespaces
  vault_kv_mount                    = var.vault_kv_mount
  vault_manage_kv_mount             = var.vault_manage_kv_mount
  vault_kv_version                  = var.vault_kv_version
  vault_approle_secrets             = var.vault_approle_secrets
  capella_credential_secrets        = var.capella_credential_secrets
  app_credential_namespaces         = var.app_credential_namespaces
  app_consul_token                  = var.app_consul_token
  vault_root_token                  = var.vault_root_token
  eso_managed_by_argocd             = var.eso_managed_by_argocd
  eso_application_name              = var.eso_application_name
  argocd_namespace                  = var.argocd_namespace
  ecr_access_key                    = var.ecr_access_key
  ecr_secret_key                    = var.ecr_secret_key
  vault_rotation_period_seconds     = var.vault_rotation_period_seconds
  kubeconfig_path                   = var.kubeconfig_path
  readiness_timeout_seconds         = var.readiness_timeout_seconds

  # Repointed after the Vault restore, which brings production's Capella.
  capella_credential_services = var.capella_credential_services
  capella_connection_string   = var.capella_connection_string
  couchbase_username          = var.couchbase_username
  couchbase_password          = var.couchbase_password

  # The restored database credentials belong to the source site.
  postgres_credential_overrides = var.postgres_credential_overrides
  postgres_app_user             = var.cloudsql_import_user
  postgres_app_password         = var.cloudsql_import_password
  min_external_secrets          = var.min_external_secrets

  # The LDAP certificate token-exchange-service trusts, which the LDAP image
  # regenerates on every container start.
  ldap_cert_vault_path        = var.ldap_cert_vault_path
  ldap_namespace              = var.openldap_deployment == "pps_chart" ? var.ldap_namespace : var.platform_namespace
  ldap_pod                    = var.ldap_pod_name
  ldap_cert_vault_overrides   = var.ldap_cert_vault_overrides
  ldap_cert_restart_workloads = var.ldap_cert_restart_workloads
}

# Phase 5b - application config that no Argo CD Application or backup carries.
module "app_config" {
  source     = "./modules/55-app-config"
  depends_on = [module.secrets]

  authn_namespace             = var.authn_namespace
  global_config_namespaces    = var.app_namespaces
  environment_name            = var.environment_name
  icrypto_env                 = var.icrypto_env
  oidcv2_enabled              = var.oidcv2_enabled
  oidc_hostname               = var.oidc_hostname
  capella_connection_string   = var.capella_connection_string
  couchbase_password          = var.couchbase_password
  app_config_secret_dir       = var.app_config_secret_dir
  kubeconfig_path             = var.kubeconfig_path
  icrypto_oidc_filter_version = var.icrypto_oidc_filter_version
}

# Phase 6 - SSO application services, delivered by Argo CD only.
module "app_services" {
  source     = "./modules/60-app-services"
  depends_on = [module.secrets, module.app_config]

  argocd_namespace          = var.argocd_namespace
  app_namespaces            = var.app_namespaces
  service_versions          = var.service_versions
  app_of_apps_enabled       = var.app_of_apps_enabled
  git_repo_url              = var.git_repo_url
  app_of_apps_path          = var.app_of_apps_path
  app_of_apps_revision      = var.app_of_apps_revision
  kubeconfig_path           = var.kubeconfig_path
  readiness_timeout_seconds = var.readiness_timeout_seconds

  cloudsql_connection_name  = module.data_restore.cloudsql_connection_name
  cloudsql_private_ip       = module.data_restore.cloudsql_private_ip
  capella_connection_string = var.capella_connection_string

  pps_health_namespace              = var.pps_health_namespace
  pps_health_image                  = var.pps_health_image
  services_namespace                = var.services_namespace
  convergence_tolerate_missing_jobs = var.convergence_tolerate_missing_jobs
  image_pull_secret_name            = var.image_pull_secret_name
  argocd_ignore_differences         = var.argocd_ignore_differences

  database_gate         = module.data_restore.database_completed
  deferred_applications = var.deferred_applications

  # The restored Applications carry the source site's Capella cluster in their
  # Helm parameters; these let Phase 6 rewrite it before anything syncs.
  # capella_connection_string is already passed above.
  couchbase_username                = var.couchbase_username
  couchbase_password                = var.couchbase_password
  capella_foreign_usernames         = var.capella_foreign_usernames
  capella_password_parameters       = var.capella_password_parameters
  convergence_tolerate_applications = var.convergence_tolerate_applications
}

# Phase 7 - Ingress reuse-or-create, TLS, DNS change request for PPS.
# Phase 7 - Ingress, TLS and the DNS change request.
#
# ingress_dns_enabled turns the whole phase off. dns_change_request_enabled
# turns off only the hand-off that asks PPS to repoint production DNS, which is
# the normal setting for a drill: the ingress, its address and its certificate
# are all created, and PPS makes the DNS change by hand afterwards.
module "ingress_dns" {
  count  = var.ingress_dns_enabled ? 1 : 0
  source = "./modules/70-ingress-dns"
  # Deliberately NO module-level depends_on. It applies to every resource in
  # the module, so depending on module.app_services made the ingress and its
  # certificate wait for the deferred Application and the database restore -
  # which silently undid the whole point of the split. The two gates below are
  # threaded values, so each resource waits for exactly what it needs:
  # wave1_gate for the ingress, full_gate for the DNS hand-off.

  ingress_namespace = var.ingress_namespace
  ingress_class     = var.ingress_class
  dr_hostnames      = var.dr_hostnames
  pps_cert_file     = var.pps_cert_file
  pps_key_file      = var.pps_key_file
  tls_secret_name   = var.tls_secret_name
  backend_services  = var.backend_services
  ingress_names     = var.ingress_names

  backend_timeout_seconds  = var.backend_timeout_seconds
  backend_timeout_services = var.backend_timeout_services

  ingress_manifest_file = var.ingress_manifest_file == "" ? "" : (startswith(var.ingress_manifest_file, "/") ? var.ingress_manifest_file : "${path.root}/${var.ingress_manifest_file}")
  kubeconfig_path       = var.kubeconfig_path
  internal_ingress_vips = var.internal_ingress_vips
  dr_subnetwork         = var.dr_subnetwork
  dr_region             = var.dr_region
  project_id            = var.project_id

  wave1_gate = module.app_services.wave1_released
  full_gate  = module.app_services.completed

  # LoadBalancer Services live outside the ingress namespace too - the LDAP
  # chart publishes one, and so does notification-service - and each leaves
  # GCP forwarding rules that block the cluster delete.
  ingress_teardown_service_namespaces = distinct(concat(
    [var.ingress_namespace, var.ldap_namespace, var.services_namespace],
    var.app_namespaces,
  ))

  dns_change_request_enabled = var.dns_change_request_enabled

  # So DR workloads reach this site through its own hostnames, not production's.
  endpoint_redirects        = var.endpoint_redirects
  dns_redirect_namespace    = var.platform_namespace
  external_ingress_vip_name = var.external_ingress_vip_name
}

# Phase 8 - Graceful restart + validation + sign-off.
#
# Off by default and not part of the one-shot build: every check here goes
# through the public hostnames, which only resolve to this site once PPS has
# made the DNS change. Run it afterwards, either by setting
# validation_enabled = true or with
#   tofu apply -target=module.validation -var-file=pps-dr.tfvars
# Stage 8: the QA readiness probes, run against the workloads that exist on DR.
# Needs no DNS, so it runs in the main apply rather than with Phase 8.
module "healthchecks" {
  count  = var.healthchecks_enabled ? 1 : 0
  source = "./modules/75-healthchecks"

  kubeconfig_path = var.kubeconfig_path
  catalog_file    = "${path.module}/modules/75-healthchecks/healthchecks.json"
  probe_image     = var.healthchecks_probe_image
  timeout_seconds = var.healthchecks_timeout_seconds
  skip_workloads  = var.healthchecks_skip_workloads
  fail_on_error   = var.healthchecks_fail_on_error

  gate = join(",", [module.app_services.completed, join(",", module.ingress_dns[*].completed)])
}

module "validation" {
  count  = var.validation_enabled ? 1 : 0
  source = "./modules/80-validation"

  kubeconfig_path       = var.kubeconfig_path
  app_namespaces        = var.app_namespaces
  argocd_namespace      = var.argocd_namespace
  post_restart_services = var.post_restart_services

  health_check_endpoints        = var.health_check_endpoints
  oidc_discovery_url            = var.oidc_discovery_url
  oidc_validation_client_id     = var.oidc_validation_client_id
  oidc_validation_client_secret = var.oidc_validation_client_secret

  capella_connection_string = var.capella_connection_string
  capella_buckets           = var.capella_buckets
  couchbase_username        = var.couchbase_username
  couchbase_password        = var.couchbase_password

  cloudsql_instance_name   = var.cloudsql_instance_name
  cloudsql_private_ip      = var.cloudsql_private_ip
  cloudsql_database_name   = var.cloudsql_database_name
  cloudsql_import_user     = var.cloudsql_import_user
  cloudsql_import_password = var.cloudsql_import_password

  dr_hostnames              = var.dr_hostnames
  readiness_timeout_seconds = var.readiness_timeout_seconds
  signoff_report_path       = var.signoff_report_path
}
