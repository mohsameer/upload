terraform {
  required_version = ">= 1.9.0"

  # New prefix for the v2 rewrite. The v1 state at "terraform/state" is left
  # untouched so the previous DR automation stays rollback-able.
  #
  # Bucket moved to dr-icrypto-gke-iac (single "a" - was dr-icrypto-gke-iaac)
  # per PPS instruction during the DR drill, 2026-09-10.
  backend "gcs" {
    bucket = "dr-icrypto-gke-iac"
    prefix = "terraform/state-v2"
  }

  required_providers {
    google = {
      source  = "hashicorp/google"
      version = "~> 6.0"
    }
    null = {
      source  = "hashicorp/null"
      version = "~> 3.2"
    }
    time = {
      source  = "hashicorp/time"
      version = "~> 0.12"
    }
    local = {
      source  = "hashicorp/local"
      version = "~> 2.5"
    }
    external = {
      source  = "hashicorp/external"
      version = "~> 2.3"
    }
  }
}
