#!/usr/bin/env bash
# Clean rebuild, unattended: tear down whatever is in state, then build the
# whole site, re-applying until the site reports healthy.
#
# Used when a previous attempt left something half-created - a node pool whose
# instances were refused leaves the cluster in ERROR with zero nodes, and GKE
# will not heal that by itself.
#
# A wave is one `tofu apply`. Several waves can be needed because a failed
# provisioner leaves its resource tainted but everything it did persists, so
# the next wave resumes instead of restarting.
set -uo pipefail

REPO="${REPO:-/home/kusha/pps-dr-iaac}"
RUNDIR="${RUNDIR:-/home/kusha/dr-build}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
LOG="${RUNDIR}/rebuild-${STAMP}.log"
REPORT="${RUNDIR}/timings-${STAMP}.txt"
MAX_WAVES="${MAX_WAVES:-4}"
HEALTH_WAIT="${HEALTH_WAIT:-900}"
# Applications the site is allowed to be healthy without, and their workloads.
# Must match convergence_tolerate_applications in the tfvars: tolerating an
# Application there while demanding every pod be ready here would still fail
# every wave. Named, never a blanket count, so the exception stays visible.
HEALTH_TOLERATE_APPS="${HEALTH_TOLERATE_APPS:-oidc-mgmt-portal}"

mkdir -p "${RUNDIR}"
cd "${REPO}" || exit 1
set -a; . /home/kusha/pps-dr-secrets/tfvars.env; set +a
export KUBECONFIG="${KUBECONFIG:-/home/kusha/.kube/config}"

stamp() { awk '{ printf "%s %s\n", strftime("[%H:%M:%S]"), $0; fflush() }'; }
say() { echo "[$(date -u +%H:%M:%S)] $*" >> "${LOG}"; }

unhealthy_apps() {
  local json
  json=$(kubectl -n argocd get applications.argoproj.io -o json 2>/dev/null) || return 1
  printf '%s' "${json}" \
    | jq -r --arg tolerate "${HEALTH_TOLERATE_APPS}" \
        '($tolerate | split(" ") | map(select(length > 0))) as $ok
         | if (.items | length) == 0 then "no-apps"
           else [ .items[]
                  | select(.status.health.status != "Healthy")
                  | .metadata.name as $n
                  | select([ $ok[] | select(. == $n) ] | length == 0)
                  | "\($n)=\(.status.health.status // "?")" ] | join(" ")
           end' 2>/dev/null
}

# A tolerated Application's pods are named after it but not identically, so
# ownership is matched on the name's prefix - the same rule wait_converged.sh
# uses.
notready_pods() {
  kubectl get pods -A --no-headers 2>/dev/null \
    | awk -v tolerate="${HEALTH_TOLERATE_APPS}" '
        BEGIN { n = split(tolerate, t, " ") }
        {
          split($3, r, "/")
          if (r[1] == r[2] || $4 == "Completed" || $4 == "Succeeded") next
          for (i = 1; i <= n; i++)
            if (t[i] != "" && ($2 == t[i] || index($2, t[i] "-") == 1)) next
          c++
        }
        END { print c+0 }'
}

# Apps keep syncing after the apply returns, so give the site a window to
# settle before calling the wave a failure.
site_healthy() {
  local deadline=$(( $(date -u +%s) + HEALTH_WAIT )) bad pods
  while :; do
    bad=$(unhealthy_apps)
    pods=$(notready_pods)
    if [[ -n "${bad}" && "${bad}" != "no-apps" ]]; then
      say "health: not Healthy -> ${bad}; ${pods} pods not ready"
    elif [[ "${bad}" == "no-apps" ]]; then
      say "health: argocd reports no applications"
    elif [[ "${pods}" != "0" ]]; then
      say "health: all apps Healthy but ${pods} pods not ready"
    else
      say "health: all applications Healthy, all pods ready"
      return 0
    fi
    [[ "$(date -u +%s)" -lt "${deadline}" ]] || { say "health: gave up after ${HEALTH_WAIT}s"; return 1; }
    sleep 30
  done
}

# TRACE=1 records where the apply spends the ten minutes it burns before
# creating anything: 5m08s computing the plan and 5m16s between the plan and
# the first resource. Private Google Access and IPv6 have both been ruled out
# by measurement, so this needs the provider's own log.
if [[ "${TRACE:-0}" == "1" ]]; then
  export TF_LOG=INFO
  export TF_LOG_PATH="${RUNDIR}/tofu-trace-${STAMP}.log"
fi

{
  echo "=== clean rebuild ${STAMP} ==="
  tofu version | head -1
  echo
} > "${LOG}"

# --- teardown ---------------------------------------------------------------
gcloud storage rm gs://dr-icrypto-gke-iac/terraform/state-v2/default.tflock >/dev/null 2>&1
say "=== DESTROY ==="
D_START=$(date -u +%s)
# Cloud SQL survives the destroy, so empty its databases first, while the
# cluster that can reach it still exists.
"$(dirname "$0")/dr_empty_postgres.sh" 2>&1 | stamp >> "${LOG}"
tofu destroy -input=false -no-color -auto-approve -var-file=pps-dr.tfvars 2>&1 | stamp >> "${LOG}"
D_RC=${PIPESTATUS[0]}
D_END=$(date -u +%s)
echo "destroy rc=${D_RC} elapsed=$(( D_END - D_START ))s" >> "${LOG}"

if [[ "${D_RC}" -ne 0 ]]; then
  echo "[$(date -u +%H:%M:%S)] destroy failed; not building on top of a half-torn-down site" >> "${LOG}"
  say "=== FINISHED rc=${D_RC} ==="
  "$(dirname "$0")/dr_phase_timings.sh" "${LOG}" "$(( D_END - D_START ))" "${D_RC}" > "${REPORT}" 2>&1
  exit "${D_RC}"
fi

# --- build ------------------------------------------------------------------
WAVE_SUMMARY=()
A_START=$(date -u +%s)
WAVE_RC=1
for (( wave = 1; wave <= MAX_WAVES; wave++ )); do
  gcloud storage rm gs://dr-icrypto-gke-iac/terraform/state-v2/default.tflock >/dev/null 2>&1
  say "=== APPLY wave ${wave}/${MAX_WAVES} ==="
  W_START=$(date -u +%s)
  tofu apply -input=false -no-color -auto-approve -var-file=pps-dr.tfvars 2>&1 | stamp >> "${LOG}"
  W_RC=${PIPESTATUS[0]}
  W_END=$(date -u +%s)
  say "wave ${wave} apply rc=${W_RC} elapsed=$(( W_END - W_START ))s"

  if [[ "${W_RC}" -eq 0 ]] && site_healthy; then
    WAVE_SUMMARY+=("wave ${wave}: $(( (W_END - W_START) / 60 ))m $(( (W_END - W_START) % 60 ))s rc=0 healthy")
    WAVE_RC=0
    break
  fi

  WAVE_SUMMARY+=("wave ${wave}: $(( (W_END - W_START) / 60 ))m $(( (W_END - W_START) % 60 ))s rc=${W_RC} not healthy")
  if [[ -s /tmp/dr-phase-failures.log ]]; then
    say "recorded phase failures:"
    sed 's/^/    /' /tmp/dr-phase-failures.log >> "${LOG}"
  fi
  [[ "${wave}" -lt "${MAX_WAVES}" ]] || { say "out of waves after ${MAX_WAVES} attempts"; break; }
  say "re-applying: a tainted provisioner resumes from what the last wave already created"
  sleep 30
done
A_END=$(date -u +%s)
say "build finished rc=${WAVE_RC} after ${#WAVE_SUMMARY[@]} wave(s)"
echo "[$(date -u +%FT%TZ)] finished" >> "${LOG}"
say "=== FINISHED rc=${WAVE_RC} ==="

"$(dirname "$0")/dr_phase_timings.sh" "${LOG}" "$(( A_END - A_START ))" "${WAVE_RC}" > "${REPORT}" 2>&1
{
  echo
  echo "destroy: $(( (D_END - D_START) / 60 ))m $(( (D_END - D_START) % 60 ))s (rc=${D_RC})"
  printf '%s\n' "${WAVE_SUMMARY[@]+${WAVE_SUMMARY[@]}}"
  echo "build:   $(( (A_END - A_START) / 60 ))m $(( (A_END - A_START) % 60 ))s (rc=${WAVE_RC})"
  echo "log:     ${LOG}"
} >> "${REPORT}"
exit "${WAVE_RC}"
