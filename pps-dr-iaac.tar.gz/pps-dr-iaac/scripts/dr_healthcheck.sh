#!/usr/bin/env bash
# Run the DR healthchecks on demand, without OpenTofu.
#
# The same checks stage 8 runs in the apply: QA's readiness probes
# (modules/75-healthchecks/healthchecks.json), against the workloads that are
# deployed on DR. A workload that is not deployed, or scaled to 0, is skipped.
#
#   scripts/dr_healthcheck.sh                       # everything in the catalog
#   SKIP_WORKLOADS="oidc-mgmt-portal" scripts/dr_healthcheck.sh
#   TIMEOUT_SECONDS=30 scripts/dr_healthcheck.sh    # fail faster
#
# Exits non-zero if a deployed workload's check fails.
set -uo pipefail

REPO="${REPO:-/home/kusha/pps-dr-iaac}"
export KUBECONFIG="${KUBECONFIG:-/home/kusha/.kube/config}"
export CATALOG="${CATALOG:-${REPO}/modules/75-healthchecks/healthchecks.json}"
export REPORT_PATH="${REPORT_PATH:-${REPO}/.dr-run/healthcheck-report.json}"
export PROBE_IMAGE="${PROBE_IMAGE:-docker.io/curlimages/curl:8.10.1}"
export TIMEOUT_SECONDS="${TIMEOUT_SECONDS:-60}"

exec "${REPO}/modules/75-healthchecks/healthchecks.sh"
