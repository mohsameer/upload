#!/usr/bin/env bash
# Live progress for a DR build, rebuild or destroy: overall percentage, what is
# done / running / pending, and an early warning for a phase that has failed.
#
# OpenTofu prints a provisioner's error only once every in-flight resource has
# finished. On a DR build the longest resource is the midpoint restore, so a
# failure in Phase 2 or Phase 5 stays invisible for up to an hour while the log
# shows nothing but "Still creating..." - and the apply is already doomed.
# Measured on 2026-10-12: vault_init failed at 14:39:45 and the error surfaced
# at 15:33:34; capella_engines failed at 17:39:47 and nothing said so.
#
# So alongside the progress bar this flags a resource that logged "Creating..."
# but has been silent for STALE seconds (it has exited, and since OpenTofu has
# not printed its completion, it exited non-zero), and shows the reasons the
# restore scripts record themselves in /tmp/dr-phase-failures.log.
#
#   scripts/dr_watch.sh                     # newest build / rebuild / destroy log
#   scripts/dr_watch.sh <log> [stale_secs]
#
# Safe to Ctrl-C and re-run at any time: it only reads the log.
set -uo pipefail

RUNDIR="${RUNDIR:-/home/kusha/dr-build}"
LOG="${1:-$(ls -t "${RUNDIR}"/{build,rebuild,destroy}-*.log 2>/dev/null | head -n1)}"
STALE="${2:-150}"
FAILURES="${FAILURES:-/tmp/dr-phase-failures.log}"

[[ -n "${LOG}" && -r "${LOG}" ]] || { echo "usage: $0 <apply-log> [stale_seconds]" >&2; exit 1; }

# shellcheck source=lib/dr_progress.sh
. "$(dirname "$0")/lib/dr_progress.sh"

[[ -t 1 ]] || echo "watching ${LOG} (a resource silent for ${STALE}s is reported as failed)"
dr_progress_follow "${LOG}" "${STALE}" "${POLL:-}" "${FAILURES}"
rc=$?
echo "log: ${LOG}"
exit "${rc}"
