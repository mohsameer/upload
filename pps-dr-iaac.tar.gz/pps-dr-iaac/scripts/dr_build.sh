#!/usr/bin/env bash
# One-shot, unattended DR build: phases 0-7 in a single tofu apply.
#
# Detached from any terminal (setsid in the launcher), every line timestamped,
# and a per-phase timing report written at the end - the run is meant to be
# read the next morning, not watched.
#
# Phase 8 stays off (validation_enabled = false): its checks resolve the public
# hostnames, which point here only after PPS makes the DNS change.
set -uo pipefail

REPO="${REPO:-/home/kusha/pps-dr-iaac}"
RUNDIR="${RUNDIR:-/home/kusha/dr-build}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
LOG="${RUNDIR}/build-${STAMP}.log"
REPORT="${RUNDIR}/timings-${STAMP}.txt"

mkdir -p "${RUNDIR}"
cd "${REPO}" || exit 1
set -a; . /home/kusha/pps-dr-secrets/tfvars.env; set +a
export KUBECONFIG="${KUBECONFIG:-/home/kusha/.kube/config}"
# Keep the output stream-timestamped rather than buffered in blocks.
export PYTHONUNBUFFERED=1

# A lock left by a killed run blocks the apply; nothing else writes this state.
gcloud storage rm gs://dr-icrypto-gke-iac/terraform/state-v2/default.tflock >/dev/null 2>&1

# TRACE=1 records where the apply spends time before it creates anything. Ten
# minutes of the first build went on nothing visible: 5m08s computing the plan
# and 5m16s between the plan and the first resource. The suspicion is an SDK
# path waiting out a timeout against a public googleapis address - the same gap
# the bastion papers over in /etc/hosts - but it needs evidence, not a guess.
if [[ "${TRACE:-0}" == "1" ]]; then
  export TF_LOG=INFO
  export TF_LOG_PATH="${RUNDIR}/tofu-trace-${STAMP}.log"
  echo "trace: ${TF_LOG_PATH}" >> "${LOG}"
fi

START_EPOCH=$(date -u +%s)
{
  echo "=== one-shot DR build ${STAMP} ==="
  echo "repo: ${REPO}"
  tofu version | head -1
  echo
} > "${LOG}"

# Every line gets a UTC timestamp, which is what makes the phase timings below
# possible: tofu prints its own per-resource durations, but not when each one
# started.
echo "[$(date -u +%H:%M:%S)] === APPLY ===" >> "${LOG}"
tofu apply -input=false -no-color -auto-approve -var-file=pps-dr.tfvars 2>&1 \
  | awk '{ printf "%s %s\n", strftime("[%H:%M:%S]"), $0; fflush() }' >> "${LOG}"
RC=${PIPESTATUS[0]}
END_EPOCH=$(date -u +%s)

echo "apply rc=${RC}" >> "${LOG}"
echo "[$(date -u +%H:%M:%S)] === FINISHED rc=${RC} ===" >> "${LOG}"

# --- per-phase timings -------------------------------------------------------
# One phase per module. First timestamped mention of a module is its start, the
# last its end; tofu's own "Creation complete after" lines give the slowest
# resources inside it.
"$(dirname "$0")/dr_phase_timings.sh" "${LOG}" "$((END_EPOCH - START_EPOCH))" "${RC}" > "${REPORT}" 2>&1

echo
echo "log:     ${LOG}"
echo "timings: ${REPORT}"
echo "watch:   scripts/dr_watch.sh ${LOG}"
exit "${RC}"
