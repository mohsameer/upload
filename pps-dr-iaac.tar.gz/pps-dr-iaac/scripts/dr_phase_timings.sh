#!/usr/bin/env bash
# Turn a timestamped apply log into a per-phase timing report.
#
# Phases are modules. A module's start is the first timestamped line that
# mentions it and its end is the last, so a phase's elapsed time includes the
# waiting its scripts do (restores, readiness gates), which is where the time
# actually goes.
set -uo pipefail
LOG="${1:?usage: dr_phase_timings.sh <log> [total_seconds] [rc]}"
TOTAL="${2:-}"
RC="${3:-}"

# A rebuild log holds the destroy as well, and its lines name the same modules.
# Timing the phases off the whole file charged the destroy's time to Phase 0,
# which is how the first report came out with an 11-minute preflight and
# overlapping phases. Read only what follows the last APPLY marker, so a
# multi-wave build reports the wave that actually finished the site.
WORK="$(mktemp)"
trap 'rm -f "${WORK}"' EXIT
APPLY_LINE=$(grep -n "=== APPLY" "${LOG}" | tail -1 | cut -d: -f1)
if [[ -n "${APPLY_LINE}" ]]; then
  tail -n "+${APPLY_LINE}" "${LOG}" > "${WORK}"
else
  cp "${LOG}" "${WORK}"
fi

declare -A PHASE=(
  [preflight]="0  Preflight"
  [dr_cluster]="1  GKE cluster + node pool"
  [registry_credentials]="1b Registry credentials"
  [platform]="2  Platform (Consul, Vault, LDAP, cert-manager)"
  [data_restore]="3  Data restore (Postgres, Capella, Consul, LDAP)"
  [argocd]="4  Argo CD + backup restore"
  [secrets]="5  Vault config, ESO, app credentials"
  [app_config]="5b Application config"
  [app_services]="6  Application sync + convergence"
  [ingress_dns]="7  Ingress, certificates, DNS request"
  [healthchecks]="8  Healthcheck validation"
  [validation]="9  Sign-off validation (off unless validation_enabled)"
)

echo "=== DR build phase timings ==="
echo "log: ${LOG}"
[[ -n "${RC}" ]] && echo "apply rc: ${RC}"
if [[ -n "${TOTAL}" ]]; then
  printf 'total:    %02d:%02d:%02d\n' $((TOTAL/3600)) $(((TOTAL%3600)/60)) $((TOTAL%60))
fi
echo
printf '%-48s %-10s %-10s %10s\n' "PHASE" "START" "END" "ELAPSED"
printf '%-48s %-10s %-10s %10s\n' "------------------------------------------------" "--------" "--------" "----------"

for key in preflight dr_cluster registry_credentials platform data_restore argocd secrets app_config app_services ingress_dns healthchecks validation; do
  first=$(grep -m1 -E "^\[[0-9:]+\] module\.${key}\." "${WORK}" 2>/dev/null | sed -E 's/^\[([0-9:]+)\].*/\1/')
  last=$(grep -E "^\[[0-9:]+\] module\.${key}\." "${WORK}" 2>/dev/null | tail -1 | sed -E 's/^\[([0-9:]+)\].*/\1/')
  [[ -z "${first}" ]] && continue
  s=$(( $(echo "${first}" | awk -F: '{print $1*3600+$2*60+$3}') ))
  e=$(( $(echo "${last}"  | awk -F: '{print $1*3600+$2*60+$3}') ))
  (( e < s )) && e=$(( e + 86400 ))   # the run crossed midnight UTC
  d=$(( e - s ))
  printf '%-48s %-10s %-10s %7d:%02d\n' "${PHASE[$key]}" "${first}" "${last}" $((d/60)) $((d%60))
done

echo
echo "=== slowest individual resources ==="
# Durations come as 1h2m3s / 4m5s / 6s. Normalised with sed rather than
# gawk's match(str, re, arr), which mawk and BWK awk reject outright.
grep -oE "module\.[^ ]+: (Creation|Modifications) complete after [0-9hms]+" "${WORK}" 2>/dev/null \
  | sed -E 's/: (Creation|Modifications) complete after /  /' \
  | while read -r addr dur; do
      h=$(echo "${dur}" | sed -nE 's/.*[^0-9]?([0-9]+)h.*/\1/p'); h=${h:-0}
      m=$(echo "${dur}" | sed -nE 's/.*[^0-9h]?([0-9]+)m.*/\1/p'); m=${m:-0}
      sec=$(echo "${dur}" | sed -nE 's/.*[^0-9hm]?([0-9]+)s$/\1/p'); sec=${sec:-0}
      printf '%6d  %-72s %s\n' "$(( h*3600 + m*60 + sec ))" "${addr}" "${dur}"
    done \
  | sort -rn | head -20 | cut -c9-

echo
echo "=== errors ==="
grep -E "^\[[0-9:]+\] (Error|╷|│ Error)" "${LOG}" 2>/dev/null | head -20 || true
grep -cE "^\[[0-9:]+\] Error" "${LOG}" 2>/dev/null | sed 's/^/error lines: /'
