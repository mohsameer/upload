#!/usr/bin/env bash
# Progress view for the DR build and destroy runs.
#
# Sourced by dr_watch.sh and dr_destroy.sh. It reads the timestamped apply or
# destroy log - the same one the run writes anyway - and draws:
#
#   - an overall bar: resources done / resources OpenTofu planned, with the
#     number still pending and the number in flight;
#   - one row per phase: done, running or pending, with its own counts;
#   - what is running right now and for how long;
#   - anything that looks failed, without waiting for OpenTofu to say so.
#
# The percentage counts resources, not minutes. A handful of them (the
# midpoint restore, the GKE cluster) take most of the wall clock, so the bar
# can sit still for a long time while one of those runs - which is why the
# in-progress list is shown right under it.
#
# Log conventions it relies on, all written by the run scripts:
#   [HH:MM:SS] === APPLY ... ===     start of a build/wave (resets the view)
#   [HH:MM:SS] === DESTROY ===       start of a destroy (resets the view)
#   [HH:MM:SS] === FINISHED rc=N === the run is over
# and OpenTofu's own "Plan: N to add/destroy" and per-resource lines.

# dr_progress_render <log> [stale_secs] [failures_file] [compact]
dr_progress_render() {
  local log="$1" stale="${2:-150}" failures="${3:-}" compact="${4:-0}"
  local now width color=0
  now=$(date -u +%H:%M:%S)
  width=$(tput cols 2>/dev/null || echo 100)
  [[ "${width}" -gt 140 ]] && width=140
  [[ -t 1 && -z "${NO_COLOR:-}" ]] && color=1

  # shellcheck disable=SC2016
  awk -v now="${now}" -v stale="${stale}" -v width="${width}" -v color="${color}" -v compact="${compact}" -v failures="${failures}" '
    function secs(t,   a) { split(t, a, ":"); return a[1] * 3600 + a[2] * 60 + a[3] }
    function age(t0,   d) { d = secs(now) - secs(t0); if (d < 0) d += 86400; return d }
    function dur(s) {
      if (s < 60) return sprintf("%ds", s)
      if (s < 3600) return sprintf("%dm%02ds", int(s / 60), s % 60)
      return sprintf("%dh%02dm", int(s / 3600), int((s % 3600) / 60))
    }
    function paint(code, text) { return color ? sprintf("\033[%sm%s\033[0m", code, text) : text }
    function reset(   k) {
      split("", started); split("", last); split("", inflight); split("", finished_at)
      split("", pdone); split("", pinfl); split("", pfirst); split("", plast); split("", pseen)
      split("", planned); split("", ptotal); split("", doneaddr); nplanned = 0
      done = 0; total = 0; errors = 0; fin = 0; rc = ""; first = ""
    }
    function phase_of(addr,   rest) {
      if (addr !~ /^module\./) return "root"
      rest = substr(addr, 8)
      match(rest, /^[A-Za-z0-9_-]+/)
      return substr(rest, 1, RLENGTH)
    }
    function bar(pct, w,   n, i, s) {
      n = int(pct * w / 100); s = ""
      for (i = 0; i < n; i++) s = s "█"
      for (; i < w; i++) s = s "░"
      return s
    }
    BEGIN {
      N = split("preflight dr_cluster registry_credentials platform data_restore argocd secrets app_config app_services ingress_dns healthchecks validation root", ORDER, " ")
      LABEL["preflight"] = "0  Preflight"
      LABEL["dr_cluster"] = "1  GKE cluster + node pool"
      LABEL["registry_credentials"] = "1b Registry credentials"
      LABEL["platform"] = "2  Platform (Consul, Vault, LDAP, cert-manager)"
      LABEL["data_restore"] = "3  Data restore (Postgres, Capella, Consul, LDAP)"
      LABEL["argocd"] = "4  Argo CD + backup restore"
      LABEL["secrets"] = "5  Vault config, ESO, app credentials"
      LABEL["app_config"] = "5b Application config"
      LABEL["app_services"] = "6  Application sync + convergence"
      LABEL["ingress_dns"] = "7  Ingress, certificates, DNS request"
      LABEL["healthchecks"] = "8  Healthcheck validation"
      LABEL["validation"] = "9  Sign-off validation"
      LABEL["root"] = "-  Root resources (addresses, buckets)"
      mode = ""; title = ""
      reset()
    }
    FILENAME == failures && failures != "" {
      if (match($0, /^\[[0-9:]+\]/)) {
        ft = substr($0, 2, RLENGTH - 2)
        if (first != "" && secs(ft) >= secs(first)) { nf++; fl[nf] = $0 }
      }
      next
    }
    {
      line = $0; stamp = ""
      if (match(line, /^\[[0-9][0-9]:[0-9][0-9]:[0-9][0-9]\] /)) {
        stamp = substr(line, 2, 8); line = substr(line, 12)
      }
      if (line ~ /^=== (DESTROY|APPLY)/) {
        reset(); nf = 0
        mode = (line ~ /DESTROY/) ? "destroy" : "apply"
        title = line; gsub(/^=== | ===$/, "", title)
        first = stamp
        next
      }
      if (line ~ /^=== FINISHED rc=[0-9]+ ===/) {
        fin = 1; fin_at = stamp; rc = line; sub(/^=== FINISHED rc=/, "", rc); sub(/ ===.*/, "", rc)
        next
      }
      if (first == "" && stamp != "") first = stamp
      if (match(line, /^  # [^ ]+ (will be created|will be destroyed|will be updated in-place|must be replaced|is tainted, so must be replaced)/)) {
        pa = line; sub(/^  # /, "", pa); sub(/ .*/, "", pa)
        if (!(pa in planned)) { planned[pa] = 1; nplanned++; ptotal[phase_of(pa)]++ }
        next
      }
      if (line ~ /^Plan: [0-9]+ to add, [0-9]+ to change, [0-9]+ to destroy/) {
        t = line; gsub(/[^0-9]+/, " ", t); sub(/^ /, "", t); split(t, p, " ")
        if (mode == "") mode = (p[1] + p[2] == 0 && p[3] > 0) ? "destroy" : "apply"
        total = (mode == "destroy") ? p[3] : p[1] + p[2]
        next
      }
      if (line ~ /^(Error:|│ Error:)/) errors++
      if (match(line, /^[^ ]+: (Creating|Modifying|Destroying)\.\.\.( |$)/)) {
        addr = line; sub(/: .*/, "", addr)
        if (mode == "") mode = (line ~ /Destroying/) ? "destroy" : "apply"
        ph = phase_of(addr); pseen[ph] = 1
        if (!(addr in inflight)) { inflight[addr] = 1; pinfl[ph]++ }
        started[addr] = stamp; last[addr] = stamp
        if (!(ph in pfirst)) pfirst[ph] = stamp
        plast[ph] = stamp
        next
      }
      if (match(line, /^[^ ]+: Still (creating|modifying|destroying)\.\.\./)) {
        addr = line; sub(/: .*/, "", addr)
        last[addr] = stamp
        next
      }
      if (match(line, /^[^ ]+: (Creation|Modifications|Destruction) complete after /)) {
        addr = line; sub(/: .*/, "", addr)
        ph = phase_of(addr); pseen[ph] = 1
        if (addr in inflight) { delete inflight[addr]; pinfl[ph]-- }
        # A replaced resource logs a destruction and then a creation; it is one
        # unit of work, finished by the second line (apply) or the first (destroy).
        counts = (mode == "destroy") ? (line ~ /Destruction complete/) : (line !~ /Destruction complete/)
        if (counts && !(addr in doneaddr)) { doneaddr[addr] = 1; pdone[ph]++; done++ }
        plast[ph] = stamp
        if (!(ph in pfirst)) pfirst[ph] = stamp
        next
      }
    }
    END {
      if (mode == "") mode = "apply"
      ninfl = 0; for (a in inflight) ninfl++
      if (nplanned > 0) total = nplanned
      pending = total - done - ninfl; if (pending < 0) pending = 0
      el_total = (first == "") ? 0 : age(first)
      if (fin && fin_at != "" && first != "") { el_total = secs(fin_at) - secs(first); if (el_total < 0) el_total += 86400 }
      if (fin && rc == 0 && total > 0 && done < total) done = total   # destroyed/created resources the log did not echo
      pct = (total > 0) ? int(100 * done / total) : 0
      if (pct > 100) pct = 100
      if (!fin && pct > 99) pct = 99
      verb = (mode == "destroy") ? "DESTROY" : "BUILD"
      if (fin) state = (rc == 0) ? paint("32", "FINISHED OK") : paint("31", "FINISHED rc=" rc)
      else state = paint("33", "running")

      # Resources silent for too long. OpenTofu prints a provisioner error only
      # after every in-flight resource drains, so silence is the early signal.
      nst = 0
      for (a in inflight) if (age(last[a]) > stale) { nst++; stl[nst] = a }

      if (compact) {
        cur = ""
        for (i = 1; i <= N; i++) { k = ORDER[i]; if ((k in pinfl) && pinfl[k] > 0) cur = cur (cur == "" ? "" : ",") k }
        if (total > 0) printf "[%s] %s %d%% (%d/%d done, %d pending, %d running) elapsed %s phase: %s%s\n", now, verb, pct, done, total, pending, ninfl, dur(el_total), (cur == "" ? "-" : cur), (fin ? " " rc : "")
        else printf "[%s] %s planning... elapsed %s\n", now, verb, dur(el_total)
        for (i = 1; i <= nst; i++) printf "  LIKELY FAILED (silent %ds): %s\n", age(last[stl[i]]), stl[i]
        exit
      }

      ttl = (title == "DESTROY" || title == "APPLY" || title == "") ? "" : "(" title ")  "
      printf "%s\n", paint("1", sprintf(" PPS DR %s", verb)) "  " ttl state
      printf " elapsed %s   %s UTC\n\n", dur(el_total), now
      bw = width - 40; if (bw > 50) bw = 50; if (bw < 12) bw = 12
      if (total > 0) {
        printf " %s  %s\n", paint(fin && rc != 0 ? "31" : "32", bar(pct, bw)), paint("1", sprintf("%3d%%", pct))
        printf " %d done  ·  %d in progress  ·  %d pending  ·  %d total\n\n", done, ninfl, pending, total
      } else if (fin) {
        printf " %s  100%%  (nothing to do)\n\n", bar(100, bw)
      } else {
        printf " %s  planning - no resource has started yet, OpenTofu is computing the plan\n\n", bar(0, bw)
      }

      printf " %-3s %-52s %-9s %5s %9s\n", "", "PHASE", "STATE", "DONE", "TIME"
      for (j = 1; j <= N; j++) {
        i = (mode == "destroy") ? N - j + 1 : j
        k = ORDER[i]
        if ((k == "validation" || k == "root") && !(k in pseen) && !(k in ptotal)) continue
        if (nplanned > 0 && !(k in ptotal) && !(k in pseen)) {
          printf " %s  %-52s %s\n", paint("2", "-"), paint("2", LABEL[k]), paint("2", "unchanged")
          continue
        }
        if (k in pseen) {
          if (pinfl[k] > 0) { sym = paint("33", "▶"); st = paint("33", "running  ") }
          else { sym = paint("32", "✔"); st = paint("32", "done     ") }
          t = (pinfl[k] > 0) ? age(pfirst[k]) : (secs(plast[k]) - secs(pfirst[k]))
          if (t < 0) t += 86400
          extra = sprintf("%d", pdone[k] + 0)
          if (ptotal[k] > 0) extra = extra "/" ptotal[k]
          else if (pinfl[k] > 0) extra = extra "+" pinfl[k]
          if (pinfl[k] == 0 && ptotal[k] > pdone[k]) { sym = paint("33", "▶"); st = paint("33", "running  ") }
          printf " %s  %-52s %s %5s %9s\n", sym, LABEL[k], st, extra, dur(t)
        } else {
          printf " %s  %-52s %s %5s\n", paint("2", "·"), paint("2", LABEL[k]), paint("2", "pending  "), (ptotal[k] > 0 ? "0/" ptotal[k] : "")
        }
      }

      if (ninfl > 0) {
        printf "\n %s\n", paint("1", "In progress")
        shown = 0
        for (a in inflight) {
          if (shown >= 8) break
          shown++
          nm = a; maxw = width - 16
          if (length(nm) > maxw) nm = "…" substr(nm, length(nm) - maxw + 2)
          printf "   %s %8s\n", sprintf("%-" maxw "s", nm), dur(age(started[a]))
        }
        if (ninfl > 8) printf "   … and %d more\n", ninfl - 8
      }
      if (nst > 0) {
        printf "\n %s\n", paint("31", "⚠ LIKELY FAILED - no output for over " stale "s (OpenTofu reports the error only after the rest drain):")
        for (i = 1; i <= nst; i++) printf "   %s  (silent %s)\n", stl[i], dur(age(last[stl[i]]))
      }
      if (nf > 0) {
        printf "\n %s\n", paint("31", "Recorded failures")
        for (i = (nf > 5 ? nf - 4 : 1); i <= nf; i++) printf "   %s\n", substr(fl[i], 1, width - 4)
      }
      if (errors > 0) printf "\n %s\n", paint("31", sprintf("%d Error: line(s) in the log - grep -n Error: <log>", errors))
    }
  ' "${log}" ${failures:+"${failures}"}
}

# dr_progress_state <log>  ->  prints "finished <rc>" or "running"
dr_progress_state() {
  local last
  last=$(grep -E '=== (DESTROY|APPLY[^=]*|FINISHED rc=[0-9]+) ===|^apply rc=[0-9]+' "$1" 2>/dev/null | tail -n1)
  case "${last}" in
    *"=== FINISHED rc="*) echo "finished $(sed -E 's/.*FINISHED rc=([0-9]+).*/\1/' <<<"${last}")" ;;
    "apply rc="*) echo "finished ${last#apply rc=}" ;;
    *) echo running ;;
  esac
}

# dr_progress_follow <log> [stale_secs] [poll_secs] [failures_file]
# Redraws until the run records its end. Returns the run's rc.
dr_progress_follow() {
  local log="$1" stale="${2:-150}" poll="${3:-}" failures="${4:-}" state rc
  if [[ -t 1 ]]; then
    poll="${poll:-3}"
    printf '\033[?25l\033[2J'
    trap 'printf "\033[?25h\n"' RETURN
    while :; do
      printf '\033[H'
      dr_progress_render "${log}" "${stale}" "${failures}" 0 | sed 's/$/\x1b[K/'
      printf '\033[J'
      state=$(dr_progress_state "${log}")
      [[ "${state}" == finished* ]] && break
      sleep "${poll}"
    done
    rc="${state#finished }"
    return "${rc:-0}"
  fi
  # Not a terminal (a pipe or a file): one summary line per poll instead of a
  # screen redraw, so it stays readable in a log.
  poll="${poll:-30}"
  while :; do
    dr_progress_render "${log}" "${stale}" "${failures}" 1
    state=$(dr_progress_state "${log}")
    [[ "${state}" == finished* ]] && break
    sleep "${poll}"
  done
  rc="${state#finished }"
  return "${rc:-0}"
}
