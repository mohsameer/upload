#!/usr/bin/env bash
# Keep 127.0.0.1:8200 on the bastion pointed at the DR Vault.
#
# pps-dr.tfvars sets vault_address = http://127.0.0.1:8200 and every vault
# service is ClusterIP, so the terraform vault provider in phase 5 has nothing
# to talk to unless this forward is up. kubectl port-forward dies whenever the
# target pod restarts, so it is supervised rather than run once.
#
# Start it before phase 5 (and before phase 8, which also talks to Vault):
#   setsid bash scripts/vault_portforward.sh >/dev/null 2>&1 &
# Then confirm:
#   curl -s http://127.0.0.1:8200/v1/sys/seal-status | jq .sealed   # false
#
# Give Vault an internal load balancer and point vault_address at it to make
# this unnecessary.
set -uo pipefail

NAMESPACE="${NAMESPACE:-persistent}"
SERVICE="${SERVICE:-svc/vault-active}"
PORT="${PORT:-8200}"
LOG="${LOG:-${HOME}/dr-run2/vault-portforward.log}"
export KUBECONFIG="${KUBECONFIG:-${HOME}/.kube/config}"

mkdir -p "$(dirname "${LOG}")"
echo "[$(date -u +%FT%TZ)] supervisor starting for ${NAMESPACE}/${SERVICE}:${PORT}" >>"${LOG}"

while true; do
  kubectl -n "${NAMESPACE}" port-forward "${SERVICE}" "${PORT}:8200" >>"${LOG}" 2>&1
  echo "[$(date -u +%FT%TZ)] port-forward exited rc=$?; restarting in 5s" >>"${LOG}"
  sleep 5
done
