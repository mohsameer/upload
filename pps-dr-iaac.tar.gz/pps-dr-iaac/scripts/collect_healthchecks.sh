#!/usr/bin/env bash
# Build the DR healthcheck catalog from a reference cluster (QA).
#
# For every Deployment and StatefulSet in the given namespaces it takes the
# container's readiness probe (else liveness, else startup) - the endpoint the
# service itself says means "healthy" - resolves a named port to its number,
# and finds the ClusterIP Service in front of it. The result is the list
# modules/75-healthchecks runs against the DR cluster.
#
#   scripts/collect_healthchecks.sh [output.json]
#
# Environment:
#   KUBECTL      command that reaches the reference cluster. Default: kubectl.
#                For QA from a laptop, through its bastion:
#                  KUBECTL='ssh -i <key> kushal@10.200.110.99 kubectl --context gke-qa-az1'
#   NAMESPACES   space-separated. Default: "services default authn".
#   SOURCE_NAME  label recorded in the file. Default: reference.
#   EXCLUDE_WORKLOADS  space-separated workload names left out of the catalog.
#                Default: "pps-pub pps-sub".
#   WORKLOAD_RENAMES   space-separated reference=dr names, for a workload that is
#                called something else on DR. Default: "pps-health=pps-health-deployment"
#                (QA names it pps-health; production and DR pps-health-deployment, so
#                without this it was skipped on DR as "not deployed").
#
# Workloads without an HTTP or exec probe are listed on stderr and left out; a
# check that no probe backs would be a guess.
set -euo pipefail

OUT="${1:-$(dirname "$0")/../modules/75-healthchecks/healthchecks.json}"
KUBECTL="${KUBECTL:-kubectl}"
NAMESPACES="${NAMESPACES:-services default authn}"
SOURCE_NAME="${SOURCE_NAME:-reference}"
EXCLUDE_WORKLOADS="${EXCLUDE_WORKLOADS:-pps-pub pps-sub}"
WORKLOAD_RENAMES="${WORKLOAD_RENAMES:-pps-health=pps-health-deployment}"

command -v jq >/dev/null || { echo "ERROR: jq is required" >&2; exit 1; }

TMP=$(mktemp -d)
trap 'rm -rf "${TMP}"' EXIT

# One program, applied per namespace: workloads + services in, checks out.
cat >"${TMP}/catalog.jq" <<'JQ'
def cport(c; p):
  if (p | type) == "number" then p
  else ((c.ports // []) | map(select(.name == p)) | .[0].containerPort) end;

(.items | map(select(.kind == "Service"
                     and .spec.type != "LoadBalancer"
                     and .spec.clusterIP != "None"
                     and .spec.selector != null))) as $svcs
| .items[]
| select(.kind == "Deployment" or .kind == "StatefulSet")
| . as $w
| ($w.spec.template.metadata.labels // {}) as $labels
| $w.spec.template.spec.containers[]
| . as $c
| ($c.readinessProbe // $c.livenessProbe // $c.startupProbe) as $probe
| select($probe != null)
| if $probe.httpGet then
    ($probe.httpGet.port) as $rawport
    | (cport($c; $rawport)) as $port
    | (($c.ports // []) | map(select(.containerPort == $port)) | .[0].name) as $pname
    | ($svcs
       | map(select(.spec.selector | to_entries | all(. as $e | $labels[$e.key] == $e.value)))
       | map({name: .metadata.name,
              port: (.spec.ports
                     | map(select(.targetPort == $rawport or .targetPort == $port or (.targetPort == $pname and $pname != null)))
                     | .[0].port)})
       | map(select(.port != null))
       | sort_by(.name != $w.metadata.name, .name) | .[0]) as $svc
    | {
        namespace: $w.metadata.namespace,
        workload: $w.metadata.name,
        kind: $w.kind,
        container: $c.name,
        type: "http",
        scheme: (($probe.httpGet.scheme // "HTTP") | ascii_upcase),
        port: $port,
        path: ($probe.httpGet.path // "/"),
        service: ($svc.name // null),
        service_port: ($svc.port // null),
        reference_replicas: ($w.spec.replicas // 1)
      }
  elif $probe.exec then
    {
      namespace: $w.metadata.namespace,
      workload: $w.metadata.name,
      kind: $w.kind,
      container: $c.name,
      type: "exec",
      command: $probe.exec.command,
      reference_replicas: ($w.spec.replicas // 1)
    }
  else empty end
JQ

: >"${TMP}/all.ndjson"
for ns in ${NAMESPACES}; do
  # shellcheck disable=SC2086
  ${KUBECTL} -n "${ns}" get deploy,sts,svc -o json >"${TMP}/${ns}.json"
  jq -c -f "${TMP}/catalog.jq" "${TMP}/${ns}.json" \
    | jq -c --arg ex "${EXCLUDE_WORKLOADS}" --arg rn "${WORKLOAD_RENAMES}" '
        select(.workload as $w | ($ex | split(" ") | index($w)) == null)
        | ($rn | split(" ") | map(select(length > 0) | split("=") | {key: .[0], value: .[1]}) | from_entries) as $map
        | .workload = ($map[.workload] // .workload)' >>"${TMP}/all.ndjson"

  jq -r --arg ns "${ns}" '
    ([.items[] | select(.kind == "Deployment" or .kind == "StatefulSet")
      | select([.spec.template.spec.containers[] | (.readinessProbe // .livenessProbe // .startupProbe)] | all(. == null))
      | .metadata.name] | unique) as $none
    | if ($none | length) > 0 then "no probe, not checked (" + $ns + "): " + ($none | join(", ")) else empty end
  ' "${TMP}/${ns}.json" >&2
done

mkdir -p "$(dirname "${OUT}")"
jq -s --arg source "${SOURCE_NAME}" --arg at "$(date -u +%Y-%m-%dT%H:%M:%SZ)" '
  {
    source: $source,
    collected_at: $at,
    note: "Generated by scripts/collect_healthchecks.sh from the reference cluster'"'"'s own readiness probes. reference_replicas is informational. Edit by re-collecting, not by hand.",
    checks: (sort_by(.namespace, .workload, .container))
  }' "${TMP}/all.ndjson" >"${OUT}"

echo "wrote $(jq '.checks | length' "${OUT}") checks to ${OUT}" >&2
