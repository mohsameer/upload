#!/usr/bin/env bash
# data.external wrapper: describe a GCS object via gcloud (fast, cached auth).
# Avoids Terraform's native google_storage_bucket_object, which goes through
# oauth2.googleapis.com per refresh and intermittently times out from this
# bastion.
#
# Input (stdin, JSON): {"uri": "gs://...", "credentials_file": "/path/to/key"}
# Output (stdout, JSON): {"generation": "<num>", "size": "<bytes>"}
set -eu

payload=$(cat)
uri=$(echo "${payload}" | jq -r '.uri')
creds=$(echo "${payload}" | jq -r '.credentials_file // ""')

if [[ -z "${uri}" || "${uri}" != gs://* ]]; then
  echo "{\"error\": \"bad uri: ${uri}\"}" >&2
  exit 1
fi

for attempt in 1 2 3; do
  if [[ -n "${creds}" ]]; then
    out=$(CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE="${creds}" \
      timeout 60 gcloud storage objects describe "${uri}" --format='value(generation,size)' 2>&1) && break
  else
    out=$(timeout 60 gcloud storage objects describe "${uri}" --format='value(generation,size)' 2>&1) && break
  fi
  [[ ${attempt} -lt 3 ]] && sleep $((attempt * 3))
done

if [[ -z "${out:-}" ]] || ! echo "${out}" | awk 'NR==1{if($1 && $2) exit 0; exit 1}'; then
  echo "{\"error\": \"describe failed for ${uri}: ${out}\"}" >&2
  exit 1
fi

gen=$(echo "${out}" | awk 'NR==1{print $1}')
size=$(echo "${out}" | awk 'NR==1{print $2}')
jq -nc --arg g "${gen}" --arg s "${size}" '{generation:$g, size:$s}'
