#!/usr/bin/env bash
# Collect a complete DR restore set from production into one prefix.
#
# Run this ON THE PROD BASTION. It produces everything modules/30-data-restore
# expects, under a single prefix, with the object names the DR tfvars use:
#
#   <prefix>/consul/consul-kv-export.json
#   <prefix>/ldap/ldap-config-backup.ldif
#   <prefix>/ldap/ldap-secauth-backup.ldif
#   <prefix>/ldap/ldap-data-backup.ldif
#   <prefix>/argocd/argocd-backup.tar.gz
#   <prefix>/postgresql/<database>.dump.d/        (pg_dump -Fd -j, PG_MODE=pod)
#   <prefix>/postgresql/<database>.dump.tar       (same, PG_UPLOAD_MODE=tar)
#   <prefix>/postgresql/<database>.dump           (pg_dump -Fc, PG_MODE=bastion)
#   <prefix>/couchbase/capella.tar.gz
#
# The names carry no date, so the DR tfvars reference them once and never need
# editing after a run. Terraform still notices a new backup: it tracks each
# object's GCS generation, not its name. Each run overwrites the previous set,
# so enable object versioning on the bucket if history matters.
#
# Consul, LDAP and Argo CD are produced by triggering PPS's own backup
# CronJobs rather than reimplementing them, so the dumps are made exactly the
# way the scheduled backups make them. Two of those schedules are infrequent
# (consul monthly, argocd monthly), which is why they are triggered here
# instead of taking whatever happens to be in the bucket.
#
# No cluster-wide globals dump: pg_dumpall reads pg_authid, which the Cloud SQL
# postgres user cannot select, and nothing needs it - every database is dumped
# individually with --no-owner --no-acl, so a restore does not depend on the
# source roles existing.
#
# Everything this script does to production is read-only except creating Jobs
# from existing CronJobs. It writes only to the target bucket prefix.
set -euo pipefail

BUCKET="${BUCKET:-pps-k8s-prod-backups}"
PREFIX="${PREFIX:-pps-dr-iac-restore}"
AZ="${AZ:-az1}"
DATE="$(date -u +%Y-%m-%d)"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
WAIT_SECONDS="${WAIT_SECONDS:-1800}"

AZ1_CTX="${AZ1_CTX:-gke_pps-analytics-189714_europe-west1-d_pps-prod-icrypto-az1}"
COMMON_CTX="${COMMON_CTX:-gke_pps-analytics-189714_europe-west1-b_pps-prod-icrypto-common-services}"
CRON_NS="${CRON_NS:-cron}"

# Postgres is the one component with no backup CronJob, so it is dumped here.
# The connection is discovered from the running idm deployment and the password
# from Vault, so nothing has to be pasted into a shell. gcloud cannot be used
# to find the instance: the bastion service account has no sqladmin permission.
PG_DUMP_JOBS="${PG_DUMP_JOBS:-4}"

# How the dump is taken.
#
#   pod      - a Job in the production cluster dumps with pg_dump -Fd -j, onto
#              a throwaway PVC, and streams the result to the bucket. Several
#              COPY streams run at once, which is the only thing that makes a
#              225GB database finish in under an hour.
#   bastion  - pg_dump -Fc piped straight to the bucket from this host. No
#              cluster objects and no disk, but one COPY stream: measured at
#              ~0.5-2 GB/min, so midpoint alone takes about 4.5 hours.
#
# Both produce a dump pg_restore can load with several workers; only the dump
# side differs. The bastion cannot do the parallel dump itself: -Fd has to
# write a directory and midpoint's is ~100GB against 92GB free here.
PG_MODE="${PG_MODE:-pod}"
PG_POD_NAMESPACE="${PG_POD_NAMESPACE:-${CRON_NS}}"
PG_POD_DISK="${PG_POD_DISK:-250Gi}"
PG_POD_STORAGE_CLASS="${PG_POD_STORAGE_CLASS:-premium-rwo}"
# pg_dump must not be older than the server (PostgreSQL 16.13 in production).
PG_POD_DUMP_IMAGE="${PG_POD_DUMP_IMAGE:-postgres:16-alpine}"
PG_POD_UPLOAD_IMAGE="${PG_POD_UPLOAD_IMAGE:-google/cloud-sdk:slim}"
# The bucket credentials the scheduled backups already use, mounted read-only.
PG_POD_CRED_SECRET="${PG_POD_CRED_SECRET:-backup-cred-sa}"
PG_POD_CRED_KEY="${PG_POD_CRED_KEY:-sa_cred}"
PG_POD_PROJECT="${PG_POD_PROJECT:-pps-analytics-189714}"
PG_POD_TIMEOUT="${PG_POD_TIMEOUT:-10800}"

# How the dump travels to the bucket.
#
#   dir  - the pg_dump -Fd directory, object per file, under <db>.dump.d/.
#          One object per table means the restore downloads it with many
#          parallel streams instead of one: a single 117GB tar staged at
#          40 MB/s, which was the restore's bottleneck.
#   tar  - one <db>.dump.tar object. Fewer objects, one stream.
PG_UPLOAD_MODE="${PG_UPLOAD_MODE:-dir}"

# Tables dumped without their rows: the schema, indexes and constraints still
# go into the archive, the data does not (pg_dump --exclude-table-data).
# Space-separated name prefixes, so one entry covers a partitioned table and
# all of its partitions - the same spelling the restore side's
# EXCLUDE_TABLE_DATA takes, in modules/30-data-restore/psql_restore.sh, except
# that a prefix here matches any relation whose name starts with it rather than
# only the table itself and its <prefix>_* children:
#
#   PG_EXCLUDE_TABLE_DATA=m_audit bash collect_dr_restore_set.sh
#
# Empty by default, and deliberately so: an unset run is a full dump, and no
# run can silently produce a partial backup because somebody changed a
# default. Set it only for a dump taken to rebuild the DR site.
#
# Why it exists. Measured on production: midpoint is 173GB, of which the audit
# tables are 168GB - 97%. m_audit_delta is 136GB across a parent and 100
# partitions, m_audit_event 16GB the same way, m_audit_item 16GB, with
# m_audit_prop_value, m_audit_ref_value and m_audit_resource a few MB between
# them. Everything the DR site actually authenticates with is the remaining
# ~5GB. The restore already refuses to load any of it: psql_restore.sh drops
# every matching TABLE DATA entry from pg_restore's table of contents. But the
# archive still carried it - 117GB, and downloading it was 57 of a 68-minute
# rebuild. Excluding the rows at dump time makes the archive ~5GB, so the time
# is not spent moving bytes that were going to be filtered out on arrival.
#
# The tradeoff, stated plainly because nothing in the bucket states it: a dump
# taken this way can never restore audit history. The object names carry no
# marker, so a set collected with this on is a DR rebuild set, not a backup of
# production. Leave it unset for anything that is meant to be a full copy.
#
# Two patterns per prefix, because the partitions are not named the way they
# look. midPoint creates them with the schema spelled into the relation name,
# so schema public holds a table literally called
# "public.m_audit_delta_132500000". pg_dump reads a pattern with psql's \d
# rules: an unquoted dot separates the schema pattern from the table pattern,
# and double quotes make everything inside them literal - wildcards included,
# which is why the trailing * sits outside the quotes:
#
#   public.m_audit*            -> schema public, relname m_audit%
#                                 (the parents, and any normally named child)
#   public."public.m_audit"*   -> schema public, relname public.m_audit%
#                                 (the ~200 partitions)
#
# A pattern that matches nothing is not an error for pg_dump unless
# --strict-names is given, so the same flags are passed for every database and
# simply do nothing on idpv3 and oidc-mgmt-portal.
PG_EXCLUDE_TABLE_DATA="${PG_EXCLUDE_TABLE_DATA:-}"

# Rendered once into the three shapes the dump needs. All three stay empty
# unless PG_EXCLUDE_TABLE_DATA is set, so the default pg_dump command line is
# character for character the one it was before this option existed.
#
#   PG_EXCLUDE_OPTS  - spliced into the Job manifest's pg_dump line. Each
#                      pattern is single-quoted there so the pod's shell hands
#                      pg_dump the double quotes and the * untouched instead of
#                      globbing them. It carries its own leading space.
#   PG_EXCLUDE_FLAGS - the same flags as argv, for PG_MODE=bastion.
#   PG_EXCLUDE_NOTE  - the pattern list, printed by the Job before it dumps.
PG_EXCLUDE_OPTS=""
PG_EXCLUDE_FLAGS=()
PG_EXCLUDE_NOTE=""
for _prefix in ${PG_EXCLUDE_TABLE_DATA}; do
  for _pat in "public.${_prefix}*" "public.\"public.${_prefix}\"*"; do
    PG_EXCLUDE_OPTS+=" --exclude-table-data='${_pat}'"
    PG_EXCLUDE_FLAGS+=("--exclude-table-data=${_pat}")
    PG_EXCLUDE_NOTE+="${PG_EXCLUDE_NOTE:+ }${_pat}"
  done
done
unset _prefix _pat

IDM_NAMESPACE="${IDM_NAMESPACE:-services}"
IDM_DEPLOY="${IDM_DEPLOY:-idm-server-v2}"
VAULT_NAMESPACE="${VAULT_NAMESPACE:-persistent}"
VAULT_DB_PATH="${VAULT_DB_PATH:-secret/idm/db-passwd}"
VAULT_DB_FIELD="${VAULT_DB_FIELD:-value}"
AUTHN_NAMESPACE="${AUTHN_NAMESPACE:-authn}"

DEST="gs://${BUCKET}/${PREFIX}"
WORKDIR="$(mktemp -d)"
trap 'rm -rf "${WORKDIR}"' EXIT

log()  { echo "[$(date -u +%H:%M:%S)] $*"; }
fail() { echo "ERROR: $*" >&2; exit 1; }

# Which stages to run. A run that stopped partway can be resumed without
# retaking what is already in the bucket - which matters for postgresql, where
# midpoint alone is a 225GB dump:
#
#   STAGES="argocd postgresql couchbase" bash collect_dr_restore_set.sh
STAGES="${STAGES:-consul ldap argocd postgresql couchbase}"
want() { [[ " ${STAGES} " == *" $1 "* ]]; }

need() { command -v "$1" >/dev/null 2>&1 || fail "$1 is not on this host"; }
need gcloud; need kubectl; need jq

# --- trigger one CronJob and wait for it --------------------------------------
run_cronjob() {
  local ctx="$1" cronjob="$2" job="${2}-dr-${STAMP}"

  kubectl --context "${ctx}" -n "${CRON_NS}" get cronjob "${cronjob}" >/dev/null 2>&1 \
    || fail "cronjob/${cronjob} not found in ${CRON_NS} on ${ctx}"

  log "triggering ${cronjob} as job/${job}"
  kubectl --context "${ctx}" -n "${CRON_NS}" create job "${job}" --from="cronjob/${cronjob}" >/dev/null

  local deadline=$((SECONDS + WAIT_SECONDS))
  while [[ ${SECONDS} -lt ${deadline} ]]; do
    local ok failed
    ok=$(kubectl --context "${ctx}" -n "${CRON_NS}" get job "${job}" -o jsonpath='{.status.succeeded}' 2>/dev/null || true)
    failed=$(kubectl --context "${ctx}" -n "${CRON_NS}" get job "${job}" -o jsonpath='{.status.failed}' 2>/dev/null || true)
    if [[ "${ok:-0}" -ge 1 ]]; then
      log "${job} succeeded"
      kubectl --context "${ctx}" -n "${CRON_NS}" delete job "${job}" >/dev/null 2>&1 || true
      return 0
    fi
    if [[ "${failed:-0}" -ge 1 ]]; then
      kubectl --context "${ctx}" -n "${CRON_NS}" logs "job/${job}" --tail=40 >&2 || true
      fail "${job} failed; the backup was not taken"
    fi
    sleep 15
  done
  fail "${job} did not finish within ${WAIT_SECONDS}s"
}

# --- newest object under a prefix --------------------------------------------
newest() {
  gcloud storage ls -l "$1" 2>/dev/null \
    | grep -vE "TOTAL:|/$" | sort -k2 | tail -n1 | awk '{print $NF}'
}

# --- dump one database from inside the cluster --------------------------------
# A Job rather than a bare pod: a Job records success or failure, which is what
# this script waits on. The password travels in a Secret that is deleted
# afterwards, never in argv, so it stays out of the pod spec and out of ps.
PG_POD_PVC=""
PG_POD_SECRET=""
pg_pod_cleanup() {
  [[ -n "${PG_POD_SECRET}" ]] && kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" \
    delete secret "${PG_POD_SECRET}" --ignore-not-found >/dev/null 2>&1
  [[ -n "${PG_POD_PVC}" ]] && kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" \
    delete pvc "${PG_POD_PVC}" --ignore-not-found >/dev/null 2>&1
  return 0
}

pg_pod_setup() {
  PG_POD_PVC="dr-pgdump-${STAMP}"
  PG_POD_SECRET="dr-pgdump-cred-${STAMP}"
  trap 'pg_pod_cleanup; rm -rf "${WORKDIR}"' EXIT

  kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" get secret "${PG_POD_CRED_SECRET}" >/dev/null 2>&1 \
    || fail "secret/${PG_POD_CRED_SECRET} not found in ${PG_POD_NAMESPACE}; it holds the bucket credentials"

  log "creating secret/${PG_POD_SECRET} and pvc/${PG_POD_PVC} (${PG_POD_DISK}, ${PG_POD_STORAGE_CLASS})"
  kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" create secret generic "${PG_POD_SECRET}" \
    --from-literal=password="${PGPASSWORD}" >/dev/null

  kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" apply -f - >/dev/null <<PVC
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: ${PG_POD_PVC}
spec:
  accessModes: [ReadWriteOnce]
  storageClassName: ${PG_POD_STORAGE_CLASS}
  resources:
    requests:
      storage: ${PG_POD_DISK}
PVC
}

pg_pod_dump() {
  local db="$1" dest="$2"
  # Database names are already DNS-safe here, but a name with an underscore
  # would make an invalid Job name.
  local safe job
  safe=$(echo "${db}" | tr '[:upper:]_.' '[:lower:]--' | cut -c1-30)
  job="dr-pgdump-${safe}-${STAMP}"

  log "Job/${job}: pg_dump -Fd -j ${PG_DUMP_JOBS} ${db} -> ${dest}"
  kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" apply -f - >/dev/null <<JOB
apiVersion: batch/v1
kind: Job
metadata:
  name: ${job}
spec:
  backoffLimit: 0
  template:
    spec:
      restartPolicy: Never
      volumes:
        - name: dump
          persistentVolumeClaim:
            claimName: ${PG_POD_PVC}
        - name: creds
          secret:
            secretName: ${PG_POD_CRED_SECRET}
      initContainers:
        # The dump has to finish before the upload starts, which is exactly
        # what an initContainer gives: ordering, on one shared volume.
        - name: dump
          image: ${PG_POD_DUMP_IMAGE}
          command: ["sh", "-ec"]
          args:
            - |
              rm -rf /dump/${db}
              [ -z "\${PG_EXCLUDE_NOTE}" ] || echo "excluding TABLE DATA for patterns: \${PG_EXCLUDE_NOTE} (schema kept, rows not dumped)"
              pg_dump -h "\${PG_HOST}" -U "\${PG_USER}" -d "\${PG_DB}" -Fd -j ${PG_DUMP_JOBS} --no-owner --no-acl${PG_EXCLUDE_OPTS} -f "/dump/\${PG_DB}"
              du -sh "/dump/\${PG_DB}"
          env:
            - { name: PG_HOST, value: "${PG_HOST}" }
            - { name: PG_USER, value: "${PG_USER}" }
            - { name: PG_DB,   value: "${db}" }
            # Single-quoted YAML: the patterns contain double quotes.
            - { name: PG_EXCLUDE_NOTE, value: '${PG_EXCLUDE_NOTE}' }
            - name: PGPASSWORD
              valueFrom:
                secretKeyRef:
                  name: ${PG_POD_SECRET}
                  key: password
          volumeMounts:
            - { name: dump, mountPath: /dump }
          resources:
            requests: { cpu: "1", memory: 1Gi }
            limits:   { cpu: "${PG_DUMP_JOBS}", memory: 2Gi }
      containers:
        - name: upload
          image: ${PG_POD_UPLOAD_IMAGE}
          command: ["sh", "-ec"]
          args:
            - |
              gcloud auth activate-service-account --key-file=/creds/${PG_POD_CRED_KEY} >/dev/null
              if [ "\${UPLOAD_MODE}" = "dir" ]; then
                # Object per dump file. gcloud copies them in parallel, and the
                # restore side downloads them in parallel too - which is the
                # point: one tar is one stream at both ends.
                gcloud storage cp -r "/dump/\${PG_DB}/*" "\${DEST_URI}/"
              else
                # Streamed, so the tarball never doubles the disk the dump
                # needs. No gzip: a -Fd dump's files are already compressed.
                tar -cf - -C /dump "\${PG_DB}" | gcloud storage cp - "\${DEST_URI}"
              fi
              echo "uploaded \${DEST_URI}"
          env:
            - { name: PG_DB,                value: "${db}" }
            - { name: DEST_URI,             value: "${dest}" }
            - { name: UPLOAD_MODE,          value: "${PG_UPLOAD_MODE}" }
            - { name: CLOUDSDK_CORE_PROJECT, value: "${PG_POD_PROJECT}" }
          volumeMounts:
            - { name: dump,  mountPath: /dump }
            - { name: creds, mountPath: /creds, readOnly: true }
          resources:
            requests: { cpu: 500m, memory: 1Gi }
            limits:   { cpu: "2",  memory: 2Gi }
JOB

  local deadline=$((SECONDS + PG_POD_TIMEOUT)) ok failed phase last=""
  while [[ ${SECONDS} -lt ${deadline} ]]; do
    ok=$(kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" get job "${job}" -o jsonpath='{.status.succeeded}' 2>/dev/null || true)
    failed=$(kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" get job "${job}" -o jsonpath='{.status.failed}' 2>/dev/null || true)
    if [[ "${ok:-0}" -ge 1 ]]; then
      kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" logs "job/${job}" --all-containers --tail=5 2>/dev/null | sed 's/^/    /' || true
      kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" delete job "${job}" --ignore-not-found >/dev/null 2>&1 || true
      log "  ${db} done"
      return 0
    fi
    if [[ "${failed:-0}" -ge 1 ]]; then
      kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" logs "job/${job}" --all-containers --tail=40 >&2 2>/dev/null || true
      fail "Job/${job} failed; nothing uploaded for ${db}"
    fi
    # One line per phase change, so a multi-hour dump does not fill the log.
    phase=$(kubectl --context "${AZ1_CTX}" -n "${PG_POD_NAMESPACE}" get pods -l "job-name=${job}" \
      -o jsonpath='{.items[0].status.phase}/{.items[0].status.initContainerStatuses[0].state.*.reason}' 2>/dev/null || true)
    if [[ "${phase}" != "${last}" ]]; then
      log "  ${db}: ${phase}"
      last="${phase}"
    fi
    sleep 30
  done
  fail "Job/${job} did not finish within ${PG_POD_TIMEOUT}s"
}

log "destination: ${DEST}"

# The database dumps stream straight to the bucket and need no local
# disk. The Capella archive and the LDAP tarball do land here, so check there
# is room rather than filling the root filesystem of a production bastion.
AVAIL_MB=$(df -Pm "${WORKDIR}" | awk 'NR==2{print $4}')
MIN_FREE_MB="${MIN_FREE_MB:-20480}"
if [[ "${AVAIL_MB:-0}" -lt "${MIN_FREE_MB}" ]]; then
  fail "only ${AVAIL_MB}MB free on $(df -P "${WORKDIR}" | awk 'NR==2{print $6}'); need ${MIN_FREE_MB}MB for the Capella and LDAP archives. Set TMPDIR to a larger filesystem or raise MIN_FREE_MB."
fi
log "free space for staging: ${AVAIL_MB}MB"

if want consul; then
# --- Consul -------------------------------------------------------------------
log "=== consul ==="
run_cronjob "${AZ1_CTX}" pps-k8s-backup-consul
SRC="$(newest "gs://${BUCKET}/consul/${AZ}/")"
[[ -n "${SRC}" ]] || fail "no consul backup found under gs://${BUCKET}/consul/${AZ}/"
log "copying ${SRC}"
# Renamed to the object name the DR tfvars expect.
gcloud storage cp "${SRC}" "${DEST}/consul/consul-kv-export.json"

fi

if want ldap; then
# --- LDAP ---------------------------------------------------------------------
log "=== ldap ==="
run_cronjob "${AZ1_CTX}" pps-k8s-backup-ldap
SRC="$(newest "gs://${BUCKET}/ldap/${AZ}/")"
[[ -n "${SRC}" ]] || fail "no ldap backup found under gs://${BUCKET}/ldap/${AZ}/"
log "expanding ${SRC}"
# The CronJob produces one tarball; the DR restore loads three separate LDIFs.
gcloud storage cp "${SRC}" "${WORKDIR}/ldap.tar.gz"
mkdir -p "${WORKDIR}/ldap" && tar -xzf "${WORKDIR}/ldap.tar.gz" -C "${WORKDIR}/ldap"
for want in config secauth data; do
  f=$(find "${WORKDIR}/ldap" -type f -name "*${want}*.ldif" | head -n1)
  [[ -n "${f}" ]] || fail "the ldap tarball has no ${want} LDIF"
  gcloud storage cp "${f}" "${DEST}/ldap/ldap-${want}-backup.ldif"
  log "  ldap-${want}-backup.ldif ($(wc -c <"${f}") bytes)"
done

fi

# --- LDAP TLS certificate (opt-in) ----------------------------------------------
# Not in the default STAGES: this copies production LDAP's PRIVATE KEY into the
# bucket. The certificate is self-signed, generated once (2025-07-01) and valid to
# 2035, so it has to be collected once, not on every run:
#   STAGES=ldaptls bash collect_dr_restore_set.sh
# modules/30-data-restore/ldap_tls_restore.sh installs these three files on the DR
# LDAP so DR serves the certificate every client of production already pins.
if want ldaptls; then
log "=== ldaptls ==="
LDAP_NS="${LDAP_NS:-ldap-v2}"
LDAP_POD_PROD="${LDAP_POD_PROD:-ldap-openldap-0}"
LDAP_CERT_DIR="${LDAP_CERT_DIR:-/opt/bitnami/openldap/certs}"
TLSDIR="${WORKDIR}/ldaptls"; mkdir -p "${TLSDIR}"; chmod 700 "${TLSDIR}"
( umask 077
  for f in openldap.crt openldap.key openldapCA.crt; do
    kubectl --context "${AZ1_CTX}" -n "${LDAP_NS}" exec "${LDAP_POD_PROD}" -c openldap -- cat "${LDAP_CERT_DIR}/${f}" > "${TLSDIR}/${f}" \
      || fail "could not read ${f} from ${LDAP_POD_PROD}"
    [[ -s "${TLSDIR}/${f}" ]] || fail "${f} is empty"
  done )
cm=$(openssl x509 -in "${TLSDIR}/openldap.crt" -noout -modulus | openssl md5)
km=$(openssl rsa -in "${TLSDIR}/openldap.key" -noout -modulus 2>/dev/null | openssl md5)
[[ "${cm}" == "${km}" ]] || fail "the LDAP key does not match its certificate"
for f in openldap.crt openldap.key openldapCA.crt; do
  gcloud storage cp "${TLSDIR}/${f}" "${DEST}/ldap/tls/${f}" >/dev/null
  log "  ldap/tls/${f}"
done
log "  certificate $(openssl x509 -in "${TLSDIR}/openldap.crt" -noout -fingerprint -sha256)"
shred -u "${TLSDIR}"/* 2>/dev/null || true
fi

if want argocd; then
# --- Argo CD ------------------------------------------------------------------
log "=== argocd ==="
run_cronjob "${COMMON_CTX}" pps-k8s-backup-argocd
SRC="$(newest "gs://${BUCKET}/argocd/${AZ}/")"
[[ -n "${SRC}" ]] || fail "no argocd backup found under gs://${BUCKET}/argocd/${AZ}/"
log "copying ${SRC}"
gcloud storage cp "${SRC}" "${DEST}/argocd/argocd-backup.tar.gz"

fi

# --- PostgreSQL ---------------------------------------------------------------
# Connection details come from the deployment that uses them, so they cannot
# drift from what midPoint actually connects to. Both postgres stages call
# this, so a resumed run rediscovers them the same way.
idm_env() {
  kubectl --context "${AZ1_CTX}" -n "${IDM_NAMESPACE}" get deploy "${IDM_DEPLOY}" -o json 2>/dev/null \
    | jq -r --arg n "$1" '.spec.template.spec.containers[0].env[]? | select(.name == $n) | .value // empty'
}

pg_discover() {
  PG_HOST="${PG_HOST:-$(idm_env REPO_HOST)}"
  PG_DATABASE="${PG_DATABASE:-$(idm_env REPO_DATABASE)}"
  PG_USER="${PG_USER:-$(idm_env REPO_USER)}"
  [[ -n "${PG_HOST}" ]] || return 1
  log "discovered ${PG_USER}@${PG_HOST}/${PG_DATABASE}"

  # The password is written into the idm pod at runtime by its init container,
  # which fetches it from Vault, so Vault is the authoritative source.
  if [[ -z "${PGPASSWORD:-}" ]]; then
    VAULT_TOKEN_VALUE=$(kubectl --context "${AZ1_CTX}" -n "${IDM_NAMESPACE}" \
      get secret vault-root-token -o jsonpath='{.data.token}' 2>/dev/null | base64 -d)
    [[ -n "${VAULT_TOKEN_VALUE}" ]] || fail "no vault-root-token in ${IDM_NAMESPACE}; export PGPASSWORD instead"
    VAULT_POD=$(kubectl --context "${AZ1_CTX}" -n "${VAULT_NAMESPACE}" get pods \
      -l app.kubernetes.io/name=vault -o jsonpath='{.items[0].metadata.name}' 2>/dev/null)
    [[ -n "${VAULT_POD}" ]] || fail "no Vault pod in ${VAULT_NAMESPACE}"
    PGPASSWORD=$(kubectl --context "${AZ1_CTX}" -n "${VAULT_NAMESPACE}" exec -c vault "${VAULT_POD}" -- \
      sh -c "VAULT_TOKEN='${VAULT_TOKEN_VALUE}' vault read -field=${VAULT_DB_FIELD} ${VAULT_DB_PATH}" 2>/dev/null)
    export PGPASSWORD
    [[ -n "${PGPASSWORD}" ]] || fail "could not read ${VAULT_DB_PATH} field ${VAULT_DB_FIELD} from Vault"
    log "database password read from Vault ${VAULT_DB_PATH}"
  fi
  return 0
}

if want postgresql; then
log "=== postgresql ==="
if ! pg_discover; then
  log "SKIPPED: could not read REPO_HOST from ${IDM_NAMESPACE}/${IDM_DEPLOY}."
else
  [[ "${PG_MODE}" == "pod" ]] || need pg_dump
  # Every application database, not just midpoint. The instance also holds
  # idpv3 and oidc-mgmt-portal, which earlier backup sets never captured - so a
  # restore from them brought midPoint back and left those two empty.
  if [[ -n "${PG_DATABASES:-}" ]]; then
    DBS="${PG_DATABASES}"
  else
    DBS=$(PGPASSWORD="${PGPASSWORD}" psql -h "${PG_HOST}" -U "${PG_USER}" -d postgres -tAc \
      "SELECT datname FROM pg_database WHERE NOT datistemplate AND datname NOT IN ('postgres','cloudsqladmin') ORDER BY pg_database_size(datname) DESC")
  fi
  [[ -n "${DBS}" ]] || fail "could not enumerate databases on ${PG_HOST}"
  log "databases to dump: $(echo ${DBS} | tr '\n' ' ')"
  if [[ -n "${PG_EXCLUDE_NOTE}" ]]; then
    log "PG_EXCLUDE_TABLE_DATA='${PG_EXCLUDE_TABLE_DATA}': dumping no rows for ${PG_EXCLUDE_NOTE}"
    log "  this set cannot restore that data - it is a DR rebuild set, not a full backup"
  fi

  # Both modes produce something pg_restore can load with several workers,
  # which is what the DR timeline depends on: a plain dump replays through one
  # connection and took 130 minutes for midpoint alone.
  case "${PG_MODE}" in
    pod)
      pg_pod_setup
      for db in ${DBS}; do
        if [[ "${PG_UPLOAD_MODE}" == "dir" ]]; then
          pg_pod_dump "${db}" "${DEST}/postgresql/${db}.dump.d"
          log "  uploaded ${db}.dump.d/ ($(gcloud storage ls "${DEST}/postgresql/${db}.dump.d/**" 2>/dev/null | wc -l) objects)"
        else
          pg_pod_dump "${db}" "${DEST}/postgresql/${db}.dump.tar"
          SIZE=$(gcloud storage ls -l "${DEST}/postgresql/${db}.dump.tar" 2>/dev/null | awk 'NR==1{print $1}')
          log "  uploaded ${db}.dump.tar (${SIZE:-?} bytes)"
        fi
      done
      pg_pod_cleanup
      PG_POD_PVC=""; PG_POD_SECRET=""
      ;;
    bastion)
      for db in ${DBS}; do
        log "pg_dump -Fc ${db} -> ${DEST}/postgresql/${db}.dump"
        # ${arr[@]+"${arr[@]}"}: an empty array expands to nothing here instead
        # of tripping set -u, which bash before 4.4 does for "${arr[@]}".
        if ! pg_dump -h "${PG_HOST}" -U "${PG_USER}" -d "${db}" -Fc --no-owner --no-acl \
             ${PG_EXCLUDE_FLAGS[@]+"${PG_EXCLUDE_FLAGS[@]}"} \
             | gcloud storage cp - "${DEST}/postgresql/${db}.dump"; then
          fail "pg_dump of ${db} failed; nothing uploaded for it"
        fi
        SIZE=$(gcloud storage ls -l "${DEST}/postgresql/${db}.dump" 2>/dev/null | awk 'NR==1{print $1}')
        log "  uploaded ${db}.dump (${SIZE:-?} bytes)"
      done
      ;;
    *) fail "PG_MODE must be pod or bastion, got '${PG_MODE}'" ;;
  esac

fi
fi

if want couchbase; then
# --- Capella ------------------------------------------------------------------
log "=== couchbase (capella) ==="
# Capella connection comes from the authn namespace, which is where oidcv2
# reads it from.
CB_URL=$(kubectl --context "${AZ1_CTX}" -n "${AUTHN_NAMESPACE}" get cm oidcv2-config-cm \
  -o jsonpath='{.data.CN_COUCHBASE_URL}' 2>/dev/null)
CB_USER=$(kubectl --context "${AZ1_CTX}" -n "${AUTHN_NAMESPACE}" get secret oidcv2-loader-capella-secrets \
  -o jsonpath='{.data.cb_user}' 2>/dev/null | base64 -d)
CB_BUCKETS="${CB_BUCKETS:-oidcv2 icrypto_persistent_ha}"
log "capella: ${CB_USER:-<unknown>}@${CB_URL:-<unknown>} buckets: ${CB_BUCKETS}"

# cbbackupmgr ships inside the Couchbase server image, so a container
# provides it on a host that has none installed.
# Fully qualified: podman resolves a short name against its own registry list
# and picks registry.connect.redhat.com, which rejects an anonymous pull.
CB_IMAGE="${CB_IMAGE:-docker.io/couchbase/server:enterprise-7.6.4}"
CB_RUNTIME=""
command -v cbbackupmgr >/dev/null 2>&1 || {
  for r in docker podman; do
    command -v "$r" >/dev/null 2>&1 && "$r" ps >/dev/null 2>&1 && { CB_RUNTIME="$r"; break; }
  done
}

if ! command -v cbbackupmgr >/dev/null 2>&1 && [[ -z "${CB_RUNTIME}" ]]; then
  cat <<'NOTE'
SKIPPED: cbbackupmgr is not installed on this host, so the Capella buckets
cannot be backed up from here. Run it from a host that has it and can reach the
production Capella endpoint, then upload with the object name the DR tfvars
expect, for example:

  cbbackupmgr config  --archive ./cb --repo dr-capella
  cbbackupmgr backup  --archive ./cb --repo dr-capella \
      --cluster couchbases://cb.<prod-cluster>.cloud.couchbase.com \
      --username <user> --password <pass>
  tar -czf capella-<date>.tar.gz -C . cb
  gcloud storage cp capella-<date>.tar.gz \
      gs://<bucket>/<prefix>/couchbase/capella-<date>.tar.gz
NOTE
else
  CB_PASS=$(kubectl --context "${AZ1_CTX}" -n "${AUTHN_NAMESPACE}" get secret oidcv2-loader-capella-secrets \
    -o jsonpath='{.data.cb_pass}' 2>/dev/null | base64 -d)
  [[ -n "${CB_URL}" && -n "${CB_USER}" && -n "${CB_PASS}" ]] || fail "incomplete Capella details in ${AUTHN_NAMESPACE}"

  mkdir -p "${WORKDIR}/cb"
  # --include-data belongs to `config`, not `backup`, and takes one
  # comma-separated list: the repository decides what is in scope, and every
  # backup into it then follows that scope.
  CB_INCLUDE="$(echo "${CB_BUCKETS}" | tr -s " " ",")"

  # The credentials in the authn namespace are a database user: they read
  # bucket data but not cluster-level service metadata, and cbbackupmgr fails
  # the whole backup on "authentication error executing 'GET' request to
  # /api/v1/backup" while transferring Query/FTS metadata. Those definitions
  # are not what the DR restore loads anyway - the restore brings data into
  # buckets that the Argo CD applications have already created with their
  # indexes. Scope the repository to data and let CB_CONFIG_EXTRA override it
  # when a privileged user is available.
  CB_CONFIG_EXTRA="${CB_CONFIG_EXTRA:---disable-cluster-query --disable-bucket-query --disable-ft-indexes --disable-ft-alias --disable-views --disable-eventing --disable-analytics --disable-cluster-analytics}"

  if command -v cbbackupmgr >/dev/null 2>&1; then
    cb() { cbbackupmgr "$@"; }
    log "using the cbbackupmgr on this host"
  else
    # The password is passed through the environment, not argv, so it does not
    # show up in the container's command line or in ps output.
    # --userns=keep-id: rootless podman otherwise maps the container's
    # couchbase user to a subuid that cannot write the bind mount, and
    # cbbackupmgr fails with "failed to lock archive: open /backup/lock.lk:
    # permission denied". :Z relabels the mount for SELinux, which this host
    # enforces.
    cb() {
      "${CB_RUNTIME}" run --rm -i \
        --userns=keep-id \
        -e CB_PASSWORD="${CB_PASS}" \
        -v "${WORKDIR}/cb:/backup:Z" \
        --entrypoint /opt/couchbase/bin/cbbackupmgr \
        "${CB_IMAGE}" "$@"
    }
    log "using cbbackupmgr from ${CB_IMAGE} via ${CB_RUNTIME}"
    "${CB_RUNTIME}" image inspect "${CB_IMAGE}" >/dev/null 2>&1 || "${CB_RUNTIME}" pull "${CB_IMAGE}"
  fi

  ARCHIVE_PATH="${WORKDIR}/cb"
  [[ -n "${CB_RUNTIME}" ]] && ARCHIVE_PATH="/backup"

  # shellcheck disable=SC2086
  cb config --archive "${ARCHIVE_PATH}" --repo dr-capella --include-data "${CB_INCLUDE}" ${CB_CONFIG_EXTRA} >/dev/null
  log "cbbackupmgr backup ${CB_BUCKETS} from ${CB_URL}"
  if [[ -n "${CB_RUNTIME}" ]]; then
    cb backup --archive "${ARCHIVE_PATH}" --repo dr-capella \
      --cluster "${CB_URL}" --username "${CB_USER}" --password "${CB_PASSWORD:-${CB_PASS}}"
  else
    cb backup --archive "${ARCHIVE_PATH}" --repo dr-capella \
      --cluster "${CB_URL}" --username "${CB_USER}" --password "${CB_PASS}"
  fi

  # Streamed, so the tarball never lands next to the archive it is made from.
  tar -czf - -C "${WORKDIR}" cb | gcloud storage cp - "${DEST}/couchbase/capella.tar.gz"
  log "  capella.tar.gz uploaded"
fi

fi

log "=== done ==="
gcloud storage ls -lr "${DEST}/" 2>/dev/null | grep -vE "^$" | tail -20
