#!/usr/bin/env bash
# Empty every user database on the DR Cloud SQL instance, so the next build
# restores into nothing.
#
# Cloud SQL is not managed by this repo and survives a destroy, which means the
# restored data would otherwise sit there until the next build's restore.
# dr_destroy.sh and dr_rebuild.sh run this BEFORE `tofu destroy`: it needs a
# pod inside the DR cluster, because the instance has only a private address
# and the bastion cannot reach it.
#
# Each database is dropped and created again, empty, rather than left out, so
# the instance keeps the same set of names. `postgres`, the templates and
# `cloudsqladmin` are never touched.
#
# Best effort by design: if the cluster is already gone or the instance does
# not answer, it says so and exits 0 so the destroy still goes ahead. The
# restore's own cleanup step (postgres_cleanup_before_restore) is the backstop.
#
#   EMPTY_POSTGRES=no   skip this step
#   DRY_RUN=1           list what would be emptied, change nothing
set -uo pipefail

REPO="${REPO:-/home/kusha/pps-dr-iaac}"
TFVARS="${TFVARS:-${REPO}/pps-dr.tfvars}"
EMPTY_POSTGRES="${EMPTY_POSTGRES:-yes}"
DRY_RUN="${DRY_RUN:-0}"
TIMEOUT_SECONDS="${EMPTY_TIMEOUT_SECONDS:-600}"
PROTECTED="postgres cloudsqladmin template0 template1"

log() { echo "empty-postgres: $*"; }

if [[ "${EMPTY_POSTGRES}" == "no" ]]; then
  log "skipped (EMPTY_POSTGRES=no)"
  exit 0
fi

# Plain `key = "value"` lines only; that is all this needs from the tfvars.
tfv() { sed -nE 's/^[[:space:]]*'"$1"'[[:space:]]*=[[:space:]]*"([^"]*)".*/\1/p' "${TFVARS}" | head -n1; }

PG_HOST="$(tfv cloudsql_private_ip)"
PG_USER="$(tfv cloudsql_import_user)"
NAMESPACE="$(tfv platform_namespace)"; NAMESPACE="${NAMESPACE:-platform}"
CLIENT_IMAGE="$(tfv postgres_client_image)"; CLIENT_IMAGE="${CLIENT_IMAGE:-postgres:16}"
PG_PORT="${PG_PORT:-5432}"
PG_PASSWORD="${TF_VAR_cloudsql_import_password:-}"
export KUBECONFIG="${KUBECONFIG:-/home/kusha/.kube/config}"

if [[ -z "${PG_HOST}" || -z "${PG_USER}" || -z "${PG_PASSWORD}" ]]; then
  log "WARNING: cloudsql_private_ip, cloudsql_import_user or TF_VAR_cloudsql_import_password is missing - databases NOT emptied"
  exit 0
fi

if ! kubectl --request-timeout=20s get ns "${NAMESPACE}" >/dev/null 2>&1; then
  log "WARNING: namespace ${NAMESPACE} not reachable (cluster already gone?) - databases NOT emptied; the next restore's cleanup step will do it"
  exit 0
fi

POD="pg-empty-all"
SECRET="${POD}-cred"
DIR=$(mktemp -d)
finish() {
  kubectl -n "${NAMESPACE}" delete pod "${POD}" --ignore-not-found --wait=false >/dev/null 2>&1 || true
  kubectl -n "${NAMESPACE}" delete secret "${SECRET}" --ignore-not-found >/dev/null 2>&1 || true
  rm -rf "${DIR}"
}
trap finish EXIT

kubectl -n "${NAMESPACE}" delete pod "${POD}" --ignore-not-found >/dev/null 2>&1 || true
kubectl -n "${NAMESPACE}" create secret generic "${SECRET}" --from-literal=PGPASSWORD="${PG_PASSWORD}" \
  --dry-run=client -o yaml >"${DIR}/secret.yaml"
kubectl -n "${NAMESPACE}" apply -f "${DIR}/secret.yaml" >/dev/null || { log "WARNING: could not create the credential secret - databases NOT emptied"; exit 0; }

cat >"${DIR}/pod.yaml" <<YAML
apiVersion: v1
kind: Pod
metadata:
  name: ${POD}
  labels:
    app.kubernetes.io/name: pg-empty
spec:
  restartPolicy: Never
  activeDeadlineSeconds: ${TIMEOUT_SECONDS}
  containers:
    - name: psql
      image: ${CLIENT_IMAGE}
      env:
        - { name: PGHOST, value: "${PG_HOST}" }
        - { name: PGPORT, value: "${PG_PORT}" }
        - { name: PGUSER, value: "${PG_USER}" }
        - { name: DRY_RUN, value: "${DRY_RUN}" }
        - { name: PROTECTED, value: "${PROTECTED}" }
        - name: PGPASSWORD
          valueFrom:
            secretKeyRef: { name: ${SECRET}, key: PGPASSWORD }
      command: ["/bin/bash", "-c"]
      args:
        - |
          set -uo pipefail
          psql -d postgres -tAc 'SELECT 1' >/dev/null || { echo "cannot connect to \${PGHOST}:\${PGPORT} as \${PGUSER}"; exit 2; }
          fail=0
          for db in \$(psql -d postgres -tAc "SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname"); do
            case " \${PROTECTED} " in *" \${db} "*) continue ;; esac
            size=\$(psql -d postgres -tAc "SELECT pg_size_pretty(pg_database_size('\${db}'))")
            if [ "\${DRY_RUN}" = "1" ]; then echo "would empty \${db} (\${size})"; continue; fi
            echo "emptying \${db} (\${size})"
            if psql -d postgres -v ON_ERROR_STOP=1 -c "DROP DATABASE \"\${db}\" WITH (FORCE)" -c "CREATE DATABASE \"\${db}\""; then
              echo "  \${db}: empty"
            else
              echo "  \${db}: FAILED"; fail=1
            fi
          done
          exit \${fail}
YAML

kubectl -n "${NAMESPACE}" apply -f "${DIR}/pod.yaml" >/dev/null || { log "WARNING: could not start the pod - databases NOT emptied"; exit 0; }
log "pod ${POD} in ${NAMESPACE} -> ${PG_HOST}:${PG_PORT} as ${PG_USER}$([[ "${DRY_RUN}" == "1" ]] && echo ' (dry run)')"

deadline=$(( $(date -u +%s) + TIMEOUT_SECONDS ))
phase=""
while :; do
  phase=$(kubectl -n "${NAMESPACE}" get pod "${POD}" -o jsonpath='{.status.phase}' 2>/dev/null || true)
  [[ "${phase}" == "Succeeded" || "${phase}" == "Failed" ]] && break
  [[ "$(date -u +%s)" -lt "${deadline}" ]] || { log "WARNING: timed out after ${TIMEOUT_SECONDS}s"; break; }
  sleep 3
done

kubectl -n "${NAMESPACE}" logs "${POD}" 2>/dev/null | sed 's/^/  /'
if [[ "${phase}" == "Succeeded" ]]; then
  log "done"
else
  log "WARNING: ended ${phase:-unknown} - some databases may not be empty; the next restore's cleanup step will empty them"
fi
exit 0
