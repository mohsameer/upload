#!/usr/bin/env bash
# Tear the DR site down in one pass, with a live progress view.
#
# google_container_cluster no longer carries lifecycle.prevent_destroy: that
# flag cannot be driven by a variable, so leaving it on made a single-pass
# destroy impossible. The guard lives here instead, where it can be explicit.
#
# Not managed by this repo and therefore untouched: Cloud SQL, the Capella
# buckets, the GCS backups, the VPC and the prod KMS key. The reserved ingress
# VIPs are destroyed only once they are in state.
#
# The destroy itself runs in the background and writes a timestamped log; this
# script draws the progress from that log until it finishes. Ctrl-C only stops
# the view: the destroy carries on, and `scripts/dr_watch.sh` picks it up again.
set -uo pipefail

REPO="${REPO:-/home/kusha/pps-dr-iaac}"
RUNDIR="${RUNDIR:-/home/kusha/dr-build}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
LOG="${LOG:-${RUNDIR}/destroy-${STAMP}.log}"

if [[ "${CONFIRM_DESTROY_DR:-}" != "yes" ]]; then
  cat >&2 <<'MSG'
Refusing to destroy the DR site.

This deletes the GKE cluster and every workload on it, including the LDAP and
Consul PVCs, which hold restored data that only exists there. Cloud SQL and
Capella are not managed here and survive.

Re-run with CONFIRM_DESTROY_DR=yes to proceed.
MSG
  exit 2
fi

cd "${REPO}" || exit 1
set -a; . "${TFVARS_ENV:-/home/kusha/pps-dr-secrets/tfvars.env}"; set +a
export KUBECONFIG="${KUBECONFIG:-/home/kusha/.kube/config}"

# shellcheck source=lib/dr_progress.sh
. "$(dirname "$0")/lib/dr_progress.sh"

mkdir -p "$(dirname "${LOG}")"
gcloud storage rm gs://dr-icrypto-gke-iac/terraform/state-v2/default.tflock >/dev/null 2>&1 || true

stamp() { awk '{ printf "%s %s\n", strftime("[%H:%M:%S]"), $0; fflush() }'; }
say() { echo "[$(date -u +%H:%M:%S)] $*" >> "${LOG}"; }

: > "${LOG}"
say "=== DESTROY ==="
{
  # Empty the Cloud SQL databases while the cluster still exists: the instance
  # survives the destroy, and the only way to reach it is from a pod in here.
  "$(dirname "$0")/dr_empty_postgres.sh" 2>&1 | stamp >> "${LOG}"
  # An external address kept across rebuilds (external_ingress_vip_manage =
  # false) is only read, but a site built before that setting still has it in
  # state as a managed resource, and destroy would delete it. Drop it from state
  # first so the address - and PPS's DNS record - survives.
  if grep -Eq '^[[:space:]]*external_ingress_vip_manage[[:space:]]*=[[:space:]]*false' pps-dr.tfvars \
     && tofu state list 2>/dev/null | grep -qxF 'google_compute_global_address.external_ingress[0]'; then
    tofu state rm 'google_compute_global_address.external_ingress[0]' 2>&1 | stamp >> "${LOG}"
    say "external ingress address kept: removed from state, not deleted"
  fi
  tofu destroy -refresh=false -input=false -no-color -auto-approve -var-file=pps-dr.tfvars 2>&1 | stamp >> "${LOG}"
  rc=${PIPESTATUS[0]}
  echo "destroy rc=${rc}" >> "${LOG}"
  say "=== FINISHED rc=${rc} ==="
} &
RUNNER=$!

trap 'echo; echo "view stopped - the destroy is still running (pid ${RUNNER}). Follow it with: scripts/dr_watch.sh ${LOG}"; exit 130' INT

dr_progress_follow "${LOG}" "${STALE:-300}" "${POLL:-}" ""
wait "${RUNNER}" 2>/dev/null
rc=$(sed -nE 's/^destroy rc=([0-9]+).*/\1/p' "${LOG}" | tail -n1)
echo "log: ${LOG}"
exit "${rc:-1}"
