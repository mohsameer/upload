provider "google" {
  project     = var.project_id
  region      = var.dr_region
  credentials = var.gcp_credentials_file
}

# Reads the backup bucket. The PPS backups live in the prod project's bucket,
# which only the prod SA can read, so backup_credentials_file (prod SA key on
# the bastion) is used here; it falls back to gcp_credentials_file when the
# backups are in a DR-readable bucket.
provider "google" {
  alias       = "backups"
  project     = var.project_id
  region      = var.dr_region
  credentials = local.backup_credentials_file
}

locals {
  backup_credentials_file = var.backup_credentials_file != "" ? var.backup_credentials_file : var.gcp_credentials_file
}

# Deliberately no kubernetes, helm or vault provider.
#
# A provider is configured before any resource in the apply runs, so one that
# needs the DR cluster (or the Vault inside it) cannot be configured on a cold
# build - which is what forced the old two-pass procedure
# (tofu apply -target=module.dr_cluster, then the rest). Every Helm release,
# Kubernetes object and Vault setting is applied by kubectl/helm/vault through
# a null_resource instead, so the whole site builds in one `tofu apply` and
# tears down in one `tofu destroy`.
#
# The Capella provider is gone for a different reason: nothing used it. The
# Capella work in Phase 3 goes through the Management API from a script.
