# DR rebuild plan — fresh GKE cluster on the existing `pps-dr` network, prod restore

Status: **PLAN ONLY — nothing mutated.** Written 2026-10-05 after read-only study of the repo
and the live DR project. Supersedes the QA-source assumptions in `DR-DRILL-QA-TO-DR.md`
where they conflict (source is now **PROD backups of 2026-09-11**).

## 0. Ground rules

- All `gcloud` runs on the DR bastion `34.91.152.93` (user `kusha`), active identity
  `icryptogkedr@pps-qa-29102018.iam.gserviceaccount.com`, project `pps-qa-29102018` (PPS - DR).
- Prod bucket reads use the already-configured SA
  `icryptogke-prod@pps-analytics-189714.iam.gserviceaccount.com`
  (`CLOUDSDK_CORE_ACCOUNT=<sa> gcloud storage ...`) — never switch the bastion's active account.
- Cluster deletion is allowed, but only after section 2 is captured **and** the user gives a go.
- Secrets (SA key JSON, DB/Vault/Capella passwords) never go into git, tfvars or this file.

## 1. Study findings

### 1.1 Repo (`feat/pps-dr-iaac-v2`)

8-phase OpenTofu, one module per phase (`modules/00-preflight` … `80-validation`, plus
`15-registry-credentials`). Cluster is created by `modules/10-gke-cluster` when
`create_gke_cluster = true`; **first build is a two-step apply** (`-target=module.dr_cluster`, then full).
State: `gs://dr-icrypto-gke-iac`, prefix `terraform/state-v2`.
The four known defects (B1–B4 in `DR-DRILL-QA-TO-DR.md`, openspec change `dr-drill-fixes`) are still open.

New gaps found against the live cluster (module `10-gke-cluster` would NOT reproduce it):

| # | Live cluster | Module today | Impact |
|---|---|---|---|
| G1 | `networkConfig.datapathProvider: LEGACY_DATAPATH`, network policy addon disabled | not set (provider default may differ by version) | Pin explicitly (`datapath_provider = "LEGACY_DATAPATH"`) or pods/NetworkPolicy behave differently |
| G2 | `resourceLabels: application=sso, owner=devops_team_sso` | no labels | add `resource_labels` |
| G3 | `privateEndpointEnforcementEnabled: true`, public endpoint enabled, DNS endpoint present but `allowExternalTraffic: false` | `enable_private_endpoint=false`; `gcp_public_cidrs_access_enabled=false` only | verify provider produces the same endpoint config; bastion kubeconfig uses the public IP |
| G4 | master authorized nets: `34.91.152.93/32`, `10.200.16.56/32`, `10.112.200.0/24`, **`10.200.100.77/32` (stage-bastion)** | example tfvars / drill doc omit stage-bastion | add it or the STAG bastion loses access |
| G5 | node pool: `autoUpgrade/autoRepair` true, surge 1, `maxPodsPerNode=110`, `shieldedInstanceConfig.enableIntegrityMonitoring=true`, `workloadMetadataConfig=GKE_METADATA`, `insecureKubeletReadonlyPortEnabled=true` | scopes set to `cloud-platform`; live scopes are the narrow default set (`devstorage.read_only`, logging, monitoring, …) | decide: keep narrow scopes (faithful) vs `cloud-platform` (module). Workload Identity is on, so pods use GKE_METADATA |
| G6 | `monitoringConfig.managedPrometheus.enabled`, logging `SYSTEM_COMPONENTS+WORKLOADS`, `hpaProfile=PERFORMANCE`, `dnsCacheConfig`, `releaseChannel=REGULAR`, version 1.35.8 | only channel set | add `monitoring_config`, `logging_config`, `dns_cache_config` or accept defaults |
| G7 | **zonal node placement**: `locations=[europe-west4-a]` on a *regional* cluster (3 nodes, one zone) | `dr_gke_node_locations` | keep `["europe-west4-a"]` for fidelity; flag as an HA decision (single-zone) |
| G8 | secondary ranges are **reserved internal ranges** (`networkconnectivity internalRanges`) named `gke-dr-icrypto-gke-cluster-{pods,services}-c7149c78` | module passes CIDR blocks and lets GKE create new secondary ranges | name collision / "range in use" risk on rebuild — see 3.2 |
| G9 | `ipAllocationPolicy.clusterIpv4Cidr 10.108.0.0/14`, `servicesIpv4Cidr 10.112.0.0/20`, master `10.200.24.0/28` | variables exist | match exactly |

### 1.2 Networking to keep (read-only, confirmed)

- VPC `pps-dr`, subnet `pps-dr` (`europe-west4`): primary `10.200.16.0/22`, `privateIpGoogleAccess: true`,
  secondary `10.112.0.0/20` (services) and `10.108.0.0/14` (pods), both backed by reserved internal ranges.
- Cloud SQL private IP `10.221.111.2` via PSA range `pps-dr-net-ip-range` (`10.221.111.0/24`), `servicenetworking` peering ACTIVE.
- Capella peering `pps-dr-cc-*` (DR Capella resolves to `10.112.200.18` from the bastion).
- GKE master peering `gke-n47e54397e006085ba3c-36bb-896d-peer` is **tied to the old cluster** and disappears
  with it; the new cluster gets a new peering using the same `10.200.24.0/28`.

**Not yet captured (my gcloud batch was interrupted):** firewall rules, Cloud NAT/routers, routes, peerings list,
reserved addresses, bastion/Jumpbox01 VMs. These must be exported in step 2 — they decide whether private nodes
can reach ECR / Docker Hub after the rebuild. Do not delete the cluster before this is saved.

### 1.3 Existing DR workloads (from skill notes; re-verify in step 2)

Namespaces populated since 2024 (`authn`, `argocd`, `bpmn`, `bpmnv2`, `ldap-v2`, `persistent`, `services`, …).
Vault root token: secret `vault-root-token` ns **`default`**. `idm-server-v2` points at Cloud SQL
`cloud-sql.pps.co.za`/`midpoint`, password in Vault `secret/idm/db-passwd`. In-cluster `postgresql-idm2` in
`persistent` is separate. Anything stateful here is lost on delete.

### 1.4 Prod backup set — `gs://pps-k8s-prod-backups/11thseptember2026/` (254.39 GiB, 25 objects)

| Path | Size | Note |
|---|---|---|
| `postgres/midpoint-20260911.sql` | **251.7 GB**, plain SQL, **uncompressed** | DB is `midpoint`, not `idm_db`. Import into Cloud SQL by `gcloud sql import sql`; allow many hours. Needs Cloud SQL service agent `objectViewer` on **the prod bucket** (see 4.3) |
| `couchbase/cb-backup-20260911/oidcv2/oidcv2-export.json` | 1.08 GB | `cbexport` JSON **list**, no doc keys → **`cbimport`** with key mode `jans_dn` (rule verified on 84,902/84,903 QA docs) |
| `couchbase/cb-backup-20260911/icrypto_persistent_ha/…-export.json` | 1.45 GB | **not usable**: keys (`idm_<uuid>`…) not derivable from the body |
| `couchbase/cb-backup-20260911/prod-capella/` | — | `cbbackupmgr` 8.0.3 repo, **failed** (401 on query metadata) — no data |
| `couchbase/prod-gsi-indexes.json`, `prod-index-definitions.sql` | 53 KB / 14 KB | replay via `couchbase_index_definitions_object` (nodes clause stripped, de-duplicated) |
| `icrypto_persistent_ha.tar.gz` | 179 MB | 2026-09-14 **`cbbackupmgr` 7.6.3 repository** (complete, 590 MB unpacked, no archive root) → method **`cbbackupmgr`** (bastion has 7.6.4) |
| `ldap/ldap-{config,data,secauth}-backup.ldif` | 0.5 MB / 104 MB / 110 MB | slapcat; same B3 DB-number caveat |
| consul / argocd / vault | **absent** | not in this folder. Consul (Vault storage!) and Argo CD must come from elsewhere (QA drill bucket or a fresh prod capture) — **open question Q2** |

Implication (implemented): per-bucket methods — `oidcv2 = cbimport` (in-cluster Job, bastion has no `cbimport`),
`icrypto_persistent_ha = cbbackupmgr` (bastion).

**Access:** the DR SA `icryptogkedr@` gets **403** on `gs://pps-k8s-prod-backups`; only the prod SA reads it. Terraform's data
sources and the in-cluster restore Jobs use the DR SA key, so the needed objects must first be **staged into a DR-readable
bucket** (section 5).

## 2. Pre-delete capture — DONE 2026-10-05

Saved on the bastion at `~/dr-config-backup-20261005/` and locally in `.dr-run/config-backup-20261005/` (git-ignored):
`gke-cluster.yaml`, `gke-nodepool.yaml`, `vpc-pps-dr.yaml`, `subnets.yaml`, `firewall-rules.yaml`, `routers.yaml` (Cloud NAT
`cr-1/external` covers all subnets → private nodes have egress), `routes.yaml`, `peerings.yaml`, `addresses.yaml`, `instances.yaml`.
`internal-ranges list` returned nothing.

Original checklist:

1. `gcloud container clusters describe … --format=yaml` (done above; keep file).
2. `gcloud container node-pools describe icrypto-dr-nodepool …`
3. `gcloud compute networks describe pps-dr`, `subnets describe pps-dr` (done), `firewall-rules list --format=yaml`,
   `routers list` + `nats describe`, `routes list`, `networks peerings list`, `addresses list --global`,
   `networkconnectivity internal-ranges list`.
4. `gcloud sql instances list` — blocked by the sqladmin egress problem (D0 in drill doc); retry first.
5. ~~In-cluster workload state~~ — **decided 2026-10-05: nothing in the current cluster is newer than the backups; do not capture workload data.**
   What IS kept as a backup is the *configuration*: cluster + node-pool YAML, VPC/subnet/firewall/NAT/routes/peerings/ranges (items 1–3).
6. Copy the config exports to the local machine (or a GCS path) — the bastion is not durable.

## 3. Rebuild

### 3.1 Repo changes — DONE 2026-10-05 (branch `feat/dr-rebuild-prod-restore`, not pushed)

OpenSpec change `dr-drill-fixes` (validated `--strict`). Implemented:

| Area | Change |
|---|---|
| Phase 1 | fidelity inputs: datapath, labels, OAuth scopes, shielded, workload metadata, logging, managed Prometheus, max pods, private endpoint enforcement, adopt-by-name secondary ranges |
| Phase 3 Postgres | `postgres_restore_method` (`psql_pod` default / `gcloud_sql_import` gated by `allow_gcloud_sql_import`), `cloudsql_private_ip`, `postgres_recreate_database`; `psql_restore.sh` FIFO-streaming Job, psql 17 |
| Phase 3 Couchbase | `couchbase_restore_methods` / `couchbase_backup_objects` / `couchbase_cbimport_key_modes` / `couchbase_index_definitions_object` / `couchbase_expected_doc_counts`; `cbimport_restore.sh`, `capella_indexes.sh`; verify via `:18091` without token |
| Phase 3 LDAP | Bitnami paths, config-first restore into emptied `slapd.d`, secauth `-n 3`, data `-n 2`, proven PPS scale/wipe procedure |
| Phase 4 | every manifest in the tarball applied, server-managed metadata stripped (B2) |
| Phase 6 | app-of-apps opt-in; `service_versions` pins restored Applications by name (img./-pps, configVersion, image.tag) (B4) |
| Phase 7 | root `backend_services` wired (B1) |
| Phase 8 | Postgres probe uses `cloudsql_private_ip` |
| Prevalidate | follows both switches |

A single `backup_bucket` remains (no per-component split): everything is staged into one DR-readable bucket instead.

### 3.2 Delete / recreate order

1. User approves delete (after the step-2 configuration exports are saved).
2. Delete cluster: `gcloud container clusters delete dr-icrypto-gke-cluster --region europe-west4` (leaves VPC, subnet, Cloud SQL, Capella untouched).
3. Check the subnet after the delete. GKE normally removes its managed secondary ranges with the cluster.
   If `gke-dr-icrypto-gke-cluster-{pods,services}-c7149c78` survive, set `dr_gke_cluster_secondary_range_name` /
   `dr_gke_services_secondary_range_name` to adopt them (implemented) instead of touching shared networking.
4. `tofu apply -target=module.dr_cluster`, then full apply per README (Phases 0–7), Phase 8 after the DNS change by PPS.

### 3.3 Verification

`prevalidate.sh` clean; `tofu plan` shows no change on Cloud SQL/Capella; cluster describe diff vs. captured YAML limited to
version/IDs; nodes Ready; master reachable only from the authorized nets; Cloud NAT/PGA lets nodes pull images.

## 4. Requested pod: `gcloud-shell` in `default`

**Created only AFTER the rebuild (decided 2026-10-05)** — it is the restore workstation for Consul, Postgres, LDAP, Couchbase etc.
Purpose: an in-cluster `gcloud`/`gsutil` toolbox authenticated as `icryptogkedr@…` from
`/home/kusha/dr-pps-qa-29102018-b2fbba3d0f9e.json`.

```bash
# on the DR bastion, with the key file already there — secret is created from the file, never echoed
kubectl -n default create secret generic dr-gcloud-sa \
  --from-file=key.json=/home/kusha/dr-pps-qa-29102018-b2fbba3d0f9e.json
```

```yaml
apiVersion: v1
kind: Pod
metadata: {name: gcloud-shell, namespace: default}
spec:
  restartPolicy: Never
  containers:
  - name: gcloud
    image: gcr.io/google.com/cloudsdktool/google-cloud-cli:stable   # reachable via Private Google Access
    command: ["/bin/sh","-c","gcloud auth activate-service-account --key-file=/var/secrets/gcp/key.json && gcloud config set project pps-qa-29102018 && sleep infinity"]
    volumeMounts: [{name: sa, mountPath: /var/secrets/gcp, readOnly: true}]
  volumes: [{name: sa, secret: {secretName: dr-gcloud-sa}}]
```

Notes: 4.1 not created on the old cluster; it is built on the new one. The IaC's own restores do not depend on it: Postgres
(`psql_restore.sh`) and Couchbase `cbimport` (`cbimport_restore.sh`) run as their own Jobs in the platform namespace with the same SA
key (Secret `dr-restore-gcp-key`); LDAP/Consul run via `kubectl exec` from the bastion. The pod is the operator's ad-hoc toolbox. 4.2 the Secret holds a full-permission SA key; delete pod + secret
when finished. 4.3 For prod bucket access add a second secret/key only if the user supplies the prod SA key file path
(the prod SA is configured on the bastion, not in the pod); otherwise keep prod reads on the bastion.

## 4b. Postgres restore — two supported paths (decided 2026-10-05)

The `sqladmin.googleapis.com` egress block from the bastion is not confirmed fixed and the Cloud SQL instance name is unknown, so the IaC supports both:

| Path | How | Needs |
|---|---|---|
| A. `gcloud sql import sql` | `cloudsql_restore.sh` (existing); Cloud SQL pulls the object from GCS | sqladmin egress, `roles/cloudsql.editor`, service agent `objectViewer` on the prod bucket |
| B. `psql` from a pod | pod in the new cluster streams the dump: `gcloud storage cat gs://…/midpoint-20260911.sql \| psql -h 10.221.111.2 -U postgres midpoint` (private IP reachable from the `pps-dr` VPC; no sqladmin API) | image with `psql` + gcloud, DB password from Vault `secret/idm/db-passwd`, no local disk (stream) |

Implemented as a tfvars switch, `postgres_restore_method = "psql_pod" | "gcloud_sql_import"`:
- **Default `psql_pod`.** `gcloud_sql_import` stays **disabled until the sqladmin networking issue is fixed** (decided 2026-10-05) — a variable `validation` should reject it unless an explicit opt-in (e.g. `allow_gcloud_sql_import = true`) is also set, so it can't be picked by accident.
- The switch selects which `null_resource`/Job runs in `modules/30-data-restore`; Phase 0 preflight skips the `google_sql_database_instance` data source (and the sqladmin reachability check) when `psql_pod` is chosen, so `cloudsql_instance_name` is not required on that path. Only the Cloud SQL private IP/host is. Path B runs as a Kubernetes Job so it survives a dropped SSH session (252 GB, many hours); run with `ON_ERROR_STOP` off only after reviewing, wrap in a single `--single-transaction` only if the dump is transaction-safe. Verify with table/row counts versus prod.

## 5. Backup access — prod SA, no staging (decided 2026-10-05)

Backups are read **directly from the prod bucket with the prod SA**; nothing is copied to a DR bucket.
Set `backup_credentials_file = "/home/kusha/pps-analytics-189714-a98e472928e5.json"` (prod SA key on the bastion,
`client_email` = `icryptogke-prod@pps-analytics-189714.iam.gserviceaccount.com`). It drives:

- Terraform backup-object reads (`google.backups` provider alias, Phases 0/3/4);
- bastion downloads (Consul, LDAP, cbbackupmgr, index file, Argo CD) via `CLOUDSDK_AUTH_CREDENTIAL_FILE_OVERRIDE`;
- the in-cluster restore Jobs (Secret `dr-backup-reader-key` in the platform namespace) — big objects are streamed /
  downloaded inside the cluster, not on the bastion.

The current cluster already has the same key as Secret `gcloud-prod-sa-key` in `default` (pods `gcloud-prod`, `pg-backup-job`);
that Secret disappears with the cluster, so the IaC rebuilds it from the bastion file.

Backup set: **`gs://pps-k8s-prod-backups/5thoctober2026/`** (supersedes `11thseptember2026/`; re-checked 2026-10-05 18:15 UTC):

| Object | Size | Restore |
|---|---|---|
| `postgresql/midpoint-20260911.sql` | 270 GB plain SQL | `psql_pod` stream |
| `postgresql/globals-roles-20261005.sql` | 3 KB | `postgres_globals_object`, loaded first |
| `couchbase/dr-capella-cbbackupmgr-20261005.tar.gz` | 227 MB (903 MB unpacked) | `cbbackupmgr` for **both** buckets: full archive `cb_archive/`, repo `dr-capella`, buckets `icrypto_persistent_ha` + `oidcv2`, log "Backup completed successfully", made with cbbackupmgr **7.6.4** = bastion version |
| `consul/consul-kv-export-20261005.json` | 16.6 MB | `consul kv import` (no snapshot in the set) |
| `ldap/ldap-{config,secauth,data}-backup.ldif` | 0.5 / 110 / 104 MB | LDAP restore (config first) |
| `argocd/argocd-backup-dr-20261005.tar.gz` | 21 KB | Phase 4: `applications.yaml`, `appprojects.yaml`, `configmaps.yaml`, `argocd-secret.yaml`, `secrets-repository.yaml`; Applications are ECR Helm OCI charts, destination `https://kubernetes.default.svc` |
| `argocd/az2/`, `argocd/az3/` `argocd-backup-prod-2026-06-15.tar.gz` | — | older prod exports, not used |

Original notes (bastion, prod SA):

```bash
export CLOUDSDK_CORE_ACCOUNT=icryptogke-prod@pps-analytics-189714.iam.gserviceaccount.com
gcloud storage ls -l gs://pps-k8s-prod-backups/11thseptember2026/        # already verified readable
```

Do **not** pull the 252 GB SQL to the bastion disk (check `df` first). Preferred: Cloud SQL imports straight from the prod bucket
(grant the Cloud SQL service agent `roles/storage.objectViewer` on `gs://pps-k8s-prod-backups`, which needs the prod project's IAM —
PPS action, or copy bucket→bucket into a DR-project bucket using the prod SA, cross-project). Couchbase/LDAP files (≈1.5 GB / 215 MB) can be
downloaded to the bastion for `cbimport` / `slapadd`.

## 6. Open questions for the user

- ~~Q1~~ ANSWERED: nothing in the current cluster is newer than the backups; keep GKE config + networking as a backup only. Delete timing still needs an explicit go.
- Q2 Consul + Argo CD sources (absent from the prod folder): **user will supply the GCS location on 2026-10-06.** Blocks `consul_backup_object` / `argocd_backup_object` in tfvars only; nothing else waits on it.
- ~~Q3~~ ANSWERED: support both `gcloud sql import` and `psql` from a pod (see 4b). Instance name/project still needed for path A and for the `psql` host check.
- Q4 Keep cluster single-zone (`europe-west4-a`) for fidelity, or go multi-zone?
- Q5 Keep narrow node OAuth scopes (live) or `cloud-platform` (module)?
- Q6 Is a prod-SA key file available for in-cluster use, or bastion-only?
- Q7 Purpose of `icrypto_persistent_ha.tar.gz` (2026-09-14)?
- ~~Q8~~ ANSWERED: after the rebuild only.

## 7. Draft `pps-dr.tfvars` (to create on the bastion; git-ignored)

```hcl
project_id           = "pps-qa-29102018"
dr_region            = "europe-west4"
gcp_credentials_file    = "/home/kusha/dr-pps-qa-29102018-b2fbba3d0f9e.json"
backup_credentials_file = "/home/kusha/pps-analytics-189714-a98e472928e5.json"   # prod SA, reads the backups

create_gke_cluster     = true
dr_gke_name            = "dr-icrypto-gke-cluster"
dr_gke_location        = "europe-west4"
dr_gke_node_locations  = ["europe-west4-a"]
dr_gke_machine_type    = "n2-custom-8-43008"
dr_gke_disk_size_gb    = 100
dr_gke_disk_type       = "pd-balanced"
dr_gke_image_type      = "COS_CONTAINERD"
dr_gke_node_sa_account = "736738276060-compute@developer.gserviceaccount.com"
dr_gke_network_link    = "projects/pps-qa-29102018/global/networks/pps-dr"
dr_gke_subnetwork_link = "projects/pps-qa-29102018/regions/europe-west4/subnetworks/pps-dr"
dr_gke_cluster_ipv4_cidr_block  = "10.108.0.0/14"
dr_gke_services_ipv4_cidr_block = "10.112.0.0/20"
dr_gke_master_ipv4_cidr_block   = "10.200.24.0/28"
dr_gke_master_authorized_networks = [
  { cidr_block = "34.91.152.93/32",  display_name = "jumpbox" },
  { cidr_block = "10.200.16.56/32",  display_name = "Jumpbox01" },
  { cidr_block = "10.112.200.0/24",  display_name = ""  },
  { cidr_block = "10.200.100.77/32", display_name = "stage-bastion" },
]
dr_gke_node_pool_name = "icrypto-dr-nodepool"
dr_gke_node_count     = 3
dr_gke_release_channel = "REGULAR"

dr_gke_datapath_provider            = "LEGACY_DATAPATH"
dr_gke_resource_labels              = { application = "sso", owner = "devops_team_sso" }
dr_gke_oauth_scopes = [
  "https://www.googleapis.com/auth/devstorage.read_only",
  "https://www.googleapis.com/auth/logging.write",
  "https://www.googleapis.com/auth/monitoring",
  "https://www.googleapis.com/auth/service.management.readonly",
  "https://www.googleapis.com/auth/servicecontrol",
  "https://www.googleapis.com/auth/trace.append",
]
dr_gke_workload_metadata_mode       = "GKE_METADATA"
dr_gke_logging_components           = ["SYSTEM_COMPONENTS", "WORKLOADS"]
dr_gke_managed_prometheus           = true
dr_gke_private_endpoint_enforcement = true

backup_bucket           = "pps-k8s-prod-backups"
backup_prefix           = "5thoctober2026"     # the only value to change for a new backup set
postgres_backup_object  = "postgresql/midpoint-20260911.sql"
postgres_globals_object = "postgresql/globals-roles-20261005.sql"
ldap_backup_objects = [
  "ldap/ldap-config-backup.ldif",
  "ldap/ldap-secauth-backup.ldif",
  "ldap/ldap-data-backup.ldif",
]
consul_backup_object  = "consul/consul-kv-export-20261005.json"
argocd_backup_object  = "argocd/argocd-backup-dr-20261005.tar.gz"
vault_backup_object   = ""            # Vault data lives in Consul
vault_restore_enabled = false

postgres_restore_method = "psql_pod"
allow_gcloud_sql_import = false
cloudsql_private_ip     = "10.221.111.2"
cloudsql_database_name  = "midpoint"
cloudsql_import_user    = "postgres"
postgres_recreate_database = true     # DR midpoint already holds older data; deliberate

capella_connection_string = "couchbases://cb.0ft6www2iz3ow6ka.cloud.couchbase.com"
couchbase_username        = "icryptodracc"
capella_buckets           = ["oidcv2", "icrypto_persistent_ha"]
couchbase_restore_methods = {
  oidcv2                = "cbbackupmgr"
  icrypto_persistent_ha = "cbbackupmgr"
}
couchbase_backup_objects = {
  oidcv2                = "couchbase/dr-capella-cbbackupmgr-20261005.tar.gz"
  icrypto_persistent_ha = "couchbase/dr-capella-cbbackupmgr-20261005.tar.gz"
}
couchbase_index_definitions_object = ""   # the cbbackupmgr archive carries GSI definitions

ldap_base_dn        = "dc=ppspar,dc=PPSDMN"
ldap_restore_config = true            # TF_VAR_ldap_admin_password = PROD admin password
```

Sensitive values as `TF_VAR_*` only. `capella_*_id` / org can stay dummy (provider unused, no `capella_api` bucket).

**Naming for future backup sets** (so nothing but `backup_prefix` changes): keep the date only in the folder and use
stable file names — `postgresql/midpoint.sql`, `postgresql/globals.sql`, `couchbase/cb-archive.tar.gz`,
`consul/consul-kv-export.json`, `ldap/ldap-{config,secauth,data}-backup.ldif`, `argocd/argocd-backup.tar.gz`.
The current set keeps its dated names, so the object paths above match it exactly.

## 8. Known risks still open

- **Platform charts differ from the old DR cluster.** Old cluster (`helm ls -A`): `consul` chart 0.41.1 (Consul 1.11.3) and
  `vault` chart 0.16.1 (Vault 1.8.5) in `persistent`; LDAP as release `ldap`, chart `openldap-0.1.1` (custom, app 2.4.57) in
  `ldap-v2`. Phase 2 installs consul 1.5.1 / vault 0.28.1 / openldap-stack-ha 4.2.5 (Bitnami OpenLDAP 2.6). Consul KV import and
  Vault-on-Consul data generally upgrade forward, but restoring the prod `cn=config` LDIF from a 2.4.x server into the 2.6 image
  can fail (module paths, backend directives). Decide before Phase B: reuse the PPS LDAP chart in `ldap-v2`, or restore data DBs
  only into a config built for 2.6.

- **LDAP / platform naming.** Phase 2 deploys OpenLDAP as release `openldap` in `platform_namespace`; prod (and the old DR
  cluster) run `ldap-openldap` in `ldap-v2`. The restored prod `cn=config` may carry replication (`olcSyncrepl`) pointing at prod
  pod names — fine at 1 replica, needs review before scaling to 2. Apps also expect services by the prod names/namespaces;
  Phase 2 naming vs. the Argo CD Applications' expectations must be reconciled when the Argo CD backup arrives (Q2).
- **Release sync hold** turns on automated sync (prune + selfHeal) for restored apps; PPS runs them Manual. Review before Phase 6.
- **Stale Couchbase docs**: `cbbackupmgr --force-updates` / `cbimport` upsert; DR-only docs remain unless the bucket is flushed (manual decision).
- **Capella from pods**: the `cbimport` Job connects from pod IPs (10.108.0.0/14) over the Capella peering; confirm the Capella
  allow-list covers pod ranges (existing DR apps suggest it does).

## 9. Pre-Phase-B prep — done 2026-10-05 (evening)

On the DR bastion (`kusha@34.91.152.93`):

| Item | Where | Notes |
|---|---|---|
| Repo copy | `~/pps-dr-iaac` (commit in `.deployed-commit`) | `scp` from local branch `feat/dr-rebuild-prod-restore` (not pushed) |
| `pps-dr.tfvars` | `~/pps-dr-iaac/pps-dr.tfvars` (600) | only `oidc_validation_client_id` still `REPLACE_ME` (Phase 8) |
| Sensitive inputs | `~/pps-dr-secrets/tfvars.env` (600) — `set -a; source …; set +a` | from the old cluster: ECR (`aws-ecr-credential-ns/aws-ecr-credential-secret`, IAM `gitlab-docker`; the `aws-secret` pair is IAM `argocd`, no ECR rights), Cloud SQL (Vault `secret/idm/db-passwd`), Capella `cb_pass`, Vault root token, LDAP admin (PPS chart values), Argo CD admin bcrypt |
| TLS | `~/pps-dr-secrets/pps-tls.{crt,key}` (600) | from `default/pps-secret-2025`, `*.pps.co.za`, **expires 2026-11-15** |
| LDAP chart + values | `~/pps-dr-secrets/ldap-chart/`, `ldap-values.json` | extracted from release `ldap` (chart `openldap` 0.1.1, image `pps-ldap:1.0.0.52`, slapd 2.6.7); contain passwords |
| Ingresses | `env/pps-dr/ingresses.yaml` (in git) | 3 hand-made ingresses: `nginx-api-gw-external` (gce), `nginx-api-gw-internal` (gce-internal, 10.200.16.101), `ingress-resource-opa-internal` (10.200.16.102, port 8181) |

Decisions: LDAP = option A (`openldap_deployment = "pps_chart"`, release `ldap` in `ldap-v2`, data-only restore).

### Open for tomorrow (before Phase B)

1. ~~External ingress IP 34.120.124.233~~ — **decided 2026-10-06: accept the DNS cycle; do not reserve.** PPS makes the DNS change post-rebuild per Phase 7 `dns_change_request`.
2. **Vault after the Consul restore** holds *prod* Vault data (Vault 1.8.5 on Consul storage on both sides) → it unseals with the
   **prod** unseal keys and the prod root token. `TF_VAR_vault_root_token` is the old DR token; get the prod keys/token.
3. **Platform chart versions**: old DR runs consul chart 0.41.1 / vault chart 0.16.1 (Vault 1.8.5); repo installs 1.5.1 / 0.28.1.
   Decide whether to pin to the old versions for fidelity.
4. **Old DR extras not in the IaC**: Argo CD internal LB `argocd-server-int` (10.200.16.66), `lsc`/`logback` ConfigMaps in `ldap-v2`.
5. Bastion `psql` is too old for SCRAM (libpq < 10): Cloud SQL login could not be tested from the bastion, and Phase 8's psql
   probe will fail there → install a newer client or move that probe in-cluster. `cbc` also missing (Phase 8).
6. `oidc_validation_client_id` / `TF_VAR_oidc_validation_client_secret` for Phase 8.
7. A user-run pod `pg-backup-job` (default ns) had its upload of `midpoint-20261005.sql.gz` killed; the set uses `midpoint-20260911.sql`.


## Resources the source environments apply out of band

A DR site built only from the backups comes up incomplete, because several
resources exist in no Argo CD Application and in no backup object. They were
recovered by sweeping the source cluster for resources carrying no
`argocd.argoproj.io/tracking-id`, and are now created by the IaC:

| Resource | Created by |
| --- | --- |
| Vault AppRole `role_id`/`secret_id` Secret pairs | Phase 5 `app_credentials` |
| `consul-secret`, `aws-secret` | Phase 5 `app_credentials` |
| 7 verbatim authn ConfigMaps (patches, scripts, log templates) | Phase 5b `app_config` |
| `cn` ConfigMap, `jans-couchbase`, `icrypto-global-config` | Phase 5b `app_config` (templated) |
| `cn` Secret | Phase 5b `app_config`, seeded from `app_config_secret_dir` |
| `pps-health-deployment` + `pps-health-service` | Phase 6 `supporting_workloads` |
| `notification-service-lb` | Phase 6 `supporting_workloads` |

Deliberately **not** created, with the reason:

| Resource | Why not |
| --- | --- |
| `pps-pub`, `pps-sub` | `replicas: 0` in the source environment |
| `postgres` (in `default`) | a utility database; midPoint uses Cloud SQL |
| `idm-audit-partition-manager` | applied upstream from the idm-audit-db-partition repo |
| `vault-<service>` (combined role_id+secret_id) | the split `-ext-role`/`-ext-secret` form is what the charts mount; nothing references these |
| `vault-root-token` per namespace | no workload references it |
| `gcp-service-account`, `postgres-secret`, `pub-sub-gcp` | only consumed by the workloads above |
| `dynatrace-bootstrapper-*` | observability agent, not required to serve traffic |

Two values are environment-specific and nothing else is: the Capella endpoint
in `jans-couchbase`, and `couchbase_password` / `couchbase_superuser_password`
inside `cn` and `oidcv2-cb-pass`. In particular the `cn` crypto keys must stay
the source site's, because Jans encrypted the restored Couchbase bucket with
them, and `oidc_hostname` stays the production name because the DR site serves
it after the cutover.
