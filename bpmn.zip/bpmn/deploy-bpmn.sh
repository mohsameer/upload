#!/usr/bin/env bash

ADDRESS="bpmn-broker-1:26500"

for f in *.bpmn
do
	echo "./zbctl --insecure  --address $ADDRESS deploy $f"
	./zbctl --insecure  --address $ADDRESS deploy $f
done